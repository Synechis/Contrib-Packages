<?php

namespace Drupal\dynamic_entity_reference_entity_test\Hook;

use Drupal\Core\Entity\EntityTypeInterface;
use Drupal\Core\Field\BaseFieldDefinition;
use Drupal\Core\State\StateInterface;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\Core\Hook\Attribute\Hook;

/**
 * Hook implementations for dynamic_entity_reference_entity_test.
 */
final class DynamicEntityReferenceEntityTestHooks {

  public function __construct(
    private readonly StateInterface $state,
  ) {
  }

  /**
   * Implements hook_entity_base_field_info().
   */
  #[Hook('entity_base_field_info')]
  public function entityBaseFieldInfo(EntityTypeInterface $entity_type) {
    $fields = [];
    // 'entity_test' with no data table and 'entity_test_mul' is with data
    // table.
    $test_entities = $this->state->get('dynamic_entity_reference_entity_test_entities', [
      'entity_test',
      'entity_test_mul',
    ]);
    $excluded_entity = $this->state->get('dynamic_entity_reference_entity_test_exclude', []);
    if (in_array($entity_type->id(), $test_entities)) {
      $allowed_entities = array_diff($test_entities, $excluded_entity);
      $settings = [
        'exclude_entity_types' => FALSE,
        'entity_type_ids' => array_combine($allowed_entities, $allowed_entities),
      ];
      foreach ($test_entities as $entity_type_id) {
        if (!in_array($entity_type_id, $excluded_entity)) {
          $settings += [
            $entity_type_id => [
              'handler' => "default:{$entity_type_id}",
              'handler_settings' => [
                'target_bundles' => NULL,
              ],
            ],
          ];
        }
      }
      $fields['dynamic_references'] = BaseFieldDefinition::create('dynamic_entity_reference')->setName('dynamic_references')->setLabel((string) new TranslatableMarkup('References'))->setDescription((string) new TranslatableMarkup('Reference another entity.'))->setRequired(FALSE)->setRevisionable($this->state->get('dynamic_entity_reference_entity_test_revisionable', FALSE))->setCardinality($this->state->get('dynamic_entity_reference_entity_test_cardinality', 1))->setDisplayOptions('form', [
        'type' => 'dynamic_entity_reference_default',
        'weight' => 10,
      ])->setDisplayOptions('view', [
        'label' => 'above',
        'type' => 'dynamic_entity_reference_label',
        'weight' => 10,
      ])->setDisplayConfigurable('form', TRUE)->setDisplayConfigurable('view', TRUE)->setSettings($settings);
      if ($this->state->get('dynamic_entity_reference_entity_test_with_two_base_fields', FALSE)) {
        $fields['der'] = BaseFieldDefinition::createFromFieldStorageDefinition($fields['dynamic_references'])->setName('der');
      }
    }
    return $fields;
  }

  /**
   * Implements hook_views_data().
   */
  #[Hook('views_data')]
  public function viewsData() {
    // @todo Currently views integration for multivalue basefields is broken
    //   this function adds a temporary fix for that remove this when is fixed
    //   https://www.drupal.org/node/2477899.
    $data = [];
    if ($this->state->get('dynamic_entity_reference_entity_test_cardinality', 1) != 1) {
      $data['entity_test__dynamic_references'] = [
        'table' => [
          'join' => [
            'entity_test' => [
              'left_field' => 'id',
              'field' => 'entity_id',
            ],
          ],
        ],
        'dynamic_references' => [
          'group' => "Test entity",
          'title' => "Test references",
          'title short' => "Test references",
          'help' => "Appears in: entity_test.",
          'field' => [
            'table' => "entity_test__dynamic_references",
            'id' => "field",
            'field_name' => "dynamic_references",
            'entity_type' => "entity_test",
            'real field' => "dynamic_references_type_id",
            'additional fields' => [
              "delta",
              "langcode",
              "bundle",
              "dynamic_references_target_id",
              "dynamic_references_target_type",
            ],
            'element type' => "div",
            'is revision' => FALSE,
            'click sortable' => TRUE,
          ],
        ],
        'dynamic_references_target_id' => [
          'group' => "Test entity",
          'title' => "Test references (dynamic_references)",
          'title short' => "Test references",
          'help' => "Appears in: entity_test.",
          'argument' => [
            'field' => "dynamic_references_target_id",
            'table' => "entity_test__dynamic_references",
            'id' => "numeric",
            'additional fields' => [],
            'field_name' => "dynamic_references",
            'entity_type' => "entity_test",
            'empty field name' => "- No value -",
          ],
          'filter' => [
            'field' => "dynamic_references_target_id",
            'table' => "entity_test__dynamic_references",
            'id' => "numeric",
            'additional fields' => [],
            'field_name' => "dynamic_references",
            'entity_type' => "entity_test",
            'allow empty' => TRUE,
          ],
          'sort' => [
            'field' => "dynamic_references_target_id",
            'table' => "entity_test__dynamic_references",
            'id' => "standard",
            'additional fields' => [],
            'field_name' => "dynamic_references",
            'entity_type' => "entity_test",
          ],
        ],
        'dynamic_references_target_type' => [
          'group' => "Test entity",
          'title' => "Test references (dynamic_references:target_type)",
          'title short' => "Test references:target_type",
          'help' => "Appears in: entity_test.",
          'argument' => [
            'field' => "dynamic_references_target_type",
            'table' => "entity_test__dynamic_references",
            'id' => "string",
            'additional fields' => [],
            'field_name' => "dynamic_references",
            'entity_type' => "entity_test",
            'empty field name' => "- No value -",
          ],
          'filter' => [
            'field' => "dynamic_references_target_type",
            'table' => "entity_test__dynamic_references",
            'id' => "string",
            'additional fields' => [],
            'field_name' => "dynamic_references",
            'entity_type' => "entity_test",
            'allow empty' => TRUE,
          ],
          'sort' => [
            'field' => "dynamic_references_target_type",
            'table' => "entity_test__dynamic_references",
            'id' => "standard",
            'additional fields' => [],
            'field_name' => "dynamic_references",
            'entity_type' => "entity_test",
          ],
        ],
      ];
      $data['entity_test_mul__dynamic_references'] = [
        'table' => [
          'join' => [
            'entity_test_mul_property_data' => [
              'left_field' => 'id',
              'field' => 'entity_id',
              'extra' => [
                            [
                              'left_field' => 'langcode',
                              'field' => 'langcode',
                            ],
              ],
            ],
          ],
        ],
        'dynamic_references' => [
          'group' => "Test entity - data table",
          'title' => "Test references",
          'title short' => "Test references",
          'help' => "Appears in: entity_test_mul.",
          'field' => [
            'table' => "entity_test__dynamic_references",
            'id' => "field",
            'field_name' => "dynamic_references",
            'entity_type' => "entity_test_mul",
            'real field' => "dynamic_references_type_id",
            'additional fields' => [
              "delta",
              "langcode",
              "bundle",
              "dynamic_references_target_id",
              "dynamic_references_target_type",
            ],
            'element type' => "div",
            'is revision' => FALSE,
            'click sortable' => TRUE,
          ],
        ],
        'dynamic_references_target_id' => [
          'group' => "Test entity - data table",
          'title' => "Test references (dynamic_references)",
          'title short' => "Test references",
          'help' => "Appears in: entity_test_mul.",
          'argument' => [
            'field' => "dynamic_references_target_id",
            'table' => "entity_test_mul__dynamic_references",
            'id' => "numeric",
            'additional fields' => [],
            'field_name' => "dynamic_references",
            'entity_type' => "entity_test_mul",
            'empty field name' => "- No value -",
          ],
          'filter' => [
            'field' => "dynamic_references_target_id",
            'table' => "entity_test_mul__dynamic_references",
            'id' => "numeric",
            'additional fields' => [],
            'field_name' => "dynamic_references",
            'entity_type' => "entity_test_mul",
            'allow empty' => TRUE,
          ],
          'sort' => [
            'field' => "dynamic_references_target_id",
            'table' => "entity_test_mul__dynamic_references",
            'id' => "standard",
            'additional fields' => [],
            'field_name' => "dynamic_references",
            'entity_type' => "entity_test_mul",
          ],
        ],
        'dynamic_references_target_type' => [
          'group' => "Test entity - data table",
          'title' => "Test references (dynamic_references:target_type)",
          'title short' => "Test references:target_type",
          'help' => "Appears in: entity_test_mul.",
          'argument' => [
            'field' => "dynamic_references_target_type",
            'table' => "entity_test_mul__dynamic_references",
            'id' => "string",
            'additional fields' => [],
            'field_name' => "dynamic_references",
            'entity_type' => "entity_test_mul",
            'empty field name' => "- No value -",
          ],
          'filter' => [
            'field' => "dynamic_references_target_type",
            'table' => "entity_test_mul__dynamic_references",
            'id' => "string",
            'additional fields' => [],
            'field_name' => "dynamic_references",
            'entity_type' => "entity_test_mul",
            'allow empty' => TRUE,
          ],
          'sort' => [
            'field' => "dynamic_references_target_type",
            'table' => "entity_test_mul__dynamic_references",
            'id' => "standard",
            'additional fields' => [],
            'field_name' => "dynamic_references",
            'entity_type' => "entity_test_mul",
          ],
        ],
      ];
    }
    return $data;
  }

}
