<?php

namespace Drupal\Tests\better_exposed_filters\Kernel;

use Drupal\views\Views;

/**
 * Tests the radio buttons/checkboxes filter widget (i.e. "bef").
 *
 * @group better_exposed_filters
 *
 * @see \Drupal\better_exposed_filters\Plugin\better_exposed_filters\filter\RadioButtons
 */
class BetterExposedFiltersKernelTest extends BetterExposedFiltersKernelTestBase {

  /**
   * {@inheritdoc}
   */
  public static $testViews = ['bef_test'];

  /**
   * Tests hiding the submit button when auto-submit is enabled.
   *
   * Checks the submit button is hidden both when the exposed form has a
   * reset button (the actions element has more than one child) and when it
   * does not (the actions element contains only the submit button).
   *
   * @throws \Drupal\Core\Entity\EntityStorageException
   */
  public function testHideSubmitButtonOnAutoSubmit() {
    $view = Views::getView('bef_test');

    // Enable auto-submit and hide auto-submit button.
    $this->setBetterExposedOptions($view, [
      'general' => [
        'autosubmit' => TRUE,
        'autosubmit_hide' => TRUE,
      ],
    ]);

    // Render the exposed form.
    $this->renderExposedForm($view);

    // Check our "submit" button is hidden.
    $actual = $this->xpath("//form//input[@type='submit'][contains(concat(' ',normalize-space(@class),' '),' js-hide ')]");
    $this->assertCount(1, $actual);

    $view->destroy();

    // Repeat with the reset button disabled, so the actions element holds
    // only the submit button.
    $view = Views::getView('bef_test');
    $display = &$view->storage->getDisplay('default');
    $display['display_options']['exposed_form']['options']['reset_button'] = FALSE;
    $this->setBetterExposedOptions($view, [
      'general' => [
        'autosubmit' => TRUE,
        'autosubmit_hide' => TRUE,
      ],
    ]);

    // Render the exposed form.
    $this->renderExposedForm($view);

    // Check our "submit" button is hidden.
    $actual = $this->xpath("//form//input[@type='submit'][contains(concat(' ',normalize-space(@class),' '),' js-hide ')]");
    $this->assertCount(1, $actual);
  }

  /**
   * Tests moving sorts, filters and pager options into secondary fieldset.
   *
   * @throws \Drupal\Core\Entity\EntityStorageException
   */
  public function testSecondaryOptions() {
    $view = Views::getView('bef_test');

    // Enable secondary options and set label.
    $this->setBetterExposedOptions($view, [
      'general' => [
        'allow_secondary' => TRUE,
        'secondary_label' => 'Secondary Options TEST',
      ],
    ]);

    // Render the exposed form.
    $this->renderExposedForm($view);

    // Assert our "secondary" options detail is hidden if no fields are placed.
    $actual = $this->xpath("//form//details[@data-drupal-selector='edit-secondary']");
    $this->assertCount(0, $actual);

    $view->destroy();

    // Move sort, pager and "field_bef_boolean" into secondary options.
    $view = Views::getView('bef_test');

    $this->setBetterExposedOptions($view, [
      'general' => [
        'allow_secondary' => TRUE,
        'secondary_label' => 'Secondary Options TEST',
      ],
      'sort' => [
        'plugin_id' => 'default',
        'advanced' => [
          'is_secondary' => TRUE,
        ],
      ],
      'pager' => [
        'plugin_id' => 'default',
        'advanced' => [
          'is_secondary' => TRUE,
        ],
      ],
      'filter' => [
        'field_bef_boolean_value' => [
          'plugin_id' => 'default',
          'advanced' => [
            'is_secondary' => TRUE,
          ],
        ],
      ],
    ]);

    // Render the exposed form.
    $this->renderExposedForm($view);

    // Assert our "secondary" options detail is visible.
    $actual = $this->xpath("//form//details[@data-drupal-selector='edit-secondary']");
    $this->assertCount(1, $actual);

    // Assert sort option was placed in secondary details.
    $actual = $this->xpath("//form//details[@data-drupal-selector='edit-secondary']//select[@name='sort_by']");
    $this->assertCount(1, $actual);

    // Assert a pager option was placed in secondary details.
    $actual = $this->xpath("//form//details[@data-drupal-selector='edit-secondary']//select[@name='items_per_page']");
    $this->assertCount(1, $actual);

    // Assert filter option was placed in secondary details.
    $actual = $this->xpath("//form//details[@data-drupal-selector='edit-secondary']//select[@name='field_bef_boolean_value']");
    $this->assertCount(1, $actual);

    $view->destroy();
  }

}
