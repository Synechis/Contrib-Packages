<?php

namespace Drupal\Tests\pathauto\Kernel;

use Drupal\Component\Render\FormattableMarkup;
use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Form\FormState;
use Drupal\Core\Url;
use Drupal\Component\Utility\Html;
use Drupal\Core\Language\Language;
use Drupal\Core\Language\LanguageInterface;
use Drupal\field\Entity\FieldConfig;
use Drupal\field\Entity\FieldStorageConfig;
use Drupal\KernelTests\KernelTestBase;
use Drupal\language\Entity\ConfigurableLanguage;
use Drupal\node\Entity\Node;
use Drupal\node\Entity\NodeType;
use Drupal\pathauto\Entity\PathautoPattern;
use Drupal\pathauto\PathautoGeneratorInterface;
use Drupal\pathauto\PathautoState;
use Drupal\taxonomy\Entity\Term;
use Drupal\taxonomy\Entity\Vocabulary;
use Drupal\Tests\pathauto\Functional\PathautoTestHelperTrait;
use Drupal\user\Entity\User;
use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;

/**
 * Unit tests for Pathauto functions.
 *
 * @group pathauto
 */
#[Group('pathauto')]
#[RunTestsInSeparateProcesses]
class PathautoKernelTest extends KernelTestBase {

  use PathautoTestHelperTrait;

  /**
   * Modules.
   *
   * @var string[]
   */
  protected static $modules = [
    'system',
    'field',
    'text',
    'user',
    'node',
    'path',
    'path_alias',
    'pathauto',
    'pathauto_custom_punctuation_test',
    'taxonomy',
    'token',
    'filter',
    'language',
  ];

  /**
   * The current user.
   *
   * @var \Drupal\user\Entity\UserInterface
   */
  protected $currentUser;

  /**
   * Node pattern.
   *
   * @var \Drupal\pathauto\PathautoPatternInterface
   */
  protected $nodePattern;

  /**
   * User pattern.
   *
   * @var \Drupal\pathauto\PathautoPatternInterface
   */
  protected $userPattern;

  /**
   * {@inheritdoc}
   */
  public function setUp(): void {
    parent::setup();

    $this->installEntitySchema('user');
    $this->installEntitySchema('node');
    $this->installEntitySchema('taxonomy_term');
    if ($this->container->get('entity_type.manager')->hasDefinition('path_alias')) {
      $this->installEntitySchema('path_alias');
    }
    $this->installConfig([
      'pathauto',
      'taxonomy',
      'system',
      'node',
    ]);

    ConfigurableLanguage::createFromLangcode('fr')->save();

    $this->installSchema('node', ['node_access']);

    $type = NodeType::create(['type' => 'page']);
    $type->save();

    $this->nodePattern = $this->createPattern('node', '/content/[node:title]');
    $this->userPattern = $this->createPattern('user', '/users/[user:name]');

    \Drupal::service('router.builder')->rebuild();

    $this->currentUser = User::create(['name' => $this->randomMachineName()]);
    $this->currentUser->save();
  }

  /**
   * Test _pathauto_get_schema_alias_maxlength().
   */
  public function testGetSchemaAliasMaxLength() {
    $this->assertSame(\Drupal::service('pathauto.alias_storage_helper')->getAliasSchemaMaxlength(), 255);
  }

  /**
   * Test pathauto_pattern_load_by_entity().
   */
  public function testPatternLoadByEntity() {
    $pattern = $this->createPattern('node', '/article/[node:title]', -1);
    $this->addBundleCondition($pattern, 'node', 'article');
    $pattern->save();

    $pattern = $this->createPattern('node', '/article/en/[node:title]', -2);
    $this->addBundleCondition($pattern, 'node', 'article');
    $pattern->addSelectionCondition(
      [
        'id' => 'language',
        'langcodes' => [
          'en' => 'en',
        ],
        'negate' => FALSE,
        'context_mapping' => [
          'language' => 'node:langcode:language',
        ],
      ]
    );

    $pattern->addRelationship('node:langcode:language');
    $pattern->save();

    $pattern = $this->createPattern('node', '/[node:title]', -1);
    $this->addBundleCondition($pattern, 'node', 'page');
    $pattern->save();

    $tests = [
      [
        'entity' => 'node',
        'values' => [
          'title' => 'Article fr',
          'type' => 'article',
          'langcode' => 'fr',
        ],
        'expected' => '/article/[node:title]',
      ],
      [
        'entity' => 'node',
        'values' => [
          'title' => 'Article en',
          'type' => 'article',
          'langcode' => 'en',
        ],
        'expected' => '/article/en/[node:title]',
      ],
      [
        'entity' => 'node',
        'values' => [
          'title' => 'Article und',
          'type' => 'article',
          'langcode' => LanguageInterface::LANGCODE_NOT_SPECIFIED,
        ],
        'expected' => '/article/[node:title]',
      ],
      [
        'entity' => 'node',
        'values' => [
          'title' => 'Page',
          'type' => 'page',
        ],
        'expected' => '/[node:title]',
      ],
      [
        'entity' => 'user',
        'values' => [
          'name' => 'User',
        ],
        'expected' => '/users/[user:name]',
      ],
    ];
    foreach ($tests as $test) {
      $entity = \Drupal::entityTypeManager()->getStorage($test['entity'])->create($test['values']);
      $entity->save();
      $actual = \Drupal::service('pathauto.generator')->getPatternByEntity($entity);
      $this->assertSame($actual->getPattern(), $test['expected'], new FormattableMarkup("Correct pattern returned for @entity_type with @values", [
        '@entity' => $test['entity'],
        '@values' => print_r($test['values'], TRUE),
      ]));
    }
  }

  /**
   * Test potential conflicts with the same alias in different languages.
   */
  public function testSameTitleDifferentLanguages() {
    // Create two English articles with the same title.
    $edit = [
      'title' => 'Sample page',
      'type' => 'page',
      'langcode' => 'en',
    ];
    $node1 = $this->drupalCreateNode($edit);
    $this->assertEntityAlias($node1, '/content/sample-page', 'en');

    $node2 = $this->drupalCreateNode($edit);
    $this->assertEntityAlias($node2, '/content/sample-page-0', 'en');

    // Now, create a French article with the same title, and verify that it gets
    // the basic alias with the correct langcode.
    $edit['langcode'] = 'fr';
    $node3 = $this->drupalCreateNode($edit);
    $this->assertEntityAlias($node3, '/content/sample-page', 'fr');
  }

  /**
   * Test pathauto_cleanstring().
   */
  public function testCleanString() {

    // Test with default settings defined in pathauto.settings.yml.
    $this->installConfig(['pathauto']);

    // Add a custom setting for the copyright symbol defined in
    // pathauto_custom_punctuation_test_pathauto_punctuation_chars_alter().
    $this->config('pathauto.settings')->set('punctuation.copyright', PathautoGeneratorInterface::PUNCTUATION_REMOVE);

    \Drupal::service('pathauto.generator')->resetCaches();

    $tests = [];

    // Test the 'ignored words' removal.
    $tests['this'] = 'this';
    $tests['this with that'] = 'this-with-that';
    $tests['this thing with that thing'] = 'thing-thing';

    // Test 'ignored words' removal and duplicate separator removal.
    $tests[' - Pathauto is the greatest - module ever - '] = 'pathauto-greatest-module-ever';

    // Test length truncation and lowering of strings.
    $long_string = $this->randomMachineName(120);
    $tests[$long_string] = strtolower(substr($long_string, 0, 100));

    // Test that HTML tags are removed.
    $tests['This <span class="text">text</span> has <br /><a href="http://example.com"><strong>HTML tags</strong></a>.'] = 'text-has-html-tags';
    $tests[Html::escape('This <span class="text">text</span> has <br /><a href="http://example.com"><strong>HTML tags</strong></a>.')] = 'text-has-html-tags';

    // Transliteration.
    $tests['ľščťžýáíéňô'] = 'lsctzyaieno';

    // Transliteration of special chars that are converted to punctuation.
    $tests['© “Drupal”'] = 'drupal';

    // Test that unicode soft hyphens (U+00AD) are removed by default.
    $tests["soft\xC2\xADhyphen"] = 'softhyphen';

    foreach ($tests as $input => $expected) {
      $output = \Drupal::service('pathauto.alias_cleaner')->cleanString($input);
      $this->assertEquals($expected, $output, new FormattableMarkup("Drupal::service('pathauto.alias_cleaner')->cleanString('@input') expected '@expected', actual '@output'", [
        '@input' => $input,
        '@expected' => $expected,
        '@output' => $output,
      ]));
    }
  }

  /**
   * Test pathauto_clean_alias().
   */
  public function testCleanAlias() {
    $tests = [];
    $tests['one/two/three'] = '/one/two/three';
    $tests['/one/two/three/'] = '/one/two/three';
    $tests['one//two///three'] = '/one/two/three';
    $tests['one/two--three/-/--/-/--/four---five'] = '/one/two-three/four-five';
    $tests['one/-//three--/four'] = '/one/three/four';

    foreach ($tests as $input => $expected) {
      $output = \Drupal::service('pathauto.alias_cleaner')->cleanAlias($input);
      $this->assertEquals($expected, $output, new FormattableMarkup("Drupal::service('pathauto.generator')->cleanAlias('@input') expected '@expected', actual '@output'", [
        '@input' => $input,
        '@expected' => $expected,
        '@output' => $output,
      ]));
    }
  }

  /**
   * Test pathauto_path_delete_multiple().
   */
  public function testPathDeleteMultiple() {
    $this->createPathAlias('/node/1', '/node-1-alias');
    $this->createPathAlias('/node/1/view', '/node-1-alias/view');
    $this->createPathAlias('/node/1', '/node-1-alias-en', 'en');
    $this->createPathAlias('/node/1', '/node-1-alias-fr', 'fr');
    $this->createPathAlias('/node/2', '/node-2-alias');
    $this->createPathAlias('/node/10', '/node-10-alias');

    \Drupal::service('pathauto.alias_storage_helper')->deleteBySourcePrefix('/node/1');
    $this->assertNoAliasExists(['path' => "/node/1"]);
    $this->assertNoAliasExists(['path' => "/node/1/view"]);
    $this->assertAliasExists(['path' => "/node/2"]);
    $this->assertAliasExists(['path' => "/node/10"]);
  }

  /**
   * Test the different update actions in createEntityAlias().
   *
   * Tests \Drupal::service('pathauto.generator')->createEntityAlias().
   */
  public function testUpdateActions() {
    $config = $this->config('pathauto.settings');

    // Test PATHAUTO_UPDATE_ACTION_NO_NEW with unaliased node and 'insert'.
    $config->set('update_action', PathautoGeneratorInterface::UPDATE_ACTION_NO_NEW);
    $config->save();
    $node = $this->drupalCreateNode(['title' => 'First title']);
    $this->assertEntityAlias($node, '/content/first-title');

    $node->path->pathauto = PathautoState::CREATE;

    // Default action is PATHAUTO_UPDATE_ACTION_DELETE.
    $config->set('update_action', PathautoGeneratorInterface::UPDATE_ACTION_DELETE);
    $config->save();
    $node->setTitle('Second title');
    $node->save();
    $this->assertEntityAlias($node, '/content/second-title');
    $this->assertNoAliasExists(['alias' => '/content/first-title']);

    // Test PATHAUTO_UPDATE_ACTION_LEAVE.
    $config->set('update_action', PathautoGeneratorInterface::UPDATE_ACTION_LEAVE);
    $config->save();
    $node->setTitle('Third title');
    $node->save();
    $this->assertEntityAlias($node, '/content/third-title');
    $this->assertAliasExists([
      'path' => '/' . $node->toUrl()->getInternalPath(),
      'alias' => '/content/second-title',
    ]);

    // Confirm that aliases are not duplicated when entities are re-saved.
    $node->save();
    $this->assertEntityAlias($node, '/content/third-title');
    $this->assertAliasIsUnique([
      'path' => '/' . $node->toUrl()->getInternalPath(),
      'alias' => '/content/third-title',
    ]);

    $config->set('update_action', PathautoGeneratorInterface::UPDATE_ACTION_DELETE);
    $config->save();
    $node->setTitle('Fourth title');
    $node->save();
    $this->assertEntityAlias($node, '/content/fourth-title');
    $this->assertNoAliasExists(['alias' => '/content/third-title']);
    // The older second alias is not deleted yet.
    $older_path = $this->assertAliasExists([
      'path' => '/' . $node->toUrl()->getInternalPath(),
      'alias' => '/content/second-title',
    ]);
    \Drupal::service('entity_type.manager')->getStorage('path_alias')->delete([$older_path]);

    $config->set('update_action', PathautoGeneratorInterface::UPDATE_ACTION_NO_NEW);
    $config->save();
    $node->setTitle('Fifth title');
    $node->save();
    $this->assertEntityAlias($node, '/content/fourth-title');
    $this->assertNoAliasExists(['alias' => '/content/fifth-title']);

    // Test PATHAUTO_UPDATE_ACTION_NO_NEW with unaliased node and 'update'.
    $this->deleteAllAliases();
    $node->save();
    $this->assertEntityAlias($node, '/content/fifth-title');

    // Test PATHAUTO_UPDATE_ACTION_NO_NEW with unaliased node and 'bulkupdate'.
    $this->deleteAllAliases();
    $node->setTitle('Sixth title');
    \Drupal::service('pathauto.generator')->updateEntityAlias($node, 'bulkupdate');
    $this->assertEntityAlias($node, '/content/sixth-title');
  }

  /**
   * Test createEntityAlias().
   *
   * Test that \Drupal::service('pathauto.generator')->createEntityAlias() will
   * not create an alias for a pattern that does not get any tokens replaced.
   */
  public function testNoTokensNoAlias() {
    $field_storage = FieldStorageConfig::create([
      'entity_type' => 'node',
      'field_name' => 'test',
      'type' => 'string',
    ]);
    $field_storage->save();
    $field = FieldConfig::create([
      'field_storage' => $field_storage,
      'bundle' => 'page',
    ]);
    $field->save();

    $this->nodePattern
      ->setPattern('/content/[node:test]')
      ->save();

    $node = $this->drupalCreateNode();
    $this->assertNoEntityAliasExists($node);

    $node->set('test', 'hello');
    $node->save();
    $this->assertEntityAlias($node, '/content/hello');
  }

  /**
   * Test path vs non-path tokens in pathauto_clean_token_values().
   */
  public function testPathTokens() {
    $this->createPattern('taxonomy_term', '/[term:parent:url:path]/[term:name]');

    $vocab = $this->addVocabulary();

    $term1 = $this->addTerm($vocab, ['name' => 'Parent term']);
    $this->assertEntityAlias($term1, '/parent-term');

    $term2 = $this->addTerm($vocab, [
      'name' => 'Child term',
      'parent' => $term1->id(),
    ]);
    $this->assertEntityAlias($term2, '/parent-term/child-term');

    $this->saveEntityAlias($term1, '/My Crazy/Alias/');
    $term2->save();
    $this->assertEntityAlias($term2, '/My Crazy/Alias/child-term');
  }

  /**
   * Test using fields for path structures.
   */
  public function testParentChildPathTokens() {
    // First create a field which will be used to create the path. It must
    // begin with a letter.
    $this->installEntitySchema('taxonomy_term');

    Vocabulary::create(['vid' => 'tags'])->save();

    $fieldname = 'a' . mb_strtolower($this->randomMachineName());
    $field_storage = FieldStorageConfig::create([
      'entity_type' => 'taxonomy_term',
      'field_name' => $fieldname,
      'type' => 'string',
    ]);
    $field_storage->save();
    $field = FieldConfig::create([
      'field_storage' => $field_storage,
      'bundle' => 'tags',
    ]);
    $field->save();

    $display = \Drupal::service('entity_display.repository')->getViewDisplay('taxonomy_term', 'tags');
    $display->setComponent($fieldname, ['type' => 'string']);
    $display->save();

    // Make the path pattern of a field use the value of this field appended
    // to the parent taxonomy term's pattern if there is one.
    $this->createPattern('taxonomy_term', '/[term:parents:join-path]/[term:' . $fieldname . ']');

    // Start by creating a parent term.
    $parent = Term::create([
      'vid' => 'tags',
      $fieldname => $this->randomMachineName(),
      'name' => $this->randomMachineName(),
    ]);
    $parent->save();

    // Create the child term.
    $child = Term::create([
      'vid' => 'tags',
      $fieldname => $this->randomMachineName(),
      'parent' => $parent,
      'name' => $this->randomMachineName(),
    ]);
    $child->save();
    $this->assertEntityAlias($child, '/' . mb_strtolower($parent->getName() . '/' . $child->$fieldname->value));

    // Re-saving the parent term should not modify the child term's alias.
    $parent->save();
    $this->assertEntityAlias($child, '/' . mb_strtolower($parent->getName() . '/' . $child->$fieldname->value));
  }

  /**
   * Tests aliases on taxonomy terms.
   */
  public function testTaxonomyPattern() {
    // Create a vocabulary and test that it's pattern variable works.
    $this->addVocabulary(['vid' => 'name']);
    $this->createPattern('taxonomy_term', 'base');
    $pattern = $this->createPattern('taxonomy_term', 'bundle', -1);
    $this->addBundleCondition($pattern, 'taxonomy_term', 'name');
    $pattern->save();
    $this->assertEntityPattern('taxonomy_term', 'name', Language::LANGCODE_NOT_SPECIFIED, '/bundle');
  }

  /**
   * Test that aliases matching existing paths are not generated.
   */
  public function testNoExistingPathAliases() {
    $this->config('pathauto.settings')
      ->set('punctuation.period', PathautoGeneratorInterface::PUNCTUATION_DO_NOTHING)
      ->save();

    $this->nodePattern
      ->setPattern('[node:title]')
      ->save();

    // Check that Pathauto does not create an alias of '/admin'.
    $node = $this->drupalCreateNode(['title' => 'Admin', 'type' => 'page']);
    $this->assertEntityAlias($node, '/admin-0');

    // Check that Pathauto does not create an alias of '/modules'.
    $node->setTitle('Modules');
    $node->save();
    $this->assertEntityAlias($node, '/modules-0');

    // Check that Pathauto does not create an alias of '/index.php'.
    $node->setTitle('index.php');
    $node->save();
    $this->assertEntityAlias($node, '/index.php-0');

    // Check that a safe value gets an automatic alias. This is also a control
    // to ensure the above tests work properly.
    $node->setTitle('Safe value');
    $node->save();
    $this->assertEntityAlias($node, '/safe-value');
  }

  /**
   * Test programmatic entity creation for aliases.
   */
  public function testProgrammaticEntityCreation() {
    $node = $this->drupalCreateNode([
      'title' => 'Test node',
      'path' => ['pathauto' => TRUE],
    ]);
    $this->assertEntityAlias($node, '/content/test-node');

    // Check the case when the pathauto widget is hidden, so it can not populate
    // the 'pathauto' property, and
    // \Drupal\path\Plugin\Field\FieldType\PathFieldItemList::computeValue()
    // populates the 'path' field with a 'langcode' property, for example during
    // an AJAX call on the entity form.
    $node = $this->drupalCreateNode([
      'title' => 'Test node 2',
      'path' => ['langcode' => 'en'],
    ]);
    $this->assertEntityAlias($node, '/content/test-node-2');

    $this->createPattern('taxonomy_term', '/[term:vocabulary]/[term:name]');
    $vocabulary = $this->addVocabulary(['name' => 'Tags']);
    $term = $this->addTerm($vocabulary, [
      'name' => 'Test term',
      'path' => ['pathauto' => TRUE],
    ]);
    $this->assertEntityAlias($term, '/tags/test-term');

    $edit['name'] = 'Test user';
    $edit['mail'] = 'test-user@example.com';
    $edit['pass'] = \Drupal::service('password_generator')->generate();
    $edit['path'] = ['pathauto' => TRUE];
    $edit['status'] = 1;
    $account = User::create($edit);
    $account->save();
    $this->assertEntityAlias($account, '/users/test-user');
  }

  /**
   * Tests word safe alias truncating.
   */
  public function testPathAliasUniquifyWordsafe() {
    $this->config('pathauto.settings')
      ->set('max_length', 26)
      ->save();

    $node_1 = $this->drupalCreateNode([
      'title' => 'thequick brownfox jumpedover thelazydog',
      'type' => 'page',
    ]);
    $node_2 = $this->drupalCreateNode([
      'title' => 'thequick brownfox jumpedover thelazydog',
      'type' => 'page',
    ]);

    // Check that alias uniquifying is truncating with $wordsafe param set to
    // TRUE.
    // If it doesn't path alias result would be content/thequick-brownf-0.
    $this->assertEntityAlias($node_1, '/content/thequick-brownfox');
    $this->assertEntityAlias($node_2, '/content/thequick-0');
  }

  /**
   * Test if aliases are (not) generated with enabled/disabled patterns.
   */
  public function testPatternStatus() {
    // Create a node to get an alias for.
    $title = 'Pattern enabled';
    $alias = '/content/pattern-enabled';
    $node1 = $this->drupalCreateNode(['title' => $title, 'type' => 'page']);
    $this->assertEntityAlias($node1, $alias);

    // Disable the pattern, save the node again and make sure the alias is still
    // working.
    $this->nodePattern->setStatus(FALSE)->save();

    $node1->save();
    $this->assertEntityAlias($node1, $alias);

    // Create a new node with disabled pattern and make sure there is no new
    // alias created.
    $title = 'Pattern disabled';
    $node2 = $this->drupalCreateNode(['title' => $title, 'type' => 'page']);
    $this->assertNoEntityAlias($node2);
  }

  /**
   * Tests that enabled entity types generates the necessary fields and plugins.
   */
  public function testSettingChangeInvalidatesCache() {

    $this->installConfig(['pathauto']);

    $this->enableModules(['entity_test']);

    $definitions = \Drupal::service('plugin.manager.alias_type')->getDefinitions();
    $this->assertFalse(isset($definitions['canonical_entities:entity_test']));

    $fields = \Drupal::service('entity_field.manager')->getBaseFieldDefinitions('entity_test');
    $this->assertFalse(isset($fields['path']));

    $this->config('pathauto.settings')
      ->set('enabled_entity_types', ['user', 'entity_test'])
      ->save();

    $definitions = \Drupal::service('plugin.manager.alias_type')->getDefinitions();
    $this->assertTrue(isset($definitions['canonical_entities:entity_test']));

    $fields = \Drupal::service('entity_field.manager')->getBaseFieldDefinitions('entity_test');
    $this->assertTrue(isset($fields['path']));

  }

  /**
   * Tests that aliases are only generated for default revisions.
   */
  public function testDefaultRevision() {
    $node1 = $this->drupalCreateNode([
      'title' => 'Default revision',
      'type' => 'page',
    ]);
    $this->assertEntityAlias($node1, '/content/default-revision');

    $node1->setNewRevision(TRUE);
    $node1->isDefaultRevision(FALSE);
    $node1->setTitle('New non-default-revision');
    $node1->save();

    $this->assertEntityAlias($node1, '/content/default-revision');
  }

  /**
   * Test that a translated pattern is used for alias generation.
   */
  public function testTranslatedPattern() {
    // The default node pattern is '/content/[node:title]'.
    // Add a French config override with a different prefix.
    $override = \Drupal::languageManager()->getLanguageConfigOverride('fr', 'pathauto.pattern.' . $this->nodePattern->id());
    $override->set('pattern', '/contenu/[node:title]')->save();

    // Create a French node.
    $node_fr = $this->drupalCreateNode([
      'title' => 'Bonjour le monde',
      'type' => 'page',
      'langcode' => 'fr',
    ]);
    $this->assertEntityAlias($node_fr, '/contenu/bonjour-le-monde', 'fr');

    // Create an English node — should use the default (non-overridden) pattern.
    $node_en = $this->drupalCreateNode([
      'title' => 'Hello world',
      'type' => 'page',
      'langcode' => 'en',
    ]);
    $this->assertEntityAlias($node_en, '/content/hello-world', 'en');
  }

  /**
   * Tests that the pathauto state property gets set to CREATED for new nodes.
   *
   * In some cases, this can trigger $node->path to be set up with no default
   * value for the pathauto property.
   */
  public function testCreateNodeWhileAccessingPath() {
    $node = Node::create([
      'type' => 'article',
      'title' => 'TestAlias',
    ]);
    $node->path->langcode;
    $node->save();
    $this->assertEntityAlias($node, '/content/testalias');
  }

  /**
   * Tests deleteEntityPathAll() with a <nolink> entity.
   *
   * Aliases should not be deleted for <nolink> entities.
   *
   * @see \Drupal\pathauto\AliasStorageHelper::deleteEntityPathAll()
   * @see https://www.drupal.org/project/pathauto/issues/3367067
   */
  public function testDeleteEntityPathAllWithNoLinkEntity() {
    // Create nodes with aliases.
    $node1 = $this->drupalCreateNode(['title' => 'First node']);
    $this->assertEntityAlias($node1, '/content/first-node');
    $node2 = $this->drupalCreateNode(['title' => 'Second node']);
    $this->assertEntityAlias($node2, '/content/second-node');

    // Create a mock entity whose canonical URL is <nolink>.
    $nolink_entity = $this->createMock(EntityInterface::class);
    $nolink_entity->expects($this->atLeastOnce())
      ->method('toUrl')
      ->with('canonical')
      ->willReturn(Url::fromRoute('<nolink>'));

    // Calling deleteEntityPathAll() on the <nolink> entity should not delete
    // any aliases.
    /** @var \Drupal\pathauto\AliasStorageHelperInterface $alias_storage_helper */
    $alias_storage_helper = \Drupal::service('pathauto.alias_storage_helper');
    $alias_storage_helper->deleteEntityPathAll($nolink_entity);

    // Assert that existing aliases are untouched.
    $this->assertEntityAlias($node1, '/content/first-node');
    $this->assertEntityAlias($node2, '/content/second-node');
  }

  /**
   * Tests that selection criteria UUIDs are preserved on form re-save.
   *
   * Calls PatternEditForm::buildEntity() with the same bundle selection
   * to verify that the form updates conditions in place rather than
   * removing and re-adding them. Without the fix, buildEntity() would
   * remove+readd the condition, regenerating its UUID on every save.
   *
   * @see https://www.drupal.org/node/2895873
   */
  public function testSelectionCriteriaUuidPreservedOnSave() {
    // Create a pattern with a bundle condition.
    $pattern = $this->createPattern('node', '/content/[node:title]');
    $this->addBundleCondition($pattern, 'node', 'page');
    $pattern->save();

    // Record the selection_criteria UUIDs after first save.
    $pattern = PathautoPattern::load($pattern->id());
    $criteria_before = $pattern->get('selection_criteria');
    $this->assertNotEmpty($criteria_before, 'Pattern has selection criteria.');
    $uuids_before = array_keys($criteria_before);

    // Build the form and call buildEntity() to simulate a form re-save
    // with the same bundles selected.
    $form_object = $this->container->get('entity_type.manager')
      ->getFormObject('pathauto_pattern', 'default');
    $form_object->setEntity($pattern);

    $form_state = new FormState();
    $form_state->setValue('bundles', ['page' => 'page']);
    $form_state->setValue('type', 'canonical_entities:node');
    $form_state->setValue('pattern', '/content/[node:title]');
    $form_state->setValue('label', $pattern->label());
    $form_state->setValue('id', $pattern->id());

    $form = $form_object->buildForm([], $form_state);
    $entity = $form_object->buildEntity($form, $form_state);
    $entity->save();

    // Reload and verify UUIDs are preserved.
    $pattern = PathautoPattern::load($pattern->id());
    $criteria_after = $pattern->get('selection_criteria');
    $uuids_after = array_keys($criteria_after);

    $this->assertEquals($uuids_before, $uuids_after, 'Selection criteria UUIDs are preserved after form re-save.');
  }

  /**
   * Tests addSelectionCondition generates a new UUID when none is provided.
   *
   * @see https://www.drupal.org/node/2895873
   */
  public function testSelectionCriteriaNewUuidGenerated() {
    $pattern = $this->createPattern('node', '/content/[node:title]');

    // Add a condition without specifying a UUID.
    $uuid = $pattern->addSelectionCondition([
      'id' => 'entity_bundle:node',
      'bundles' => ['page' => 'page'],
      'negate' => FALSE,
      'context_mapping' => ['node' => 'node'],
    ]);
    $pattern->save();

    $this->assertNotEmpty($uuid, 'A UUID was generated for the new condition.');

    // Add a second condition without specifying a UUID.
    $uuid2 = $pattern->addSelectionCondition([
      'id' => 'language',
      'langcodes' => ['en' => 'en'],
      'negate' => FALSE,
      'context_mapping' => ['language' => 'language'],
    ]);

    $this->assertNotEmpty($uuid2, 'A UUID was generated for the second condition.');
    $this->assertNotEquals($uuid, $uuid2, 'Each condition gets a unique UUID.');

    $pattern->save();
    $pattern = PathautoPattern::load($pattern->id());
    $criteria = $pattern->get('selection_criteria');
    // Verify 'uuid' is not stored inside any condition configuration.
    foreach ($criteria as $config) {
      $this->assertArrayNotHasKey('uuid', $config);
    }
  }

  /**
   * Creates a node programmatically.
   *
   * @param array $settings
   *   The array of values for the node.
   *
   * @return \Drupal\node\Entity\Node
   *   The created node.
   */
  protected function drupalCreateNode(array $settings = []) {
    // Populate defaults array.
    $settings += [
      'title' => $this->randomMachineName(8),
      'type' => 'page',
    ];

    $node = Node::create($settings);
    $node->save();

    return $node;
  }

}
