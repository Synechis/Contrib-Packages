<?php

namespace Drupal\paragraphs_type_permissions\Hook;

use Drupal\Core\Access\AccessResult;
use Drupal\Core\Session\AccountInterface;
use Drupal\paragraphs\ParagraphInterface;
use Drupal\Core\Url;
use Drupal\Core\Routing\RouteMatchInterface;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\Core\StringTranslation\StringTranslationTrait;

/**
 * Hook implementations for paragraphs_type_permissions.
 */
class ParagraphsTypePermissionsHooks {
  use StringTranslationTrait;

  /**
   * Implements hook_help().
   */
  #[Hook('help')]
  public function help($route_name, RouteMatchInterface $route_match) {
    switch ($route_name) {
      // Help for the Paragraphs type permissions module.
      case 'help.page.paragraphs_type_permissions':
        $output = '';
        $output .= '<h3>' . $this->t('About') . '</h3>';
        $output .= '<p>' . $this->t('The Paragraphs Type permission module allows administrators to configure permissions individually for each <em>Paragraphs type</em>. For more information, see the <a href=":online">online documentation for the Paragraphs module</a>.', [
          ':online' => 'https://www.drupal.org/node/2444881',
        ]) . '</p>';
        $output .= '<h3>' . $this->t('Uses') . '</h3>';
        $output .= '<dt>' . $this->t('Configuring permissions per Paragraphs type') . '</dt>';
        $output .= '<dd>' . $this->t('Administrators can configure the permissions to view, create, edit, and delete each <em>Paragraphs type</em> individually on the <a href=":permissions">Permissions page</a>.', [
          ':permissions' => Url::fromRoute('user.admin_permissions')->toString(),
        ]) . '</dd>';
        return $output;

      break;
    }
  }

  /**
   * Implements hook_ENTITY_TYPE_access() for entity type "paragraph".
   */
  #[Hook('paragraph_access')]
  public static function paragraphAccess(ParagraphInterface $entity, $operation, AccountInterface $account) {
    $permissions =& drupal_static('paragraphs_type_permissions_paragraph_access', []);
    if (!in_array($operation, [
      'view',
      'update',
      'delete',
    ], TRUE)) {
      // If there was no type to check against, or the $op was not one of the
      // supported ones, we return access denied.
      return AccessResult::neutral();
    }
    // Set static cache id to use the type machine name.
    $type = $entity->getType();
    if ($operation == 'view' && !$entity->status->value) {
      return AccessResult::forbidden();
    }
    // If we've already checked access for this type, user and op, return from
    // cache.
    if (isset($permissions[$account->id()][$type][$operation])) {
      return $permissions[$account->id()][$type][$operation];
    }
    // If the current user has access to this type/operation, return access
    // allowed, forbidden otherwise.
    if ($account->hasPermission('bypass paragraphs type content access') || $account->hasPermission($operation . ' paragraph content ' . $type)) {
      $permissions[$account->id()][$type][$operation] = AccessResult::allowed()->cachePerPermissions();
    }
    else {
      $permissions[$account->id()][$type][$operation] = AccessResult::forbidden()->cachePerPermissions();
    }
    return $permissions[$account->id()][$type][$operation];
  }

  /**
   * Implements hook_ENTITY_TYPE_create_access() for entity type "paragraph".
   */
  #[Hook('paragraph_create_access')]
  public static function paragraphCreateAccess(
    ?AccountInterface $account = NULL,
    array $context = [],
    $entity_bundle = NULL,
  ) {
    $permissions =& drupal_static('paragraphs_type_permissions_paragraph_create_access', []);
    // Set static cache id to use the type machine name.
    $type = $entity_bundle;
    $op = 'create';
    // If we've already checked access for this type, user and op, return from
    // cache.
    if (isset($permissions[$account->id()][$type][$op])) {
      return $permissions[$account->id()][$type][$op];
    }
    // If the current user has access to this type/op, return access allowed,
    // forbidden otherwise.
    if ($account->hasPermission('bypass paragraphs type content access') || $account->hasPermission($op . ' paragraph content ' . $type)) {
      $permissions[$account->id()][$type][$op] = AccessResult::allowed()->cachePerPermissions();
    }
    else {
      $permissions[$account->id()][$type][$op] = AccessResult::forbidden()->cachePerPermissions();
    }
    return $permissions[$account->id()][$type][$op];
  }

}
