<?php

declare(strict_types=1);

namespace Drupal\Tests\flag\FunctionalJavascript;

use Drupal\Component\Utility\Html;
use Drupal\Core\Url;
use Drupal\FunctionalJavascriptTests\WebDriverTestBase;
use Drupal\Tests\flag\Traits\FlagCreateTrait;

/**
 * Tests modal form options for action link plugins.
 *
 * @group flag
 */
class ModalFormTest extends WebDriverTestBase {

  use FlagCreateTrait;

  /**
   * {@inheritdoc}
   */
  protected $defaultTheme = 'stark';

  /**
   * {@inheritdoc}
   */
  protected static $modules = ['flag', 'flag_link_test', 'node', 'user'];

  /**
   * Flag to test with.
   *
   * @var \Drupal\flag\FlagInterface
   */
  protected $flag;

  /**
   * The flag service.
   *
   * @var \Drupal\flag\FlagServiceInterface
   */
  protected $flagService;

  /**
   * Test node.
   *
   * @var \Drupal\node\NodeInterface
   */
  protected $node;

  /**
   * Admin user.
   *
   * @var \Drupal\user\UserInterface
   */
  protected $admin;

  /**
   * Normal user.
   *
   * @var \Drupal\user\UserInterface
   */
  protected $webUser;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    // A test flag.
    $this->flag = $this->createFlag('node', [], 'confirm');
    $this->flagService = $this->container->get('flag');

    // A node to test with.
    $this->admin = $this->createUser([], NULL, TRUE);
    $type = $this->createContentType();
    $this->node = $this->createNode([
      'type' => $type->id(),
      'uid' => $this->admin->id(),
    ]);

    $this->webUser = $this->createUser(array_keys($this->flag->actionPermissions()));
    $this->drupalLogin($this->webUser);
  }

  /**
   * Tests the modal form option for the confirm form link type.
   */
  public function testModalOption() {
    // Verify default, non-modal behavior.
    $this->drupalGet($this->node->toUrl());
    $this->clickLink($this->flag->getShortText('flag'));

    // Should be on the confirm form page, since this isn't using a modal.
    $expected = Url::fromRoute('flag.confirm_flag', [
      'flag' => $this->flag->id(),
      'entity_id' => $this->node->id(),
    ]);

    /** @var \Drupal\FunctionalJavascriptTests\JSWebAssert $assert_session */
    $assert_session = $this->assertSession();

    $assert_session->addressEquals($expected->getInternalPath());
    $assert_session->buttonExists('Create flagging')->press();
    $assert_session->addressEquals($this->node->toUrl());

    // Unflag.
    $this->clickLink($this->flag->getShortText('unflag'));
    $expected = Url::fromRoute('flag.confirm_unflag', [
      'flag' => $this->flag->id(),
      'entity_id' => $this->node->id(),
    ]);
    $assert_session->addressEquals($expected->getInternalPath());
    $assert_session->buttonExists('Delete flagging')->press();
    $assert_session->addressEquals($this->node->toUrl());

    // Set the modal option for the 'confirm' link.
    $configuration = $this->flag->getLinkTypePlugin()->getConfiguration();
    $configuration['form_behavior'] = 'modal';
    $this->flag->getLinkTypePlugin()->setConfiguration($configuration);
    $this->flag->save();

    $link_selector = '.js-flag-' . Html::cleanCssIdentifier($this->flag->id()) . '-' . $this->node->id() . ' a';

    // Flag and unflag from the full view mode.
    $this->drupalGet($this->node->toUrl());
    $this->confirmInModal($this->flag->getShortText('flag'), 'Create flagging');
    $assert_session->addressEquals($this->node->toUrl()->getInternalPath());
    $assert_session->linkExists($this->flag->getShortText('unflag'));
    $assert_session->elementAttributeContains('css', $link_selector, 'href', 'view_mode=full');

    $this->confirmInModal($this->flag->getShortText('unflag'), 'Delete flagging');
    $assert_session->addressEquals($this->node->toUrl()->getInternalPath());
    $assert_session->linkExists($this->flag->getShortText('flag'));
    $assert_session->elementAttributeContains('css', $link_selector, 'href', 'view_mode=full');

    // Flag and unflag from a link rendered in the default view mode.
    $test_page = Url::fromRoute('flag_link_test.page', [
      'entity_type_id' => 'node',
      'entity_id' => $this->node->id(),
      'flag' => $this->flag->id(),
    ]);
    $this->drupalGet($test_page);
    $this->confirmInModal($this->flag->getShortText('flag'), 'Create flagging');
    $assert_session->addressEquals($test_page->getInternalPath());
    $assert_session->linkExists($this->flag->getShortText('unflag'));
    $assert_session->elementAttributeContains('css', $link_selector, 'href', 'view_mode=default');

    $this->confirmInModal($this->flag->getShortText('unflag'), 'Delete flagging');
    $assert_session->addressEquals($test_page->getInternalPath());
    $assert_session->linkExists($this->flag->getShortText('flag'));
    $assert_session->elementAttributeContains('css', $link_selector, 'href', 'view_mode=default');
  }

  /**
   * Clicks a flag link and submits its confirm form in the modal.
   *
   * @param string $link_text
   *   The flag link text.
   * @param string $button
   *   The confirm form submit button label.
   */
  protected function confirmInModal(string $link_text, string $button): void {
    $this->clickLink($link_text);
    $this->assertSession()->assertWaitOnAjaxRequest();
    $this->assertSession()->elementExists('css', '.ui-dialog-buttonpane')->pressButton($button);
    $this->assertSession()->assertWaitOnAjaxRequest();
  }

  /**
   * Tests the non-modal dialog option closes properly after AJAX submit.
   */
  public function testDialogOption() {
    $configuration = $this->flag->getLinkTypePlugin()->getConfiguration();
    $configuration['form_behavior'] = 'dialog';
    $this->flag->getLinkTypePlugin()->setConfiguration($configuration);
    $this->flag->save();

    /** @var \Drupal\FunctionalJavascriptTests\JSWebAssert $assert_session */
    $assert_session = $this->assertSession();

    $this->drupalGet($this->node->toUrl());
    $this->clickLink($this->flag->getShortText('flag'));
    $assert_session->assertWaitOnAjaxRequest();
    $assert_session->addressEquals($this->node->toUrl()->getInternalPath());

    $assert_session->buttonExists('Create flagging');
    $this->click('button:contains("Create flagging")');
    $assert_session->assertWaitOnAjaxRequest();
    $assert_session->addressEquals($this->node->toUrl()->getInternalPath());
    $assert_session->assertNoElementAfterWait('css', '.ui-dialog');
    $assert_session->linkExists($this->flag->getShortText('unflag'));
    $this->assertNotNull($this->flagService->getFlagging($this->flag, $this->node, $this->webUser));

    // Unflag.
    $this->clickLink($this->flag->getShortText('unflag'));
    $assert_session->assertWaitOnAjaxRequest();
    $assert_session->addressEquals($this->node->toUrl()->getInternalPath());

    $assert_session->buttonExists('Delete flagging');
    $this->click('button:contains("Delete flagging")');
    $assert_session->assertWaitOnAjaxRequest();
    $assert_session->addressEquals($this->node->toUrl()->getInternalPath());
    $assert_session->assertNoElementAfterWait('css', '.ui-dialog');
    $assert_session->linkExists($this->flag->getShortText('flag'));
    $this->assertNull($this->flagService->getFlagging($this->flag, $this->node, $this->webUser));
  }

}
