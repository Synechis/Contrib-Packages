<?php

declare(strict_types=1);

namespace Drupal\Tests\flag\Functional;

/**
 * Tests the Flood settings.
 *
 * @group flag
 */
class FlagFloodTest extends FlagTestBase {

  /**
   * {@inheritdoc}
   */
  protected $defaultTheme = 'stark';

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'flag',
    'node',
    'user',
  ];

  /**
   * The flag used for the test.
   *
   * @var \Drupal\flag\FlagInterface
   */
  protected $flag;

  /**
   * The flag service.
   *
   * @var \Drupal\flag\FlagServiceInterface
   */
  protected $flagService;

  /**
   * Test node.
   *
   * @var \Drupal\node\NodeInterface
   */
  protected $node;

  /**
   * Normal user.
   *
   * @var \Drupal\user\UserInterface
   */
  protected $webUser;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->node = $this->createNode([
      'type' => 'article',
      'uid' => $this->rootUser->id(),
    ]);

    // A test flag.
    $this->flag = $this->createFlag('node', ['article'], 'ajax_link');
    $this->flagService = $this->container->get('flag');

    $this->drupalLogin($this->rootUser);

    $this->drupalGet('admin/structure/flags/manage/' . $this->flag->id());
    $edit = [
      'flood_control_active' => 1,
      'flood_control_limit' => 2,
      'flood_control_window' => 3600,
    ];
    $this->submitForm($edit, 'Save Flag');

    $this->webUser = $this->createUser([
      'access content',
    ]);

    $this->grantFlagPermissions($this->flag);
    $this->drupalLogin($this->webUser);

  }

  /**
   * Tests that the form rejects a limit or window below one.
   */
  public function testFormValidation(): void {
    $this->drupalLogin($this->rootUser);
    $this->drupalGet('admin/structure/flags/manage/' . $this->flag->id());
    $this->submitForm([
      'flood_control_active' => 1,
      'flood_control_limit' => 0,
      'flood_control_window' => 0,
    ], 'Save Flag');
    $this->assertSession()->pageTextContains('Number of flaggings per time window must be at least 1 when flood control is enabled.');
    $this->assertSession()->pageTextContains('Time window in seconds must be at least 1 when flood control is enabled.');

    // Zero values are fine as long as flood control is disabled.
    $this->submitForm([
      'flood_control_active' => 0,
      'flood_control_limit' => 0,
      'flood_control_window' => 0,
    ], 'Save Flag');
    $this->assertSession()->pageTextContains('has been updated.');
  }

  /**
   * Test flood set up actually works.
   */
  public function testFlagFlood(): void {
    $this->drupalGet('node/' . $this->node->id());

    $page = $this->getSession()->getPage();
    // Check that flag link is present and click it.
    $flagLink = $page->findLink($this->flag->getShortText('flag'));
    $this->assertNotNull($flagLink, 'flag link exists.');
    // Keep the link, including its CSRF token, to replay it later.
    $flagHref = $flagLink->getAttribute('href');
    $flagLink->click();

    // Check that unflag link is displayed and click it.
    $unflagLink = $page->findLink($this->flag->getShortText('unflag'));
    $this->assertNotNull($unflagLink, 'unflag link exists.');
    $unflagLink->click();

    // Check that flag link re-appears and click it.
    $flagLink2 = $page->findLink($this->flag->getShortText('flag'));
    $this->assertNotNull($flagLink2, 'flag cycle return to start.');
    $flagLink2->click();

    // The limit is reached, so the flagged state remains but flagging again is
    // not possible. Unflagging must stay available.
    $unflagLink3 = $page->findLink($this->flag->getShortText('unflag'));
    $this->assertNotNull($unflagLink3, 'unflag link exists when flood limit is reached.');
    $unflagLink3->click();

    // Verify that there is no flag link present, which confirms flood set up
    // is correct and working.
    $flagLink3 = $page->findLink($this->flag->getShortText('flag'));
    $this->assertNull($flagLink3, 'flag link not found.');

    // Replaying the previously rendered flag link must be forbidden as well.
    $this->drupalGet($this->getAbsoluteUrl($flagHref));
    $this->assertSession()->statusCodeEquals(403);
  }

}
