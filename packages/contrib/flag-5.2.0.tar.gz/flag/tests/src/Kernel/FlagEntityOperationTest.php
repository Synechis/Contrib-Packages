<?php

declare(strict_types=1);

namespace Drupal\Tests\flag\Kernel;

use Drupal\Core\Cache\CacheableMetadata;
use Drupal\Core\Config\Entity\ConfigEntityListBuilder;
use Drupal\flag\Hook\FlagHooks;

/**
 * Tests the cacheability handling of hook_entity_operation() for flags.
 *
 * @group flag
 */
class FlagEntityOperationTest extends FlagKernelTestBase {

  /**
   * Tests operations and bubbled cacheability for enabled and disabled flags.
   */
  public function testEntityOperationBubblesCacheability(): void {
    $flag = $this->createFlag('node', ['article']);
    $hooks = $this->container->get(FlagHooks::class);

    $cacheability = new CacheableMetadata();
    $operations = $hooks->entityOperation($flag, $cacheability);
    $this->assertSame(['disable', 'reset'], array_keys($operations));
    $this->assertContains('config:flag.flag.' . $flag->id(), $cacheability->getCacheTags());
    $this->assertSame(array_keys($operations), array_keys($hooks->entityOperation($flag)));

    $flag->disable()->save();
    $cacheability = new CacheableMetadata();
    $operations = $hooks->entityOperation($flag, $cacheability);
    $this->assertSame(['enable', 'reset'], array_keys($operations));
    $this->assertContains('config:flag.flag.' . $flag->id(), $cacheability->getCacheTags());
    $this->assertSame(array_keys($operations), array_keys($hooks->entityOperation($flag)));
  }

  /**
   * Tests the cacheability reaches the caller through the core list builder.
   */
  public function testListBuilderReceivesCacheability(): void {
    if (version_compare(\Drupal::VERSION, '11.3.0-alpha1', '<')) {
      $this->markTestSkipped('EntityListBuilder::getOperations() does not accept cacheability before Drupal 11.3.');
    }

    $flag = $this->createFlag('node', ['article']);
    $list_builder = $this->container->get('entity_type.manager')->getListBuilder('flag');
    $this->assertInstanceOf(ConfigEntityListBuilder::class, $list_builder);

    $cacheability = new CacheableMetadata();
    // @phpstan-ignore-next-line
    $operations = $list_builder->getOperations($flag, $cacheability);
    $this->assertArrayHasKey('reset', $operations);
    $this->assertArrayHasKey('disable', $operations);
    $this->assertContains('config:flag.flag.' . $flag->id(), $cacheability->getCacheTags());
  }

}
