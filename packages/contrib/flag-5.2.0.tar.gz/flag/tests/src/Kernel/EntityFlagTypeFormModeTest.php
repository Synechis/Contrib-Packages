<?php

declare(strict_types=1);

namespace Drupal\Tests\flag\Kernel;

use Drupal\Core\Entity\Entity\EntityFormMode;
use Drupal\node\Entity\NodeType;

/**
 * Tests which form operations show flags on entity forms.
 *
 * @group flag
 */
class EntityFlagTypeFormModeTest extends FlagKernelTestBase {

  /**
   * Tests isAddEditForm() with core operations and custom form modes.
   */
  public function testIsAddEditForm(): void {
    NodeType::create(['type' => 'article', 'name' => 'Article'])->save();
    EntityFormMode::create([
      'id' => 'node.custom',
      'label' => 'Custom',
      'targetEntityType' => 'node',
    ])->save();

    $flag = $this->createFlag('node', ['article']);
    /** @var \Drupal\flag\Plugin\Flag\EntityFlagType $flag_type */
    $flag_type = $flag->getFlagTypePlugin();

    $this->assertTrue($flag_type->isAddEditForm('default'));
    $this->assertTrue($flag_type->isAddEditForm('edit'));
    $this->assertTrue($flag_type->isAddEditForm('custom'), 'Custom form modes are treated as add/edit forms.');
    $this->assertFalse($flag_type->isAddEditForm('delete'));
    $this->assertFalse($flag_type->isAddEditForm('scheduled_transitions_add'), 'Operations that are not form modes are not add/edit forms.');
  }

}
