<?php

declare(strict_types=1);

namespace Drupal\Tests\flag\Kernel;

use Drupal\Core\Session\AnonymousUserSession;
use Drupal\flag\FlagInterface;
use Drupal\node\Entity\Node;
use Drupal\node\Entity\NodeType;
use Drupal\user\Entity\Role;
use Drupal\user\RoleInterface;

/**
 * Tests the flag link render array built for anonymous users.
 *
 * @see https://www.drupal.org/project/flag/issues/3295483
 * @see https://www.drupal.org/project/flag/issues/3630623
 * @group flag
 */
class AnonymousFlagLinkTest extends FlagKernelTestBase {

  /**
   * The flag.
   *
   * @var \Drupal\flag\FlagInterface
   */
  protected FlagInterface $flag;

  /**
   * The flaggable node.
   *
   * @var \Drupal\node\Entity\Node
   */
  protected Node $node;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->installConfig(['user']);

    NodeType::create([
      'type' => 'article',
      'name' => 'Article',
    ])->save();

    $this->flag = $this->createFlagFromArray([
      'id' => 'test_flag',
      'label' => 'Test flag',
      'entity_type' => 'node',
      'bundles' => ['article'],
      'link_type' => 'ajax_link',
    ]);

    $this->node = Node::create([
      'type' => 'article',
      'title' => 'Test node',
    ]);
    $this->node->save();

    $this->setCurrentUser(new AnonymousUserSession());
  }

  /**
   * Tests nothing is rendered for anonymous users who may not flag.
   */
  public function testAnonymousWithoutPermission(): void {
    $build = $this->buildLink();

    $this->assertArrayNotHasKey('#theme', $build);
    $this->assertArrayNotHasKey('#access', $build);
    // The access result still varies the render cache.
    $this->assertContains('user.permissions', $build['#cache']['contexts'] ?? []);
  }

  /**
   * Tests the flag link is rendered for anonymous users who may flag.
   */
  public function testAnonymousWithFlagPermission(): void {
    $this->grantAnonymousPermissions(['flag test_flag']);

    $build = $this->buildLink();

    $this->assertSame('flag', $build['#theme']);
    $this->assertSame('flag', $build['#action']);
    $this->assertTrue($build['#access']);
    $this->assertArrayHasKey('href', $build['#attributes']);
    $this->assertArrayHasKey('#title', $build);
  }

  /**
   * Tests the flag is kept after flagging when unflagging is not allowed.
   */
  public function testAnonymousFlaggedWithoutUnflagPermission(): void {
    $this->grantAnonymousPermissions(['flag test_flag']);
    $this->flagService->flag($this->flag, $this->node);

    $build = $this->buildLink();

    // Rendered without a link, so the flagged message can be displayed.
    $this->assertSame('flag', $build['#theme']);
    $this->assertSame('unflag', $build['#action']);
    $this->assertTrue($build['#access']);
    $this->assertArrayNotHasKey('href', $build['#attributes'] ?? []);
    $this->assertArrayNotHasKey('#title', $build);
  }

  /**
   * Grants permissions to the anonymous role.
   *
   * @param string[] $permissions
   *   The permissions to grant.
   */
  private function grantAnonymousPermissions(array $permissions): void {
    $role = Role::load(RoleInterface::ANONYMOUS_ID);
    foreach ($permissions as $permission) {
      $role->grantPermission($permission);
    }
    $role->save();
  }

  /**
   * Builds the flag link render array for the current user.
   */
  private function buildLink(): array {
    return $this->flag->getLinkTypePlugin()->getAsFlagLink($this->flag, $this->node, 'default');
  }

}
