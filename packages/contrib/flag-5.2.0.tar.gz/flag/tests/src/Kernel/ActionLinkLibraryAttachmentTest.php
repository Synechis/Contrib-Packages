<?php

declare(strict_types=1);

namespace Drupal\Tests\flag\Kernel;

use Drupal\Core\Session\AnonymousUserSession;
use Drupal\flag\FlagInterface;
use Drupal\node\Entity\Node;
use Drupal\node\Entity\NodeType;

/**
 * Tests that AJAX libraries are only attached when the flag link is rendered.
 *
 * @see https://www.drupal.org/project/flag/issues/3628869
 * @group flag
 */
class ActionLinkLibraryAttachmentTest extends FlagKernelTestBase {

  /**
   * The flag using the AJAX link type.
   *
   * @var \Drupal\flag\Entity\Flag
   */
  protected $ajaxFlag;

  /**
   * The flag using the field entry link type with dialog behavior.
   *
   * @var \Drupal\flag\Entity\Flag
   */
  protected $dialogFlag;

  /**
   * The flaggable node.
   *
   * @var \Drupal\node\Entity\Node
   */
  protected $node;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    // Reserve uid 1, otherwise the first created user gets it and the
    // SuperUserAccessPolicy grants it every permission.
    $this->setUpCurrentUser();

    NodeType::create([
      'type' => 'article',
      'name' => 'Article',
    ])->save();

    $this->ajaxFlag = $this->createFlagFromArray([
      'id' => 'test_ajax_flag',
      'label' => 'Test AJAX flag',
      'entity_type' => 'node',
      'bundles' => ['article'],
      'link_type' => 'ajax_link',
    ]);

    $this->dialogFlag = $this->createFlagFromArray([
      'id' => 'test_dialog_flag',
      'label' => 'Test dialog flag',
      'entity_type' => 'node',
      'bundles' => ['article'],
      'link_type' => 'field_entry',
      'linkTypeConfig' => [
        'form_behavior' => 'modal',
      ],
    ]);

    $this->node = Node::create([
      'type' => 'article',
      'title' => 'Test node',
    ]);
    $this->node->save();
  }

  /**
   * Tests the AJAX link library is only attached for users who may flag.
   */
  public function testAjaxLinkLibraryAttachment(): void {
    // A user who may flag gets the library and the use-ajax class.
    $allowed_user = $this->createUser([
      'flag test_ajax_flag',
      'unflag test_ajax_flag',
    ]);
    $this->assertTrue($this->ajaxFlag->actionAccess('flag', $allowed_user, $this->node)->isAllowed());
    $this->setCurrentUser($allowed_user);
    $build = $this->buildLink($this->ajaxFlag);
    $this->assertTrue(isset($build['#attributes']['href']));
    $this->assertContains('flag/flag.link_ajax', $build['#attached']['library'] ?? []);
    $this->assertContains('use-ajax', $build['#attributes']['class'] ?? []);

    // A user who may not flag gets neither.
    $denied_user = $this->createUser();
    $this->assertFalse($this->ajaxFlag->actionAccess('flag', $denied_user, $this->node)->isAllowed());
    $this->setCurrentUser($denied_user);
    $build = $this->buildLink($this->ajaxFlag);
    $this->assertNotContains('flag/flag.link_ajax', $build['#attached']['library'] ?? []);
    $this->assertNotContains('use-ajax', $build['#attributes']['class'] ?? []);

    // Neither does the anonymous user.
    $anonymous = new AnonymousUserSession();
    $this->assertFalse($this->ajaxFlag->actionAccess('flag', $anonymous, $this->node)->isAllowed());
    $this->setCurrentUser($anonymous);
    $build = $this->buildLink($this->ajaxFlag);
    $this->assertNotContains('flag/flag.link_ajax', $build['#attached']['library'] ?? []);
    $this->assertNotContains('use-ajax', $build['#attributes']['class'] ?? []);
  }

  /**
   * Tests the library is attached for an unflag action the user may perform.
   */
  public function testUnflagActionLibraryAttachment(): void {
    // A user with only the unflag permission who has already flagged gets
    // the library, because the unflag link is actionable.
    $unflag_only_user = $this->createUser(['unflag test_ajax_flag']);
    $this->flagService->flag($this->ajaxFlag, $this->node, $unflag_only_user);
    $this->assertTrue($this->ajaxFlag->actionAccess('unflag', $unflag_only_user, $this->node)->isAllowed());
    $this->setCurrentUser($unflag_only_user);
    $build = $this->buildLink($this->ajaxFlag);
    $this->assertContains('flag/flag.link_ajax', $build['#attached']['library'] ?? []);
    $this->assertContains('use-ajax', $build['#attributes']['class'] ?? []);
  }

  /**
   * Tests no library is attached for an unflag action the user may not perform.
   */
  public function testUnflagDeniedLibraryAttachment(): void {
    // A user with only the flag permission who has already flagged gets the
    // unflag denied text instead of a link, so no library is attached.
    $flag_only_user = $this->createUser(['flag test_ajax_flag']);
    $this->flagService->flag($this->ajaxFlag, $this->node, $flag_only_user);
    $this->assertFalse($this->ajaxFlag->actionAccess('unflag', $flag_only_user, $this->node)->isAllowed());
    $this->setCurrentUser($flag_only_user);
    $build = $this->buildLink($this->ajaxFlag);
    $this->assertArrayHasKey('#unflag_denied_text', $build);
    $this->assertNotContains('flag/flag.link_ajax', $build['#attached']['library'] ?? []);
    $this->assertNotContains('use-ajax', $build['#attributes']['class'] ?? []);
  }

  /**
   * Tests the dialog library is only attached for users who may flag.
   */
  public function testDialogLibraryAttachment(): void {
    // A user who may flag gets the dialog attributes.
    $allowed_user = $this->createUser([
      'flag test_dialog_flag',
      'unflag test_dialog_flag',
    ]);
    $this->assertTrue($this->dialogFlag->actionAccess('flag', $allowed_user, $this->node)->isAllowed());
    $this->setCurrentUser($allowed_user);
    $build = $this->buildLink($this->dialogFlag);
    $this->assertContains('core/drupal.ajax', $build['#attached']['library'] ?? []);
    $this->assertContains('use-ajax', $build['#attributes']['class'] ?? []);
    $this->assertSame('modal', $build['#attributes']['data-dialog-type'] ?? NULL);

    // Users who may not flag get no dialog attributes at all.
    foreach ([new AnonymousUserSession(), $this->createUser()] as $denied_user) {
      $this->assertFalse($this->dialogFlag->actionAccess('flag', $denied_user, $this->node)->isAllowed());
      $this->setCurrentUser($denied_user);
      $build = $this->buildLink($this->dialogFlag);
      $this->assertNotContains('core/drupal.ajax', $build['#attached']['library'] ?? []);
      $this->assertNotContains('use-ajax', $build['#attributes']['class'] ?? []);
      $this->assertArrayNotHasKey('data-dialog-type', $build['#attributes'] ?? []);
    }
  }

  /**
   * Builds the flag link render array for the current user.
   */
  private function buildLink(FlagInterface $flag): array {
    return $flag->getLinkTypePlugin()->getAsFlagLink($flag, $this->node, 'default');
  }

}
