<?php

declare(strict_types=1);

namespace Drupal\Tests\flag\Kernel;

use Drupal\Core\Cache\CacheableDependencyInterface;
use Drupal\Core\Session\AnonymousUserSession;
use Drupal\flag\FlagInterface;
use Drupal\node\Entity\Node;
use Drupal\node\Entity\NodeType;
use Symfony\Component\HttpFoundation\Request;

/**
 * Tests the flood control of flags.
 *
 * @group flag
 */
class FlagFloodControlTest extends FlagKernelTestBase {

  /**
   * The flood control service.
   *
   * @var \Drupal\flag\Service\FlagFloodControlServiceInterface
   */
  protected $floodControl;

  /**
   * The flag under test, with a limit of two flaggings per hour.
   *
   * @var \Drupal\flag\FlagInterface
   */
  protected $flag;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->installSchema('user', ['users_data']);

    // The first user is uid 1, create that to avoid that our test users
    // implicitly have all permissions even those that don't exist.
    $this->createUser();

    NodeType::create(['type' => 'article', 'name' => 'Article'])->save();

    $this->flag = $this->createFlag('node', ['article']);
    $this->flag->setFloodControlActive(TRUE);
    $this->flag->setFloodControlLimit(2);
    $this->flag->setFloodControlWindow(3600);
    $this->flag->save();

    $this->floodControl = \Drupal::service('flag.flood_control');
  }

  /**
   * Creates a user who may flag and unflag the flag under test.
   *
   * @param array $extraPermissions
   *   (optional) Additional permissions for the user.
   *
   * @return \Drupal\user\UserInterface
   *   The user.
   */
  protected function createFlagger(array $extraPermissions = []) {
    return $this->createUser(array_merge([
      'flag ' . $this->flag->id(),
      'unflag ' . $this->flag->id(),
    ], $extraPermissions));
  }

  /**
   * Creates an article node.
   *
   * @return \Drupal\node\NodeInterface
   *   The node.
   */
  protected function createArticle() {
    $node = Node::create(['type' => 'article', 'title' => $this->randomMachineName()]);
    $node->save();
    return $node;
  }

  /**
   * Flags a number of new articles on behalf of an account.
   *
   * @param \Drupal\Core\Session\AccountInterface $account
   *   The account that flags.
   * @param int $count
   *   The number of articles to flag.
   *
   * @return \Drupal\flag\FlaggingInterface[]
   *   The flaggings.
   */
  protected function flagArticles($account, int $count): array {
    $flaggings = [];
    for ($i = 0; $i < $count; $i++) {
      $flaggings[] = $this->flagService->flag($this->flag, $this->createArticle(), $account);
    }
    return $flaggings;
  }

  /**
   * Counts the flood events registered for an account and the flag.
   *
   * The flood API offers no way to read the events, so the count is probed
   * with increasing thresholds.
   *
   * @param \Drupal\Core\Session\AccountInterface $account
   *   The account.
   *
   * @return int
   *   The number of registered events within the time window.
   */
  protected function countFloodEvents($account): int {
    $identifier = $this->floodControl->createIdentifier($this->flag->id(), $account);
    $count = 0;
    while (!\Drupal::flood()->isAllowed('flag.flagging', $count + 1, $this->flag->getFloodControlWindow(), $identifier)) {
      $count++;
    }
    return $count;
  }

  /**
   * Tests that new flags have flood control disabled with sensible defaults.
   */
  public function testDefaults(): void {
    $flag = $this->createFlag('node', ['article']);

    $this->assertFalse($flag->getFloodControlActive());
    $this->assertSame(FlagInterface::DEFAULT_FLOOD_CONTROL_LIMIT, $flag->getFloodControlLimit());
    $this->assertSame(FlagInterface::DEFAULT_FLOOD_CONTROL_WINDOW, $flag->getFloodControlWindow());

    $config = $this->config('flag.flag.' . $flag->id());
    $this->assertFalse($config->get('flood_control_active'));
    $this->assertSame(FlagInterface::DEFAULT_FLOOD_CONTROL_LIMIT, $config->get('flood_control_limit'));
    $this->assertSame(FlagInterface::DEFAULT_FLOOD_CONTROL_WINDOW, $config->get('flood_control_window'));
  }

  /**
   * Tests that nothing is limited while flood control is inactive.
   */
  public function testInactiveFloodControl(): void {
    $this->flag->setFloodControlActive(FALSE);
    $this->flag->save();

    $user = $this->createFlagger();
    $this->flagArticles($user, 3);

    $this->assertSame(0, $this->countFloodEvents($user));
    $this->assertTrue($this->flag->actionAccess('flag', $user, $this->createArticle())->isAllowed());
  }

  /**
   * Tests that flagging is forbidden once the limit is reached.
   */
  public function testLimitReached(): void {
    $user = $this->createFlagger();
    $article = $this->createArticle();

    $this->flagArticles($user, 1);
    $this->assertTrue($this->flag->actionAccess('flag', $user, $article)->isAllowed());

    $flaggings = $this->flagArticles($user, 1);
    $this->assertFalse($this->flag->actionAccess('flag', $user, $article)->isAllowed());

    // Unflagging stays possible, as flood control only limits flagging.
    $this->assertTrue($this->flag->actionAccess('unflag', $user, $flaggings[0]->getFlaggable())->isAllowed());
  }

  /**
   * Tests that the limit does not apply to users who may bypass it.
   */
  public function testBypassPermission(): void {
    $user = $this->createFlagger(['bypass flagging flood control']);
    $this->flagArticles($user, 3);

    // Flaggings of users who may bypass the limit are not registered.
    $this->assertSame(0, $this->countFloodEvents($user));
    $this->assertTrue($this->flag->actionAccess('flag', $user, $this->createArticle())->isAllowed());
  }

  /**
   * Tests that flagging is possible again after the time window expired.
   */
  public function testWindowExpires(): void {
    $this->flag->setFloodControlWindow(2);
    $this->flag->save();

    $user = $this->createFlagger();
    $this->flagArticles($user, 2);
    $article = $this->createArticle();
    $this->assertFalse($this->flag->actionAccess('flag', $user, $article)->isAllowed());

    // The kernel test flood backend works with the real time, so wait until
    // the time window has passed.
    usleep(2100000);

    $this->assertTrue($this->flag->actionAccess('flag', $user, $article)->isAllowed());
  }

  /**
   * Tests that every user has an own limit.
   */
  public function testUsersAreIndependent(): void {
    $alice = $this->createFlagger();
    $bob = $this->createFlagger();
    $article = $this->createArticle();

    $this->flagArticles($alice, 2);

    $this->assertFalse($this->flag->actionAccess('flag', $alice, $article)->isAllowed());
    $this->assertTrue($this->flag->actionAccess('flag', $bob, $article)->isAllowed());
  }

  /**
   * Tests that the flagging owner, not the current user, is limited.
   */
  public function testFlaggingOwnerIsRegistered(): void {
    $alice = $this->createFlagger();
    $bob = $this->createFlagger();
    $article = $this->createArticle();

    // Bob is the current user, but the flaggings belong to Alice.
    $this->setCurrentUser($bob);
    $this->flagArticles($alice, 2);

    $this->assertFalse($this->flag->actionAccess('flag', $alice, $article)->isAllowed());
    $this->assertTrue($this->flag->actionAccess('flag', $bob, $article)->isAllowed());
  }

  /**
   * Tests that updating an existing flagging does not count as flagging.
   */
  public function testUpdatingFlaggingIsNotRegistered(): void {
    $user = $this->createFlagger();
    $flagging = $this->flagArticles($user, 1)[0];
    $this->assertSame(1, $this->countFloodEvents($user));

    $flagging->save();
    $flagging->save();

    $this->assertSame(1, $this->countFloodEvents($user));
    $this->assertTrue($this->flag->actionAccess('flag', $user, $this->createArticle())->isAllowed());
  }

  /**
   * Tests that anonymous users are limited per IP address.
   */
  public function testAnonymousUsersAreSeparatedByIp(): void {
    $anonymous = new AnonymousUserSession();
    $requestStack = \Drupal::requestStack();

    $requestStack->push(Request::create('/', 'GET', [], [], [], ['REMOTE_ADDR' => '192.0.2.1']));
    $this->floodControl->register($this->flag, $anonymous);
    $this->floodControl->register($this->flag, $anonymous);
    $this->assertFalse($this->floodControl->access($this->flag, $anonymous)->isAllowed());
    $requestStack->pop();

    $requestStack->push(Request::create('/', 'GET', [], [], [], ['REMOTE_ADDR' => '192.0.2.2']));
    $access = $this->floodControl->access($this->flag, $anonymous);
    $this->assertTrue($access->isAllowed());
    $this->assertInstanceOf(CacheableDependencyInterface::class, $access);
    $this->assertContains('ip', $access->getCacheContexts());
    $requestStack->pop();
  }

}
