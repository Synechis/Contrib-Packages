<?php

declare(strict_types=1);

namespace Drupal\Tests\flag\Kernel;

use Drupal\flag\Cron\FlagCronService;
use Drupal\flag\Entity\Flag;

/**
 * Tests the Flag Cron Service.
 *
 * @group flag
 */
class FlagCronServiceTest extends FlagKernelTestBase {

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'system',
    'flag',
    'user',
  ];

  /**
   * The FlagCronService service.
   *
   * @var \Drupal\flag\Cron\FlagCronService
   */
  protected FlagCronService $flagCronService;

  /**
   * Flag.
   *
   * @var \Drupal\flag\Entity\Flag
   */
  protected $flag;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    // Get the flag cron service.
    $this->flagCronService = $this->container->get('flag.cron_service');

    // Set up flag with anonymous deletion enabled.
    $this->flag = Flag::create([
      'id' => 'test',
      'label' => 'Test Flag',
      'entity_type' => 'node',
      'flag_type' => 'entity:node',
      'link_type' => 'reload',
      'flagTypeConfig' => [],
      'linkTypeConfig' => [],
      'is_anon_enabled' => TRUE,
      'cron_batch_size' => 0,
    ]);
    $this->flag->save();

  }

  /**
   * Tests cron service finds and removed expired anonymous flags.
   */
  public function testCronService():void {
    // Populate data.
    $this->createData($this->flag->id());
    // Confirm flags exist before running cron.
    $pre_flags = $this->container->get('entity_type.manager')->getStorage('flagging')->loadByProperties(['uid' => 0]);
    $this->assertCount(5, $pre_flags, 'There are 5 expired anonymous flags before cron.');

    // Run the flag cron service.
    $this->flagCronService->runCronLogic();

    // Confirm flags are deleted.
    $post_flags = $this->container->get('entity_type.manager')->getStorage('flagging')->loadByProperties(['uid' => 0]);
    $this->assertEmpty($post_flags, 'All expired anonymous flags have been deleted by cron.');
  }

  /**
   * Tests batch size setting is working correctly.
   */
  public function testBatchSize() {
    // Create new flag with token cron batch size set.
    $flag_batch = Flag::create([
      'id' => 'test_batch_size',
      'label' => 'Test Flag Batch Size',
      'entity_type' => 'node',
      'flag_type' => 'entity:node',
      'link_type' => 'reload',
      'flagTypeConfig' => [],
      'linkTypeConfig' => [],
      'is_anon_enabled' => TRUE,
      'cron_batch_size' => 2,
    ]);
    $flag_batch->save();

    // Populate data.
    $this->createData($flag_batch->id());

    // Confirm flags exist before running cron.
    $pre_flags = $this->container->get('entity_type.manager')->getStorage('flagging')->loadByProperties(['uid' => 0]);
    $this->assertCount(5, $pre_flags, 'There are 5 expired anonymous flags before cron.');

    // Run cron logic once: should delete only 2 due to batch size.
    $this->flagCronService->runCronLogic();
    $remaining_flags = $this->container->get('entity_type.manager')->getStorage('flagging')->loadByProperties(['uid' => 0]);
    $this->assertCount(3, $remaining_flags, '2 flags deleted, 3 remain after first run.');

    // Run cron logic again: delete another 2.
    $this->flagCronService->runCronLogic();
    $remaining_flags = $this->container->get('entity_type.manager')->getStorage('flagging')->loadByProperties(['uid' => 0]);
    $this->assertCount(1, $remaining_flags, '2 more flags deleted, 1 remains after second run.');

    // Final run: delete the last one.
    $this->flagCronService->runCronLogic();
    $remaining_flags = $this->container->get('entity_type.manager')->getStorage('flagging')->loadByProperties(['uid' => 0]);
    $this->assertEmpty($remaining_flags, 'All expired anonymous flags deleted after final run.');
  }

  /**
   * Tests disabled anonymous flags is working correctly.
   */
  public function testDisabledDeletion(): void {
    // Create new flag with token cron batch size set.
    $flag_no_delete = Flag::create([
      'id' => 'test_no_delete',
      'label' => 'Test No Delete Flags',
      'entity_type' => 'node',
      'flag_type' => 'entity:node',
      'link_type' => 'reload',
      'flagTypeConfig' => [],
      'linkTypeConfig' => [],
      'is_anon_enabled' => FALSE,
      'cron_batch_size' => 0,
    ]);
    $flag_no_delete->save();

    // Populate data.
    $this->createData($flag_no_delete->id());

    // Confirm flags exist before running cron.
    $pre_flags = $this->container->get('entity_type.manager')->getStorage('flagging')->loadByProperties(['uid' => 0]);
    $this->assertCount(5, $pre_flags, 'There are 5 expired anonymous flags before cron.');

    // Run the flag cron service.
    $this->flagCronService->runCronLogic();

    // Confirm flags are NOT deleted.
    $post_flags = $this->container->get('entity_type.manager')->getStorage('flagging')->loadByProperties(['uid' => 0]);
    $this->assertNotEmpty($post_flags, 'All anonymous flags have NOT been deleted by cron.');
  }

  /**
   * Create dummy data for testing.
   *
   * @param string $flagId
   *   The flag id.
   */
  private function createData(string $flagId): void {
    // Create 5 anonymous flaggings expired more than a minute ago.
    $flagging_storage = $this->container->get('entity_type.manager')->getStorage('flagging');
    $max_lifetime = (int) ini_get('session.gc_maxlifetime');
    for ($i = 0; $i < 5; $i++) {
      $flagging_storage->create([
        'flag_id' => $flagId,
        'entity_type' => 'node',
        'entity_id' => $i + 1,
        'uid' => 0,
        'created' => time() - ($max_lifetime + 60 + $i),
      ])->save();
    }
  }

}
