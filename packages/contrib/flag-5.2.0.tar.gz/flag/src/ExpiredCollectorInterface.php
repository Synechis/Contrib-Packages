<?php

namespace Drupal\flag;

/**
 * Interface for services that collect and delete expired anonymous flaggings.
 */
interface ExpiredCollectorInterface {

  /**
   * Collects expired anonymous flaggings.
   *
   * @param \Drupal\flag\FlagInterface $flag
   *   The flag entity.
   * @param int $limit
   *   Number of flaggings to fetch.
   *
   * @return \Drupal\flag\FlaggingInterface[]
   *   The expired anonymous flaggings.
   *
   * @throws \Drupal\Component\Plugin\Exception\InvalidPluginDefinitionException
   * @throws \Drupal\Component\Plugin\Exception\PluginNotFoundException
   */
  public function collectExpiredAnon(FlagInterface $flag, int $limit = 0): array;

  /**
   * Deletes the given flagging entities.
   *
   * @param array $flaggings
   *   The flaggings.
   *
   * @throws \Drupal\Component\Plugin\Exception\InvalidPluginDefinitionException
   * @throws \Drupal\Component\Plugin\Exception\PluginNotFoundException
   * @throws \Drupal\Core\Entity\EntityStorageException
   */
  public function deleteMultipleFlagging(array $flaggings): void;

}
