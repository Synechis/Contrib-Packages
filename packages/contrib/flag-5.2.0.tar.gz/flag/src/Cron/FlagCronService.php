<?php

namespace Drupal\flag\Cron;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Logger\LoggerChannelTrait;
use Drupal\flag\ExpiredCollectorInterface;

/**
 * Flag cron service that handles anonymous flag removal logic.
 */
class FlagCronService {

  use LoggerChannelTrait;

  public function __construct(
    protected EntityTypeManagerInterface $entityTypeManager,
    protected ExpiredCollectorInterface $collector,
  ) {
  }

  /**
   * Removes expired flagging.
   *
   * @throws \Drupal\Component\Plugin\Exception\InvalidPluginDefinitionException
   * @throws \Drupal\Component\Plugin\Exception\PluginNotFoundException
   * @throws \Drupal\Core\Entity\EntityStorageException
   */
  public function runCronLogic(): void {
    $flags = $this->entityTypeManager->getStorage('flag')->loadMultiple();

    /** @var \Drupal\flag\FlagInterface $flag */
    foreach ($flags as $flag) {
      if (!$flag->getAnonFlagsEnabled()) {
        continue;
      }

      $limit = $flag->getCronBatchSize();
      $expired_flaggings = $this->collector->collectExpiredAnon($flag, $limit);
      // Delete only if there are expired flaggings.
      if (!empty($expired_flaggings)) {
        $this->collector->deleteMultipleFlagging($expired_flaggings);
        $this->getLogger('flag')->notice('Deleted @count expired anonymous flaggings for flag @flag in cron.', [
          '@count' => count($expired_flaggings),
          '@flag' => $flag->id(),
        ]);
      }
    }
  }

}
