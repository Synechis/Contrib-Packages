<?php

namespace Drupal\flag\Service;

use Drupal\Core\Access\AccessResultInterface;
use Drupal\Core\Session\AccountInterface;
use Drupal\flag\FlagInterface;

/**
 * Interface for the Flag Flood Control service.
 */
interface FlagFloodControlServiceInterface {

  /**
   * Checks whether an account may use a flag with regard to flood control.
   *
   * @param \Drupal\flag\FlagInterface $flag
   *   The flag object.
   * @param \Drupal\Core\Session\AccountInterface $account
   *   The account to check.
   *
   * @return \Drupal\Core\Access\AccessResultInterface
   *   Allowed if flood control is inactive, not exceeded or bypassed by the
   *   account. Forbidden otherwise.
   */
  public function access(FlagInterface $flag, AccountInterface $account): AccessResultInterface;

  /**
   * Registers a flagging with the flood api for a flag.
   *
   * Nothing is registered if flood control is inactive for the flag or the
   * account may bypass it.
   *
   * @param \Drupal\flag\FlagInterface $flag
   *   The flag object.
   * @param \Drupal\Core\Session\AccountInterface|null $account
   *   (optional) The account to register. Defaults to the current user.
   */
  public function register(FlagInterface $flag, ?AccountInterface $account = NULL): void;

  /**
   * Returns an identifier based on the account and flag id.
   *
   * @param int|string $flagId
   *   The id of the flag.
   * @param \Drupal\Core\Session\AccountInterface|null $account
   *   (optional) The account. Defaults to the current user.
   *
   * @return string
   *   The constructed identifier.
   */
  public function createIdentifier($flagId, ?AccountInterface $account = NULL): string;

}
