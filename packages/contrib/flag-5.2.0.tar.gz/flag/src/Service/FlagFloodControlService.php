<?php

namespace Drupal\flag\Service;

use Drupal\Core\Access\AccessResult;
use Drupal\Core\Access\AccessResultInterface;
use Drupal\Core\Cache\CacheTagsInvalidatorInterface;
use Drupal\Core\Flood\FloodInterface;
use Drupal\Core\Session\AccountInterface;
use Drupal\flag\FlagInterface;
use Symfony\Component\HttpFoundation\RequestStack;

/**
 * Implements flood control for flags.
 */
class FlagFloodControlService implements FlagFloodControlServiceInterface {

  public function __construct(
    protected AccountInterface $currentUser,
    protected FloodInterface $flood,
    protected CacheTagsInvalidatorInterface $cacheTagsInvalidator,
    protected RequestStack $requestStack,
  ) {
  }

  /**
   * {@inheritdoc}
   */
  public function access(FlagInterface $flag, AccountInterface $account): AccessResultInterface {
    $result = AccessResult::allowed()
      ->addCacheableDependency($flag)
      ->cachePerPermissions();

    if (!$flag->getFloodControlActive() || $account->hasPermission('bypass flagging flood control')) {
      return $result;
    }

    // The result changes whenever the account flags, so tie it to a tag that
    // register() invalidates.
    $result->addCacheContexts(['user'])
      ->addCacheTags([$this->getCacheTag($flag, $account)]);
    if ($account->isAnonymous()) {
      // Anonymous users are told apart by their IP address.
      $result->addCacheContexts(['ip']);
    }

    $identifier = $this->createIdentifier($flag->id(), $account);
    if ($this->flood->isAllowed('flag.flagging', $flag->getFloodControlLimit(), $flag->getFloodControlWindow(), $identifier)) {
      return $result;
    }

    // Flood events expire with time, which cache tags cannot express, so the
    // forbidden result must not be cached.
    return AccessResult::forbidden('Flag flood control limit exceeded.')
      ->addCacheableDependency($result)
      ->setCacheMaxAge(0);
  }

  /**
   * {@inheritdoc}
   */
  public function register(FlagInterface $flag, ?AccountInterface $account = NULL): void {
    $account = $account ?: $this->currentUser;
    if (!$flag->getFloodControlActive() || $account->hasPermission('bypass flagging flood control')) {
      return;
    }
    $identifier = $this->createIdentifier($flag->id(), $account);
    $this->flood->register('flag.flagging', $flag->getFloodControlWindow(), $identifier);
    $this->cacheTagsInvalidator->invalidateTags([$this->getCacheTag($flag, $account)]);
  }

  /**
   * {@inheritdoc}
   */
  public function createIdentifier($flagId, ?AccountInterface $account = NULL): string {
    $account = $account ?: $this->currentUser;
    // All anonymous users share the uid 0, so they must not share a flood
    // bucket. Like core's flood control, identify them by their IP address.
    $user = $account->isAnonymous()
      ? 'anonymous:' . ($this->requestStack->getCurrentRequest()?->getClientIp() ?? 'unknown')
      : $account->id();
    return $user . '-' . $flagId;
  }

  /**
   * Returns the cache tag for the flood state of an account and flag.
   */
  protected function getCacheTag(FlagInterface $flag, AccountInterface $account): string {
    return 'flag_flood:' . $this->createIdentifier($flag->id(), $account);
  }

}
