<?php

namespace Drupal\flag;

use Drupal\Component\Datetime\TimeInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;

/**
 * Collects and deletes expired anonymous flaggings.
 */
class ExpiredCollector implements ExpiredCollectorInterface {

  public function __construct(
    protected EntityTypeManagerInterface $entityTypeManager,
    protected TimeInterface $time,
  ) {
  }

  /**
   * Collects expired anonymous flaggings.
   *
   * @param \Drupal\flag\FlagInterface $flag
   *   The flag entity.
   * @param int $limit
   *   Number of flaggings to fetch.
   *
   * @return \Drupal\flag\FlaggingInterface[]
   *   The expired anonymous flaggings.
   *
   * @throws \Drupal\Component\Plugin\Exception\InvalidPluginDefinitionException
   * @throws \Drupal\Component\Plugin\Exception\PluginNotFoundException
   */
  public function collectExpiredAnon(FlagInterface $flag, int $limit = 0): array {
    $storage = $this->entityTypeManager->getStorage('flagging');
    $query = $storage->getQuery();
    $query->accessCheck(FALSE);
    $query->condition('flag_id', $flag->id());
    $query->condition('created', $this->time->getRequestTime() - (int) ini_get('session.gc_maxlifetime'), '<');
    $query->condition('uid', 0);
    // If limit available.
    if (!empty($limit)) {
      $query->range(0, $limit);
    }
    $ids = $query->execute();
    if (empty($ids)) {
      return [];
    }
    return array_values($storage->loadMultiple($ids));
  }

  /**
   * Deletes the given flagging entities.
   *
   * @param array $flaggings
   *   The flaggings.
   *
   * @throws \Drupal\Component\Plugin\Exception\InvalidPluginDefinitionException
   * @throws \Drupal\Component\Plugin\Exception\PluginNotFoundException
   * @throws \Drupal\Core\Entity\EntityStorageException
   */
  public function deleteMultipleFlagging(array $flaggings): void {
    $this->entityTypeManager->getStorage('flagging')->delete($flaggings);
  }

}
