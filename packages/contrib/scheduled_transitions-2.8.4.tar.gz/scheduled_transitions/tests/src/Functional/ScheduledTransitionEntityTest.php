<?php

declare(strict_types=1);

namespace Drupal\Tests\scheduled_transitions\Functional;

use Drupal\content_moderation\Plugin\WorkflowType\ContentModerationInterface;
use Drupal\Core\Cache\Cache;
use Drupal\scheduled_transitions\Form\ScheduledTransitionsSettingsForm as SettingsForm;
use Drupal\scheduled_transitions\Routing\ScheduledTransitionsRouteProvider;
use Drupal\scheduled_transitions_test\Entity\ScheduledTransitionsTestEntity;
use Drupal\Tests\BrowserTestBase;
use Drupal\Tests\content_moderation\Traits\ContentModerationTestTrait;
use Drupal\Tests\scheduled_transitions\Traits\ScheduledTransitionTestTrait;

/**
 * Tests an entity with scheduled transitions capabilities.
 *
 * @group scheduled_transitions
 */
class ScheduledTransitionEntityTest extends BrowserTestBase {

  use ContentModerationTestTrait;
  use ScheduledTransitionTestTrait;

  protected $defaultTheme = 'stark';

  protected static $modules = [
    'entity_test_revlog',
    'scheduled_transitions_test',
    'scheduled_transitions',
    'content_moderation',
    'workflows',
    'dynamic_entity_reference',
    'user',
    'block',
    'system',
  ];

  protected function setUp(): void {
    parent::setUp();
    $this->drupalPlaceBlock('local_tasks_block');
  }

  /**
   * Tests transition pages access depending on enabled entity type/bundle.
   */
  public function testAccessByBundle(): void {
    $this->enabledBundles([['st_entity_test', 'st_entity_test']]);

    $workflow = $this->createEditorialWorkflow();
    $plugin = $workflow->getTypePlugin();
    static::assertInstanceOf(ContentModerationInterface::class, $plugin);
    $plugin->addEntityTypeAndBundle('st_entity_test', 'st_entity_test');
    $workflow->save();

    /** @var \Drupal\user\UserInterface $currentUser */
    $currentUser = $this->drupalCreateUser([
      'administer st_entity_test entities',
      'use editorial transition create_new_draft',
      'use editorial transition publish',
      'use editorial transition archive',
      'view scheduled transitions st_entity_test st_entity_test',
    ]);
    $this->drupalLogin($currentUser);

    $entity = ScheduledTransitionsTestEntity::create([
      'type' => 'st_entity_test',
      'name' => 'foo',
    ]);
    $entity->save();

    $this->drupalGet($entity->toUrl(ScheduledTransitionsRouteProvider::LINK_TEMPLATE));
    $this->assertSession()->statusCodeEquals(200);

    \Drupal::configFactory()->getEditable('scheduled_transitions.settings')
      ->set('bundles', [])
      ->save(TRUE);
    Cache::invalidateTags([SettingsForm::SETTINGS_TAG]);

    $this->drupalGet($entity->toUrl(ScheduledTransitionsRouteProvider::LINK_TEMPLATE));
    $this->assertSession()->statusCodeEquals(403);
  }

}
