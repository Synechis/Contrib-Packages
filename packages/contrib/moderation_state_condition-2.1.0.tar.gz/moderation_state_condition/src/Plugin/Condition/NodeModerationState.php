<?php

namespace Drupal\moderation_state_condition\Plugin\Condition;

/**
 * Provides a 'Node Moderation State' condition.
 *
 * @Condition(
 *   id = "node_moderation_state_condition_moderation_state",
 *   label = @Translation("Node Moderation State"),
 *   context_definitions = {
 *     "node" = @ContextDefinition(
 *       "entity:node",
 *        label = @Translation("Node")
 *      )
 *   }
 * )
 */
class NodeModerationState extends ModerationStateBase {}
