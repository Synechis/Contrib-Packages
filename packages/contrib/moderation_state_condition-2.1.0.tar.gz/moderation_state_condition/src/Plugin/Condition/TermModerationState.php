<?php

namespace Drupal\moderation_state_condition\Plugin\Condition;

/**
 * Provides a 'Term Moderation State' condition.
 *
 * @Condition(
 *   id = "term_moderation_state_condition_moderation_state",
 *   label = @Translation("Term Moderation State"),
 *   context_definitions = {
 *     "taxonomy_term" = @ContextDefinition(
 *       "entity:taxonomy_term",
 *        label = @Translation("Taxonomy Term")
 *      )
 *   }
 * )
 */
class TermModerationState extends ModerationStateBase {

  /**
   * {@inheritdoc}
   */
  public function evaluate() {
    if (empty($this->configuration['moderation_states']) && !$this->isNegated()) {
      return TRUE;
    }

    $entity = $this->getContextValue('taxonomy_term');
    $moderation_state = $entity?->get('moderation_state')->getString();

    return in_array($moderation_state, $this->configuration['moderation_states']);
  }

}
