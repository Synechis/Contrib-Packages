# Moderation State Condition

A module that provides a condition plugin for moderation states.
