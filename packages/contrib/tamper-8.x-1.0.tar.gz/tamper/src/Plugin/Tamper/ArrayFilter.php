<?php

namespace Drupal\tamper\Plugin\Tamper;

use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\tamper\Attribute\Tamper;
use Drupal\tamper\Exception\TamperException;
use Drupal\tamper\ItemUsage;
use Drupal\tamper\TamperBase;
use Drupal\tamper\TamperableItemInterface;

/**
 * Plugin implementation for filtering data.
 */
#[Tamper(
  id: 'array_filter',
  label: new TranslatableMarkup('Filter items'),
  description: new TranslatableMarkup('Filter empty items from a list.'),
  category: new TranslatableMarkup('List'),
  handle_multiples: TRUE,
  itemUsage: ItemUsage::IGNORED,
)]
class ArrayFilter extends TamperBase {

  /**
   * {@inheritdoc}
   */
  public function tamper($data, ?TamperableItemInterface $item = NULL) {
    // Don't process empty values.
    if (empty($data)) {
      return $data;
    }

    if (!is_array($data)) {
      throw new TamperException('Input should be an array.');
    }
    return array_values(array_filter($data));
  }

  /**
   * {@inheritdoc}
   */
  public function multiple() {
    return TRUE;
  }

}
