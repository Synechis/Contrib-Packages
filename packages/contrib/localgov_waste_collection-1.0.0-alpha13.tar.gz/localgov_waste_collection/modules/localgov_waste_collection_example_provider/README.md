# LocalGov Waste collection example data provider

This module provides a very simple example data provider that can be used as the basis for custom data providers.

## How to use

- Enable the module and set it as the active data provider in the [parent module settings](../../README.md#configuration).
- Search for postcode `SF1 1AA` to see postcode search results.
- Search for any other postcode to see the no results page for address search.
- Select `9 Surveillance Circular` to see the no results page for schedule lookup.
- Select any other property to view, print, and download a waste collection schedule.

Note the address on the waste collection schedule will always be for the address `4 Surveillance Circular` (see the `getAddressFromUprn` method in `ExampleDataProvider.php`).
