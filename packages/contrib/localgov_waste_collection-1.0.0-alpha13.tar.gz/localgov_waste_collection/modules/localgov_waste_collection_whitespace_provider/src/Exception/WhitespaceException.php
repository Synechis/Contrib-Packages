<?php

namespace Drupal\localgov_waste_collection_whitespace_provider\Exception;

/**
 * Exception class for problems with calls to Whitespace.
 */
class WhitespaceException extends \Exception {

}
