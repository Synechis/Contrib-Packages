<?php

namespace Drupal\domain_path;

use Drupal\Core\Database\Connection;
use Drupal\domain\DomainNegotiatorInterface;
use Drupal\path_alias\AliasRepository;
use Drupal\path_alias\AliasRepositoryInterface;

/**
 * Domain-aware path alias lookup operations.
 *
 * Decorates path_alias.repository. The inherited core interface
 * methods (preloadPathAlias, lookupBySystemPath, lookupByAlias)
 * use getBaseQuery() which is overridden to include both
 * domain-specific and global aliases. This lets core's
 * AliasManager — with its AliasPrefixList filter, static cache,
 * and Fiber batching — handle domain aliases natively.
 *
 * The domain-specific methods (preloadPathAliasByDomain,
 * lookupBySystemPathAndDomain, lookupByAliasAndDomain) query a
 * single explicit domain and are used by the outbound processor
 * and uniqueness validators.
 *
 * @internal
 */
class DomainAliasRepository extends AliasRepository implements AliasRepositoryInterface, DomainAliasRepositoryInterface {

  /**
   * Constructs a DomainAliasRepository.
   *
   * @param \Drupal\path_alias\AliasRepositoryInterface $inner
   *   The decorated path alias repository.
   * @param \Drupal\Core\Database\Connection $connection
   *   A database connection for reading and writing path aliases.
   * @param \Drupal\domain\DomainNegotiatorInterface $domainNegotiator
   *   The domain negotiation context.
   */
  public function __construct(
    protected AliasRepositoryInterface $inner,
    Connection $connection,
    protected DomainNegotiatorInterface $domainNegotiator,
  ) {
    parent::__construct($connection);
  }

  /**
   * Returns a domain-aware base query with global fallback.
   *
   * When an active domain exists, includes both domain-specific and
   * global aliases. Domain-specific aliases are ordered first so
   * they take priority in the inherited lookup methods (via
   * array_reverse() in preloadPathAlias, or fetchAssoc() in
   * lookupBySystemPath/lookupByAlias).
   *
   * When no active domain exists (early bootstrap, CLI), returns
   * global aliases only.
   *
   * @return \Drupal\Core\Database\Query\SelectInterface
   *   A Select query object.
   */
  protected function getBaseQuery() {
    $query = parent::getBaseQuery();
    $domain_id = $this->domainNegotiator->getActiveId();
    if ($domain_id) {
      $or = $this->connection->condition('OR');
      $or->condition('base_table.domain_id', $domain_id);
      $or->isNull('base_table.domain_id');
      $query->condition($or);
      // Non-NULL (domain) sorts before NULL (global) in DESC.
      // After array_reverse(), domain aliases overwrite global.
      $query->orderBy('base_table.domain_id', 'DESC');
    }
    else {
      // Filter out aliases that are domain-specific.
      $query->isNull('base_table.domain_id');
    }
    return $query;
  }

  /**
   * Returns a base query filtered to a specific domain.
   *
   * Uses the unfiltered parent query (no domain_id condition)
   * and adds a condition for the given domain. Used by the
   * explicit-domain methods.
   *
   * @param string $domain_id
   *   The domain ID.
   *
   * @return \Drupal\Core\Database\Query\SelectInterface
   *   A Select query object.
   */
  protected function getDomainBaseQuery(string $domain_id) {
    $query = parent::getBaseQuery();
    $query->condition('base_table.domain_id', $domain_id);
    return $query;
  }

  /**
   * {@inheritdoc}
   */
  public function preloadPathAliasByDomain($preloaded, $domain_id, $langcode) {
    $select = $this->getDomainBaseQuery($domain_id)
      ->fields('base_table', ['path', 'alias']);

    if (!empty($preloaded)) {
      $conditions = $this->connection->condition('OR');
      foreach ($preloaded as $preloaded_item) {
        $conditions->condition('base_table.path', $this->connection->escapeLike($preloaded_item), 'LIKE');
      }
      $select->condition($conditions);
    }

    $this->addLanguageFallback($select, $langcode);

    $select->orderBy('base_table.id', 'DESC');

    // We want the most recently created alias for each source, however that
    // will be at the start of the result-set, so fetch everything and reverse
    // it. Note that it would not be sufficient to reverse the ordering of the
    // 'base_table.id' column, as that would not guarantee other conditions
    // added to the query, such as those in ::addLanguageFallback, would be
    // reversed.
    // @todo Switch back to Drupal 11+ FetchAs::Associative when possible.
    $results = $select->execute()->fetchAll(\PDO::FETCH_ASSOC);
    $aliases = [];
    foreach (array_reverse($results) as $result) {
      $aliases[$result['path']] = $result['alias'];
    }

    return $aliases;
  }

  /**
   * {@inheritdoc}
   */
  public function lookupBySystemPathAndDomain($path, $domain_id, $langcode) {
    // See the queries above. Use LIKE for case-insensitive matching.
    $select = $this->getDomainBaseQuery($domain_id)
      ->fields('base_table', ['id', 'path', 'alias', 'domain_id', 'langcode'])
      ->condition('base_table.path', $this->connection->escapeLike($path), 'LIKE');

    $this->addLanguageFallback($select, $langcode);

    $select->orderBy('base_table.id', 'DESC');

    return $select->execute()->fetchAssoc() ?: NULL;
  }

  /**
   * {@inheritdoc}
   */
  public function lookupByAliasAndDomain($alias, $domain_id, $langcode) {
    // See the queries above. Use LIKE for case-insensitive matching.
    $select = $this->getDomainBaseQuery($domain_id)
      ->fields('base_table', ['id', 'path', 'alias', 'domain_id', 'langcode'])
      ->condition('base_table.alias', $this->connection->escapeLike($alias), 'LIKE');

    $this->addLanguageFallback($select, $langcode);

    $select->orderBy('base_table.id', 'DESC');

    return $select->execute()->fetchAssoc() ?: NULL;
  }

  /**
   * {@inheritdoc}
   */
  public function pathHasMatchingAlias($initial_substring) {
    return $this->inner->pathHasMatchingAlias($initial_substring);
  }

}
