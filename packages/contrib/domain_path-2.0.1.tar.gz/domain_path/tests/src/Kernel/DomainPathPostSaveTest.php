<?php

namespace Drupal\Tests\domain_path\Kernel;

use Drupal\node\Entity\Node;
use Drupal\node\Entity\NodeType;
use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;

/**
 * Tests DomainPathItem::postSave() CRUD operations.
 *
 * @group domain_path
 *
 * @phpstan-ignore-next-line
 */
#[Group('domain_path')]
#[RunTestsInSeparateProcesses]
class DomainPathPostSaveTest extends DomainPathKernelTestBase {

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'domain',
    'domain_path',
    'field',
    'node',
    'path',
    'path_alias',
    'system',
    'text',
    'user',
  ];

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->installEntitySchema('node');
    $this->installSchema('node', ['node_access']);

    NodeType::create([
      'type' => 'article',
      'name' => 'Article',
    ])->save();
  }

  /**
   * Sets an alias on a domain_path item for the given domain.
   *
   * @param \Drupal\node\Entity\Node $node
   *   The node entity.
   * @param string $domain_id
   *   The domain ID.
   * @param string $alias
   *   The alias to set.
   */
  protected function setDomainPathAlias(Node $node, string $domain_id, string $alias): void {
    $items = $node->get('domain_path');
    foreach ($items as $item) {
      if ($item->get('domain_id')->getValue() === $domain_id) {
        $item->set('alias', $alias);
        return;
      }
    }
  }

  /**
   * Tests saving a node creates a domain path alias.
   */
  public function testNodeSaveCreatesDomainPathAlias(): void {
    $domain_a = $this->domainIds[0];

    $node = Node::create([
      'type' => 'article',
      'title' => 'Test',
    ]);
    $this->setDomainPathAlias($node, $domain_a, '/my-alias');
    $node->save();

    $aliases = $this->pathAliasStorage()->loadByProperties([
      'path' => '/node/' . $node->id(),
      'domain_id' => $domain_a,
    ]);
    $this->assertCount(1, $aliases);
    $alias = reset($aliases);
    $this->assertEquals('/my-alias', $alias->getAlias());
  }

  /**
   * Tests updating a node updates the domain path alias.
   */
  public function testNodeSaveUpdatesDomainPathAlias(): void {
    $domain_a = $this->domainIds[0];

    $node = Node::create([
      'type' => 'article',
      'title' => 'Test',
    ]);
    $this->setDomainPathAlias($node, $domain_a, '/original');
    $node->save();

    $aliases = $this->pathAliasStorage()->loadByProperties([
      'path' => '/node/' . $node->id(),
      'domain_id' => $domain_a,
    ]);
    $original_pid = reset($aliases)->id();

    // Reload and update alias.
    $node = Node::load($node->id());
    $this->setDomainPathAlias($node, $domain_a, '/updated');
    $node->save();

    $aliases = $this->pathAliasStorage()->loadByProperties([
      'path' => '/node/' . $node->id(),
      'domain_id' => $domain_a,
    ]);
    $this->assertCount(1, $aliases);
    $alias = reset($aliases);
    $this->assertEquals('/updated', $alias->getAlias());
    $this->assertEquals($original_pid, $alias->id());
  }

  /**
   * Tests clearing an alias deletes the path alias entity.
   */
  public function testNodeSaveClearingAliasDeletesPathAlias(): void {
    $domain_a = $this->domainIds[0];

    $node = Node::create([
      'type' => 'article',
      'title' => 'Test',
    ]);
    $this->setDomainPathAlias($node, $domain_a, '/to-delete');
    $node->save();

    // Verify alias exists.
    $aliases = $this->pathAliasStorage()->loadByProperties([
      'path' => '/node/' . $node->id(),
      'domain_id' => $domain_a,
    ]);
    $this->assertCount(1, $aliases);

    // Reload and clear alias.
    $node = Node::load($node->id());
    $this->setDomainPathAlias($node, $domain_a, '');
    $node->save();

    // Verify alias is deleted.
    $this->pathAliasStorage()->resetCache();
    $aliases = $this->pathAliasStorage()->loadByProperties([
      'path' => '/node/' . $node->id(),
      'domain_id' => $domain_a,
    ]);
    $this->assertCount(0, $aliases);
  }

  /**
   * Tests saving without alias creates no domain path alias.
   */
  public function testNodeSaveWithEmptyAliasCreatesNothing(): void {
    $domain_a = $this->domainIds[0];

    $node = Node::create([
      'type' => 'article',
      'title' => 'Test',
    ]);
    // Do not set any alias — save with defaults.
    $node->save();

    $aliases = $this->pathAliasStorage()->loadByProperties([
      'path' => '/node/' . $node->id(),
      'domain_id' => $domain_a,
    ]);
    $this->assertCount(0, $aliases);
  }

}
