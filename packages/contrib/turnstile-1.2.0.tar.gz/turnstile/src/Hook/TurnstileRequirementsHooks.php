<?php

declare(strict_types=1);

namespace Drupal\turnstile\Hook;

use Drupal\Core\Extension\Requirement\RequirementSeverity;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\Core\Link;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\Core\Url;

/**
 * Requirements hook implementations for the Turnstile module.
 *
 * Hook classes are only discovered on Drupal 11.1+ and the
 * runtime_requirements hook is only invoked on Drupal 11.2+; older cores use
 * the legacy turnstile_requirements() implementation in turnstile.install
 * instead. Both implementations use the same 'turnstile' requirements key, so
 * on Drupal 11.2 (which invokes both) the entry is not duplicated.
 */
class TurnstileRequirementsHooks {

  use StringTranslationTrait;

  /**
   * Implements hook_runtime_requirements().
   */
  #[Hook('runtime_requirements')]
  public function runtimeRequirements(): array {
    $requirements = [];
    $turnstile_keys = turnstile_keys();

    if (!$turnstile_keys || empty($turnstile_keys['site_key']) || empty($turnstile_keys['secret_key'])) {
      $url_key_config = Url::fromUri('internal:/admin/config/system/keys');
      $url_turnstile_config = Url::fromUri('internal:/admin/config/people/captcha/turnstile');

      $link_key_config = Link::fromTextAndUrl($this->t('use the Key module'), $url_key_config)->toString();
      $link_turnstile_config = Link::fromTextAndUrl($this->t('Turnstile configuration page'), $url_turnstile_config)->toString();

      $requirements['turnstile'] = [
        'title' => $this->t('Turnstile'),
        'description' => $this->t('You must @link_to_key to create a Turnstile Site and Secret Keys, then select it in the @link_to_turnstile.', [
          '@link_to_key' => $link_key_config,
          '@link_to_turnstile' => $link_turnstile_config,
        ]),
        'severity' => RequirementSeverity::Error,
      ];
    }
    return $requirements;
  }

}
