<?php

namespace Drupal\addtocal_augment\Controller;

use Drupal\addtocal_augment\IcsLink;
use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;

/**
 * A controller that outputs text/calendar data that has been passed in its URL.
 *
 * This is a 'dumb' controller that outputs any iCalendar data that sets a
 * text/calendar Content-Type header and then outputs unmodified content that
 * was generated * in AddToCal::buildLinks().
 *
 * The URL to this controller includes {ics} and {signature} path attributes:
 *
 *   * $ics is the full buildLinks() output for iCal or Outlook, as generated
 *     by buildLinks(). It's base64-encoded in transit.
 *
 *   * $signature is used to validate that the contents are unmodified.
 */
class IcsController extends ControllerBase {

  public function __construct(
    protected IcsLink $icsLink,
  ) {}

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container): static {
    return new static($container->get('addtocal_augment.ics_link'));
  }

  /**
   * Validate $ics contents and output them as-is.
   */
  public function renderIcs(string $ics, string $signature): Response {
    $ical = $this->icsLink->verify($ics, $signature);
    if ($ical === NULL) {
      throw new AccessDeniedHttpException();
    }

    $response = new Response($ical);
    $response->headers->set('Content-Type', 'text/calendar; charset=utf-8');
    $response->headers->set('Content-Disposition', 'attachment; filename="event.ics"');
    $response->headers->set('X-Content-Type-Options', 'nosniff');
    return $response;
  }

}
