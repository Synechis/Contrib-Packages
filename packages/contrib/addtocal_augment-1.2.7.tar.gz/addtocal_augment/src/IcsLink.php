<?php

namespace Drupal\addtocal_augment;

use Drupal\Component\Utility\Crypt;
use Drupal\Core\PrivateKey;
use Drupal\Core\Site\Settings;
use Drupal\Core\Url;

/**
 * Builds and verifies signed URLs for serving generated iCal content.
 *
 * Generates a link to the IcsController URL that includes.
 */
class IcsLink {

  public function __construct(
    protected PrivateKey $privateKey,
  ) {}

  /**
   * Build a signed URL that will serve the given iCal string.
   */
  public function buildUrl(string $ical_string): Url {
    $ics = $this->encode($ical_string);
    return Url::fromRoute('addtocal_augment.render_ics', [
      'ics' => $ics,
      'signature' => $this->sign($ics),
    ]);
  }

  /**
   * Verify a payload/signature pair and return its decoded iCal string.
   *
   * @return string|null
   *   The decoded iCal string, or NULL if verification or decoding fails.
   */
  public function verify(string $payload, string $signature): ?string {
    if (!hash_equals($this->sign($payload), $signature)) {
      return NULL;
    }
    return $this->decode($payload);
  }

  /**
   * Sign a URL payload using Drupal's private key.
   *
   * @param string $payload
   *   The contents that the ics controller will output.
   *
   * @return string
   *   A signature unique to this payload/key combination.
   */
  protected function sign(string $payload): string {
    $key = $this->privateKey->get() . Settings::getHashSalt();
    return Crypt::hmacBase64($payload, $key);
  }

  /**
   * Base64-encode data such that it's appropriate for use as a URL component.
   *
   * @param string $data
   *   The contents of an iCal string, probably.
   *
   * @return string
   *   Base64-encoded string for use in a /path/{ics}/ URL.
   */
  protected function encode(string $data): string {
    return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
  }

  /**
   * Base64-decode a URL component into decoded output.
   *
   * @param string $data
   *   Base64-encoded string as found in a /path/{ics}/ URL.
   *
   * @return string
   *   Decoded text, most likely iCal output that will render in its controller.
   */
  protected function decode(string $data): ?string {
    $remainder = strlen($data) % 4;
    if ($remainder) {
      $data .= str_repeat('=', 4 - $remainder);
    }
    $decoded = base64_decode(strtr($data, '-_', '+/'), TRUE);
    return $decoded === FALSE ? NULL : $decoded;
  }

}
