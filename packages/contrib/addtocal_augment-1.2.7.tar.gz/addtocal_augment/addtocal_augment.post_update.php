<?php

/**
 * @file
 * Post update functions for the Add to Calendar Date Augmenter module.
 */

/**
 * Rebuild the container to register the new ICS link service and route.
 */
function addtocal_augment_post_update_ics_link_service(): void {
  // Empty post-update hook: running it forces a cache and container rebuild.
}
