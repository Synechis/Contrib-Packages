<?php

declare(strict_types=1);

namespace Drupal\Tests\addtocal_augment\Kernel;

use Drupal\addtocal_augment\Plugin\DateAugmenter\AddToCal;
use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\entity_test\Entity\EntityTest;
use Drupal\KernelTests\KernelTestBase;
use PHPUnit\Framework\Attributes\Group;

/**
 * Tests the markup rendered for add to calendar links.
 *
 * @coversDefaultClass \Drupal\addtocal_augment\Plugin\DateAugmenter\AddToCal
 * @group addtocal_augment
 */
#[Group('addtocal_augment')]
class AddToCalRenderTest extends KernelTestBase {

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'system',
    'user',
    'entity_test',
    'date_augmenter',
    'addtocal_augment',
  ];

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();
    $this->installEntitySchema('user');
    $this->installEntitySchema('entity_test');
    $this->container->get('router.builder')->rebuild();
  }

  /**
   * Tests the links rendered by both the inline and modal templates.
   */
  public function testRenderedLinks(): void {
    $plugin = AddToCal::create($this->container, [], 'addtocal', []);
    $entity = EntityTest::create(['name' => 'Kernel test event']);
    $timezone = new \DateTimeZone('America/Chicago');

    foreach (['inline' => '', 'modal' => 'modal'] as $variant => $target) {
      // Use dates far in the future so the event is never filtered as past.
      $start = DrupalDateTime::createFromFormat('Y-m-d H:i:s', '2099-10-29 15:00:00', $timezone);
      $end = DrupalDateTime::createFromFormat('Y-m-d H:i:s', '2099-10-29 16:00:00', $timezone);
      $output = [];
      $plugin->augmentOutput($output, $start, $end, [
        'entity' => $entity,
        'settings' => [
          'label' => 'Add to calendar',
          'target' => $target,
        ],
      ]);
      $this->assertArrayHasKey('addtocal', $output, "$variant: links were added");
      $this->render($output);

      foreach (['ical', 'outlook'] as $service) {
        $links = $this->cssSelect("a.addtocal__$service");
        $this->assertCount(1, $links, "$variant: one $service link");
        $link = $links[0];
        $href = (string) $link['href'];

        $this->assertMatchesRegularExpression('@^/([^/]+/)*addtocal-augment/ics/[A-Za-z0-9_-]+/[A-Za-z0-9_-]+$@', $href, "$variant: $service link is a relative ICS controller path");
        $this->assertSame('nofollow', (string) $link['rel'], "$variant: $service link is nofollow");
        $this->assertFalse(isset($link['download']), "$variant: $service link has no download attribute");

        // The href must carry a valid signed payload for this event.
        [$ics, $signature] = array_slice(explode('/', $href), -2);
        $ical = $this->container->get('addtocal_augment.ics_link')->verify($ics, $signature);
        $this->assertNotNull($ical, "$variant: $service link signature is valid");
        $this->assertStringContainsString("\r\nSUMMARY:Kernel test event\r\n", $ical);
      }

      $google = $this->cssSelect('a.addtocal__google');
      $this->assertCount(1, $google, "$variant: one Google link");
      $google_href = (string) $google[0]['href'];
      $this->assertStringStartsWith('https://calendar.google.com/calendar/render?', $google_href, "$variant: Google link is absolute");
      $this->assertStringContainsString('action=TEMPLATE', $google_href);
      $this->assertStringContainsString('text=Kernel%20test%20event', $google_href);
      $this->assertStringNotContainsString('&&', $google_href, "$variant: Google query string is well formed");
    }
  }

}
