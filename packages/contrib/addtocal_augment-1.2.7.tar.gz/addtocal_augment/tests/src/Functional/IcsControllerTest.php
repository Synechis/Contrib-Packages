<?php

declare(strict_types=1);

namespace Drupal\Tests\addtocal_augment\Functional;

use Drupal\Tests\BrowserTestBase;
use PHPUnit\Framework\Attributes\Group;

/**
 * Tests the controller that serves signed iCal payloads.
 *
 * @coversDefaultClass \Drupal\addtocal_augment\Controller\IcsController
 * @group addtocal_augment
 */
#[Group('addtocal_augment')]
class IcsControllerTest extends BrowserTestBase {

  /**
   * {@inheritdoc}
   */
  protected static $modules = ['addtocal_augment'];

  /**
   * {@inheritdoc}
   */
  protected $defaultTheme = 'stark';

  /**
   * An iCal payload to serve.
   */
  const PAYLOAD = "BEGIN:VCALENDAR\r\nVERSION:2.0\r\nBEGIN:VEVENT\r\nSUMMARY:Crème brûlée tasting\r\nDTSTART:20991029T200000Z\r\nDTEND:20991029T210000Z\r\nEND:VEVENT\r\nEND:VCALENDAR";

  /**
   * Builds signed route parameters for a payload.
   *
   * @return string[]
   *   An array with 'ics' and 'signature' keys.
   */
  protected function buildParameters(string $payload): array {
    return $this->container->get('addtocal_augment.ics_link')
      ->buildUrl($payload)
      ->getRouteParameters();
  }

  /**
   * Tests that a validly signed payload is served as a calendar file.
   */
  public function testValidPayload(): void {
    $url = $this->container->get('addtocal_augment.ics_link')->buildUrl(self::PAYLOAD);
    $this->drupalGet($url);

    $assert = $this->assertSession();
    $assert->statusCodeEquals(200);
    $assert->responseHeaderEquals('Content-Type', 'text/calendar; charset=utf-8');
    $assert->responseHeaderEquals('Content-Disposition', 'attachment; filename="event.ics"');
    $assert->responseHeaderEquals('X-Content-Type-Options', 'nosniff');
    $this->assertSame(self::PAYLOAD, $this->getSession()->getPage()->getContent());
  }

  /**
   * Tests that modified payloads and signatures are denied.
   */
  public function testTamperedPayloadIsDenied(): void {
    $parameters = $this->buildParameters(self::PAYLOAD);
    $other = $this->buildParameters("BEGIN:VCALENDAR\r\nSUMMARY:Something else\r\nEND:VCALENDAR");

    $tampered_ics = substr($parameters['ics'], 0, -1) . ($parameters['ics'][-1] === 'A' ? 'B' : 'A');
    $tampered_signature = substr($parameters['signature'], 0, -1) . ($parameters['signature'][-1] === 'A' ? 'B' : 'A');

    foreach ([
      'tampered payload' => [$tampered_ics, $parameters['signature']],
      'tampered signature' => [$parameters['ics'], $tampered_signature],
      'signature from another payload' => [$other['ics'], $parameters['signature']],
    ] as [$ics, $signature]) {
      $this->drupalGet("addtocal-augment/ics/$ics/$signature");
      $this->assertSession()->statusCodeEquals(403);
      $this->assertStringNotContainsString('BEGIN:VCALENDAR', $this->getSession()->getPage()->getContent());
    }
  }

  /**
   * Tests that malformed paths do not match the route.
   */
  public function testMalformedPathsAreNotFound(): void {
    $parameters = $this->buildParameters(self::PAYLOAD);

    // Missing signature.
    $this->drupalGet('addtocal-augment/ics/' . $parameters['ics']);
    $this->assertSession()->statusCodeEquals(404);

    // Characters outside the URL-safe base64 alphabet.
    $this->drupalGet('addtocal-augment/ics/abc%21/' . $parameters['signature']);
    $this->assertSession()->statusCodeEquals(404);
  }

}
