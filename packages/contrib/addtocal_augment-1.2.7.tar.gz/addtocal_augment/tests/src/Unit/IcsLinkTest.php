<?php

declare(strict_types=1);

namespace Drupal\Tests\addtocal_augment\Unit;

use Drupal\addtocal_augment\IcsLink;
use Drupal\Core\PrivateKey;
use Drupal\Core\Site\Settings;
use Drupal\Tests\UnitTestCase;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\Attributes\Group;

/**
 * Tests signing, encoding and verification of ICS payload URLs.
 *
 * @coversDefaultClass \Drupal\addtocal_augment\IcsLink
 * @group addtocal_augment
 */
#[Group('addtocal_augment')]
class IcsLinkTest extends UnitTestCase {

  /**
   * The characters allowed by the addtocal_augment.render_ics route.
   */
  const ROUTE_PATTERN = '/^[A-Za-z0-9\-_]+$/';

  /**
   * The service under test.
   *
   * @var \Drupal\addtocal_augment\IcsLink
   */
  protected $icsLink;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();
    new Settings(['hash_salt' => 'addtocal_augment_test_salt']);
    $this->icsLink = $this->createIcsLink('addtocal_augment_test_key');
  }

  /**
   * Creates an IcsLink service using the given private key.
   */
  protected function createIcsLink(string $key): IcsLink {
    $private_key = $this->createMock(PrivateKey::class);
    $private_key->method('get')->willReturn($key);
    return new IcsLink($private_key);
  }

  /**
   * Builds a URL for a payload and returns its route parameters.
   *
   * @return string[]
   *   An array with 'ics' and 'signature' keys.
   */
  protected function buildParameters(string $payload, ?IcsLink $ics_link = NULL): array {
    $url = ($ics_link ?? $this->icsLink)->buildUrl($payload);
    $this->assertSame('addtocal_augment.render_ics', $url->getRouteName());
    return $url->getRouteParameters();
  }

  /**
   * Tests that payloads survive a round trip and only use route-safe chars.
   *
   * @dataProvider providerPayloads
   */
  #[DataProvider('providerPayloads')]
  public function testRoundTrip(string $payload): void {
    $parameters = $this->buildParameters($payload);
    $this->assertMatchesRegularExpression(self::ROUTE_PATTERN, $parameters['ics']);
    $this->assertMatchesRegularExpression(self::ROUTE_PATTERN, $parameters['signature']);
    $this->assertSame($payload, $this->icsLink->verify($parameters['ics'], $parameters['signature']));
  }

  /**
   * Data provider for testRoundTrip().
   */
  public static function providerPayloads(): array {
    return [
      // Lengths covering every remainder mod 3, so base64 padding of zero, one
      // and two "=" characters is stripped and restored.
      'Length mod 3 = 1' => ['a'],
      'Length mod 3 = 2' => ['ab'],
      'Length mod 3 = 0' => ['abc'],
      // Standard base64 encodes these bytes as "+/+/", which are not allowed
      // in the route and must be translated to "-_".
      'Bytes encoding to + and /' => ["\xfb\xff\xbf\xfb\xff\xbf"],
      'Multibyte UTF-8' => ["SUMMARY:Crème brûlée 🎉\r\nLOCATION:Zürich"],
      'Full iCal payload' => [implode("\r\n", [
        'BEGIN:VCALENDAR',
        'VERSION:2.0',
        'BEGIN:VEVENT',
        'UID:uuid12345',
        'SUMMARY:An event, with; punctuation',
        'DTSTART:20211029T200000Z',
        'DTEND:20211029T210000Z',
        'END:VEVENT',
        'END:VCALENDAR',
      ]),
      ],
    ];
  }

  /**
   * Tests that a modified payload or signature fails verification.
   */
  public function testTamperedInputIsRejected(): void {
    $parameters = $this->buildParameters("BEGIN:VCALENDAR\r\nSUMMARY:Original\r\nEND:VCALENDAR");
    $other = $this->buildParameters("BEGIN:VCALENDAR\r\nSUMMARY:Malicious\r\nEND:VCALENDAR");

    // Changing a single character of either value must invalidate the pair.
    $tampered_ics = substr($parameters['ics'], 0, -1) . ($parameters['ics'][-1] === 'A' ? 'B' : 'A');
    $tampered_signature = substr($parameters['signature'], 0, -1) . ($parameters['signature'][-1] === 'A' ? 'B' : 'A');
    $this->assertNull($this->icsLink->verify($tampered_ics, $parameters['signature']));
    $this->assertNull($this->icsLink->verify($parameters['ics'], $tampered_signature));

    // A valid signature for one payload must not validate another.
    $this->assertNull($this->icsLink->verify($other['ics'], $parameters['signature']));
    $this->assertNull($this->icsLink->verify($parameters['ics'], ''));
  }

  /**
   * Tests that signatures are bound to the site's private key and hash salt.
   */
  public function testSignaturesAreSiteSpecific(): void {
    $payload = "BEGIN:VCALENDAR\r\nSUMMARY:Site specific\r\nEND:VCALENDAR";
    $parameters = $this->buildParameters($payload);

    $other_key = $this->createIcsLink('a_different_private_key');
    $this->assertNull($other_key->verify($parameters['ics'], $parameters['signature']), 'A different private key rejects the signature.');

    new Settings(['hash_salt' => 'a_different_hash_salt']);
    $this->assertNull($this->icsLink->verify($parameters['ics'], $parameters['signature']), 'A different hash salt rejects the signature.');
  }

}
