<?php

declare(strict_types=1);

namespace Drupal\Tests\canvas_ai\Kernel\Plugin\AiFunctionCall;

use Drupal\ai\Service\FunctionCalling\ExecutableFunctionCallInterface;
use Drupal\canvas\ComponentSource\ComponentSourceManager;
use Drupal\canvas\Entity\Page;
use Drupal\canvas_ai\CanvasAiPermissions;
use Drupal\canvas_ai\CanvasAiTempStore;
use Drupal\canvas_ai\Plugin\AiFunctionCall\SetAIGeneratedComponentStructure;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Session\AccountInterface;
use Drupal\Core\Session\AccountProxyInterface;
use Drupal\Tests\canvas\Kernel\CanvasKernelTestBase;
use Drupal\Tests\canvas\Traits\CreateTestJsComponentTrait;
use Drupal\Tests\canvas_ai\Traits\FunctionalCallTestTrait;
use Drupal\Tests\canvas_ai\Traits\ImageMediaPropTestTrait;
use Drupal\Tests\user\Traits\UserCreationTrait;
use Drupal\user\Entity\User;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\Attributes\Group;
use Symfony\Component\Yaml\Yaml;

/**
 * Tests for the SetAIGeneratedComponentStructure function call plugin.
 *
 * This test will be replaced by
 * \Drupal\Tests\canvas_ai\Kernel\Plugin\AiFunctionCall\PlaceComponentsTest
 * once the set_component_structure tool is deleted.
 *
 * @see \Drupal\Tests\canvas_ai\Kernel\Plugin\AiFunctionCall\PlaceComponentsTest
 */
#[Group('canvas_ai')]
final class SetAIGeneratedComponentStructureTest extends CanvasKernelTestBase {

  use CreateTestJsComponentTrait;
  use FunctionalCallTestTrait;
  use ImageMediaPropTestTrait;
  use UserCreationTrait;

  /**
   * The function call plugin manager.
   *
   * @var \Drupal\Component\Plugin\PluginManagerInterface
   */
  protected $functionCallManager;

  /**
   * A test user with AI permissions.
   *
   * @var \Drupal\Core\Session\AccountInterface
   */
  protected AccountInterface $privilegedUser;

  /**
   * A test user without AI permissions.
   *
   * @var \Drupal\Core\Session\AccountInterface
   */
  protected AccountInterface $unprivilegedUser;

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    ...self::CANVAS_KERNEL_TEST_MINIMAL_MODULES,
    'field',
    'ai',
    'ai_agents',
    'canvas_ai',
  ];

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();
    $this->installEntitySchema('path_alias');
    $this->installEntitySchema('user');
    $this->installConfig(['canvas']);
    $this->installEntitySchema('file');
    $this->installEntitySchema('path_alias');
    $this->installEntitySchema(Page::ENTITY_TYPE_ID);
    $this->setUpImageMediaType();
    $this->container->get(ComponentSourceManager::class)->generateComponents();

    $this->functionCallManager = $this->container->get('plugin.manager.ai.function_calls');
    $privileged_user = $this->createUser([CanvasAiPermissions::USE_CANVAS_AI]);
    $unprivileged_user = $this->createUser();
    if (!$privileged_user instanceof User || !$unprivileged_user instanceof User) {
      throw new \Exception('Failed to create test users');
    }
    $this->privilegedUser = $privileged_user;
    $this->unprivilegedUser = $unprivileged_user;
    $this->container->get(ConfigFactoryInterface::class)
      ->getEditable('system.theme')
      ->set('default', 'stark')
      ->save();
  }

  /**
   * Tests setting component structure with proper permissions and valid data.
   */
  #[DataProvider('componentStructureDataProvider')]
  public function testSetComponentStructureWithPermissionsAndValidData(string $layout_type, string $yaml_input, array $expected_output): void {
    $this->container->get(AccountProxyInterface::class)->setAccount($this->privilegedUser);
    // Set the current layout to a valid layout.
    $this->container->get(CanvasAiTempStore::class)->setData(CanvasAiTempStore::CURRENT_LAYOUT_KEY, $this->getCurrentLayout($layout_type));

    $tool = $this->functionCallManager->createInstance('canvas_ai:set_component_structure');
    $this->assertInstanceOf(SetAIGeneratedComponentStructure::class, $tool);
    $tool->setContextValue('component_structure', $yaml_input);
    $tool->execute();
    self::assertEquals($expected_output, $tool->getStructuredOutput());
  }

  /**
   * Tests setting component structure without proper permissions.
   */
  public function testSetComponentStructureWithoutPermissions(): void {
    $this->container->get(AccountProxyInterface::class)->setAccount($this->unprivilegedUser);

    $tool = $this->functionCallManager->createInstance('canvas_ai:set_component_structure');
    $this->assertInstanceOf(ExecutableFunctionCallInterface::class, $tool);

    // Expect an exception to be thrown.
    $this->expectException(\Exception::class);
    $this->expectExceptionMessage('The current user does not have the right permissions to run this tool.');

    $tool->setContextValue('component_structure', 'test: value');
    $tool->execute();
  }

  /**
   * Tests setting component structure with invalid YAML.
   */
  #[DataProvider('invalidComponentStructureDataProvider')]
  public function testSetComponentStructureWithInvalidYaml(string $layout_type, string $yaml_input, array $expected_error): void {
    $this->container->get(AccountProxyInterface::class)->setAccount($this->privilegedUser);
    // Set the current layout to a valid layout.
    $this->container->get(CanvasAiTempStore::class)->setData(CanvasAiTempStore::CURRENT_LAYOUT_KEY, $this->getCurrentLayout($layout_type));

    $result = $this->getComponentToolOutput($yaml_input);
    $expected_error = 'Failed to process layout data: ' . Yaml::dump($expected_error);
    $this->assertStringContainsString($expected_error, $result);
  }

  /**
   * Tests setting component structure with invalid component validation.
   */
  public function testSetComponentStructureWithInvalidComponents(): void {
    $this->container->get(AccountProxyInterface::class)->setAccount($this->privilegedUser);
    // Set the current layout to a valid layout.
    $this->container->get(CanvasAiTempStore::class)->setData(CanvasAiTempStore::CURRENT_LAYOUT_KEY, $this->getCurrentLayout('multi_region_empty'));

    $valid_yaml = <<<YAML
      operations:
        - target: 'content'
          reference_uuid: ''
          placement: 'inside'
          components:
          - invalid.component.id:
              props:
                title: 'Invalid Component'
      YAML;

    $result = $this->getComponentToolOutput($valid_yaml);
    $this->assertSame("Failed to process layout data: Component validation errors: components.0.[invalid.component.id]: The 'canvas.component.invalid.component.id' config does not exist.", self::normalizeErrorString($result));

    $invalid_nested_component = <<<YAML
      operations:
        - target: 'content'
          reference_uuid: ''
          placement: 'inside'
          components:
            - sdc.canvas_test_sdc.two_column:
                props:
                  width: 50
                slots:
                  column_one:
                    - sdc.canvas_test_sdc.invalid_component:
                        props:
                          heading: 'My Hero'
                          subheading: 'SubSnub'
                          cta1href: 'https://example.com'
                          cta1: 'View it!'
                          cta2: 'Click it!'
      YAML;
    $result = $this->getComponentToolOutput($invalid_nested_component);
    $this->assertSame("Failed to process layout data: Component validation errors: components.0.[sdc.canvas_test_sdc.two_column].slots.column_one.0.[sdc.canvas_test_sdc.invalid_component]: The 'canvas.component.sdc.canvas_test_sdc.invalid_component' config does not exist.", self::normalizeErrorString($result));
  }

  /**
   * Tests component validation logic.
   */
  public function testValidateComponent(): void {
    $this->container->get(AccountProxyInterface::class)->setAccount($this->privilegedUser);

    $invalid_yaml = <<<YAML
      operations:
        - target: 'content'
          reference_uuid: ''
          placement: 'inside'
          components:
            - sdc.canvas_test_sdc.my-hero:
                props:
                  subheading: 'SubSnub'
                  cta1: 'View it!'
                  cta1href: 'https://canvas-example.com'
                  cta2: 'Click it!'
      YAML;

    $result = $this->getComponentToolOutput($invalid_yaml);
    $this->assertSame("Failed to process layout data: Component validation errors: components.0.[sdc.canvas_test_sdc.my-hero].props.heading: The property heading is required.", self::normalizeErrorString($result));
    // Ensure we gracefully 'props' not being set.
    $decoded = Yaml::parse($invalid_yaml);
    unset($decoded['operations'][0]['components'][0]['sdc.canvas_test_sdc.my-hero']['props']);
    $result = $this->getComponentToolOutput(Yaml::dump($decoded));
    $this->assertSame('Failed to process layout data: Component validation errors: components.0.[sdc.canvas_test_sdc.my-hero].props.heading: The property heading is required. components.0.[sdc.canvas_test_sdc.my-hero].props.cta1href: The property cta1href is required.', self::normalizeErrorString($result));

    $invalid_nested_yaml = <<<YAML
operations:
  - target: 'content'
    reference_uuid: ''
    placement: 'inside'
    components:
      - sdc.canvas_test_sdc.two_column:
          props:
            width: 50
          slots:
            column_one:
              - sdc.canvas_test_sdc.my-hero:
                  props:
                    heading: 'My Hero'
                    subheading: 'SubSnub'
                    cta1: 'View it!'
                    cta2: 'Click it!'
YAML;
    $result = $this->getComponentToolOutput($invalid_nested_yaml);
    $this->assertSame('Failed to process layout data: Component validation errors: components.0.[sdc.canvas_test_sdc.two_column].slots.column_one.0.[sdc.canvas_test_sdc.my-hero].props.cta1href: The property cta1href is required.', self::normalizeErrorString($result));

    // Ensure we error on invalid slot names.
    $decoded = Yaml::parse($invalid_nested_yaml);
    $decoded['operations'][0]['components'][0]['sdc.canvas_test_sdc.two_column']['slots']['not_real_slot'] = $decoded['operations'][0]['components'][0]['sdc.canvas_test_sdc.two_column']['slots']['column_one'];
    $invalid_slot_name_yaml = Yaml::dump($decoded);
    $result = $this->getComponentToolOutput($invalid_slot_name_yaml);
    $this->assertSame('Failed to process layout data: Component validation errors: components.0.[sdc.canvas_test_sdc.two_column]: Invalid component subtree. This component subtree contains an invalid slot name for component <em class="placeholder">sdc.canvas_test_sdc.two_column</em>: <em class="placeholder">not_real_slot</em>. Valid slot names are: <em class="placeholder">column_one, column_two</em>. components.0.[sdc.canvas_test_sdc.two_column].slots.column_one.0.[sdc.canvas_test_sdc.my-hero].props.cta1href: The property cta1href is required. components.0.[sdc.canvas_test_sdc.two_column].slots.not_real_slot.0.[sdc.canvas_test_sdc.my-hero].props.cta1href: The property cta1href is required.', self::normalizeErrorString($result));
  }

  /**
   * Tests a media item the current user is not allowed to view.
   *
   * An image prop is populated by a reference to a media item, and Canvas
   * resolves that reference with the current user's access rights: an agent
   * must not be able to put media on the page for a user who may not see it.
   */
  public function testSetComponentStructureWithInaccessibleMedia(): void {
    $media = $this->createImageMedia();
    $yaml = <<<YAML
      operations:
        - target: 'content'
          reference_uuid: ''
          placement: 'inside'
          components:
          - sdc.canvas_test_sdc.image:
              props:
                image: {$media->id()}
      YAML;

    // The first account ::setUp() creates is user 1, which bypasses access
    // checks: the very same media item raises no validation error for it.
    $this->assertSame(1, (int) $this->privilegedUser->id());
    $this->container->get(AccountProxyInterface::class)->setAccount($this->privilegedUser);
    $this->container->get(CanvasAiTempStore::class)->setData(CanvasAiTempStore::CURRENT_LAYOUT_KEY, $this->getCurrentLayout('multi_region_empty'));
    $result = $this->getComponentToolOutput($yaml);
    $this->assertSame('Component structure processed successfully.', $result);

    // User A may use Canvas AI, but may not view the media item.
    $user_a = $this->createUserWithoutMediaAccess();
    $this->assertFalse($media->access('view', $user_a));
    $this->container->get(AccountProxyInterface::class)->setAccount($user_a);
    $this->container->get(CanvasAiTempStore::class)->setData(CanvasAiTempStore::CURRENT_LAYOUT_KEY, $this->getCurrentLayout('multi_region_empty'));
    $result = $this->getComponentToolOutput($yaml);
    $this->assertSame(\sprintf('Failed to process layout data: %s', self::MEDIA_ACCESS_DENIED_MESSAGE), self::normalizeErrorString($result));
  }

  /**
   * Tests that props that do not exist on a component fail validation.
   */
  public function testValidateComponentWithNonExistentProps(): void {
    $this->container->get(AccountProxyInterface::class)->setAccount($this->privilegedUser);

    // A valid required prop plus a prop the component does not define.
    $bogus_prop_yaml = <<<YAML
      operations:
        - target: 'content'
          reference_uuid: ''
          placement: 'inside'
          components:
            - sdc.canvas_test_sdc.props-no-slots:
                props:
                  heading: 'A valid heading'
                  nonexistent_prop: 'This prop does not exist'
      YAML;
    $result = $this->getComponentToolOutput($bogus_prop_yaml);
    $this->assertSame('Failed to process layout data: Component validation errors: components.0.[sdc.canvas_test_sdc.props-no-slots].props.nonexistent_prop: Component `sdc.canvas_test_sdc.props-no-slots`: the `nonexistent_prop` prop is not defined. (code garbage)', self::normalizeErrorString($result));

    // Any prop sent to a component that defines no props must fail.
    $zero_prop_component_yaml = <<<YAML
      operations:
        - target: 'content'
          reference_uuid: ''
          placement: 'inside'
          components:
            - sdc.canvas_test_sdc.druplicon:
                props:
                  heading: 'Druplicon has no props'
      YAML;
    $result = $this->getComponentToolOutput($zero_prop_component_yaml);
    $this->assertSame('Failed to process layout data: Component validation errors: components.0.[sdc.canvas_test_sdc.druplicon].props.heading: Component `sdc.canvas_test_sdc.druplicon`: the `heading` prop is not defined. (code garbage)', self::normalizeErrorString($result));

    // A non-existent prop on a component nested inside a slot.
    $nested_bogus_prop_yaml = <<<YAML
      operations:
        - target: 'content'
          reference_uuid: ''
          placement: 'inside'
          components:
            - sdc.canvas_test_sdc.two_column:
                props:
                  width: 50
                slots:
                  column_one:
                    - sdc.canvas_test_sdc.heading:
                        props:
                          text: 'A heading'
                          element: 'h2'
                          nonexistent_prop: 'Bogus'
      YAML;
    $result = $this->getComponentToolOutput($nested_bogus_prop_yaml);
    $this->assertSame('Failed to process layout data: Component validation errors: components.0.[sdc.canvas_test_sdc.two_column].slots.column_one.0.[sdc.canvas_test_sdc.heading].props.nonexistent_prop: Component `sdc.canvas_test_sdc.heading`: the `nonexistent_prop` prop is not defined. (code garbage)', self::normalizeErrorString($result));

    // A missing required prop and a non-existent prop are both reported.
    $combined_yaml = <<<YAML
      operations:
        - target: 'content'
          reference_uuid: ''
          placement: 'inside'
          components:
            - sdc.canvas_test_sdc.props-no-slots:
                props:
                  nonexistent_prop: 'This prop does not exist'
      YAML;
    $result = $this->getComponentToolOutput($combined_yaml);
    $this->assertSame('Failed to process layout data: Component validation errors: components.0.[sdc.canvas_test_sdc.props-no-slots].props.heading: The property heading is required. components.0.[sdc.canvas_test_sdc.props-no-slots].props.nonexistent_prop: Component `sdc.canvas_test_sdc.props-no-slots`: the `nonexistent_prop` prop is not defined. (code garbage)', self::normalizeErrorString($result));

    // Props provided as a scalar instead of a mapping must also fail instead
    // of being silently dropped.
    $scalar_props_yaml = <<<YAML
      operations:
        - target: 'content'
          reference_uuid: ''
          placement: 'inside'
          components:
            - sdc.canvas_test_sdc.druplicon:
                props: 'heading: Not a mapping'
      YAML;
    $result = $this->getComponentToolOutput($scalar_props_yaml);
    $this->assertSame('Failed to process layout data: Component validation errors: components.0.[sdc.canvas_test_sdc.druplicon].props: Component `sdc.canvas_test_sdc.druplicon`: the props must be a mapping of prop names to values. (code garbage)', self::normalizeErrorString($result));

    // Code components (JS source) resolve props the same way as SDCs, so a
    // prop the component does not define must fail for them too.
    $this->createTestCodeComponent();
    $js_bogus_prop_yaml = <<<YAML
      operations:
        - target: 'content'
          reference_uuid: ''
          placement: 'inside'
          components:
            - js.test-code-component:
                props:
                  heading: 'A valid heading'
                  nonexistent_prop: 'This prop does not exist'
      YAML;
    $result = $this->getComponentToolOutput($js_bogus_prop_yaml);
    $this->assertSame('Failed to process layout data: Component validation errors: components.0.[js.test-code-component].props.nonexistent_prop: Component `js.test-code-component`: the `nonexistent_prop` prop is not defined. (code garbage)', self::normalizeErrorString($result));
  }

  private function getComponentToolOutput(string $yaml): string {
    return $this->getToolOutput('canvas_ai:set_component_structure', ['component_structure' => $yaml]);
  }

  /**
   * Data provider for component structure test cases.
   *
   * @return array
   */
  public static function componentStructureDataProvider(): array {
    return [
      'test_placement_inside_single' => [
        'layout_type' => 'multi_region_empty',
        'yaml_input' => <<<YAML
          operations:
            - target: 'content'
              reference_uuid: ''
              placement: 'inside'
              components:
                - sdc.canvas_test_sdc.heading:
                    props:
                      text: "Some text"
                      element: "h1"
          YAML,
        'expected_output' => [
          'operations' => [
            [
              'operation' => 'ADD',
              'components' => [
                [
                  'id' => 'sdc.canvas_test_sdc.heading',
                  'nodePath' => [1, 0],
                  'fieldValues' => [
                    'text' => 'Some text',
                    'element' => 'h1',
                  ],
                ],
              ],
            ],
          ],
        ],
      ],
      'test_placement_inside_multiple' => [
        'layout_type' => 'multi_region_empty',
        'yaml_input' => <<<YAML
          operations:
            - target: 'content'
              reference_uuid: ''
              placement: 'inside'
              components:
                - sdc.canvas_test_sdc.heading:
                    props:
                      text: "Some text"
                      element: "h1"
            - target: 'footer'
              reference_uuid: ''
              placement: 'inside'
              components:
                - sdc.canvas_test_sdc.two_column:
                    props:
                      width: 50
                    slots:
                      column_one:
                        - sdc.canvas_test_sdc.my-hero:
                            props:
                              heading: 'My Hero'
                              subheading: 'SubSnub'
                              cta1: 'View it!'
                              cta1href: 'https://example.com'
                              cta2: 'Click it!'
          YAML,
        'expected_output' => [
          'operations' => [
            [
              'operation' => 'ADD',
              'components' => [
                [
                  'id' => 'sdc.canvas_test_sdc.heading',
                  'nodePath' => [1, 0],
                  'fieldValues' => [
                    'text' => 'Some text',
                    'element' => 'h1',
                  ],
                ],
                [
                  'id' => 'sdc.canvas_test_sdc.two_column',
                  'nodePath' => [2, 0],
                  'fieldValues' => [
                    'width' => 50,
                  ],
                ],
                [
                  'id' => 'sdc.canvas_test_sdc.my-hero',
                  'nodePath' => [2, 0, 0, 0],
                  'fieldValues' => [
                    'heading' => 'My Hero',
                    'subheading' => 'SubSnub',
                    'cta1' => 'View it!',
                    'cta1href' => 'https://example.com',
                    'cta2' => 'Click it!',
                  ],
                ],
              ],
            ],
          ],
        ],
      ],
      'test_placement_below' => [
        'layout_type' => 'multi_region_non_empty',
        'yaml_input' => <<<YAML
          operations:
            - target: 'content'
              reference_uuid: '72384115-a8ee-44bc-9a13-de1c7a4d9b96'
              placement: 'below'
              components:
                - sdc.canvas_test_sdc.heading:
                    props:
                      text: "After existing component"
                      element: "h2"
          YAML,
        'expected_output' => [
          'operations' => [
            [
              'operation' => 'ADD',
              'components' => [
                [
                  'id' => 'sdc.canvas_test_sdc.heading',
                  'nodePath' => [1, 1],
                  'fieldValues' => [
                    'text' => 'After existing component',
                    'element' => 'h2',
                  ],
                ],
              ],
            ],
          ],
        ],
      ],
      'test_placement_complex' => [
        'layout_type' => 'multi_region_non_empty',
        'yaml_input' => <<<YAML
          operations:
            - target: 'content'
              reference_uuid: '72384115-a8ee-44bc-9a13-de1c7a4d9b96'
              placement: 'above'
              components:
                - sdc.canvas_test_sdc.heading:
                    props:
                      text: "Above existing component"
                      element: "h2"
                - sdc.canvas_test_sdc.two_column:
                    props:
                      width: 25
                    slots:
                      column_two:
                        - sdc.canvas_test_sdc.druplicon: {}
                        - sdc.canvas_test_sdc.druplicon: {}
                        - sdc.canvas_test_sdc.druplicon: {}
            - target: 'content'
              reference_uuid: '72384115-a8ee-44bc-9a13-de1c7a4d9b96'
              placement: 'below'
              components:
                - sdc.canvas_test_sdc.heading:
                    props:
                      text: "Below existing component"
                      element: "h2"
            - target: 'header'
              reference_uuid: ''
              placement: 'inside'
              components:
                - sdc.canvas_test_sdc.heading:
                    props:
                      text: "Some text"
                      element: "h1"
          YAML,
        'expected_output' => [
          'operations' => [
            [
              'operation' => 'ADD',
              'components' => [
                [
                  'id' => 'sdc.canvas_test_sdc.heading',
                  'nodePath' => [1, 0],
                  'fieldValues' => [
                    'text' => 'Above existing component',
                    'element' => 'h2',
                  ],
                ],
                [
                  'id' => 'sdc.canvas_test_sdc.two_column',
                  'nodePath' => [1, 1],
                  'fieldValues' => [
                    'width' => 25,
                  ],
                ],
                [
                  'id' => 'sdc.canvas_test_sdc.druplicon',
                  'nodePath' => [1, 1, 1, 0],
                  'fieldValues' => [],
                ],
                [
                  'id' => 'sdc.canvas_test_sdc.druplicon',
                  'nodePath' => [1, 1, 1, 1],
                  'fieldValues' => [],
                ],
                [
                  'id' => 'sdc.canvas_test_sdc.druplicon',
                  'nodePath' => [1, 1, 1, 2],
                  'fieldValues' => [],
                ],
                [
                  'id' => 'sdc.canvas_test_sdc.heading',
                  'nodePath' => [1, 3],
                  'fieldValues' => [
                    'text' => 'Below existing component',
                    'element' => 'h2',
                  ],
                ],
                [
                  'id' => 'sdc.canvas_test_sdc.heading',
                  'nodePath' => [0, 0],
                  'fieldValues' => [
                    'text' => 'Some text',
                    'element' => 'h1',
                  ],
                ],
              ],
            ],
          ],
        ],
      ],
    ];
  }

  /**
   * Provides different invalid component structure test cases.
   *
   * @return array
   *   An array of test cases.
   */
  public static function invalidComponentStructureDataProvider(): array {
    return [
      'test_invalid_below_placement' => [
        'layout_type' => 'multi_region_empty',
        'yaml_input' => <<<YAML
          operations:
            - target: 'content'
              reference_uuid: ''
              placement: 'below'
              components:
                - sdc.canvas_test_sdc.heading:
                    props:
                      text: "Some text"
                      element: "h1"
          YAML,
        'expected_error' => [
          'Operation 0' => [
            'The reference_uuid must be provided for above/below placement.',
          ],
        ],
      ],
      'test_invalid_inside_placement' => [
        'layout_type' => 'multi_region_non_empty',
        'yaml_input' => <<<YAML
          operations:
            - target: 'content'
              reference_uuid: ''
              placement: 'inside'
              components:
                - sdc.canvas_test_sdc.heading:
                    props:
                      text: "Some text"
                      element: "h1"
          YAML,
        'expected_error' => [
          'Operation 0' => [
            'The target content has "inside" placement specified, but it contains child components. Select any child component in the target and use "above" or "below" placement instead.',
          ],
        ],
      ],
      'test_invalid_placement_value' => [
        'layout_type' => 'multi_region_empty',
        'yaml_input' => <<<YAML
          operations:
            - target: 'content'
              reference_uuid: ''
              placement: 'invalid_placement'
              components:
                - sdc.canvas_test_sdc.heading:
                    props:
                      text: "Some text"
                      element: "h1"
          YAML,
        'expected_error' => [
          'Operation 0' => [
            'The placement key is missing or invalid in the operation.',
          ],
        ],
      ],
      'test_inside_placement_with_reference_uuid' => [
        'layout_type' => 'multi_region_empty',
        'yaml_input' => <<<YAML
          operations:
            - target: 'content'
              reference_uuid: 'some-uuid-123'
              placement: 'inside'
              components:
                - sdc.canvas_test_sdc.heading:
                    props:
                      text: "Some text"
                      element: "h1"
          YAML,
        'expected_error' => [
          'Operation 0' => [
            'The reference_uuid is not required for inside placement.',
          ],
        ],
      ],
      'test_empty_components' => [
        'layout_type' => 'multi_region_empty',
        'yaml_input' => <<<YAML
          operations:
            - target: 'content'
              reference_uuid: ''
              placement: 'inside'
              components: []
          YAML,
        'expected_error' => [
          'Operation 0' => [
            'The operation must contain components.',
          ],
        ],
      ],
      'test_unknown_target_region' => [
        'layout_type' => 'multi_region_empty',
        'yaml_input' => <<<YAML
          operations:
            - target: 'sidebar'
              reference_uuid: ''
              placement: 'inside'
              components:
                - sdc.canvas_test_sdc.heading:
                    props:
                      text: "Some text"
                      element: "h1"
          YAML,
        'expected_error' => [
          'Operation 0' => [
            'Region "sidebar" does not exist. Available regions are: header, content, footer.',
          ],
        ],
      ],
      'test_missing_target' => [
        'layout_type' => 'multi_region_empty',
        'yaml_input' => <<<YAML
          operations:
            - reference_uuid: ''
              placement: 'inside'
              components:
                - sdc.canvas_test_sdc.heading:
                    props:
                      text: "Some text"
                      element: "h1"
          YAML,
        'expected_error' => [
          'Operation 0' => [
            'The target key is missing or invalid in the operation.',
          ],
        ],
      ],
      'test_non_string_target' => [
        'layout_type' => 'multi_region_empty',
        'yaml_input' => <<<YAML
          operations:
            - target: 0
              reference_uuid: ''
              placement: 'inside'
              components:
                - sdc.canvas_test_sdc.heading:
                    props:
                      text: "Some text"
                      element: "h1"
          YAML,
        'expected_error' => [
          'Operation 0' => [
            'The target key is missing or invalid in the operation.',
          ],
        ],
      ],
    ];
  }

  /**
   * Returns a predefined layout based on the type.
   *
   * @param string $type
   *   The type of layout to return.
   *
   * @return string
   *   The JSON-encoded layout.
   */
  private function getCurrentLayout(string $type): string {
    $layouts = [
      'multi_region_empty' => json_encode([
        'regions' => [
          'header' => [
            'nodePathPrefix' => [0],
            'components' => [],
          ],
          'content' => [
            'nodePathPrefix' => [1],
            'components' => [],
          ],
          'footer' => [
            'nodePathPrefix' => [2],
            'components' => [],
          ],
        ],
      ], JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR),
      'multi_region_non_empty' => json_encode([
        'regions' => [
          'header' => [
            'nodePathPrefix' => [0],
            'components' => [],
          ],
          'content' => [
            'nodePathPrefix' => [1],
            'components' => [
              [
                'name' => 'sdc.canvas_test_sdc.heading',
                'uuid' => '72384115-a8ee-44bc-9a13-de1c7a4d9b96',
                'nodePath' => [1, 0],
              ],
            ],
          ],
          'footer' => [
            'nodePathPrefix' => [2],
            'components' => [],
          ],
        ],
      ], JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR),
    ];
    return $layouts[$type];
  }

}
