/**
 * @file
 * Overrides Drupal's tableDragHandle theme function to use custom SVG icons.
 */

(function (Drupal) {
  'use strict';

  /**
   * Custom SVG icon for drag handle (matches Radix UI DragHandleDots2Icon).
   */
  const dragHandleSvg = `<svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg" class="drag-handle-icon" aria-hidden="true">
    <path d="M5.5 4.625C6.12132 4.625 6.625 4.12132 6.625 3.5C6.625 2.87868 6.12132 2.375 5.5 2.375C4.87868 2.375 4.375 2.87868 4.375 3.5C4.375 4.12132 4.87868 4.625 5.5 4.625ZM9.5 4.625C10.1213 4.625 10.625 4.12132 10.625 3.5C10.625 2.87868 10.1213 2.375 9.5 2.375C8.87868 2.375 8.375 2.87868 8.375 3.5C8.375 4.12132 8.87868 4.625 9.5 4.625ZM6.625 7.5C6.625 8.12132 6.12132 8.625 5.5 8.625C4.87868 8.625 4.375 8.12132 4.375 7.5C4.375 6.87868 4.87868 6.375 5.5 6.375C6.12132 6.375 6.625 6.87868 6.625 7.5ZM9.5 8.625C10.1213 8.625 10.625 8.12132 10.625 7.5C10.625 6.87868 10.1213 6.375 9.5 6.375C8.87868 6.375 8.375 6.87868 8.375 7.5C8.375 8.12132 8.87868 8.625 9.5 8.625ZM6.625 11.5C6.625 12.1213 6.12132 12.625 5.5 12.625C4.87868 12.625 4.375 12.1213 4.375 11.5C4.375 10.8787 4.87868 10.375 5.5 10.375C6.12132 10.375 6.625 10.8787 6.625 11.5ZM9.5 12.625C10.1213 12.625 10.625 12.1213 10.625 11.5C10.625 10.8787 10.1213 10.375 9.5 10.375C8.87868 10.375 8.375 10.8787 8.375 11.5C8.375 12.1213 8.87868 12.625 9.5 12.625Z" fill="currentColor" fill-rule="evenodd" clip-rule="evenodd"></path>
  </svg>`;

  /**
   * Override the tableDragHandle theme function.
   *
   * @param {string} dragOrientation
   *   The drag orientation ('drag' or 'drag-y').
   *
   * @return {string}
   *   HTML markup for the table drag handle with custom SVG.
   */
  Drupal.theme.tableDragHandle = function (dragOrientation = 'drag') {
    const title = dragOrientation === 'drag-y'
      ? Drupal.t('Change order')
      : Drupal.t('Move in any direction');
    return `<a href="#" title="${title}" class="tabledrag-handle" aria-label="${title}">${dragHandleSvg}</a>`;
  };

})(Drupal);

