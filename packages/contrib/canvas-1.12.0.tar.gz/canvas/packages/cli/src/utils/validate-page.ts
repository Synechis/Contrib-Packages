import fs from 'fs/promises';
import path from 'path';
import { loadComponentsMetadata } from '@drupal-canvas/discovery';
import { createCanvasAjv } from '@drupal-canvas/json-schema-validation';

import pageSpecSchema from '../../../workbench/src/lib/schemas/page-spec.schema.json';
import {
  formatPagePathAliasChangeError,
  getPathAliasChange,
} from './page-path-alias-validation';
import { pageResultName } from './page-result-name';
import {
  collectUnreconciledColorProps,
  collectUnreconciledMediaProps,
} from './prop-transforms';
import {
  buildElementsValidationContext,
  validateElements,
} from './validate-elements';

import type { DiscoveryResult } from '@drupal-canvas/discovery';
import type { AuthoredSpecElementMap } from 'drupal-canvas/json-render-utils';
import type { BrandKitColorEntry } from '../types/Component';
import type { PageListItem } from '../types/Page';
import type { Result } from '../types/Result';

export interface PageValidationOptions {
  remotePageByUuid?: Map<string, PageListItem>;
  availablePageVariantIds?: ReadonlySet<string>;
  remoteBrandKitColors?: BrandKitColorEntry[];
}

/**
 * Validates discovered pages against a catalog built from the discovery result.
 *
 * Builds a catalog from enabled components, then reads each page file and
 * validates its elements by converting to a json-render spec and running
 * `catalog.validate()`.
 */
export async function validatePages(
  discoveryResult: DiscoveryResult,
  options: PageValidationOptions = {},
): Promise<{ results: Result[] }> {
  const validatePageSpec = createCanvasAjv().compile(pageSpecSchema);

  const metadata = await loadComponentsMetadata(discoveryResult);
  const context = buildElementsValidationContext(metadata);
  const discoveredPages = discoveryResult.pages;
  const results: Result[] = [];

  for (const page of discoveredPages) {
    const fileName = path.basename(page.path);
    try {
      const fileContent = await fs.readFile(page.path, 'utf-8');
      const spec = JSON.parse(fileContent) as Record<string, unknown>;
      const pageTitle = typeof spec.title === 'string' ? spec.title : undefined;
      const elements = (spec.elements as AuthoredSpecElementMap) ?? {};

      const details: { heading?: string; content: string }[] = [];

      if (
        typeof spec.pageVariant === 'string' &&
        options.availablePageVariantIds &&
        !options.availablePageVariantIds.has(spec.pageVariant)
      ) {
        details.push({
          heading: 'pageVariant',
          content: `Unknown page template "${spec.pageVariant}". Pull it from the site or add its file under page-templates.`,
        });
      }

      // Validate the page file structure against the page spec schema.
      if (!validatePageSpec(spec)) {
        for (const error of validatePageSpec.errors ?? []) {
          details.push({
            heading: error.instancePath || undefined,
            content:
              error.keyword === 'additionalProperties' &&
              error.params?.additionalProperty
                ? `${error.message}: '${error.params.additionalProperty}'`
                : (error.message ?? 'Unknown validation error'),
          });
        }
      }

      // Validate page elements against the component catalog.
      const elementsResult = validateElements(elements, context);
      if (!elementsResult.success && elementsResult.details) {
        details.push(...elementsResult.details);
      }
      const unreconciledMedia = collectUnreconciledMediaProps(
        elements,
        metadata,
      );
      for (const entry of unreconciledMedia) {
        details.push({
          heading: `elements.${entry.elementId}.props.${entry.propName}`,
          content: `Unreconciled external media URL "${entry.src}". Run \`canvas reconcile-media\` to resolve.`,
        });
      }
      const unreconciledColors = collectUnreconciledColorProps(
        elements,
        metadata,
        options.remoteBrandKitColors ?? [],
      );
      for (const entry of unreconciledColors) {
        details.push({
          heading: `elements.${entry.elementId}.props.${entry.propName}`,
          content: `Unknown brand kit color key "${entry.key}". Run \`canvas pull\` to refresh local colors, or push the color before referencing it.`,
        });
      }

      // Prefer the UUID from the parsed spec, but fall back to discovery so
      // remote-aware validation can still run if discovery already found one.
      let uuid: string | null = null;
      if (typeof spec.uuid === 'string') {
        uuid = spec.uuid;
      } else if (typeof page.uuid === 'string') {
        uuid = page.uuid;
      }
      const pagePath = typeof spec.path === 'string' ? spec.path : '';
      if (options.remotePageByUuid && uuid) {
        const remotePage = options.remotePageByUuid.get(uuid);
        const pathAliasChange = remotePage
          ? getPathAliasChange(pagePath, remotePage.path)
          : null;
        if (pathAliasChange) {
          details.push({
            heading: 'path',
            content: formatPagePathAliasChangeError(pathAliasChange),
          });
        }
      }

      const success = details.length === 0 && elementsResult.success;
      results.push({
        itemName: pageResultName(pageTitle, page, { includePath: !success }),
        success,
        details: details.length > 0 ? details : undefined,
      });
    } catch (error) {
      results.push({
        itemName: pageResultName(undefined, page, { includePath: true }),
        success: false,
        details: [
          {
            heading: fileName,
            content:
              error instanceof Error
                ? error.message
                : `Unknown error: ${String(error)}`,
          },
        ],
      });
    }
  }

  return { results };
}
