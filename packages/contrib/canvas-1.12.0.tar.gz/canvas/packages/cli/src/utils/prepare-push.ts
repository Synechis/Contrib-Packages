import fs from 'fs/promises';
import path from 'path';
import chalk from 'chalk';
import { parse } from '@babel/parser';
import * as p from '@clack/prompts';
import { transformColorExamplesInProps } from '@drupal-canvas/discovery';
import { getImportsFromAst } from '@drupal-canvas/ui/features/code-editor/utils/ast-utils';

import { getGlobalCss } from './build-tailwind.js';
import { sortByDependencies } from './dependency-sort';
import { createProgressCallback, processInPool } from './request-pool';
import { fileExists } from './utils';

import type { ApiService } from '../services/api.js';
import type {
  AssetLibrary,
  BrandKitColorEntry,
  Component,
} from '../types/Component.js';
import type { Result } from '../types/Result.js';

type ComponentOperation = 'create' | 'update' | 'delete';

type ComponentUploadTask =
  | {
      machineName: string;
      operation: 'create' | 'update';
      componentPayload: Component;
      // Dependencies needed to sort creates in dependency-first order
      importedJsComponents: string[];
    }
  | {
      machineName: string;
      operation: 'delete';
      // Dependencies needed to sort deletes in reverse order (dependents first)
      // to avoid "component still referenced" errors from backend
      importedJsComponents: string[];
    };

interface ComponentUploadResult {
  machineName: string;
  success: boolean;
  operation: ComponentOperation;
  error?: Error;
}

interface BuiltComponentForPush {
  machineName: string;
  componentName: string;
  componentPayload: Component;
  importedJsComponents: string[];
}

interface PushProgressSpinner {
  start: (message?: string) => void;
  stop: (message?: string) => void;
  message: (message?: string) => void;
}

/**
 * Determine the operation for each component (create, update, or delete)
 * and build upload tasks with payloads attached.
 */
async function buildComponentUploadTasks(
  preparedByName: Map<string, BuiltComponentForPush>,
  apiService: { listComponents: () => Promise<Record<string, unknown>> },
  onProgress: () => void,
  colorsByCssVariable: Map<string, BrandKitColorEntry>,
): Promise<ComponentUploadTask[]> {
  const existingComponents = await apiService.listComponents();
  const remoteNames = new Set(Object.keys(existingComponents));

  const tasks: ComponentUploadTask[] = [];
  for (const [machineName, prepared] of preparedByName.entries()) {
    onProgress();
    // Serialize color examples for API submission.
    // transformColorExamplesInProps expects a Metadata['props']-shaped wrapper
    const wrappedProps = prepared.componentPayload.props
      ? { properties: prepared.componentPayload.props }
      : null;
    const serializedResult = transformColorExamplesInProps(
      wrappedProps,
      colorsByCssVariable,
      'toUuid',
    );
    // Extract the flat map back from the wrapper to match Component['props'] type.
    const serializedProps = serializedResult?.properties as
      | Component['props']
      | undefined;
    const serializedPayload: Component = {
      ...prepared.componentPayload,
      props:
        serializedProps === null || serializedProps === undefined
          ? prepared.componentPayload.props
          : serializedProps,
    };
    if (remoteNames.has(machineName)) {
      let componentPayload = serializedPayload;
      if (componentPayload.type === 'external') {
        const serverComponent = existingComponents[machineName] as Component;
        // Preserve dependencies used by retained React fallback assets. Entity
        // fields describe the current props, so only the external definition is
        // authoritative for that category.
        const fallbackDataDependencies = {
          ...(serverComponent.dataDependencies ?? {}),
        };
        delete fallbackDataDependencies.entityFields;
        componentPayload = {
          ...componentPayload,
          dataDependencies: {
            ...fallbackDataDependencies,
            ...(componentPayload.dataDependencies ?? {}),
          },
        };
      }
      tasks.push({
        machineName,
        operation: 'update',
        componentPayload,
        importedJsComponents: prepared.importedJsComponents,
      });
    } else {
      tasks.push({
        machineName,
        operation: 'create',
        componentPayload: serializedPayload,
        importedJsComponents: prepared.importedJsComponents,
      });
    }
  }

  // Parse dependencies for components being deleted during push.
  // When deleting components, we need to know their dependencies to delete them
  // in reverse order (dependents first) to avoid server errors about components still
  // being referenced.
  //
  // Example: If 'card' imports 'button', both being deleted:
  //   - Must delete 'card' first (the dependent)
  //   - Then delete 'button' (the dependency)
  for (const name of remoteNames) {
    if (!preparedByName.has(name)) {
      const serverComponent = existingComponents[name] as Component;

      // External components are owned by the configured headless frontend:
      // the CLI creates and updates their metadata but must never delete them
      // since it is possible to configure multiple frontends that use different
      // components.
      if (serverComponent.type === 'external') {
        continue;
      }

      // Parse imports from server component's source code (no local file exists)
      let importedJsComponents: string[] = [];
      try {
        const ast = parse(serverComponent.sourceCodeJs ?? '', {
          sourceType: 'module',
          plugins: ['jsx', 'typescript'],
        });
        importedJsComponents = getImportsFromAst(ast, '@/components/');
      } catch (error) {
        p.log.error(chalk.red(`Error: ${String(error)}`));
      }
      tasks.push({
        machineName: name,
        operation: 'delete',
        importedJsComponents,
      });
    }
  }

  return tasks;
}

/**
 * Upload (create, update, or delete) multiple components.
 *
 * Creates: Processed in dependency-first waves (Icon → Button → Card)
 *   - Within each wave, tasks run in parallel
 *   - Waves run sequentially to respect dependencies
 *
 * Updates: Processed in parallel (components already exist, order doesn't matter)
 *
 * Deletes: Processed in reverse dependency waves (Card → Button → Icon)
 *   - Dependents must be deleted before dependencies
 *   - Prevents "component still referenced" backend errors
 */
export async function uploadComponents(
  uploadTasks: ComponentUploadTask[],
  apiService: Pick<
    ApiService,
    'createComponent' | 'updateComponent' | 'deleteComponent'
  >,
  onProgress: () => void,
): Promise<ComponentUploadResult[]> {
  const createTasks = uploadTasks.filter((t) => t.operation === 'create');
  const updateTasks = uploadTasks.filter((t) => t.operation === 'update');
  const deleteTasks = uploadTasks.filter((t) => t.operation === 'delete');

  const results: ComponentUploadResult[] = [];
  const taskIndexMap = new Map<string, number>();
  uploadTasks.forEach((task, index) => {
    taskIndexMap.set(`${task.operation}:${task.machineName}`, index);
  });

  // Process creates in dependency waves. Components that import other components
  // must be created after their dependencies exist on the server. We group
  // components into waves by dependency level - each wave runs in parallel,
  // but waves run sequentially.
  //
  // Example: product-card → button → icon, badge (no deps)
  //   Wave 1: [icon, badge]   ← run in parallel
  //   Wave 2: [button]        ← waits for wave 1
  //   Wave 3: [product-card]   ← waits for wave 2
  if (createTasks.length > 0) {
    const waves =
      createTasks.length > 1
        ? sortByDependencies(createTasks, (task) => task.importedJsComponents)
        : [createTasks];

    for (let i = 0; i < waves.length; i++) {
      const wave = waves[i];
      const waveResults = await processTaskBatch(wave, apiService, onProgress);
      results.push(...waveResults);
    }
  }

  // Process updates in parallel
  if (updateTasks.length > 0) {
    const updateResults = await processTaskBatch(
      updateTasks,
      apiService,
      onProgress,
    );
    results.push(...updateResults);
  }

  // Process deletes in reverse dependency waves.
  // Components that import others must be deleted before their dependencies
  // (opposite of creates). Otherwise, backend rejects: "component still referenced".
  //
  // Example: card → button → icon
  //   Wave 1: [card]    ← deletes first (imports button)
  //   Wave 2: [button]  ← waits for wave 1 (imports icon)
  //   Wave 3: [icon]    ← waits for wave 2 (no imports)
  if (deleteTasks.length > 0) {
    const waves =
      deleteTasks.length > 1
        ? sortByDependencies(deleteTasks, (task) => task.importedJsComponents)
        : [deleteTasks];

    // sortByDependencies returns dependency-first order, but for deletes we want
    // the opposite. Reverse both wave order and items within each wave.
    waves.reverse();
    waves.forEach((wave) => wave.reverse());

    for (let i = 0; i < waves.length; i++) {
      const wave = waves[i];
      const waveResults = await processTaskBatch(wave, apiService, onProgress);
      results.push(...waveResults);
    }
  }

  // Sort results back to original task order for consistent output
  return results.sort((a, b) => {
    const indexA = taskIndexMap.get(`${a.operation}:${a.machineName}`) ?? 0;
    const indexB = taskIndexMap.get(`${b.operation}:${b.machineName}`) ?? 0;
    return indexA - indexB;
  });
}
/**
 * Execute a single upload task with fallback handling.
 */
async function executeUploadTask(
  task: ComponentUploadTask,
  apiService: Pick<
    ApiService,
    'createComponent' | 'updateComponent' | 'deleteComponent'
  >,
): Promise<ComponentUploadResult> {
  const execute = (raw: boolean) => {
    switch (task.operation) {
      case 'create':
        return apiService.createComponent(task.componentPayload, raw);
      case 'update':
        return apiService.updateComponent(
          task.machineName,
          task.componentPayload,
        );
      case 'delete':
        return apiService.deleteComponent(task.machineName);
    }
  };

  let error: Error | undefined;
  try {
    await execute(true);
  } catch {
    try {
      await execute(false);
    } catch (fallbackError) {
      error =
        fallbackError instanceof Error
          ? fallbackError
          : new Error(String(fallbackError));
    }
  }

  return {
    machineName: task.machineName,
    success: !error,
    operation: task.operation,
    error,
  };
}

/**
 * Process a batch of tasks in parallel and collect results.
 */
async function processTaskBatch(
  uploadTasks: ComponentUploadTask[],
  apiService: Pick<
    ApiService,
    'createComponent' | 'updateComponent' | 'deleteComponent'
  >,
  onProgress: () => void,
): Promise<ComponentUploadResult[]> {
  const results = await processInPool(uploadTasks, async (task) => {
    const result = await executeUploadTask(task, apiService);
    onProgress();
    return result;
  });

  return results.map((result, index) => {
    if (result.success && result.result) {
      return result.result;
    }
    return {
      machineName: uploadTasks[index].machineName,
      success: false,
      operation: uploadTasks[index].operation,
      error: result.error || new Error('Unknown error during upload'),
    };
  });
}

/**
 * Upload already-built components to Drupal.
 *
 * This is the push path used by the shared build service. Backend dependency
 * metadata is still extracted before this point so create/delete ordering is
 * preserved.
 */
export async function pushBuiltComponents(
  builtComponents: BuiltComponentForPush[],
  apiService: ApiService,
  actionLabel: string = 'Uploading',
  activeSpinner?: PushProgressSpinner,
  brandKitColors: BrandKitColorEntry[] = [],
): Promise<Result[]> {
  const results: Result[] = [];
  const spinner = activeSpinner ?? p.spinner();
  const spinnerStarted = activeSpinner !== undefined;

  if (builtComponents.length === 0) {
    return results;
  }

  const preparedByName = new Map(
    builtComponents.map((component) => [
      component.machineName,
      {
        machineName: component.machineName,
        componentName: component.componentName,
        componentPayload: component.componentPayload,
        importedJsComponents: component.importedJsComponents,
      },
    ]),
  );

  const existenceProgress = createProgressCallback(
    spinner,
    'Checking component existence',
    preparedByName.size,
  );

  if (spinnerStarted) {
    spinner.message('Checking component operations');
  } else {
    spinner.start('Checking component operations');
  }
  // Build CSS variable → BrandKitColorEntry map for color example serialization.
  const colorsByCssVariable = new Map(
    brandKitColors.map((c) => [c.cssVariable, c]),
  );

  let uploadTasks: ComponentUploadTask[];
  try {
    uploadTasks = await buildComponentUploadTasks(
      preparedByName,
      apiService,
      existenceProgress,
      colorsByCssVariable,
    );
  } catch (error) {
    spinner.stop('Component operation check failed', 2);
    throw error;
  }

  const uploadProgress = createProgressCallback(
    spinner,
    `${actionLabel} components`,
    uploadTasks.length,
  );

  spinner.message(`${actionLabel} components`);
  const uploadResults = await uploadComponents(
    uploadTasks,
    apiService,
    uploadProgress,
  );

  const operationLabels: Record<ComponentOperation, string> = {
    create: 'Created',
    update: chalk.cyan('Updated'),
    delete: chalk.dim('Deleted'),
  };
  for (const uploadResult of uploadResults) {
    const builtComponent = builtComponents.find((component) => {
      return component.machineName === uploadResult.machineName;
    });
    results.push({
      itemName: builtComponent?.componentName ?? uploadResult.machineName,
      success: uploadResult.success,
      details: [
        {
          content: uploadResult.success
            ? operationLabels[uploadResult.operation]
            : uploadResult.error?.message?.trim() || 'Unknown upload error',
        },
      ],
    });
  }

  const hasFailures = results.some((result) => !result.success);
  spinner.stop('Pushed components', hasFailures ? 2 : 0);
  return results;
}

/**
 * Reads the project's `package.json` verbatim, if present.
 *
 * @param projectRoot
 *   The project root directory.
 *
 * @returns The raw file contents, or `undefined` when no `package.json` exists.
 */
async function readProjectPackageJson(
  projectRoot: string,
): Promise<string | undefined> {
  const packageJsonPath = path.join(projectRoot, 'package.json');
  if (!(await fileExists(packageJsonPath))) {
    return undefined;
  }
  return fs.readFile(packageJsonPath, 'utf-8');
}

/**
 * Prepare the global asset library (CSS/JS) update for Drupal.
 *
 * @param outputDir
 *   The build output directory containing the compiled global CSS/JS.
 * @param projectRoot
 *   The project root.
 */
export async function prepareGlobalAssetLibraryUpdate(
  outputDir: string,
  projectRoot?: string,
): Promise<{
  result: Result;
  assetLibrary?: Partial<AssetLibrary>;
}> {
  try {
    const globalCompiledCssPath = path.join(outputDir, 'index.css');
    const globalCompiledCssExists = await fileExists(globalCompiledCssPath);
    if (globalCompiledCssExists) {
      const globalCompiledCss = await fs.readFile(
        path.join(outputDir, 'index.css'),
        'utf-8',
      );
      const classNameCandidateIndexFile = await fs.readFile(
        path.join(outputDir, 'index.js'),
        'utf-8',
      );
      const originalCss = await getGlobalCss();
      const packageJson = projectRoot
        ? await readProjectPackageJson(projectRoot)
        : undefined;
      return {
        result: {
          success: true,
          itemName: 'Global CSS (Tailwind CSS build)',
          details: [{ content: 'Pushed' }],
        },
        assetLibrary: {
          css: { original: originalCss, compiled: globalCompiledCss },
          js: { original: classNameCandidateIndexFile, compiled: '' },
          // Only send the key when a package.json exists, so an absent file
          // never clobbers a previously stored one.
          ...(packageJson !== undefined ? { packageJson } : {}),
        },
      };
    }
    return {
      result: {
        success: false,
        itemName: 'Global CSS (Tailwind CSS build)',
        details: [
          {
            content: `Compiled Tailwind CSS file not found at ${globalCompiledCssPath}.`,
          },
        ],
      },
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    return {
      result: {
        success: false,
        itemName: 'Global CSS (Tailwind CSS build)',
        details: [{ content: errorMessage }],
      },
    };
  }
}

/**
 * Upload the global asset library (CSS/JS) to Drupal.
 */
export async function uploadGlobalAssetLibrary(
  apiService: ApiService,
  outputDir: string,
): Promise<Result> {
  const { result, assetLibrary } =
    await prepareGlobalAssetLibraryUpdate(outputDir);

  if (!result.success || !assetLibrary) {
    return result;
  }

  try {
    await apiService.updateGlobalAssetLibrary(assetLibrary);
    return result;
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    return {
      success: false,
      itemName: 'Global CSS (Tailwind CSS build)',
      details: [{ content: errorMessage }],
    };
  }
}
