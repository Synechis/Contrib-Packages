import fs from 'fs/promises';
import os from 'os';
import path from 'path';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';

import {
  collectPageResults,
  entitiesHaveColorProps,
  preparePages,
  pushPages,
} from './prepare-pages-push';

import type {
  ComponentMetadata,
  DiscoveredPage,
  DiscoveryResult,
} from '@drupal-canvas/discovery';
import type { ApiService } from '../services/api';
import type { PageListItem } from '../types/Page';

const emptyDiscoveryResult: DiscoveryResult = {
  componentRoot: '',
  projectRoot: '',
  components: [],
  pages: [],
  contentTemplates: [],
  pageTemplates: [],
  warnings: [],
  stats: { scannedFiles: 0, ignoredFiles: 0 },
  componentSchemas: new Map(),
};

function mockDiscoveredPage(
  name: string,
  uuid: string | null,
  filePath: string,
  relativePath = name + '.json',
): DiscoveredPage {
  return {
    name,
    slug: name,
    uuid,
    path: filePath,
    relativePath,
  };
}

function mockPageListItem(
  id: number,
  uuid: string,
  title: string,
  pagePath: string,
): PageListItem {
  return {
    id,
    uuid,
    title,
    status: true,
    path: pagePath,
    internalPath: `/page/${id}`,
    autoSaveLabel: null,
    autoSavePath: null,
    links: {},
    description: '',
  };
}

describe('preparePages', () => {
  let tmpDir: string;

  beforeEach(async () => {
    tmpDir = await fs.mkdtemp(path.join(os.tmpdir(), 'prepare-pages-test-'));
  });

  afterEach(async () => {
    await fs.rm(tmpDir, { recursive: true, force: true });
  });

  it('should prepare pages from local files', async () => {
    const filePath = path.join(tmpDir, 'home.json');
    await fs.writeFile(
      filePath,
      JSON.stringify({
        uuid: 'page-uuid-1',
        title: 'Home',
        pageVariant: 'marketing',
        elements: {
          'comp-1': { type: 'js.hero', props: { heading: 'Welcome' } },
        },
      }),
      'utf-8',
    );

    const pages = [mockDiscoveredPage('home', 'page-uuid-1', filePath)];
    const versions = new Map([['js.hero', 'v1']]);

    const { valid, failed } = await preparePages(
      pages,
      versions,
      emptyDiscoveryResult,
    );

    expect(failed).toHaveLength(0);
    expect(valid).toHaveLength(1);
    expect(valid[0].result.title).toBe('Home');
    expect(valid[0].result.uuid).toBe('page-uuid-1');
    expect(valid[0].result.pageVariant).toBe('marketing');
    expect(valid[0].result.components).toHaveLength(1);
    expect(valid[0].result.components[0].component_id).toBe('js.hero');
    expect(valid[0].result.components[0].component_version).toBe('v1');
  });

  it('should handle pages with no uuid', async () => {
    const filePath = path.join(tmpDir, 'new-page.json');
    await fs.writeFile(
      filePath,
      JSON.stringify({ title: 'New Page', elements: {} }),
      'utf-8',
    );

    const pages = [mockDiscoveredPage('new-page', null, filePath)];
    const { valid, failed } = await preparePages(
      pages,
      new Map(),
      emptyDiscoveryResult,
    );

    expect(failed).toHaveLength(0);
    expect(valid).toHaveLength(1);
    expect(valid[0].result.uuid).toBeNull();
  });

  it('should report failed pages for invalid JSON', async () => {
    const filePath = path.join(tmpDir, 'bad.json');
    await fs.writeFile(filePath, 'not valid json', 'utf-8');

    const pages = [mockDiscoveredPage('bad', null, filePath)];
    const { valid, failed } = await preparePages(
      pages,
      new Map(),
      emptyDiscoveryResult,
    );

    expect(valid).toHaveLength(0);
    expect(failed).toHaveLength(1);
  });
});

describe('entitiesHaveColorProps', () => {
  let tmpDir: string;

  beforeEach(async () => {
    tmpDir = await fs.mkdtemp(path.join(os.tmpdir(), 'pages-color-check-'));
  });

  afterEach(async () => {
    await fs.rm(tmpDir, { recursive: true, force: true });
  });

  it('returns true when a page uses a component with color props', async () => {
    const pagePath = path.join(tmpDir, 'home.json');
    await fs.writeFile(
      pagePath,
      JSON.stringify({
        title: 'Home',
        elements: {
          card: {
            type: 'js.color-card',
            props: { accent: 'canvas-color:brand-red' },
          },
        },
      }),
      'utf-8',
    );

    const pages = [mockDiscoveredPage('home', null, pagePath)];
    const metadata: ComponentMetadata[] = [
      {
        name: 'Color Card',
        machineName: 'color-card',
        status: true,
        required: [],
        slots: {},
        props: {
          properties: {
            accent: {
              title: 'Accent',
              type: 'string',
              $ref: 'json-schema-definitions://canvas.module/color',
            },
          },
        },
      },
    ];

    await expect(entitiesHaveColorProps(pages, metadata)).resolves.toBe(true);
  });

  it('returns false when no page uses components with color props', async () => {
    const pagePath = path.join(tmpDir, 'home.json');
    await fs.writeFile(
      pagePath,
      JSON.stringify({
        title: 'Home',
        elements: {
          hero: {
            type: 'js.hero',
            props: { heading: 'Hello' },
          },
        },
      }),
      'utf-8',
    );

    const pages = [mockDiscoveredPage('home', null, pagePath)];
    const metadata: ComponentMetadata[] = [
      {
        name: 'Hero',
        machineName: 'hero',
        status: true,
        required: [],
        slots: {},
        props: {
          properties: {
            heading: {
              title: 'Heading',
              type: 'string',
            },
          },
        },
      },
    ];

    await expect(entitiesHaveColorProps(pages, metadata)).resolves.toBe(false);
  });

  it('returns true when a content-template-shaped file uses a component with color props', async () => {
    const templatePath = path.join(tmpDir, 'node.article.full.json');
    await fs.writeFile(
      templatePath,
      JSON.stringify({
        label: 'Article — Full',
        entityType: 'node',
        bundle: 'article',
        viewMode: 'full',
        elements: {
          card: {
            type: 'js.color-card',
            props: { accent: 'canvas-color:brand-red' },
          },
        },
      }),
      'utf-8',
    );

    const metadata: ComponentMetadata[] = [
      {
        name: 'Color Card',
        machineName: 'color-card',
        status: true,
        required: [],
        slots: {},
        props: {
          properties: {
            accent: {
              title: 'Accent',
              type: 'string',
              $ref: 'json-schema-definitions://canvas.module/color',
            },
          },
        },
      },
    ];

    await expect(
      entitiesHaveColorProps([{ path: templatePath }], metadata),
    ).resolves.toBe(true);
  });
});

describe('pushPages', () => {
  let tmpDir: string;

  beforeEach(async () => {
    tmpDir = await fs.mkdtemp(path.join(os.tmpdir(), 'push-pages-test-'));
  });

  afterEach(async () => {
    await fs.rm(tmpDir, { recursive: true, force: true });
  });

  it('should update existing pages', async () => {
    const filePath = path.join(tmpDir, 'home.json');
    await fs.writeFile(
      filePath,
      JSON.stringify({ uuid: 'page-uuid-1', title: 'Home', elements: {} }),
      'utf-8',
    );

    const prepared = [
      {
        index: 0,
        result: {
          uuid: 'page-uuid-1',
          title: 'Home',
          description: '',
          pageVariant: 'marketing',
          path: '/home',
          components: [],
          filePath,
        },
      },
    ];

    const remoteByUuid = new Map([
      ['page-uuid-1', mockPageListItem(1, 'page-uuid-1', 'Home', '/home')],
    ]);

    const api = {
      updatePage: vi.fn().mockResolvedValue({}),
      createPage: vi.fn(),
    } as unknown as Pick<ApiService, 'createPage' | 'updatePage'>;

    const results = await pushPages(prepared, remoteByUuid, api);

    expect(results).toHaveLength(1);
    expect(results[0].success).toBe(true);
    expect(results[0].result?.operation).toBe('Updated');
    expect(api.updatePage).toHaveBeenCalledTimes(1);
    expect(api.updatePage).toHaveBeenCalledWith(1, {
      title: 'Home',
      description: '',
      pageVariant: 'marketing',
      status: true,
      path: '/home',
      components: [],
    });
    expect(api.createPage).not.toHaveBeenCalled();
  });

  it('omits page variants when the site does not support them', async () => {
    const filePath = path.join(tmpDir, 'home.json');
    await fs.writeFile(
      filePath,
      JSON.stringify({ uuid: 'page-uuid-1', title: 'Home', elements: {} }),
      'utf-8',
    );
    const prepared = [
      {
        index: 0,
        result: {
          uuid: 'page-uuid-1',
          title: 'Home',
          description: '',
          pageVariant: 'marketing',
          path: '/home',
          components: [],
          filePath,
        },
      },
    ];
    const remoteByUuid = new Map([
      ['page-uuid-1', mockPageListItem(1, 'page-uuid-1', 'Home', '/home')],
    ]);
    const updatePage = vi.fn().mockResolvedValue({});

    await pushPages(
      prepared,
      remoteByUuid,
      { updatePage, createPage: vi.fn() },
      false,
    );

    expect(updatePage).toHaveBeenCalledWith(1, {
      title: 'Home',
      description: '',
      status: true,
      path: '/home',
      components: [],
    });
  });

  it('should reject path alias changes for existing pages', async () => {
    const filePath = path.join(tmpDir, 'home.json');
    await fs.writeFile(
      filePath,
      JSON.stringify({ uuid: 'page-uuid-1', title: 'Home', elements: {} }),
      'utf-8',
    );

    const prepared = [
      {
        index: 0,
        result: {
          uuid: 'page-uuid-1',
          title: 'Home',
          description: '',
          pageVariant: null,
          path: '/new-home',
          components: [],
          filePath,
        },
      },
    ];

    const remoteByUuid = new Map([
      ['page-uuid-1', mockPageListItem(1, 'page-uuid-1', 'Home', '/home')],
    ]);

    const api = {
      updatePage: vi.fn(),
      createPage: vi.fn(),
    } as unknown as Pick<ApiService, 'createPage' | 'updatePage'>;

    const results = await pushPages(prepared, remoteByUuid, api);

    expect(results).toHaveLength(1);
    expect(results[0].success).toBe(false);
    expect(results[0].pageTitle).toBe('Home');
    expect(results[0].error?.message).toBe(
      'Path alias changes are not allowed for existing pages. Remote path is "/home"; local path is "/new-home".',
    );
    expect(api.updatePage).not.toHaveBeenCalled();
    expect(api.createPage).not.toHaveBeenCalled();
  });

  it('should reject missing path aliases for existing pages', async () => {
    const filePath = path.join(tmpDir, 'home.json');
    await fs.writeFile(
      filePath,
      JSON.stringify({ uuid: 'page-uuid-1', title: 'Home', elements: {} }),
      'utf-8',
    );

    const prepared = [
      {
        index: 0,
        result: {
          uuid: 'page-uuid-1',
          title: 'Home',
          description: '',
          pageVariant: null,
          path: '',
          components: [],
          filePath,
        },
      },
    ];

    const remoteByUuid = new Map([
      ['page-uuid-1', mockPageListItem(1, 'page-uuid-1', 'Home', '/home')],
    ]);

    const api = {
      updatePage: vi.fn(),
      createPage: vi.fn(),
    } as unknown as Pick<ApiService, 'createPage' | 'updatePage'>;

    const results = await pushPages(prepared, remoteByUuid, api);

    expect(results).toHaveLength(1);
    expect(results[0].success).toBe(false);
    expect(results[0].pageTitle).toBe('Home');
    expect(results[0].error?.message).toBe(
      'Path alias changes are not allowed for existing pages. Remote path is "/home"; local path is "".',
    );
    expect(api.updatePage).not.toHaveBeenCalled();
    expect(api.createPage).not.toHaveBeenCalled();
  });

  it('should create new pages and write UUID back', async () => {
    const filePath = path.join(tmpDir, 'new.json');
    await fs.writeFile(
      filePath,
      JSON.stringify({ title: 'New Page', elements: {} }),
      'utf-8',
    );

    const prepared = [
      {
        index: 0,
        result: {
          uuid: null as string | null,
          title: 'New Page',
          description: '',
          pageVariant: null,
          path: '',
          components: [],
          filePath,
        },
      },
    ];

    const api = {
      updatePage: vi.fn(),
      createPage: vi.fn().mockResolvedValue({
        uuid: 'server-assigned-uuid',
        id: 1,
        title: 'New Page',
        components: [],
      }),
    } as unknown as Pick<ApiService, 'createPage' | 'updatePage'>;

    const results = await pushPages(prepared, new Map(), api);

    expect(results).toHaveLength(1);
    expect(results[0].success).toBe(true);
    expect(results[0].result?.operation).toBe('Created');
    expect(api.createPage).toHaveBeenCalledTimes(1);
    expect(api.createPage).toHaveBeenCalledWith({
      title: 'New Page',
      description: '',
      pageVariant: null,
      status: false,
      path: '',
      components: [],
    });
    expect(api.updatePage).not.toHaveBeenCalled();

    // Verify UUID was written back to the file.
    const content = JSON.parse(await fs.readFile(filePath, 'utf-8'));
    expect(content.uuid).toBe('server-assigned-uuid');
  });

  it('keeps failed push results aligned to the original discovered page index', async () => {
    const secondFilePath = path.join(tmpDir, 'second.json');

    const prepared = [
      {
        index: 1,
        result: {
          uuid: 'page-uuid-2',
          title: 'Second',
          description: '',
          pageVariant: null,
          path: '/changed-second',
          components: [],
          filePath: secondFilePath,
        },
      },
    ];

    const remoteByUuid = new Map([
      ['page-uuid-2', mockPageListItem(2, 'page-uuid-2', 'Second', '/second')],
    ]);

    const api = {
      updatePage: vi.fn(),
      createPage: vi.fn(),
    } as unknown as Pick<ApiService, 'createPage' | 'updatePage'>;

    const results = await pushPages(prepared, remoteByUuid, api);

    expect(results).toHaveLength(1);
    expect(results[0].success).toBe(false);
    expect(results[0].index).toBe(1);
    expect(results[0].pageTitle).toBe('Second');
  });
});

describe('collectPageResults', () => {
  it('should collect successful results', () => {
    const pushResults = [
      {
        success: true,
        result: { title: 'Home', operation: 'Updated' as const },
        index: 0,
      },
      {
        success: true,
        result: { title: 'About', operation: 'Created' as const },
        index: 1,
      },
    ];

    const results = collectPageResults(pushResults, [], []);

    expect(results).toHaveLength(2);
    expect(results[0]).toEqual({
      itemName: 'Home',
      success: true,
      details: [{ content: 'Updated' }],
    });
    expect(results[1]).toEqual({
      itemName: 'About',
      success: true,
      details: [{ content: 'Created' }],
    });
  });

  it('should collect failed push results', () => {
    const pages = [
      mockDiscoveredPage('home', null, '/tmp/home.json', 'pages/home.json'),
    ];

    const pushResults = [
      {
        success: false,
        error: new Error('API error'),
        index: 0,
        pageTitle: 'Home',
      },
    ];

    const results = collectPageResults(pushResults, [], pages);

    expect(results).toHaveLength(1);
    expect(results[0].success).toBe(false);
    expect(results[0].itemName).toBe('Home (pages/home.json)');
    expect(results[0].details?.[0].content).toBe('API error');
  });

  it('collects failed preparations with the title and relative path', () => {
    const pages = [
      mockDiscoveredPage('bad', null, '/tmp/bad.json', 'pages/bad.json'),
    ];

    const failedPreps = [
      {
        index: 0,
        error: new Error('Invalid components'),
        pageTitle: 'Broken page',
      },
    ];

    const results = collectPageResults([], failedPreps, pages);

    expect(results).toHaveLength(1);
    expect(results[0].success).toBe(false);
    expect(results[0].itemName).toBe('Broken page (pages/bad.json)');
    expect(results[0].details?.[0].content).toBe('Invalid components');
  });

  it('falls back to the relative path for failed preparations without a title', () => {
    const pages = [
      mockDiscoveredPage('bad', null, '/tmp/bad.json', 'pages/bad.json'),
    ];

    const failedPreps = [{ index: 0, error: new Error('Invalid JSON') }];

    const results = collectPageResults([], failedPreps, pages);

    expect(results).toHaveLength(1);
    expect(results[0].success).toBe(false);
    expect(results[0].itemName).toBe('pages/bad.json');
    expect(results[0].details?.[0].content).toBe('Invalid JSON');
  });
});
