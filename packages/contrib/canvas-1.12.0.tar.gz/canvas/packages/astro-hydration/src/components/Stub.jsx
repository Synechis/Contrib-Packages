/* Add any additional functions/hooks to expose to in-browser JS components here.

  In order to have Astro bundle code with un-minified names, we use dynamic imports in this Stub component.
  Using dynamic imports results in Rollup (Astro uses Vite which uses Rollup) exporting the all hooks,
  jsx, jsxs, and Fragment functions, with names, from the corresponding module bundles, which
  can then be imported by the in-browser JS components. */

const { ...preact } = await import('preact');
const { ...preactCompat } = await import('preact/compat');
const { ...preactHooks } = await import('preact/hooks');
const { ...preactRenderToString } = await import('preact-render-to-string');
const { ...jsxRuntime } = await import('../lib/jsx-runtime-default');
const { default: clsx } = await import('clsx');
const { ...tailwindMerge } = await import('tailwind-merge');
const { cva } = await import('class-variance-authority');
const { DrupalJsonApiParams } = await import('../lib/jsonapi-params');
const useSwr = await import('../lib/swr');
const tailwindTypography = await import('../lib/tailwindcss-typography');

const { ...drupalCanvas } = await import('../lib/drupal-canvas');
const { ...drupalCanvasReact } = await import('../lib/drupal-canvas-react');
// For backward compatibility import separately elements that were moved to the drupal-canvas package
// so they have separate files in dist that can be used in backward compatible import map entries.
const FormattedText = await import('drupal-canvas/FormattedText');
const {
  sortMenu: sortLinksetMenu,
  getPageData,
  getSiteData,
} = await import('drupal-canvas/drupal-utils');
const Image = await import('drupal-canvas/next-image-standalone');
const { cn } = await import('drupal-canvas/utils');
const { JsonApiClient } = await import('drupal-canvas/jsonapi-client');
const { getNodePath, sortMenu } = await import('drupal-canvas/jsonapi-utils');

// Only load in the browser: Astro evaluates this module during SSR/build when
// we add the SSR directive <Stub client:load/> and canvas-island touches
// customElements (not available server-side)
if (typeof window !== 'undefined' && typeof customElements !== 'undefined') {
  await import('../lib/canvas-island.ts');
  // The client renderer Drupal points every island at; it wraps Astro's Preact
  // renderer with the drupal-canvas context providers.
  await import('../lib/canvas-client.ts');
}

export default function () {}
