<?php

namespace Drupal\localgov_microsites_demo\EventSubscriber;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Entity\FieldableEntityInterface;
use Drupal\default_content\Event\DefaultContentEvents;
use Drupal\default_content\Event\ImportEvent;
use Drupal\group_content_menu\GroupContentMenuInterface;
use Drupal\menu_link_content\MenuLinkContentInterface;
use Drupal\node\NodeInterface;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

/**
 * Repairs demo content references after default content import.
 */
class DemoNewsContentImportSubscriber implements EventSubscriberInterface {

  /**
   * Fixed menu link ownership for demo microsites.
   */
  protected const MENU_LINK_ASSIGNMENTS = [
    '3f68b819-3b48-49bc-a272-8c3326186e91' => [
      'group_uuid' => 'd8b010b5-5bbd-4333-a81b-5a58eae9b121',
      'menu_plugin_id' => 'lgms_main_menu',
    ],
    'afcbf1ec-83ce-4528-bd7d-cb6c11610aa6' => [
      'group_uuid' => 'd8b010b5-5bbd-4333-a81b-5a58eae9b121',
      'menu_plugin_id' => 'lgms_main_menu',
    ],
    'e9504143-ed00-4cf5-9421-2b6489369186' => [
      'group_uuid' => 'd8b010b5-5bbd-4333-a81b-5a58eae9b121',
      'menu_plugin_id' => 'lgms_main_menu',
    ],
    'd2966bcd-9f67-4d8c-87dc-9c76e0cde990' => [
      'group_uuid' => 'd8b010b5-5bbd-4333-a81b-5a58eae9b121',
      'menu_plugin_id' => 'lgms_utility_menu',
    ],
    'e79a8239-9a38-4b5c-a330-a8399dda8e92' => [
      'group_uuid' => 'd8b010b5-5bbd-4333-a81b-5a58eae9b121',
      'menu_plugin_id' => 'lgms_utility_menu',
    ],
    '73256f13-7c9e-48b3-ad10-fa0b6e482999' => [
      'group_uuid' => '39342783-d0a8-4f83-9528-f8fce250e21f',
      'menu_plugin_id' => 'lgms_main_menu',
    ],
    '2de558cc-56d9-4093-9fce-7ba07dac0f07' => [
      'group_uuid' => '39342783-d0a8-4f83-9528-f8fce250e21f',
      'menu_plugin_id' => 'lgms_main_menu',
    ],
  ];

  /**
   * The entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected EntityTypeManagerInterface $entityTypeManager;

  /**
   * Constructs a new event subscriber.
   *
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The entity type manager.
   */
  public function __construct(EntityTypeManagerInterface $entity_type_manager) {
    $this->entityTypeManager = $entity_type_manager;
  }

  /**
   * {@inheritdoc}
   */
  public static function getSubscribedEvents(): array {
    return [
      DefaultContentEvents::IMPORT => 'onImport',
    ];
  }

  /**
   * Repairs demo newsroom references if import dependency cycles dropped them.
   *
   * @param \Drupal\default_content\Event\ImportEvent $event
   *   The default content import event.
   */
  public function onImport(ImportEvent $event): void {
    if ($event->getModule() !== 'localgov_microsites_demo') {
      return;
    }

    $imported_entities = $event->getImportedEntities();

    $this->repairMicrositeMenuLinks($imported_entities);

    $node_storage = $this->entityTypeManager->getStorage('node');

    $newsrooms = [];
    $articles = [];

    foreach ($imported_entities as $entity) {
      if (!$entity instanceof NodeInterface) {
        continue;
      }
      if ($entity->bundle() === 'localgov_newsroom') {
        $newsrooms[] = $entity;
      }
      elseif ($entity->bundle() === 'localgov_news_article') {
        $articles[] = $entity;
      }
    }

    if (count($newsrooms) !== 1) {
      return;
    }

    /** @var \Drupal\node\NodeInterface $newsroom */
    $newsroom = reset($newsrooms);

    // In single-newsroom demo installs, article newsroom references can be
    // dropped by import ordering. Re-attach and save to regenerate aliases.
    foreach ($articles as $article) {
      if (!$article instanceof FieldableEntityInterface || !$article->hasField('localgov_newsroom')) {
        continue;
      }

      if ($article->get('localgov_newsroom')->isEmpty()) {
        $article->set('localgov_newsroom', ['target_id' => $newsroom->id()]);
        $article->save();
      }
    }

    if (!$newsroom->hasField('localgov_newsroom_featured') || !$newsroom->get('localgov_newsroom_featured')->isEmpty()) {
      return;
    }

    $newsroom_article_ids = $node_storage->getQuery()
      ->accessCheck(FALSE)
      ->condition('type', 'localgov_news_article')
      ->condition('localgov_newsroom.target_id', $newsroom->id())
      ->sort('created', 'DESC')
      ->range(0, 3)
      ->execute();

    if ($newsroom_article_ids === []) {
      return;
    }

    $featured_references = array_map(static function ($nid): array {
      return ['target_id' => (int) $nid];
    }, array_values($newsroom_article_ids));

    $newsroom->set('localgov_newsroom_featured', $featured_references);
    $newsroom->save();
  }

  /**
   * Reassigns imported menu links to the correct generated group menus.
   *
   * Default content exports store numeric group menu IDs in menu_name. Those
   * IDs depend on install order, so resolve the intended group menu at import
   * time from stable group and menu plugin identifiers.
   *
   * @param array $imported_entities
   *   The imported entities keyed by UUID.
   */
  protected function repairMicrositeMenuLinks(array $imported_entities): void {
    $menu_links = [];

    foreach ($imported_entities as $entity) {
      if ($entity instanceof MenuLinkContentInterface) {
        $menu_links[$entity->uuid()] = $entity;
      }
    }

    if ($menu_links === []) {
      return;
    }

    foreach (self::MENU_LINK_ASSIGNMENTS as $menu_link_uuid => $assignment) {
      if (!isset($menu_links[$menu_link_uuid])) {
        continue;
      }

      $menu_name = $this->resolveGroupMenuName($assignment['group_uuid'], $assignment['menu_plugin_id']);
      if ($menu_name === NULL) {
        continue;
      }

      $menu_link = $menu_links[$menu_link_uuid];
      if ($menu_link->getMenuName() === $menu_name) {
        continue;
      }

      $menu_link->set('menu_name', $menu_name);
      $menu_link->save();
    }
  }

  /**
   * Resolves a stable group UUID and menu plugin pair to the live menu name.
   */
  protected function resolveGroupMenuName(string $group_uuid, string $menu_plugin_id): ?string {
    $groups = $this->entityTypeManager
      ->getStorage('group')
      ->loadByProperties(['uuid' => $group_uuid]);
    $group = reset($groups);

    if (!$group) {
      return NULL;
    }

    $group_relationships = $this->entityTypeManager
      ->getStorage('group_relationship')
      ->loadByGroup($group, 'group_content_menu:' . $menu_plugin_id);
    $group_relationship = reset($group_relationships);

    if (!$group_relationship) {
      return NULL;
    }

    return GroupContentMenuInterface::MENU_PREFIX . $group_relationship->getEntity()->id();
  }

}
