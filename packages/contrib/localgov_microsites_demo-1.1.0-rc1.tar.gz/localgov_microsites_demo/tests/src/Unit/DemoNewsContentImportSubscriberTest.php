<?php

namespace Drupal\Tests\localgov_microsites_demo\Unit;

use Drupal\Core\Entity\EntityStorageInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Field\FieldItemListInterface;
use Drupal\Core\Entity\Query\QueryInterface;
use Drupal\Tests\UnitTestCase;
use Drupal\default_content\Event\ImportEvent;
use Drupal\group\Entity\GroupInterface;
use Drupal\group\Entity\GroupRelationshipInterface;
use Drupal\group\Entity\Storage\GroupRelationshipStorageInterface;
use Drupal\group_content_menu\GroupContentMenuInterface;
use Drupal\localgov_microsites_demo\EventSubscriber\DemoNewsContentImportSubscriber;
use Drupal\menu_link_content\MenuLinkContentInterface;
use Drupal\node\NodeInterface;
use PHPUnit\Framework\Attributes\CoversClass;
use PHPUnit\Framework\Attributes\Group;

#[CoversClass(DemoNewsContentImportSubscriber::class)]
#[Group('localgov_microsites_demo')]
class DemoNewsContentImportSubscriberTest extends UnitTestCase {

  public function testSkipsWhenImportIsFromDifferentModule(): void {
    $entity_type_manager = $this->createMock(EntityTypeManagerInterface::class);
    $entity_type_manager->expects($this->never())->method('getStorage');

    $subscriber = new DemoNewsContentImportSubscriber($entity_type_manager);
    $event = new ImportEvent([], 'some_other_module');

    $subscriber->onImport($event);
  }

  public function testRepairsMissingArticleNewsroomReferences(): void {
    $node_storage = $this->createMock(EntityStorageInterface::class);
    $entity_type_manager = $this->createMock(EntityTypeManagerInterface::class);
    $entity_type_manager->expects($this->once())
      ->method('getStorage')
      ->with('node')
      ->willReturn($node_storage);

    $newsroom = $this->createMock(NodeInterface::class);
    $newsroom->method('bundle')->willReturn('localgov_newsroom');
    $newsroom->method('id')->willReturn(42);
    $newsroom->method('hasField')
      ->willReturnMap([
        ['localgov_newsroom_featured', FALSE],
      ]);

    $newsroom_field = $this->createMock(FieldItemListInterface::class);
    $newsroom_field->method('isEmpty')->willReturn(TRUE);

    $article = $this->createMock(NodeInterface::class);
    $article->method('bundle')->willReturn('localgov_news_article');
    $article->method('hasField')
      ->willReturnMap([
        ['localgov_newsroom', TRUE],
      ]);
    $article->method('get')
      ->willReturnMap([
        ['localgov_newsroom', $newsroom_field],
      ]);
    $article->expects($this->once())
      ->method('set')
      ->with('localgov_newsroom', ['target_id' => 42]);
    $article->expects($this->once())->method('save');

    $event = new ImportEvent([$newsroom, $article], 'localgov_microsites_demo');
    $subscriber = new DemoNewsContentImportSubscriber($entity_type_manager);

    $subscriber->onImport($event);
  }

  public function testRepairsMicrositeMenuAssignments(): void {
    $menu_link = $this->createMock(MenuLinkContentInterface::class);
    $menu_link->method('uuid')->willReturn('3f68b819-3b48-49bc-a272-8c3326186e91');
    $menu_link->method('getMenuName')->willReturn('group_menu_link_content-999');
    $menu_link->expects($this->once())
      ->method('set')
      ->with('menu_name', 'group_menu_link_content-42');
    $menu_link->expects($this->once())->method('save');

    $group = $this->createMock(GroupInterface::class);

    $group_storage = $this->createMock(EntityStorageInterface::class);
    $group_storage->expects($this->once())
      ->method('loadByProperties')
      ->with(['uuid' => 'd8b010b5-5bbd-4333-a81b-5a58eae9b121'])
      ->willReturn([$group]);

    $group_menu = $this->createMock(GroupContentMenuInterface::class);
    $group_menu->method('id')->willReturn(42);

    $group_relationship = $this->createMock(GroupRelationshipInterface::class);
    $group_relationship->method('getEntity')->willReturn($group_menu);

    $group_relationship_storage = $this->createMock(GroupRelationshipStorageInterface::class);
    $group_relationship_storage->expects($this->once())
      ->method('loadByGroup')
      ->with($group, 'group_content_menu:lgms_main_menu')
      ->willReturn([$group_relationship]);

    $node_storage = $this->createMock(EntityStorageInterface::class);

    $entity_type_manager = $this->createMock(EntityTypeManagerInterface::class);
    $entity_type_manager->expects($this->exactly(3))
      ->method('getStorage')
      ->willReturnMap([
        ['group', $group_storage],
        ['group_relationship', $group_relationship_storage],
        ['node', $node_storage],
      ]);

    $event = new ImportEvent([$menu_link], 'localgov_microsites_demo');
    $subscriber = new DemoNewsContentImportSubscriber($entity_type_manager);

    $subscriber->onImport($event);
  }

  public function testSetsFeaturedArticlesWhenMissing(): void {
    $query = $this->createMock(QueryInterface::class);
    $query->method('accessCheck')->with(FALSE)->willReturnSelf();
    $query->method('condition')->willReturnSelf();
    $query->method('sort')->with('created', 'DESC')->willReturnSelf();
    $query->method('range')->with(0, 3)->willReturnSelf();
    $query->method('execute')->willReturn([11, 10, 9]);

    $node_storage = $this->createMock(EntityStorageInterface::class);
    $node_storage->method('getQuery')->willReturn($query);

    $entity_type_manager = $this->createMock(EntityTypeManagerInterface::class);
    $entity_type_manager->expects($this->once())
      ->method('getStorage')
      ->with('node')
      ->willReturn($node_storage);

    $featured_field = $this->createMock(FieldItemListInterface::class);
    $featured_field->method('isEmpty')->willReturn(TRUE);

    $newsroom = $this->createMock(NodeInterface::class);
    $newsroom->method('bundle')->willReturn('localgov_newsroom');
    $newsroom->method('id')->willReturn(42);
    $newsroom->method('hasField')
      ->willReturnMap([
        ['localgov_newsroom_featured', TRUE],
      ]);
    $newsroom->method('get')
      ->willReturnMap([
        ['localgov_newsroom_featured', $featured_field],
      ]);
    $newsroom->expects($this->once())
      ->method('set')
      ->with('localgov_newsroom_featured', [
        ['target_id' => 11],
        ['target_id' => 10],
        ['target_id' => 9],
      ]);
    $newsroom->expects($this->once())->method('save');

    $event = new ImportEvent([$newsroom], 'localgov_microsites_demo');
    $subscriber = new DemoNewsContentImportSubscriber($entity_type_manager);

    $subscriber->onImport($event);
  }

  public function testDoesNotOverrideExistingFeaturedArticles(): void {
    $node_storage = $this->createMock(EntityStorageInterface::class);
    $node_storage->expects($this->never())->method('getQuery');

    $entity_type_manager = $this->createMock(EntityTypeManagerInterface::class);
    $entity_type_manager->expects($this->once())
      ->method('getStorage')
      ->with('node')
      ->willReturn($node_storage);

    $featured_field = $this->createMock(FieldItemListInterface::class);
    $featured_field->method('isEmpty')->willReturn(FALSE);

    $newsroom = $this->createMock(NodeInterface::class);
    $newsroom->method('bundle')->willReturn('localgov_newsroom');
    $newsroom->method('hasField')
      ->willReturnMap([
        ['localgov_newsroom_featured', TRUE],
      ]);
    $newsroom->method('get')
      ->willReturnMap([
        ['localgov_newsroom_featured', $featured_field],
      ]);
    $newsroom->expects($this->never())->method('set');
    $newsroom->expects($this->never())->method('save');

    $event = new ImportEvent([$newsroom], 'localgov_microsites_demo');
    $subscriber = new DemoNewsContentImportSubscriber($entity_type_manager);

    $subscriber->onImport($event);
  }

}
