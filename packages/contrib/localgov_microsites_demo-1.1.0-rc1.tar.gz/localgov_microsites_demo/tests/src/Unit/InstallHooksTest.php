<?php

namespace Drupal\Tests\localgov_microsites_demo\Unit;

use Drupal\Core\Config\Config;
use Drupal\Core\Config\Entity\ConfigEntityInterface;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\DependencyInjection\ContainerBuilder;
use Drupal\Core\Entity\EntityStorageInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\path_alias\AliasManagerInterface;
use Drupal\Tests\UnitTestCase;
use Drupal\group\Entity\GroupInterface;
use PHPUnit\Framework\Attributes\CoversFunction;
use PHPUnit\Framework\Attributes\Group;

#[CoversFunction('localgov_microsites_demo_modules_installed')]
#[CoversFunction('localgov_microsites_demo_resolve_front_page_path')]
#[Group('localgov_microsites_demo')]
class InstallHooksTest extends UnitTestCase {

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    require_once DRUPAL_ROOT . '/modules/contrib/localgov_microsites_demo/localgov_microsites_demo.install';
  }

  /**
   * {@inheritdoc}
   */
  protected function tearDown(): void {
    \Drupal::setContainer(new ContainerBuilder());
    parent::tearDown();
  }

  /**
   * Verifies sync installs are intentionally skipped for demo clean installs.
   */
  public function testModulesInstalledReturnsEarlyWhenSyncing(): void {
    $this->assertNull(localgov_microsites_demo_modules_installed(['localgov_microsites_demo'], TRUE));
  }

  /**
   * Verifies hook_modules_installed() ignores unrelated module installs.
   */
  public function testModulesInstalledReturnsEarlyForOtherModules(): void {
    $this->assertNull(localgov_microsites_demo_modules_installed(['node'], FALSE));
  }

  /**
   * Verifies clean-install flow applies demo group domain settings.
   */
  public function testModulesInstalledRunsDemoSettingsOnCleanInstall(): void {
    $group_one = $this->createMock(GroupInterface::class);
    $group_one->method('id')->willReturn('11');
    $group_one->method('label')->willReturn('Scarfolk People\'s Park');
    $group_one->method('uuid')->willReturn('d8b010b5-5bbd-4333-a81b-5a58eae9b121');

    $group_two = $this->createMock(GroupInterface::class);
    $group_two->method('id')->willReturn('22');
    $group_two->method('label')->willReturn('Scarfolk Independent Living');
    $group_two->method('uuid')->willReturn('39342783-d0a8-4f83-9528-f8fce250e21f');

    $group_three = $this->createMock(GroupInterface::class);
    $group_three->method('id')->willReturn('33');
    $group_three->method('label')->willReturn('Scarfolk Digital Blog');
    $group_three->method('uuid')->willReturn('53e7283e-e826-4bad-928e-fbbddc6cfbbf');

    $group_storage = $this->createMock(EntityStorageInterface::class);
    $group_storage->expects($this->exactly(3))
      ->method('loadByProperties')
      ->willReturnMap([
        [['uuid' => 'd8b010b5-5bbd-4333-a81b-5a58eae9b121'], [$group_one]],
        [['uuid' => '39342783-d0a8-4f83-9528-f8fce250e21f'], [$group_two]],
        [['uuid' => '53e7283e-e826-4bad-928e-fbbddc6cfbbf'], [$group_three]],
      ]);

    $domain_one = $this->createMock(ConfigEntityInterface::class);
    $domain_one->method('id')->willReturn('group_11');
    $domain_one->method('set')->willReturnSelf();
    $domain_one->method('setThirdPartySetting')->willReturnSelf();
    $domain_one->expects($this->once())->method('save');

    $domain_two = $this->createMock(ConfigEntityInterface::class);
    $domain_two->method('id')->willReturn('group_22');
    $domain_two->method('set')->willReturnSelf();
    $domain_two->method('setThirdPartySetting')->willReturnSelf();
    $domain_two->expects($this->once())->method('save');

    $domain_three = $this->createMock(ConfigEntityInterface::class);
    $domain_three->method('id')->willReturn('group_33');
    $domain_three->method('set')->willReturnSelf();
    $domain_three->method('setThirdPartySetting')->willReturnSelf();
    $domain_three->expects($this->once())->method('save');

    $domain_storage = $this->createMock(EntityStorageInterface::class);
    $domain_storage->expects($this->exactly(3))
      ->method('load')
      ->willReturnMap([
        ['group_11', NULL],
        ['group_22', NULL],
        ['group_33', NULL],
      ]);
    $domain_storage->expects($this->exactly(3))
      ->method('create')
      ->willReturnCallback(function (array $values) use ($domain_one, $domain_two, $domain_three) {
        return match ($values['id']) {
          'group_11' => $domain_one,
          'group_22' => $domain_two,
          'group_33' => $domain_three,
        };
      });

    $entity_type_manager = $this->createMock(EntityTypeManagerInterface::class);
    $entity_type_manager->expects($this->exactly(2))
      ->method('getStorage')
      ->willReturnMap([
        ['group', $group_storage],
        ['domain', $domain_storage],
      ]);

    $alias_manager = $this->createMock(AliasManagerInterface::class);
    $alias_manager->expects($this->exactly(3))
      ->method('getPathByAlias')
      ->willReturnMap([
        ['/welcome-scarfolk-peoples-park', '/node/101'],
        ['/living-independently', '/living-independently'],
        ['/scarfolk-digital', '/scarfolk-digital'],
      ]);

    $editable_config = $this->getMockBuilder(Config::class)
      ->disableOriginalConstructor()
      ->onlyMethods(['set', 'save'])
      ->getMock();
    $editable_config->expects($this->exactly(9))
      ->method('set')
      ->willReturnSelf();
    $editable_config->expects($this->exactly(3))->method('save');

    $config_factory = $this->createMock(ConfigFactoryInterface::class);
    $config_factory->expects($this->exactly(3))
      ->method('getEditable')
      ->willReturnMap([
        ['domain.config.group_11.system.site', $editable_config],
        ['domain.config.group_22.system.site', $editable_config],
        ['domain.config.group_33.system.site', $editable_config],
      ]);

    $container = new ContainerBuilder();
    $container->set('entity_type.manager', $entity_type_manager);
    $container->set('path_alias.manager', $alias_manager);
    $container->set('config.factory', $config_factory);
    \Drupal::setContainer($container);

    $this->assertNull(localgov_microsites_demo_modules_installed(['localgov_microsites_demo'], FALSE));
  }

  /**
   * Verifies front page alias resolution returns canonical node paths.
   */
  public function testResolveFrontPagePathReturnsCanonicalNodePath(): void {
    $alias_manager = $this->createMock(AliasManagerInterface::class);
    $alias_manager->expects($this->once())
      ->method('getPathByAlias')
      ->with('/welcome')
      ->willReturn('/node/123');

    $container = new ContainerBuilder();
    $container->set('path_alias.manager', $alias_manager);
    \Drupal::setContainer($container);

    $this->assertSame('/node/123', localgov_microsites_demo_resolve_front_page_path('welcome'));
  }

  /**
   * Verifies non-node aliases are returned as aliases.
   */
  public function testResolveFrontPagePathKeepsAliasForNonNodePath(): void {
    $alias_manager = $this->createMock(AliasManagerInterface::class);
    $alias_manager->expects($this->once())
      ->method('getPathByAlias')
      ->with('/living-independently')
      ->willReturn('/localgov-directory/channel/1');

    $container = new ContainerBuilder();
    $container->set('path_alias.manager', $alias_manager);
    \Drupal::setContainer($container);

    $this->assertSame('/living-independently', localgov_microsites_demo_resolve_front_page_path('/living-independently'));
  }

}
