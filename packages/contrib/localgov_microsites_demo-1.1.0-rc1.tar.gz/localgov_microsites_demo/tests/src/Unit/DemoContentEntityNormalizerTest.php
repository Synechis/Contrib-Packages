<?php

namespace Drupal\Tests\localgov_microsites_demo\Unit;

use Drupal\Core\Entity\ContentEntityInterface;
use Drupal\Core\Entity\EntityRepositoryInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Entity\ContentEntityTypeInterface;
use Drupal\Core\Extension\ModuleHandlerInterface;
use Drupal\Core\Field\FieldDefinitionInterface;
use Drupal\Core\Field\FieldStorageDefinitionInterface;
use Drupal\Core\Language\LanguageManagerInterface;
use Drupal\Tests\UnitTestCase;
use Drupal\localgov_microsites_demo\Normalizer\DemoContentEntityNormalizer;
use PHPUnit\Framework\Attributes\CoversClass;
use PHPUnit\Framework\Attributes\Group;

#[CoversClass(DemoContentEntityNormalizer::class)]
#[Group('localgov_microsites_demo')]
class DemoContentEntityNormalizerTest extends UnitTestCase {

  /**
   * Builds an entity type mock for parent field filtering.
   */
  private function createEntityTypeMock(): ContentEntityTypeInterface {
    $entity_type = $this->createMock(ContentEntityTypeInterface::class);
    $entity_type->method('getKey')
      ->willReturnMap([
        ['langcode', NULL],
        ['default_langcode', NULL],
      ]);
    $entity_type->method('getRevisionMetadataKey')->with('revision_created')->willReturn(NULL);
    $entity_type->method('get')->willReturn(NULL);
    return $entity_type;
  }

  /**
   * Builds a test subject that exposes getFieldsToNormalize().
   */
  private function createNormalizer(): TestableDemoContentEntityNormalizer {
    return new TestableDemoContentEntityNormalizer(
      $this->createMock(EntityTypeManagerInterface::class),
      $this->createMock(ModuleHandlerInterface::class),
      $this->createMock(EntityRepositoryInterface::class),
      $this->createMock(LanguageManagerInterface::class)
    );
  }

  /**
   * Creates a minimal field definition mock accepted by parent normalizer.
   */
  private function createFieldDefinitionMock(): FieldDefinitionInterface {
    $storage_definition = $this->createMock(FieldStorageDefinitionInterface::class);

    $field_definition = $this->createMock(FieldDefinitionInterface::class);
    $field_definition->method('getFieldStorageDefinition')->willReturn($storage_definition);

    return $field_definition;
  }

  public function testAddsGidForGroupRelationshipEntities(): void {
    $entity = $this->createMock(ContentEntityInterface::class);
    $entity->method('getFieldDefinitions')->willReturn([
      'title' => $this->createFieldDefinitionMock(),
    ]);
    $entity->method('getEntityType')->willReturn($this->createEntityTypeMock());
    $entity->method('getEntityTypeId')->willReturn('group_relationship');
    $entity->method('hasField')->with('gid')->willReturn(TRUE);

    $fields = $this->createNormalizer()->publicGetFieldsToNormalize($entity);

    $this->assertContains('title', $fields);
    $this->assertContains('gid', $fields);
  }

  public function testDoesNotDuplicateGidField(): void {
    $entity = $this->createMock(ContentEntityInterface::class);
    $entity->method('getFieldDefinitions')->willReturn([
      'gid' => $this->createFieldDefinitionMock(),
      'title' => $this->createFieldDefinitionMock(),
    ]);
    $entity->method('getEntityType')->willReturn($this->createEntityTypeMock());
    $entity->method('getEntityTypeId')->willReturn('group_relationship');
    $entity->method('hasField')->with('gid')->willReturn(TRUE);

    $fields = $this->createNormalizer()->publicGetFieldsToNormalize($entity);

    $this->assertSame(1, count(array_keys($fields, 'gid', TRUE)));
  }

  public function testDoesNotAddGidForOtherEntityTypes(): void {
    $entity = $this->createMock(ContentEntityInterface::class);
    $entity->method('getFieldDefinitions')->willReturn([
      'title' => $this->createFieldDefinitionMock(),
    ]);
    $entity->method('getEntityType')->willReturn($this->createEntityTypeMock());
    $entity->method('getEntityTypeId')->willReturn('node');
    $entity->expects($this->never())->method('hasField');

    $fields = $this->createNormalizer()->publicGetFieldsToNormalize($entity);

    $this->assertContains('title', $fields);
    $this->assertNotContains('gid', $fields);
  }

}

/**
 * Test-only wrapper exposing a protected method.
 */
class TestableDemoContentEntityNormalizer extends DemoContentEntityNormalizer {

  /**
   * Exposes getFieldsToNormalize() for unit testing.
   */
  public function publicGetFieldsToNormalize(ContentEntityInterface $entity): array {
    return $this->getFieldsToNormalize($entity);
  }

}
