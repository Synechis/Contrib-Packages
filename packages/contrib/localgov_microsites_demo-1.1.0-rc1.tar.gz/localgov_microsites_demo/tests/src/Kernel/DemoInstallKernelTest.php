<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_microsites_demo\Kernel;

use Drupal\KernelTests\KernelTestBase;
use Drupal\node\Entity\Node;
use Drupal\node\Entity\NodeType;
use Drupal\path_alias\Entity\PathAlias;
use PHPUnit\Framework\Attributes\CoversFunction;
use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;

#[CoversFunction('localgov_microsites_demo_modules_installed')]
#[CoversFunction('localgov_microsites_demo_resolve_front_page_path')]
#[Group('localgov_microsites_demo')]
#[RunTestsInSeparateProcesses]
class DemoInstallKernelTest extends KernelTestBase {

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'node',
    'path_alias',
    'system',
    'user',
  ];

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    require_once DRUPAL_ROOT . '/modules/contrib/localgov_microsites_demo/localgov_microsites_demo.install';

    $this->installEntitySchema('node');
    $this->installEntitySchema('path_alias');
    $this->installEntitySchema('user');
    $this->installSchema('node', 'node_access');

    $this->installConfig([
      'node',
      'system',
      'user',
    ]);

    NodeType::create([
      'type' => 'page',
      'name' => 'Page',
    ])->save();
  }

  /**
   * Verifies aliases resolving to node paths return canonical paths.
   */
  public function testResolveFrontPagePathReturnsCanonicalNodePath(): void {
    $node = Node::create([
      'type' => 'page',
      'title' => 'Welcome page',
      'uid' => 1,
    ]);
    $node->save();

    PathAlias::create([
      'path' => '/node/' . $node->id(),
      'alias' => '/welcome-page',
      'langcode' => 'en',
    ])->save();

    $this->assertSame('/node/' . $node->id(), localgov_microsites_demo_resolve_front_page_path('/welcome-page'));
    $this->assertSame('/not-a-node', localgov_microsites_demo_resolve_front_page_path('/not-a-node'));
  }

  /**
   * Verifies demo clean-install flow skips sync and unrelated installs.
   */
  public function testModulesInstalledEarlyReturnPaths(): void {
    $this->assertNull(localgov_microsites_demo_modules_installed(['localgov_microsites_demo'], TRUE));
    $this->assertNull(localgov_microsites_demo_modules_installed(['node'], FALSE));
  }

}
