<?php

namespace Drupal\domain_path_pathauto\Hook;

use Drupal\Core\Database\Connection;
use Drupal\Core\Entity\ContentEntityInterface;
use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\Core\KeyValueStore\KeyValueFactoryInterface;
use Drupal\domain\DomainInterface;
use Drupal\domain_path\DomainPathHelper;
use Drupal\domain_path_pathauto\DomainPathautoFieldItemList;
use Drupal\domain_path_pathauto\DomainPathautoItem;
use Drupal\domain_path_pathauto\DomainPathautoWidget;
use Drupal\pathauto\AliasStorageHelperInterface;

/**
 * Hook implementations for domain_path_pathauto.
 *
 * This class is final and internal. To customize pathauto
 * hook behavior, implement the corresponding hooks in your
 * own module. If you need an extension point that hooks
 * cannot provide, please open an issue in the
 * domain_path issue queue.
 *
 * @internal
 */
final class DomainPathPathautoHooks {

  public function __construct(
    protected AliasStorageHelperInterface $aliasStorageHelper,
    protected Connection $database,
    protected KeyValueFactoryInterface $keyValueFactory,
  ) {}

  /**
   * Implements hook_field_info_alter().
   */
  #[Hook('field_info_alter')]
  public function fieldInfoAlter(&$info) {
    $info['domain_path']['class'] = DomainPathautoItem::class;
    $info['domain_path']['list_class'] = DomainPathautoFieldItemList::class;
  }

  /**
   * Implements hook_field_widget_info_alter().
   */
  #[Hook('field_widget_info_alter')]
  public function fieldWidgetInfoAlter(&$widgets) {
    $widgets['domain_path']['class'] = DomainPathautoWidget::class;
  }

  /**
   * Implements hook_entity_delete().
   */
  #[Hook('entity_delete')]
  public function entityDelete(EntityInterface $entity) {
    if (
      $entity->hasLinkTemplate('canonical')
      && $entity instanceof ContentEntityInterface
      && $entity->hasField(DomainPathHelper::PATH_FIELD)
      && $entity->getFieldDefinition(DomainPathHelper::PATH_FIELD)->getType() === 'domain_path'
    ) {
      $this->aliasStorageHelper->deleteEntityPathAll($entity);
      foreach ($entity->get(DomainPathHelper::PATH_FIELD) as $item) {
        $item->get('pathauto')->purge();
      }
    }
  }

  /**
   * Implements hook_ENTITY_TYPE_delete() for domain entities.
   */
  #[Hook('domain_delete')]
  public function domainDelete(EntityInterface $entity) {
    if (!$entity instanceof DomainInterface) {
      return;
    }

    // Query the key_value table for collections starting with
    // our domain prefix.
    $prefix = 'domain_path_pathauto_state.' . $entity->id() . '.';
    $query = $this->database->select('key_value', 'kv')
      ->fields('kv', ['collection'])
      ->condition('collection', $this->database->escapeLike($prefix) . '%', 'LIKE')
      ->distinct();

    $collections = $query->execute()->fetchCol();

    foreach ($collections as $collection) {
      $this->keyValueFactory->get($collection)->deleteAll();
    }
  }

}
