<?php

namespace Drupal\Tests\domain_path_pathauto\Kernel;

use Drupal\node\Entity\Node;
use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;

/**
 * Tests domain-scoped alias uniquification.
 *
 * @group domain_path_pathauto
 *
 * @phpstan-ignore-next-line
 */
#[Group('domain_path_pathauto')]
#[RunTestsInSeparateProcesses]
class DomainPathautoUniquifierTest extends DomainPathautoKernelTestBase {

  /**
   * Tests same alias on different domains gets uniquified.
   */
  public function testSameAliasOnDifferentDomainsNotUniquified(): void {
    $domain_a = $this->domainIds[0];
    $domain_b = $this->domainIds[1];

    // Create first node — gets /content/test-title on both domains.
    $node1 = Node::create([
      'type' => 'page',
      'title' => 'Test title',
    ]);
    $node1->save();

    // Create second node with same title — should get a suffix.
    $node2 = Node::create([
      'type' => 'page',
      'title' => 'Test title',
    ]);
    $node2->save();

    // Node 2 should have uniquified alias on both domains.
    $aliases_a = $this->pathAliasStorage()->loadByProperties([
      'path' => '/node/' . $node2->id(),
      'domain_id' => $domain_a,
    ]);
    $this->assertCount(1, $aliases_a);
    $this->assertEquals(
      '/content/test-title-0',
      reset($aliases_a)->getAlias()
    );

    $aliases_b = $this->pathAliasStorage()->loadByProperties([
      'path' => '/node/' . $node2->id(),
      'domain_id' => $domain_b,
    ]);
    $this->assertCount(1, $aliases_b);
    $this->assertEquals(
      '/content/test-title-0',
      reset($aliases_b)->getAlias()
    );
  }

  /**
   * Tests alias reserved on one domain but not on another.
   */
  public function testIsReservedPerDomain(): void {
    $domain_a = $this->domainIds[0];
    $domain_b = $this->domainIds[1];

    // Create a domain-specific alias only on domain A.
    $alias = $this->createPathAlias('/node/999', '/test-alias', 'en', $domain_a);

    // Verify the alias was stored correctly.
    $this->assertEquals($domain_a, $alias->get('domain_id')->target_id);

    // Verify lookup by alias works.
    $result = $this->container->get('domain_path.repository')
      ->lookupByAliasAndDomain('/test-alias', $domain_a, 'en');
    $this->assertNotNull($result, 'Alias lookup should find the alias');
    $this->assertEquals('/node/999', $result['path']);

    /** @var \Drupal\domain_path_pathauto\DomainAliasUniquifier $uniquifier */
    $uniquifier = $this->container
      ->get('domain_path_pathauto.alias_uniquifier');

    // /test-alias is reserved on domain A (belongs to /node/999).
    $this->assertTrue(
      $uniquifier->isReserved('/test-alias', '/node/1', 'en', $domain_a)
    );

    // /test-alias is NOT reserved on domain B (no alias exists).
    $this->assertFalse(
      $uniquifier->isReserved('/test-alias', '/node/1', 'en', $domain_b)
    );
  }

  /**
   * Tests partial conflict uniquifies only the affected domain.
   */
  public function testPartialConflictUniquifiesOnlyAffectedDomain(): void {
    $domain_a = $this->domainIds[0];
    $domain_b = $this->domainIds[1];

    // Pre-create an alias only on domain A.
    $this->createPathAlias(
      '/node/999', '/content/unique-only', 'en', $domain_a
    );

    // Create a node with title 'Unique only'.
    $node = Node::create([
      'type' => 'page',
      'title' => 'Unique only',
    ]);
    $node->save();

    // Domain A: conflict exists — should get '-0' suffix.
    $aliases_a = $this->pathAliasStorage()->loadByProperties([
      'path' => '/node/' . $node->id(),
      'domain_id' => $domain_a,
    ]);
    $this->assertCount(1, $aliases_a);
    $this->assertEquals(
      '/content/unique-only-0',
      reset($aliases_a)->getAlias()
    );

    // Domain B: no conflict — should get the base alias.
    $aliases_b = $this->pathAliasStorage()->loadByProperties([
      'path' => '/node/' . $node->id(),
      'domain_id' => $domain_b,
    ]);
    $this->assertCount(1, $aliases_b);
    $this->assertEquals(
      '/content/unique-only',
      reset($aliases_b)->getAlias()
    );
  }

  /**
   * Tests no conflict produces no suffix.
   */
  public function testNoConflictNoSuffix(): void {
    $domain_a = $this->domainIds[0];
    $domain_b = $this->domainIds[1];

    $node = Node::create([
      'type' => 'page',
      'title' => 'Completely unique title',
    ]);
    $node->save();

    $aliases_a = $this->pathAliasStorage()->loadByProperties([
      'path' => '/node/' . $node->id(),
      'domain_id' => $domain_a,
    ]);
    $this->assertCount(1, $aliases_a);
    $this->assertEquals(
      '/content/completely-unique-title',
      reset($aliases_a)->getAlias()
    );

    $aliases_b = $this->pathAliasStorage()->loadByProperties([
      'path' => '/node/' . $node->id(),
      'domain_id' => $domain_b,
    ]);
    $this->assertCount(1, $aliases_b);
    $this->assertEquals(
      '/content/completely-unique-title',
      reset($aliases_b)->getAlias()
    );
  }

}
