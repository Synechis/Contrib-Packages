<?php

namespace Drupal\Tests\domain_path_pathauto\FunctionalJavascript;

use Drupal\FunctionalJavascriptTests\WebDriverTestBase;
use Drupal\Tests\domain\Traits\DomainTestTrait;
use Drupal\Tests\node\Traits\ContentTypeCreationTrait;
use Drupal\Tests\pathauto\Functional\PathautoTestHelperTrait;
// @phpstan-ignore-next-line
use PHPUnit\Framework\Attributes\Group;
// @phpstan-ignore-next-line
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;

/**
 * Tests pathauto #states on the domain path widget.
 *
 * @group domain_path_pathauto
 *
 * @phpstan-ignore-next-line
 */
#[Group('domain_path_pathauto')]
#[RunTestsInSeparateProcesses]
class DomainPathautoStatesTest extends WebDriverTestBase {

  use ContentTypeCreationTrait;
  use DomainTestTrait;
  use PathautoTestHelperTrait;

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'domain',
    'domain_access',
    'domain_path',
    'domain_path_pathauto',
    'field',
    'node',
    'path',
    'path_alias',
    'pathauto',
    'system',
    'text',
    'token',
    'user',
  ];

  /**
   * {@inheritdoc}
   */
  protected $defaultTheme = 'stark';

  /**
   * We use the standard profile for testing.
   *
   * @var string
   */
  protected $profile = 'standard';

  /**
   * The test domains.
   *
   * @var \Drupal\domain\DomainInterface[]
   */
  protected array $domains;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $storage = \Drupal::entityTypeManager()->getStorage('domain');
    $this->baseHostname = $storage->createHostname();
    $this->setBaseDomain();

    $this->domainCreateTestDomains(2);
    $this->domains = $this->getDomains();

    // Core 11.4's standard profile no longer ships a content type, so create
    // one. Re-confirm the Domain Access fields afterwards so they are added to
    // the new bundle's form display (the node type insert hook runs before the
    // default form display exists).
    $this->createContentType(['type' => 'test_page', 'name' => 'Test page']);
    $this->container->get('domain_access.helper')
      ->confirmFields('node', 'test_page');

    // Keep fields in the main form body so they are
    // directly interactable (not in vertical tabs).
    \Drupal::configFactory()->getEditable('domain_access.settings')
      ->set('node_advanced_tab', FALSE)
      ->save();
    \Drupal::configFactory()->getEditable('domain_path.settings')
      ->set('use_advanced_group', FALSE)
      ->save();

    $admin = $this->drupalCreateUser([
      'bypass node access',
      'administer domains',
      'administer url aliases',
      'administer domain paths',
      'publish to any domain',
      'administer content types',
      'administer node fields',
      'administer node display',
    ]);
    $this->drupalLogin($admin);

    $this->container->get('entity_field.manager')
      ->clearCachedFieldDefinitions();
    $this->rebuildContainer();

    // Create pathauto pattern for the test_page content type.
    $pattern = $this->createPattern('node', '/content/[node:title]');
    $this->addBundleCondition($pattern, 'node', 'test_page');
    $pattern->save();
  }

  /**
   * Tests pathauto checkbox disables the alias field.
   */
  public function testPathautoCheckboxDisablesAliasField(): void {
    $page = $this->getSession()->getPage();
    $assert = $this->assertSession();

    $domain_ids = array_keys($this->domains);
    $domain_a = $domain_ids[0];
    $domain_b = $domain_ids[1];

    $alias_a = 'input[name="domain_path[' . $domain_a . '][alias]"]';
    $alias_b = 'input[name="domain_path[' . $domain_b . '][alias]"]';
    $pathauto_a = 'domain_path[' . $domain_a . '][pathauto]';
    $pathauto_b = 'domain_path[' . $domain_b . '][pathauto]';

    $this->drupalGet('node/add/test_page');

    // Check both domain access checkboxes.
    // Domain A is pre-checked; check domain B.
    $page->checkField('field_domain_access[' . $domain_b . ']');
    $assert->waitForElementVisible('css', $alias_b);

    // Pathauto checkboxes should exist.
    $assert->fieldExists($pathauto_a);
    $assert->fieldExists($pathauto_b);

    // For new nodes, pathauto is checked and alias fields
    // are disabled by default.
    $this->assertNotEmpty(
      $page->find('css', $alias_a . ':disabled')
    );
    $this->assertNotEmpty(
      $page->find('css', $alias_b . ':disabled')
    );

    // Uncheck pathauto for A: alias A becomes enabled.
    $page->uncheckField($pathauto_a);
    $result = $page->waitFor(5, function () use ($page, $alias_a) {
      return $page->find('css', $alias_a . ':disabled') === NULL;
    });
    $this->assertTrue($result);

    // B's alias should still be disabled.
    $this->assertNotEmpty(
      $page->find('css', $alias_b . ':disabled')
    );

    // Re-check pathauto for A: alias A becomes disabled.
    $page->checkField($pathauto_a);
    $this->assertNotEmpty(
      $assert->waitForElement('css', $alias_a . ':disabled')
    );

    // B's alias should still be disabled.
    $this->assertNotEmpty(
      $page->find('css', $alias_b . ':disabled')
    );
  }

  /**
   * Tests pathauto and delete checkboxes both disable.
   */
  public function testPathautoAndDeleteBothDisable(): void {
    $page = $this->getSession()->getPage();
    $assert = $this->assertSession();

    $domain_ids = array_keys($this->domains);
    $domain_a = $domain_ids[0];
    $domain_b = $domain_ids[1];

    $alias_a = 'input[name="domain_path[' . $domain_a . '][alias]"]';
    $alias_b = 'input[name="domain_path[' . $domain_b . '][alias]"]';
    $pathauto_a = 'domain_path[' . $domain_a . '][pathauto]';
    $pathauto_b = 'domain_path[' . $domain_b . '][pathauto]';
    $delete = 'domain_path_wrapper[domain_path_delete]';

    // Create node with pathauto aliases on both domains.
    $title = 'Test Both ' . $this->randomMachineName();
    $this->drupalGet('node/add/test_page');

    // Domain A is pre-checked; check domain B.
    $page->checkField('field_domain_access[' . $domain_b . ']');
    $assert->waitForElementVisible('css', $alias_b);
    $page->fillField('title[0][value]', $title);
    // Pathauto checked by default, generates on save.
    $page->pressButton('Save');
    $assert->waitForText($title);

    // Edit the node.
    $node = $this->drupalGetNodeByTitle($title);
    $this->drupalGet('node/' . $node->id() . '/edit');
    $assert->waitForElementVisible('css', $alias_a);

    // Uncheck pathauto for both domains so alias fields
    // are enabled.
    $page->uncheckField($pathauto_a);
    $page->uncheckField($pathauto_b);
    $page->waitFor(5, function () use ($page, $alias_b) {
      return $page->find('css', $alias_b . ':disabled') === NULL;
    });
    $this->assertNull($page->find('css', $alias_a . ':disabled'));
    $this->assertNull($page->find('css', $alias_b . ':disabled'));

    // Check delete: both alias fields become disabled.
    $page->checkField($delete);
    $this->assertNotEmpty(
      $assert->waitForElement('css', $alias_a . ':disabled')
    );
    $this->assertNotEmpty(
      $page->find('css', $alias_b . ':disabled')
    );

    // Uncheck delete: both re-enabled (pathauto off).
    $page->uncheckField($delete);
    $page->waitFor(5, function () use ($page, $alias_a) {
      return $page->find('css', $alias_a . ':disabled') === NULL;
    });
    $this->assertNull($page->find('css', $alias_b . ':disabled'));

    // Check pathauto for A only: A disabled, B enabled.
    $page->checkField($pathauto_a);
    $this->assertNotEmpty(
      $assert->waitForElement('css', $alias_a . ':disabled')
    );
    $this->assertNull($page->find('css', $alias_b . ':disabled'));
  }

}
