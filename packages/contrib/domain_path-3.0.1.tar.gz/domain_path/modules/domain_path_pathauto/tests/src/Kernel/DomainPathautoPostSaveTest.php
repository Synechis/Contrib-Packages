<?php

namespace Drupal\Tests\domain_path_pathauto\Kernel;

use Drupal\node\Entity\Node;
use Drupal\pathauto\PathautoState;
use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;

/**
 * Tests pathauto-aware DomainPathautoItem::postSave().
 *
 * @group domain_path_pathauto
 *
 * @phpstan-ignore-next-line
 */
#[Group('domain_path_pathauto')]
#[RunTestsInSeparateProcesses]
class DomainPathautoPostSaveTest extends DomainPathautoKernelTestBase {

  /**
   * Tests pathauto CREATE generates an alias per domain.
   */
  public function testPathautoCreateGeneratesAlias(): void {
    $domain_a = $this->domainIds[0];
    $domain_b = $this->domainIds[1];

    $node = Node::create([
      'type' => 'page',
      'title' => 'Test title',
    ]);
    $node->save();

    // Verify auto-generated aliases on each domain.
    $aliases_a = $this->pathAliasStorage()->loadByProperties([
      'path' => '/node/' . $node->id(),
      'domain_id' => $domain_a,
    ]);
    $this->assertCount(1, $aliases_a);
    $this->assertEquals(
      '/content/test-title',
      reset($aliases_a)->getAlias()
    );

    $aliases_b = $this->pathAliasStorage()->loadByProperties([
      'path' => '/node/' . $node->id(),
      'domain_id' => $domain_b,
    ]);
    $this->assertCount(1, $aliases_b);
    $this->assertEquals(
      '/content/test-title',
      reset($aliases_b)->getAlias()
    );
  }

  /**
   * Tests pathauto SKIP uses a manual alias.
   */
  public function testPathautoSkipUsesManualAlias(): void {
    $domain_a = $this->domainIds[0];

    $node = Node::create([
      'type' => 'page',
      'title' => 'Test title',
    ]);

    // Set pathauto to SKIP and provide a manual alias.
    foreach ($node->get('domain_path') as $item) {
      if ($item->get('domain_id')->getValue() === $domain_a) {
        $item->set('alias', '/my-manual-alias');
        $item->get('pathauto')->setValue(PathautoState::SKIP);
      }
    }
    $node->save();

    $aliases = $this->pathAliasStorage()->loadByProperties([
      'path' => '/node/' . $node->id(),
      'domain_id' => $domain_a,
    ]);
    $this->assertCount(1, $aliases);
    $this->assertEquals(
      '/my-manual-alias',
      reset($aliases)->getAlias()
    );
  }

  /**
   * Tests clearing alias with SKIP deletes the alias.
   */
  public function testPathautoSkipClearingAliasDeletesIt(): void {
    $domain_a = $this->domainIds[0];

    // First create a node with a manual alias.
    $node = Node::create([
      'type' => 'page',
      'title' => 'Test title',
    ]);
    foreach ($node->get('domain_path') as $item) {
      if ($item->get('domain_id')->getValue() === $domain_a) {
        $item->set('alias', '/to-delete');
        $item->get('pathauto')->setValue(PathautoState::SKIP);
      }
    }
    $node->save();

    // Verify alias exists.
    $aliases = $this->pathAliasStorage()->loadByProperties([
      'path' => '/node/' . $node->id(),
      'domain_id' => $domain_a,
    ]);
    $this->assertCount(1, $aliases);

    // Reload and clear alias with SKIP.
    $node = Node::load($node->id());
    foreach ($node->get('domain_path') as $item) {
      if ($item->get('domain_id')->getValue() === $domain_a) {
        $item->set('alias', '');
        $item->get('pathauto')->setValue(PathautoState::SKIP);
      }
    }
    $node->save();

    // Verify alias is deleted.
    $this->pathAliasStorage()->resetCache();
    $aliases = $this->pathAliasStorage()->loadByProperties([
      'path' => '/node/' . $node->id(),
      'domain_id' => $domain_a,
    ]);
    $this->assertCount(0, $aliases);
  }

}
