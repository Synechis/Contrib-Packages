<?php

namespace Drupal\Tests\domain_path_pathauto\Kernel;

use Drupal\domain\Entity\Domain;
use Drupal\domain_path_pathauto\Hook\DomainPathPathautoHooks;
use Drupal\node\Entity\Node;
use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;

/**
 * Tests domain deletion cleans up pathauto state.
 *
 * @group domain_path_pathauto
 *
 * @phpstan-ignore-next-line
 */
#[Group('domain_path_pathauto')]
#[RunTestsInSeparateProcesses]
class DomainPathautoStateDomainDeleteTest extends DomainPathautoKernelTestBase {

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    // The DomainPathPathautoHooks service was constructed before
    // we overrode the keyvalue service in the parent setUp. Update
    // its keyValueFactory to use the database-backed factory so
    // domainDelete() can properly clean up state.
    $hooks = $this->container->get(DomainPathPathautoHooks::class);
    $ref = new \ReflectionProperty($hooks, 'keyValueFactory');
    $ref->setValue($hooks, $this->container->get('keyvalue'));
  }

  /**
   * Tests deleting a domain removes its pathauto state.
   */
  public function testDomainDeleteCleansUpPathautoState(): void {
    $domain_a = $this->domainIds[0];
    $domain_b = $this->domainIds[1];

    $node = Node::create([
      'type' => 'page',
      'title' => 'Test node',
    ]);
    $node->save();

    // Verify state exists for both domains.
    $this->assertNotNull(
      $this->getPathautoState($domain_a, 'node', $node->id())
    );
    $this->assertNotNull(
      $this->getPathautoState($domain_b, 'node', $node->id())
    );

    // Delete domain A.
    Domain::load($domain_a)->delete();

    // State for domain A should be gone.
    $this->assertNull(
      $this->getPathautoState($domain_a, 'node', $node->id())
    );
  }

  /**
   * Tests deleting a domain preserves other domain state.
   */
  public function testDomainDeletePreservesOtherDomainState(): void {
    $domain_a = $this->domainIds[0];
    $domain_b = $this->domainIds[1];

    $node = Node::create([
      'type' => 'page',
      'title' => 'Test node',
    ]);
    $node->save();

    // Delete domain A.
    Domain::load($domain_a)->delete();

    // Domain B state survives.
    $this->assertNotNull(
      $this->getPathautoState($domain_b, 'node', $node->id())
    );
  }

  /**
   * Tests deleting a domain with no state does not fail.
   */
  public function testDomainDeleteWithNoStateDoesNotFail(): void {
    $domain_a = $this->domainIds[0];

    // Save a dummy node to ensure the key_value table exists
    // before calling domainDelete(), which queries it directly.
    $node = Node::create([
      'type' => 'page',
      'title' => 'Dummy',
    ]);
    $node->save();
    $node->delete();

    // Delete domain A — no state remains, should not throw.
    Domain::load($domain_a)->delete();

    $this->assertNull(Domain::load($domain_a));
  }

}
