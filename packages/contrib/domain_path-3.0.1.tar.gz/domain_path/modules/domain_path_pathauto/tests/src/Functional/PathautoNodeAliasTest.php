<?php

namespace Drupal\Tests\domain_path_pathauto\Functional;

use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;

/**
 * Tests the Domain Path Pathauto integration.
 *
 * @group domain_path_pathauto
 *
 * @phpstan-ignore-next-line
 */
#[RunTestsInSeparateProcesses]
class PathautoNodeAliasTest extends DomainPathPathautoTestBase {

  /**
   * Tests node alias generation based on content type and pathauto settings.
   *
   * The method verifies if a node alias is correctly created for content types
   * with a pathauto pattern enabled. It also ensures that no alias is generated
   * for content types where the pathauto pattern is disabled.
   */
  public function testNodeAlias(): void {
    // Content type with pathauto pattern enabled.
    $title = $this->randomMachineName();
    $this->drupalGet('node/add/test_page');
    $this->assertSession()->statusCodeEquals(200);
    $this->fillField('title[0][value]', $title);
    $this->pressButton('Save');
    $this->assertSession()->pageTextContains($title);

    $node = $this->drupalGetNodeByTitle($title);
    $this->drupalGet('node/' . $node->id() . '/edit');
    $this->assertSession()->statusCodeEquals(200);

    $this->assertSame(1, $this->pathAliasStorage()->getQuery()
      ->accessCheck('FALSE')
      ->condition('domain_id', 'example_com')
      ->condition('path', '/node/' . $node->id())
      ->condition('alias', '/content/' . $title)
      ->count()->execute());

    // Content type with pathauto pattern disabled. The base class only adds a
    // pathauto pattern for the 'test_page' bundle, so a second content type
    // without a pattern is created here.
    $this->drupalCreateContentType([
      'type' => 'test_article',
      'name' => 'Test article',
    ]);
    $title = $this->randomMachineName();
    $this->drupalGet('node/add/test_article');
    $this->assertSession()->statusCodeEquals(200);
    $this->fillField('title[0][value]', $title);
    $this->pressButton('Save');
    $this->assertSession()->pageTextContains($title);

    $node = $this->drupalGetNodeByTitle($title);
    $this->drupalGet('node/' . $node->id() . '/edit');
    $this->assertSession()->statusCodeEquals(200);

    $this->assertSame(0, $this->pathAliasStorage()->getQuery()
      ->accessCheck('FALSE')
      ->condition('domain_id', 'example_com')
      ->condition('path', '/node/' . $node->id())
      ->count()->execute());
  }

}
