<?php

namespace Drupal\Tests\domain_path_pathauto\Kernel;

use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;

/**
 * Tests that taxonomy term children get domain aliases.
 *
 * @group domain_path_pathauto
 *
 * @phpstan-ignore-next-line
 */
#[Group('domain_path_pathauto')]
#[RunTestsInSeparateProcesses]
class DomainPathautoTaxonomyChildrenTest extends DomainPathautoKernelTestBase {

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'domain',
    'domain_path',
    'domain_path_pathauto',
    'field',
    'node',
    'path',
    'path_alias',
    'pathauto',
    'system',
    'taxonomy',
    'text',
    'token',
    'user',
  ];

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->installEntitySchema('taxonomy_term');
    $this->installConfig(['taxonomy']);

    // Enable domain paths for taxonomy terms (only node is
    // enabled by default).
    $config = $this->config('domain_path.settings');
    $entity_types = $config->get('entity_types');
    $entity_types[] = 'taxonomy_term';
    $config->set('entity_types', $entity_types)->save();

    $this->createPattern(
      'taxonomy_term',
      '/[term:parents:join-path]/[term:name]'
    );
  }

  /**
   * Tests child terms get domain aliases when parent is updated.
   *
   * Uses a pattern with [term:parents:join-path] so child aliases
   * include the parent name. When the parent is renamed, the
   * recursive call in PathautoGenerator::updateEntityAlias()
   * dispatches polymorphically to DomainPathautoGenerator, which
   * regenerates domain aliases for each child with the updated
   * parent name. This was broken in the old decorator pattern
   * where recursion stayed inside the plain PathautoGenerator.
   */
  public function testChildTermGetsDomainAliasOnParentUpdate(): void {
    $domain_a = $this->domainIds[0];
    $domain_b = $this->domainIds[1];
    $vocabulary = $this->addVocabulary();

    // Create parent term (no parents, so join-path is empty).
    $parent = $this->addTerm($vocabulary, ['name' => 'parent-term']);
    $parent_path = '/taxonomy/term/' . $parent->id();

    // Parent should have domain aliases on both domains.
    $this->assertDomainAlias(
      $parent_path, '/parent-term', $domain_a
    );
    $this->assertDomainAlias(
      $parent_path, '/parent-term', $domain_b
    );

    // Create child term — alias includes parent name via
    // [term:parents:join-path].
    $child = $this->addTerm($vocabulary, [
      'name' => 'child-term',
      'parent' => $parent->id(),
    ]);
    $child_path = '/taxonomy/term/' . $child->id();

    $this->assertDomainAlias(
      $child_path, '/parent-term/child-term', $domain_a
    );
    $this->assertDomainAlias(
      $child_path, '/parent-term/child-term', $domain_b
    );

    // Clear the Token module's drupal_static cache for parent
    // names. Without this, token_taxonomy_term_load_all_parents()
    // returns stale parent labels from the same request. This is
    // a known Token module limitation — in production, parent
    // renames and child alias rebuilds happen in separate
    // requests where this cache is naturally empty.
    drupal_static_reset('token_taxonomy_term_load_all_parents');

    // Rename parent — updateEntityAlias() recurses into children
    // via loadTermChildren(). With inheritance, the recursive
    // $this->updateEntityAlias() call lands on
    // DomainPathautoGenerator, so children get new domain aliases.
    $parent->setName('parent-renamed');
    $parent->save();

    $this->pathAliasStorage()->resetCache();

    // Child domain aliases must reflect the renamed parent.
    $this->assertDomainAlias(
      $child_path, '/parent-renamed/child-term', $domain_a
    );
    $this->assertDomainAlias(
      $child_path, '/parent-renamed/child-term', $domain_b
    );

    // Parent aliases updated too.
    $this->assertDomainAlias(
      $parent_path, '/parent-renamed', $domain_a
    );
  }

  /**
   * Asserts a single domain alias exists with the expected value.
   *
   * @param string $path
   *   The source path (e.g. '/taxonomy/term/1').
   * @param string $expected_alias
   *   The expected alias string.
   * @param string $domain_id
   *   The domain ID.
   */
  protected function assertDomainAlias(string $path, string $expected_alias, string $domain_id): void {
    $aliases = $this->pathAliasStorage()->loadByProperties([
      'path' => $path,
      'domain_id' => $domain_id,
    ]);
    $this->assertCount(1, $aliases, sprintf(
      'Expected 1 alias for %s on domain %s, found %d.',
      $path, $domain_id, count($aliases)
    ));
    $this->assertEquals($expected_alias, reset($aliases)->getAlias());
  }

}
