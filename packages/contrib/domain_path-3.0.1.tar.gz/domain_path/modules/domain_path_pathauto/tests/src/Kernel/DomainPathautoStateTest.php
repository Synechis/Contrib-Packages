<?php

namespace Drupal\Tests\domain_path_pathauto\Kernel;

use Drupal\node\Entity\Node;
use Drupal\pathauto\PathautoState;
use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;

/**
 * Tests per-domain pathauto state tracking.
 *
 * @group domain_path_pathauto
 *
 * @phpstan-ignore-next-line
 */
#[Group('domain_path_pathauto')]
#[RunTestsInSeparateProcesses]
class DomainPathautoStateTest extends DomainPathautoKernelTestBase {

  /**
   * Tests state is stored per domain.
   */
  public function testStateStoredPerDomain(): void {
    $domain_a = $this->domainIds[0];
    $domain_b = $this->domainIds[1];

    $node = Node::create([
      'type' => 'page',
      'title' => 'State test',
    ]);
    $node->save();

    // Each domain should have its own state entry.
    $state_a = $this->getPathautoState(
      $domain_a, 'node', $node->id()
    );
    $state_b = $this->getPathautoState(
      $domain_b, 'node', $node->id()
    );
    $this->assertNotNull($state_a);
    $this->assertNotNull($state_b);
  }

  /**
   * Tests new entity defaults to CREATE when pattern exists.
   */
  public function testNewEntityDefaultsToCreate(): void {
    $domain_a = $this->domainIds[0];

    $node = Node::create([
      'type' => 'page',
      'title' => 'New node',
    ]);

    // Unsaved node — state should be CREATE for each domain.
    foreach ($node->get('domain_path') as $item) {
      if ($item->get('domain_id')->getValue() === $domain_a) {
        $this->assertEquals(
          PathautoState::CREATE,
          $item->get('pathauto')->getValue()
        );
      }
    }
  }

  /**
   * Tests state persists across saves.
   */
  public function testStatePersistsAcrossSaves(): void {
    $domain_a = $this->domainIds[0];

    $node = Node::create([
      'type' => 'page',
      'title' => 'Persist test',
    ]);

    // Set SKIP on domain A before saving.
    foreach ($node->get('domain_path') as $item) {
      if ($item->get('domain_id')->getValue() === $domain_a) {
        $item->set('alias', '/manual');
        $item->get('pathauto')->setValue(PathautoState::SKIP);
      }
    }
    $node->save();

    // Verify SKIP persisted in key_value.
    $this->assertEquals(
      PathautoState::SKIP,
      $this->getPathautoState($domain_a, 'node', $node->id())
    );

    // Reload and re-save without changing state.
    $node = Node::load($node->id());
    $node->save();

    // SKIP should still be persisted.
    $this->assertEquals(
      PathautoState::SKIP,
      $this->getPathautoState($domain_a, 'node', $node->id())
    );
  }

  /**
   * Tests state is cleaned on entity delete.
   */
  public function testStateCleanedOnEntityDelete(): void {
    $domain_a = $this->domainIds[0];
    $domain_b = $this->domainIds[1];

    $node = Node::create([
      'type' => 'page',
      'title' => 'Delete test',
    ]);
    $node->save();
    $nid = $node->id();

    // Verify state exists.
    $this->assertNotNull(
      $this->getPathautoState($domain_a, 'node', $nid)
    );
    $this->assertNotNull(
      $this->getPathautoState($domain_b, 'node', $nid)
    );

    // Delete the node.
    $node->delete();

    // State should be purged for both domains.
    $this->assertNull(
      $this->getPathautoState($domain_a, 'node', $nid)
    );
    $this->assertNull(
      $this->getPathautoState($domain_b, 'node', $nid)
    );
  }

}
