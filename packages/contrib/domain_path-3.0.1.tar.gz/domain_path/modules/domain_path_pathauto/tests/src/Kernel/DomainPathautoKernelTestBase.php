<?php

namespace Drupal\Tests\domain_path_pathauto\Kernel;

use Drupal\Core\KeyValueStore\KeyValueFactoryInterface;
use Drupal\node\Entity\NodeType;
use Drupal\pathauto\PathautoState;
use Drupal\Tests\domain_path\Kernel\DomainPathKernelTestBase;
use Drupal\Tests\pathauto\Functional\PathautoTestHelperTrait;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;

/**
 * Base class for domain_path_pathauto Kernel tests.
 *
 * @phpstan-ignore-next-line
 */
#[RunTestsInSeparateProcesses]
abstract class DomainPathautoKernelTestBase extends DomainPathKernelTestBase {

  use PathautoTestHelperTrait;

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'domain',
    'domain_path',
    'domain_path_pathauto',
    'field',
    'node',
    'path',
    'path_alias',
    'pathauto',
    'system',
    'text',
    'token',
    'user',
  ];

  /**
   * The key value factory.
   *
   * @var \Drupal\Core\KeyValueStore\KeyValueFactoryInterface
   */
  protected KeyValueFactoryInterface $keyValueFactory;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->installEntitySchema('node');
    $this->installSchema('node', ['node_access']);
    $this->installConfig(['system', 'pathauto', 'node']);

    // Use the database-backed key_value store so pathauto state
    // is persisted to the database, matching production behavior.
    $this->container->set(
      'keyvalue',
      $this->container->get('keyvalue.database')
    );

    NodeType::create([
      'type' => 'page',
      'name' => 'Page',
    ])->save();

    $this->createPattern('node', '/content/[node:title]');

    $this->container->get('router.builder')->rebuild();

    $this->keyValueFactory = $this->container->get('keyvalue');
  }

  /**
   * {@inheritdoc}
   *
   * Overrides PathAliasTestTrait::createPathAlias() (pulled in
   * by PathautoTestHelperTrait) to restore domain_id support.
   */
  // phpcs:ignore Generic.CodeAnalysis.UselessOverridingMethod.Found
  protected function createPathAlias(string $path, string $alias, string $langcode = 'en', ?string $domain_id = NULL) {
    return parent::createPathAlias($path, $alias, $langcode, $domain_id);
  }

  /**
   * Returns the pathauto state for a domain/entity combination.
   *
   * @param string $domain_id
   *   The domain ID.
   * @param string $entity_type
   *   The entity type ID.
   * @param int|string $entity_id
   *   The entity ID.
   *
   * @return int|null
   *   The pathauto state value, or NULL if not set.
   */
  protected function getPathautoState(string $domain_id, string $entity_type, $entity_id): ?int {
    $collection = 'domain_path_pathauto_state.' . $domain_id . '.' . $entity_type;
    $key = PathautoState::getPathautoStateKey($entity_id);
    $value = $this->keyValueFactory->get($collection)->get($key);
    return $value !== NULL ? (int) $value : NULL;
  }

}
