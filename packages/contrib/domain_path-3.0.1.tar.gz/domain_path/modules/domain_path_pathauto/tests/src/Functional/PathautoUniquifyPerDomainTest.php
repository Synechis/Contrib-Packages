<?php

namespace Drupal\Tests\domain_path_pathauto\Functional;

use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;

/**
 * Tests that alias uniquification is scoped per domain.
 *
 * Verifies that two nodes with the same title on different domains get
 * identical aliases without uniquification suffixes (e.g. -0).
 *
 * @group domain_path_pathauto
 *
 * @phpstan-ignore-next-line
 */
#[RunTestsInSeparateProcesses]
class PathautoUniquifyPerDomainTest extends DomainPathPathautoTestBase {

  /**
   * Tests that identical aliases on different domains are not uniquified.
   *
   * Creates two nodes with the same title, each assigned to a different
   * domain. Asserts that both nodes get the same auto-generated alias
   * without a -0 suffix, because alias uniquification should be scoped
   * per domain.
   */
  public function testAliasNotUniquifiedAcrossDomains(): void {
    $domain_ids = array_keys($this->domains);
    $domain_a = $domain_ids[0];
    $domain_b = $domain_ids[1];
    $title = $this->randomMachineName();
    $expected_alias = '/content/' . $title;

    // Create the first node assigned to domain A only.
    $this->drupalGet('node/add/test_page');
    $this->assertSession()->statusCodeEquals(200);
    $this->fillField('title[0][value]', $title);
    $this->checkField("field_domain_access[$domain_a]");
    $this->uncheckField("field_domain_access[$domain_b]");
    $this->pressButton('Save');
    $this->assertSession()->pageTextContains($title);

    $node_a = $this->drupalGetNodeByTitle($title);

    // Verify alias on domain A.
    $this->assertSame(1, $this->pathAliasStorage()->getQuery()
      ->accessCheck(FALSE)
      ->condition('domain_id', $domain_a)
      ->condition('path', '/node/' . $node_a->id())
      ->condition('alias', $expected_alias)
      ->count()->execute(),
      'Node A has the expected alias on domain A.');

    // Create the second node with the same title, assigned to domain B.
    $this->drupalGet('node/add/test_page');
    $this->assertSession()->statusCodeEquals(200);
    $this->fillField('title[0][value]', $title);
    $this->checkField("field_domain_access[$domain_b]");
    $this->uncheckField("field_domain_access[$domain_a]");
    $this->pressButton('Save');
    $this->assertSession()->pageTextContains($title);

    // drupalGetNodeByTitle returns the first match, so load by path.
    $node_b_aliases = $this->pathAliasStorage()->loadByProperties([
      'domain_id' => $domain_b,
      'alias' => $expected_alias,
    ]);
    $this->assertCount(1, $node_b_aliases,
      'Node B has the expected alias on domain B without uniquification.');

    $node_b_alias = reset($node_b_aliases);
    $this->assertNotEquals(
      '/node/' . $node_a->id(),
      $node_b_alias->getPath(),
      'The alias on domain B belongs to a different node than domain A.'
    );

    // Verify no uniquified domain alias exists (e.g. /content/title-0).
    // Core path aliases (without domain) may still be uniquified by
    // Pathauto's regular AliasUniquifier — that's expected and not our
    // concern here.
    $uniquified_domain_a = $this->pathAliasStorage()->getQuery()
      ->accessCheck(FALSE)
      ->condition('domain_id', $domain_a)
      ->condition('alias', $expected_alias . '-', 'STARTS_WITH')
      ->count()->execute();
    $this->assertSame(0, $uniquified_domain_a,
      'No uniquified alias suffix exists on domain A.');

    $uniquified_domain_b = $this->pathAliasStorage()->getQuery()
      ->accessCheck(FALSE)
      ->condition('domain_id', $domain_b)
      ->condition('alias', $expected_alias . '-', 'STARTS_WITH')
      ->count()->execute();
    $this->assertSame(0, $uniquified_domain_b,
      'No uniquified alias suffix exists on domain B.');
  }

}
