<?php

namespace Drupal\Tests\domain_path_pathauto\Kernel;

use Drupal\domain_path_pathauto\DomainPathautoFieldItemList;
use Drupal\domain_path_pathauto\DomainPathautoItem;
use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;

/**
 * Tests field/widget class substitution via hook_field_info_alter.
 *
 * @group domain_path_pathauto
 *
 * @phpstan-ignore-next-line
 */
#[Group('domain_path_pathauto')]
#[RunTestsInSeparateProcesses]
class DomainPathautoFieldAlterTest extends DomainPathautoKernelTestBase {

  /**
   * Tests field type class is swapped to DomainPathautoItem.
   */
  public function testFieldTypeClassIsSwapped(): void {
    $definition = $this->container->get('plugin.manager.field.field_type')
      ->getDefinition('domain_path');
    $this->assertEquals(
      DomainPathautoItem::class,
      $definition['class']
    );
  }

  /**
   * Tests field item list class is swapped.
   */
  public function testFieldItemListClassIsSwapped(): void {
    $definition = $this->container->get('plugin.manager.field.field_type')
      ->getDefinition('domain_path');
    $this->assertEquals(
      DomainPathautoFieldItemList::class,
      $definition['list_class']
    );
  }

}
