<?php

namespace Drupal\domain_path\HttpKernel;

use Drupal\Core\PathProcessor\OutboundPathProcessorInterface;
use Drupal\Core\Render\BubbleableMetadata;
use Drupal\domain\DomainInterface;
use Drupal\domain_path\DomainAliasManagerInterface;
use Symfony\Component\HttpFoundation\Request;

/**
 * Aliases outbound paths for the target domain.
 *
 * When $options['domain'] is set (by DomainSourcePathProcessor
 * or directly by custom code), this processor resolves the alias
 * via the domain-aware alias manager — which includes a fallback
 * to core alias processing — and sets $options['alias'] = TRUE
 * so core's AliasPathProcessor (300) is skipped entirely.
 *
 * Priority 305 — after DomainSourcePathProcessor (310) and before
 * core's AliasPathProcessor (300).
 *
 * @internal
 */
class DomainPathAliasProcessor implements OutboundPathProcessorInterface {

  /**
   * Constructs a DomainPathAliasProcessor.
   *
   * @param \Drupal\domain_path\DomainAliasManagerInterface $aliasManager
   *   The domain-aware alias manager.
   */
  public function __construct(
    protected DomainAliasManagerInterface $aliasManager,
  ) {}

  /**
   * {@inheritdoc}
   */
  public function processOutbound($path, &$options = [], ?Request $request = NULL, ?BubbleableMetadata $bubbleable_metadata = NULL) {
    // Skip external URLs or paths without a domain target.
    if (!empty($options['external']) || !isset($options['domain'])) {
      return $path;
    }

    // The domain option must be a DomainInterface entity.
    $domain = $options['domain'];
    if (!$domain instanceof DomainInterface) {
      return $path;
    }

    $langcode = isset($options['language']) ? $options['language']->getId() : NULL;

    // getAliasByPathAndDomain() already includes a fallback to
    // core path alias processing, so we can skip core's
    // AliasPathProcessor (priority 300) entirely.
    $options['alias'] = TRUE;

    return $this->aliasManager
      ->getAliasByPathAndDomain($path, $domain->id(), $langcode);
  }

}
