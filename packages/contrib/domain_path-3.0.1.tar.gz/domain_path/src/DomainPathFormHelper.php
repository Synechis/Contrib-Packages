<?php

namespace Drupal\domain_path;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Entity\ContentEntityInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Render\Element;
use Drupal\Core\Session\AccountInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\domain_access\DomainAccessManager;

/**
 * Alters entity forms with domain path fields.
 *
 * @final
 */
class DomainPathFormHelper {

  use StringTranslationTrait;

  public function __construct(
    protected DomainPathHelper $domainPathHelper,
    protected EntityTypeManagerInterface $entityTypeManager,
    protected ConfigFactoryInterface $configFactory,
    protected AccountInterface $currentUser,
  ) {}

  /**
   * Gets the domain path configuration.
   *
   * @return \Drupal\Core\Config\ImmutableConfig
   *   The domain path configuration object.
   */
  protected function getConfig() {
    return $this->configFactory->get('domain_path.settings');
  }

  /**
   * The domain paths form element for the entity form.
   *
   * @param array $form
   *   The form array.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state object.
   * @param \Drupal\Core\Entity\EntityInterface $entity
   *   Referenced entity.
   *
   * @return array
   *   Return the modified form array.
   */
  public function alterEntityForm(&$form, FormStateInterface $form_state, $entity) {
    $domain_access = $this->getAlterFormDomainAccess($form, $form_state);

    // Predict whether content_translation will hide the
    // field_domain_access widget on this form: that happens for
    // non-default translations when the bundle has
    // untranslatable_fields_hide enabled AND the field itself is
    // not translatable. We cannot read #access directly because
    // content_translation registers `entityFormSharedElements` as a
    // #process callback that runs AFTER hook_form_alter. When the
    // widget will be hidden the JS States API cannot drive domain
    // path visibility, so fall back to a server-side decision based
    // on the entity's stored values.
    //
    // @see \Drupal\content_translation\ContentTranslationHandler::entityFormSharedElements
    $domain_access_widget_hidden = FALSE;
    $entity_access_values = [];
    $entity_all_affiliates = FALSE;
    if ($this->domainPathHelper->isDomainAccessInstalled()
      && $entity instanceof ContentEntityInterface
      && !$entity->isDefaultTranslation()
      && $entity->isDefaultTranslationAffectedOnly()
      && $entity->hasField('field_domain_access')
      && !$entity->getFieldDefinition('field_domain_access')->isTranslatable()
    ) {
      $domain_access_widget_hidden = TRUE;
      $entity_access_values = DomainAccessManager::getAccessValues($entity);
      $entity_all_affiliates = DomainAccessManager::getAllValue($entity);
    }

    $visible_paths = 0;
    $path_keys = Element::children($form[DomainPathHelper::PATH_FIELD]['widget']);
    foreach ($path_keys as $key) {
      $path_element =& $form[DomainPathHelper::PATH_FIELD]['widget'][$key];
      $alias_element =& $path_element['alias'];

      $domain_id = $path_element['domain_id']['#value'];

      if (isset($alias_element['#states']['disabled'])) {
        $alias_element['#states']['disabled'] = [
          $alias_element['#states']['disabled'],
          'or',
          ['input[name="domain_path_wrapper[domain_path_delete]"]' => ['checked' => TRUE]],
        ];
      }
      else {
        $alias_element['#states']['disabled'] =
          ['input[name="domain_path_wrapper[domain_path_delete]"]' => ['checked' => TRUE]];
      }

      $path = $alias_element['#default_value'] ?? '';
      if ($path !== '') {
        $visible_paths += 1;
      }

      // Domain access visibility: only relevant when domain_access
      // module is installed.
      if ($this->domainPathHelper->isDomainAccessInstalled()) {
        // The field_domain_access widget is not on the form (e.g.
        // hidden by content_translation on a translation form):
        // decide visibility from the entity's stored values, since
        // #states cannot work without the controlling inputs.
        if ($domain_access_widget_hidden) {
          if (!$entity_all_affiliates && !isset($entity_access_values[$domain_id])) {
            $path_element['#access'] = FALSE;
          }
        }
        // If domain settings are on the page for this domain we only
        // show if it's checked. e.g. on the node form, we only show
        // the domain path field for domains we're publishing to.
        elseif (isset($form['field_domain_access']['widget']['#options'][$domain_id])) {
          $conditions = [];
          if ($form['field_domain_access']['widget']['#type'] === 'checkboxes') {
            $conditions['input[name="field_domain_access[' . $domain_id . ']"]'] = ['checked' => TRUE];
          }
          elseif ($form['field_domain_access']['widget']['#type'] === 'radios') {
            $conditions['input[name="field_domain_access"]'] = ['value' => $domain_id];
          }
          // #states conditions do not work correctly with multi-select
          // widgets.
          elseif ($form['field_domain_access']['widget']['#type'] === 'select'
            && !($form['field_domain_access']['widget']['#multiple'] ?? FALSE)) {
            $conditions['select[name="field_domain_access"]'] = ['value' => $domain_id];
          }
          if (!empty($conditions)) {
            // Hide initially to prevent pre-#states flash.
            $path_element['#attributes']['style'] = 'display:none';
            $path_element['#states']['visible'] = [
              [
                $conditions,
                'or',
                [
                  'input[name="field_domain_all_affiliates[value]"]' => ['checked' => TRUE],
                ],
              ],
            ];
          }
        }
        // #options are available but do not contain the domain being
        // processed, so we hide the corresponding path field.
        elseif (isset($form['field_domain_access']['widget']['#options'])) {
          $path_element['#access'] = FALSE;
        }
        // Hide the path field when the user doesn't have access to
        // this domain.
        elseif (!isset($domain_access[$domain_id])) {
          $path_element['#access'] = FALSE;
        }
      }

    }

    // Container for domain path fields.
    $form[DomainPathHelper::PATH_FIELD] = [
      '#tree' => TRUE,
      '#type' => 'details',
      '#title' => $this->t('Domain-specific paths'),
      '#description' => $this->t('Override the default URL alias for individual domains.
      Alias must start with a slash.
      For example, type "/about" when writing an about page.'),
      '#weight' => 110,
      '#open' => TRUE,
    ] + $form[DomainPathHelper::PATH_FIELD];

    // Add an option to delete all domain paths. This is just for convenience
    // so the user doesn't have to manually remove the paths from each domain.
    $form[DomainPathHelper::PATH_FIELD]['domain_path_delete'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Delete all aliases for this content'),
      '#description' => $this->t('Checking this box will delete all aliases for this content, avoiding the need to remove them individually.'),
      '#default_value' => FALSE,
      '#weight' => 1000,
    ];

    // We only need to enable the delete checkbox if we have at least two
    // visible defined domain paths. See https://www.drupal.org/i/3461258
    $show_delete = $visible_paths > 1;

    $form[DomainPathHelper::PATH_FIELD]['domain_path_delete']['#access'] = $show_delete;

    // Hide the default URL alias for better UI.
    if ($this->getConfig()->get('hide_path_alias_ui')) {
      unset($form['path']);
    }

    // Move the domain path field to the advanced group.
    if (
      isset($form['advanced'])
      && !isset($form[DomainPathHelper::PATH_FIELD]['#group'])
      && $this->getConfig()->get('use_advanced_group')
    ) {
      $form[DomainPathHelper::PATH_FIELD]['#group'] = 'advanced';
      // Move the domain path field below the domain group if present.
      $form['#after_build'][] = [self::class, 'afterEntityFormBuild'];
    }

    // Add our validation and submit handlers.
    $form['#validate'][] = [self::class, 'validateEntityForm'];
    if (!empty($form['actions']) && array_key_exists('submit', $form['actions'])) {
      $form['actions']['submit']['#submit'][] = [self::class, 'submitEntityForm'];
    }
    else {
      // If no actions we just tack it on to the form submit handlers.
      $form['#submit'][] = [self::class, 'submitEntityForm'];
    }

    return $form;
  }

  /**
   * Form #after_build callback.
   */
  public static function afterEntityFormBuild(array $form, FormStateInterface $form_state): array {
    if (
      isset($form['domain']) &&
      isset($form[DomainPathHelper::PATH_FIELD])
    ) {
      $domain_group_weight = $form['domain']['#weight'];
      $form[DomainPathHelper::PATH_FIELD]['#weight'] = $domain_group_weight + 1;
    }
    return $form;
  }

  /**
   * Validation handler for the domain paths element.
   *
   * @param array $form
   *   The form array.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state object.
   */
  public static function validateEntityForm(array &$form, FormStateInterface $form_state) {
    // No special validation needed at this time.
  }

  /**
   * Submit handler for the domain paths element.
   *
   * @param array $form
   *   The form array.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state object.
   */
  public static function submitEntityForm($form, FormStateInterface $form_state) {
    \Drupal::service(self::class)->doSubmitEntityForm($form, $form_state);
  }

  /**
   * Processes the domain path form submission.
   *
   * @param array $form
   *   The form array.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state object.
   */
  public function doSubmitEntityForm($form, FormStateInterface $form_state) {
    $domain_path_wrapper_values = $form_state->getValue('domain_path_wrapper');
    if (!empty($domain_path_wrapper_values['domain_path_delete'])) {
      $entity = $form_state->getFormObject()->getEntity();
      $entity_system_path = '/' . $entity->toUrl()->getInternalPath();
      $properties = [
        'path' => $entity_system_path,
        'langcode' => $entity->language()->getId(),
      ];
      $domain_path_storage = $this->entityTypeManager->getStorage('path_alias');
      $domain_paths = $domain_path_storage->loadByProperties($properties);
      foreach ($domain_paths as $domain_path) {
        $domain_path->delete();
      }
    }
  }

  /**
   * Determines the domain access settings for altering the entity form.
   *
   * @param array $form
   *   The form array.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state object.
   *
   * @return bool|array
   *   Returns TRUE if the domain access module is not installed or
   *   domain access is enabled for all domains. Returns an array of
   *   target IDs if specific domain access is configured.
   */
  protected function getAlterFormDomainAccess($form, $form_state) {
    if (!$this->domainPathHelper->isDomainAccessInstalled()) {
      return TRUE;
    }

    $entity = $form_state->getFormObject()->getEntity();
    /** @var \Drupal\user\UserInterface $user */
    $user = $this->entityTypeManager->getStorage('user')->load($this->currentUser->id());
    // Domain access widgets are present on this form.
    if (($this->hasDomainAccessWidgets($form) && $this->hasDynamicDomainPaths($form))
      // Or form entity doesn't have domain access fields.
      || !$this->domainPathHelper->hasDomainAccessFields($entity)) {
      if (DomainAccessManager::getAllValue($user)
        || $user->hasPermission('publish to any domain')) {
        return TRUE;
      }
      // We allow only the domains the user is assigned to.
      return DomainAccessManager::getAccessValues($user);
    }
    // No domain access fields on the form, so we can check the entity
    // itself.
    if ($entity->isNew()) {
      // We need to know to which domain the entity will be published
      // before allowing the creation of the corresponding domain paths.
      return FALSE;
    }
    // We keep only the domains the user has access to and that are
    // assigned to this entity. The domain assignments cannot be changed
    // as the access fields are not present on the form.
    return $this->domainPathHelper->getEntityDomainAccessForUser($entity, $user);
  }

  /**
   * Check if the form contains accessible domain access fields.
   *
   * @param array $form
   *   The form structure to check for domain access fields.
   *
   * @return bool
   *   TRUE if the form contains accessible domain access fields,
   *   FALSE otherwise.
   */
  protected function hasDomainAccessWidgets(array $form) {
    return ((!empty($form['field_domain_access']) && ($form['field_domain_access']['#access'] ?? FALSE))
      || (!empty($form['field_domain_all_affiliates']) && ($form['field_domain_all_affiliates']['#access'] ?? FALSE)));
  }

  /**
   * Checks if the domain paths are dynamic based on the domain access field.
   *
   * @param array $form
   *   The form array to evaluate, containing domain access widgets.
   *
   * @return bool
   *   TRUE if the domain paths are dynamic, FALSE otherwise.
   */
  protected function hasDynamicDomainPaths(array $form) {
    return (isset($form['field_domain_access']['widget']['#type'])
      && (($form['field_domain_access']['widget']['#type'] === 'checkboxes')
        || ($form['field_domain_access']['widget']['#type'] === 'radios')
        || ($form['field_domain_access']['widget']['#type'] === 'select'
          && !($form['field_domain_access']['widget']['#multiple'] ?? FALSE))));
  }

}
