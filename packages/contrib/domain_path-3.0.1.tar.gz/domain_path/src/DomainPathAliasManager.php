<?php

namespace Drupal\domain_path;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Language\LanguageInterface;
use Drupal\Core\Language\LanguageManagerInterface;
use Drupal\path_alias\AliasManagerInterface;

/**
 * Domain-aware alias manager.
 *
 * Delegates getAliasByPath() and getPathByAlias() to core's
 * AliasManager, which uses the domain-aware repository for
 * lookups. This ensures core's AliasPrefixList filter, static
 * cache, and Fiber batching all work natively with domain aliases.
 *
 * Provides getAliasByPathAndDomain() / getPathByAliasAndDomain()
 * for explicit domain lookups (used by the outbound processor for
 * cross-domain links).
 *
 * @internal
 */
class DomainPathAliasManager implements AliasManagerInterface, DomainAliasManagerInterface {

  /**
   * Holds the map of explicit-domain path lookups.
   *
   * @var array
   */
  protected $lookupMap = [];

  /**
   * Holds aliases for which no path was found (explicit domain).
   *
   * @var array
   */
  protected $noPath = [];

  /**
   * Holds paths that have no alias (explicit domain).
   *
   * @var array
   */
  protected $noAlias = [];

  public function __construct(
    protected AliasManagerInterface $inner,
    protected DomainAliasRepositoryInterface $domainAliasRepository,
    protected LanguageManagerInterface $languageManager,
    protected ConfigFactoryInterface $configFactory,
  ) {
  }

  /**
   * Gets the domain path configuration.
   *
   * @return \Drupal\Core\Config\ImmutableConfig
   *   The domain path configuration object.
   */
  protected function getConfig() {
    return $this->configFactory->get('domain_path.settings');
  }

  /**
   * Resolves the langcode using the configured language method.
   *
   * @param string|null $langcode
   *   An explicit language code, or NULL to use the configured default.
   *
   * @return string
   *   The resolved language code.
   */
  protected function resolveLangcode(?string $langcode): string {
    if ($langcode) {
      return $langcode;
    }
    $method = $this->getConfig()->get('language_method')
      ?: LanguageInterface::TYPE_CONTENT;
    return $this->languageManager->getCurrentLanguage($method)->getId();
  }

  /**
   * {@inheritdoc}
   *
   * Delegates to core's AliasManager. The domain-aware repository
   * ensures domain-specific aliases are returned transparently.
   */
  public function getAliasByPath($path, $langcode = NULL) {
    return $this->inner->getAliasByPath($path, $langcode);
  }

  /**
   * {@inheritdoc}
   *
   * Delegates to core's AliasManager. The domain-aware repository
   * ensures domain-specific aliases are returned transparently.
   */
  public function getPathByAlias($alias, $langcode = NULL) {
    return $this->inner->getPathByAlias($alias, $langcode);
  }

  /**
   * {@inheritdoc}
   */
  public function getAliasByPathAndDomain($path, $domain_id, $langcode = NULL) {
    if (!str_starts_with($path, '/')) {
      throw new \InvalidArgumentException(sprintf('Source path %s has to start with a slash.', $path));
    }

    // The root path is always aliased to itself.
    if ($path === '/') {
      return $path;
    }

    $langcode = $this->resolveLangcode($langcode);

    // If we already know that there are no aliases for this path,
    // simply return.
    if (!empty($this->noAlias[$domain_id][$langcode][$path])) {
      return $path;
    }
    // If the alias has already been loaded, return it from static cache.
    if (isset($this->lookupMap[$domain_id][$langcode][$path])) {
      return $this->lookupMap[$domain_id][$langcode][$path];
    }

    // Try to load alias from storage.
    if ($path_alias = $this->domainAliasRepository->lookupBySystemPathAndDomain($path, $domain_id, $langcode)) {
      $this->lookupMap[$domain_id][$langcode][$path] = $path_alias['alias'];
      return $path_alias['alias'];
    }

    // Fall back to core aliasing (global aliases).
    $alias = $this->inner->getAliasByPath($path, $langcode);

    if ($alias === $path) {
      // We can't record anything into $this->lookupMap because we
      // didn't find any aliases for this path. Thus cache to
      // $this->noAlias.
      $this->noAlias[$domain_id][$langcode][$path] = TRUE;
    }
    else {
      $this->lookupMap[$domain_id][$langcode][$path] = $alias;
      return $alias;
    }

    return $path;
  }

  /**
   * {@inheritdoc}
   */
  public function getPathByAliasAndDomain($alias, $domain_id, $langcode = NULL) {
    $langcode = $this->resolveLangcode($langcode);

    if (empty($alias) || !empty($this->noPath[$domain_id][$langcode][$alias])) {
      return $alias;
    }

    // Check static cache.
    if (isset($this->lookupMap[$domain_id][$langcode])
      && ($path = array_search($alias, $this->lookupMap[$domain_id][$langcode]))) {
      return $path;
    }

    // Try domain-specific lookup.
    if ($path_alias = $this->domainAliasRepository->lookupByAliasAndDomain($alias, $domain_id, $langcode)) {
      $this->lookupMap[$domain_id][$langcode][$path_alias['path']] = $alias;
      return $path_alias['path'];
    }

    // Fall back to core aliasing.
    $path = $this->inner->getPathByAlias($alias, $langcode);

    if ($path === $alias) {
      $this->noPath[$domain_id][$langcode][$alias] = TRUE;
    }
    else {
      $this->lookupMap[$domain_id][$langcode][$path] = $alias;
      return $path;
    }

    return $alias;
  }

  /**
   * {@inheritdoc}
   */
  public function cacheClear($source = NULL) {
    // Clear the cache of the inner alias manager.
    $this->inner->cacheClear($source);
    // Only flush the specific source from the lookup map, not the
    // entire map, to preserve cached lookups for other paths.
    if ($source) {
      foreach ($this->lookupMap as $domain_id => $domain_lookups) {
        foreach (array_keys($domain_lookups) as $lang) {
          unset($this->lookupMap[$domain_id][$lang][$source]);
        }
      }
    }
    else {
      $this->lookupMap = [];
    }
    $this->noPath = [];
    $this->noAlias = [];
  }

  /**
   * Sets the cache key for the preload alias cache.
   *
   * On Drupal 10, core calls this method to enable the cross-request
   * preload cache. On Drupal 11.3+ this is a no-op (core deprecated
   * the upstream method).
   */
  public function setCacheKey($key) {
    // Forward to the inner alias manager (Drupal 10 only).
    if (method_exists($this->inner, 'setCacheKey')) {
      $this->inner->setCacheKey($key);
    }
  }

  /**
   * Writes the preload cache.
   *
   * On Drupal 10, core calls this at the end of each request.
   * On Drupal 11.3+ this is a no-op (core deprecated the upstream
   * method and never calls it).
   */
  public function writeCache() {
    // Forward to the inner alias manager (Drupal 10 only).
    if (method_exists($this->inner, 'writeCache')) {
      $this->inner->writeCache();
    }
  }

}
