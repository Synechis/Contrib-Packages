<?php

namespace Drupal\domain_path\Hook;

use Drupal\Core\Hook\Attribute\Hook;
use Drupal\domain_path\DomainPathFormHelper;
use Drupal\domain_path\DomainPathHelper;

/**
 * Form hook implementations for domain_path.
 *
 * This class is final and internal. To customize the domain
 * path form behavior, implement hook_form_alter() or
 * hook_form_FORM_ID_alter() in your own module. If you need
 * an extension point that hooks cannot provide, please open
 * an issue in the domain_path issue queue.
 *
 * @internal
 */
final class DomainPathFormHooks {

  public function __construct(
    protected DomainPathHelper $domainPathHelper,
    protected DomainPathFormHelper $domainPathFormHelper,
  ) {}

  /**
   * Implements hook_form_alter().
   */
  #[Hook('form_alter')]
  public function formAlter(&$form, &$form_state, $form_id) {
    if (isset($form[DomainPathHelper::PATH_FIELD]['widget'])
      && ($object = $form_state->getFormObject())
      && is_callable([$object, 'getEntity'])
      && ($entity = $object->getEntity())) {
      if ($this->domainPathHelper->domainPathsIsEnabled($entity)) {
        $this->domainPathFormHelper->alterEntityForm($form, $form_state, $entity);
      }
    }
  }

  /**
   * Implements hook_domain_config_ui_disallowed_configurations_alter().
   *
   * Prevents domain-level overrides for domain_path settings,
   * since domain_path has its own per-domain configuration.
   */
  #[Hook('domain_config_ui_disallowed_configurations_alter')]
  public function domainConfigUiDisallowedConfigurationsAlter(array &$configurations) {
    $configurations[] = 'domain_path.settings';
  }

}
