<?php

namespace Drupal\domain_path\Hook;

use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Entity\EntityTypeInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Field\BaseFieldDefinition;
use Drupal\Core\Field\FieldStorageDefinitionInterface;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\domain\DomainInterface;
use Drupal\domain_path\DomainPathAliasListBuilder;
use Drupal\domain_path\DomainPathHelper;
use Drupal\domain_path\Entity\DomainPathAlias;
use Drupal\domain_path\Plugin\Validation\Constraint\DomainPathUniquePathAliasConstraint;

/**
 * Entity hook implementations for domain_path.
 *
 * This class is final and internal. To customize entity
 * hook behavior, implement the corresponding hooks in your
 * own module. If you need an extension point that hooks
 * cannot provide, please open an issue in the domain_path
 * issue queue.
 *
 * @internal
 */
final class DomainPathEntityHooks {

  use StringTranslationTrait;

  public function __construct(
    protected EntityTypeManagerInterface $entityTypeManager,
    protected DomainPathHelper $domainPathHelper,
  ) {}

  /**
   * Implements hook_entity_delete().
   */
  #[Hook('entity_delete')]
  public function entityDelete(EntityInterface $entity) {
    // Delete domain paths on domain delete.
    if ($entity instanceof DomainInterface) {
      $domain_paths = $this->entityTypeManager
        ->getStorage('path_alias')
        ->loadByProperties(['domain_id' => $entity->id()]);
      if ($domain_paths) {
        foreach ($domain_paths as $domain_path) {
          $domain_path->delete();
        }
      }
    }
  }

  /**
   * Implements hook_entity_base_field_info().
   */
  #[Hook('entity_base_field_info')]
  public function entityBaseFieldInfo(EntityTypeInterface $entity_type) {
    $fields = [];
    if ($entity_type->id() === 'path_alias') {
      $fields['domain_id'] = BaseFieldDefinition::create('entity_reference')
        ->setLabel($this->t('Domain'))
        ->setDescription($this->t('The domain this path alias applies to.'))
        ->setRevisionable(TRUE)
        ->setSetting('target_type', 'domain')
        ->setSetting('handler', 'default')
        ->setDisplayOptions('view', [
          'label' => 'above',
          'type' => 'entity_reference_label',
        ])
        ->setDisplayOptions('form', [
          'type' => 'entity_reference_autocomplete',
          'settings' => [
            'match_operator' => 'CONTAINS',
            'size' => 60,
            'autocomplete_type' => 'tags',
            'placeholder' => '',
          ],
        ]);
    }
    else {
      if ($enabled_entity_types = $this->domainPathHelper->getConfiguredEntityTypes()) {
        if (in_array($entity_type->id(), $enabled_entity_types)) {
          $fields[DomainPathHelper::PATH_FIELD] = BaseFieldDefinition::create('domain_path')
            ->setCustomStorage(TRUE)
            ->setLabel($this->t('Domain URL alias'))
            ->setTranslatable(TRUE)
            ->setComputed(TRUE)
            ->setCardinality(FieldStorageDefinitionInterface::CARDINALITY_UNLIMITED)
            ->setDisplayOptions('form', [
              'type' => 'domain_path',
              'weight' => 30,
            ])
            ->setDisplayConfigurable('form', TRUE);
        }
      }
    }
    return $fields;
  }

  /**
   * Implements hook_entity_type_alter().
   */
  #[Hook('entity_type_alter')]
  public function entityTypeAlter(array &$entity_types) {
    if (isset($entity_types['path_alias'])) {
      $entity_types['path_alias']->setClass(DomainPathAlias::class);
      $entity_types['path_alias']->setListBuilderClass(DomainPathAliasListBuilder::class);
    }
  }

  /**
   * Implements hook_validation_constraint_alter().
   */
  #[Hook('validation_constraint_alter')]
  public function validationConstraintAlter(array &$definitions) {
    if (isset($definitions['UniquePathAlias'])) {
      $definitions['UniquePathAlias']['class'] = DomainPathUniquePathAliasConstraint::class;
    }
  }

}
