<?php

namespace Drupal\domain_path;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Entity\FieldableEntityInterface;
use Drupal\Core\Extension\ModuleHandlerInterface;
use Drupal\Core\Session\AccountInterface;
use Drupal\domain_access\DomainAccessManager;
use Drupal\user\UserInterface;

/**
 * Helper class for domain path operations.
 *
 * @final
 */
class DomainPathHelper {

  public const PATH_FIELD = 'domain_path';

  public function __construct(
    protected EntityTypeManagerInterface $entityTypeManager,
    protected ModuleHandlerInterface $moduleHandler,
    protected ConfigFactoryInterface $configFactory,
  ) {
  }

  /**
   * Gets the domain path configuration.
   *
   * @return \Drupal\Core\Config\ImmutableConfig
   *   The domain path configuration object.
   */
  protected function getConfig() {
    return $this->configFactory->get('domain_path.settings');
  }

  /**
   * Checks if the domain_access module is installed.
   *
   * @return bool
   *   TRUE if domain_access is installed, FALSE otherwise.
   */
  public function isDomainAccessInstalled(): bool {
    return $this->moduleHandler->moduleExists('domain_access');
  }

  /**
   * Helper function for retrieving configured entity types.
   *
   * @return array
   *   Returns array of configured entity types.
   */
  public function getConfiguredEntityTypes(): array {
    return $this->getConfig()->get('entity_types') ?? [];
  }

  /**
   * Check if domain paths is enabled for a given entity.
   *
   * @param \Drupal\Core\Entity\EntityInterface $entity
   *   The entity object.
   *
   * @return bool
   *   Return TRUE or FALSE.
   */
  public function domainPathsIsEnabled(EntityInterface $entity) {
    return in_array($entity->getEntityTypeId(), $this->getConfiguredEntityTypes());
  }

  /**
   * Determine the domain access for an entity based on the user's permissions.
   *
   * @param \Drupal\Core\Entity\FieldableEntityInterface $entity
   *   The entity for which domain access is being evaluated.
   * @param \Drupal\Core\Entity\FieldableEntityInterface $user
   *   The user whose domain access is being checked.
   *
   * @return bool|array
   *   The domain access information for the user on the entity.
   */
  public function getEntityDomainAccessForUser($entity, $user) {
    if (DomainAccessManager::getAllValue($entity)
      // If the entity doesn't have domain access fields,
      // we assume it's open to all affiliates.
      || !$this->hasDomainAccessFields($entity)) {
      if (DomainAccessManager::getAllValue($user)
        || $user->hasPermission('publish to any domain')) {
        $domain_access = TRUE;
      }
      else {
        $domain_access = DomainAccessManager::getAccessValues($user);
      }
    }
    else {
      $entity_domains = DomainAccessManager::getAccessValues($entity);
      if (DomainAccessManager::getAllValue($user)
        || $user->hasPermission('publish to any domain')) {
        $domain_access = $entity_domains;
      }
      else {
        $user_domains = DomainAccessManager::getAccessValues($user);
        $domain_access = array_intersect_key($entity_domains, $user_domains);
      }
    }
    return $domain_access;
  }

  /**
   * Checks if a user account can access a specific domain.
   *
   * @param \Drupal\Core\Session\AccountInterface $account
   *   The user account to check.
   * @param int $domain_id
   *   The domain ID to check access for.
   *
   * @return bool
   *   TRUE if the user can access the domain, FALSE otherwise.
   */
  public function userCanAccessDomain(AccountInterface $account, $domain_id): bool {
    if (!$this->isDomainAccessInstalled()) {
      return TRUE;
    }

    // Users with global permission can access any domain.
    if ($account->hasPermission('publish to any domain')) {
      return TRUE;
    }

    // Load the full user entity to check domain assignments.
    /** @var \Drupal\user\UserInterface $user */
    $user = $this->entityTypeManager->getStorage('user')->load($account->id());
    if (!$user) {
      return FALSE;
    }

    // Check if the user has access to all domains.
    if (DomainAccessManager::getAllValue($user)) {
      return TRUE;
    }

    // Check if the user has access to this specific domain.
    $user_domains = DomainAccessManager::getAccessValues($user);
    if (isset($user_domains[$domain_id])) {
      return TRUE;
    }

    return FALSE;
  }

  /**
   * Retrieves the domains the user has access to.
   *
   * @param \Drupal\Core\Session\AccountInterface $account
   *   The user account to check.
   *
   * @return array
   *   An array of domains that the user has access to, keyed by domain ID.
   */
  public function getUserAccessibleDomains(AccountInterface $account) {
    $domains = $this->entityTypeManager->getStorage('domain')->loadMultipleSorted();

    if (!$this->isDomainAccessInstalled()) {
      return $domains;
    }

    // Users with global permission can access any domain.
    if ($account->hasPermission('publish to any domain')) {
      return $domains;
    }

    // Load the full user entity to check domain assignments.
    if ($account instanceof UserInterface) {
      $user = $account;
    }
    else {
      /** @var \Drupal\user\UserInterface $user */
      $user = $this->entityTypeManager->getStorage('user')->load($account->id());
      if (!$user) {
        return [];
      }
    }

    // Check if the user has access to all domains.
    if (DomainAccessManager::getAllValue($user)) {
      return $domains;
    }

    $accessible_domains = [];

    // Check if the user has access to the domains.
    $user_domains = DomainAccessManager::getAccessValues($user);
    foreach ($domains as $domain_id => $domain) {
      if (array_key_exists($domain_id, $user_domains)) {
        $accessible_domains[$domain_id] = $domain;
      }
    }

    return $accessible_domains;
  }

  /**
   * Checks if the entity has domain access fields.
   *
   * @param \Drupal\Core\Entity\FieldableEntityInterface $entity
   *   The entity to check for domain access fields.
   *
   * @return bool
   *   TRUE if the entity has domain access fields, FALSE otherwise.
   */
  public function hasDomainAccessFields(FieldableEntityInterface $entity) {
    return $entity->hasField('field_domain_access') || $entity->hasField('field_domain_all_affiliates');
  }

}
