<?php

namespace Drupal\domain_path\Plugin\Validation\Constraint;

use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\Core\Validation\Attribute\Constraint;
use Symfony\Component\Validator\Constraint as SymfonyConstraint;

/**
 * Constraint for creating domain alias starting with a slash.
 *
 * @internal
 */
#[Constraint(
  id: 'DomainPathSlash',
  label: new TranslatableMarkup('Domain path must start with a slash.', [], ['context' => 'Validation']),
)]
class DomainPathSlashConstraint extends SymfonyConstraint {

  /**
   * Violation message.
   *
   * @var string
   */
  public $message = 'Domain path "%alias" needs to start with a slash.';

}
