<?php

namespace Drupal\domain_path\Plugin\Validation\Constraint;

use Drupal\Core\Path\Plugin\Validation\Constraint\UniquePathAliasConstraintValidator;
use Symfony\Component\Validator\Constraint;

/**
 * Constraint validator for a unique path alias.
 *
 * @internal
 */
class DomainPathUniquePathAliasConstraintValidator extends UniquePathAliasConstraintValidator {

  /**
   * {@inheritdoc}
   */
  public function validate($entity, Constraint $constraint): void {
    /** @var \Drupal\domain_path\DomainPathAliasInterface $entity */
    $path = $entity->getPath();
    $alias = $entity->getAlias();
    $langcode = $entity->language()->getId();

    $storage = $this->entityTypeManager->getStorage('path_alias');
    $query = $storage->getQuery()
      ->accessCheck(FALSE)
      ->condition('alias', $alias, '=')
      ->condition('langcode', $langcode, '=');

    if (!$entity->isNew()) {
      $query->condition('id', $entity->id(), '<>');
    }
    if ($path) {
      $query->condition('path', $path, '<>');
    }

    // Scope uniqueness check to the current domain.
    if ($entity->hasDomainId()) {
      $query->condition('domain_id', $entity->getDomainId());
    }
    else {
      $query->notExists('domain_id');
    }

    if ($result = $query->range(0, 1)->execute()) {
      $existing_alias_id = reset($result);
      $existing_alias = $storage->load($existing_alias_id);

      if ($entity->hasDomainId()) {
        $this->context->buildViolation($constraint->messageDomain, [
          '%alias' => $alias,
          '%domain' => $entity->getDomainId(),
        ])->addViolation();
      }
      elseif ($existing_alias->getAlias() !== $alias) {
        $this->context->buildViolation($constraint->differentCapitalizationMessage, [
          '%alias' => $alias,
          '%stored_alias' => $existing_alias->getAlias(),
        ])->addViolation();
      }
      else {
        $this->context->buildViolation($constraint->message, [
          '%alias' => $alias,
        ])->addViolation();
      }
    }
  }

}
