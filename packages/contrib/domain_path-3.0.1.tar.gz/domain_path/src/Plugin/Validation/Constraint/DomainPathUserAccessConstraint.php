<?php

namespace Drupal\domain_path\Plugin\Validation\Constraint;

use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\Core\Validation\Attribute\Constraint;
use Symfony\Component\Validator\Constraint as SymfonyConstraint;

/**
 * Constraint for creating domain alias for users without access to domain.
 *
 * @internal
 */
#[Constraint(
  id: 'DomainPathUserAccess',
  label: new TranslatableMarkup('Domain path.', [], ['context' => 'Validation']),
)]
class DomainPathUserAccessConstraint extends SymfonyConstraint {

  /**
   * Violation message.
   *
   * @var string
   */
  public $message = "You don't have access to this domain.";

}
