<?php

namespace Drupal\domain_path\Plugin\Validation\Constraint;

use Drupal\Core\DependencyInjection\ContainerInjectionInterface;
use Drupal\domain_path\DomainAliasRepositoryInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\Validator\Constraint;
use Symfony\Component\Validator\ConstraintValidator;

/**
 * Constraint validator for creating domain alias that does not already exist.
 *
 * @internal
 */
class DomainPathUniqueConstraintValidator extends ConstraintValidator implements ContainerInjectionInterface {

  public function __construct(
    protected DomainAliasRepositoryInterface $domainAliasRepository,
  ) {
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('domain_path.repository'),
    );
  }

  /**
   * {@inheritdoc}
   */
  public function validate($value, Constraint $constraint) {
    // An empty alias cannot collide with an existing one, so there is nothing
    // to validate. Returning early also avoids a pointless lookup that would
    // pass an empty value to the database escape function.
    if ($value->alias === NULL || $value->alias === '') {
      return;
    }
    // Query the domain alias repository directly instead of the full
    // DomainPathAliasManager, which falls back to core aliasing and
    // would incorrectly flag aliases from other domains as duplicates.
    $path_alias = $this->domainAliasRepository->lookupByAliasAndDomain(
      $value->alias, $value->domain_id, $value->langcode);
    if ($path_alias) {
      // Get the entity from the root of the validation context.
      $entity = $this->context->getRoot()->getValue();
      if ($entity->isNew()) {
        $duplicate = TRUE;
      }
      else {
        $entity_source = '/' . $entity->toUrl()->getInternalPath();
        $duplicate = $path_alias['path'] !== $entity_source;
      }
      if ($duplicate) {
        $this->context->addViolation(
          $constraint->message,
          ['%alias' => $value->alias, '%domain' => $value->domain_id],
        );
      }
    }
  }

}
