<?php

namespace Drupal\domain_path\Plugin\Validation\Constraint;

use Drupal\Core\Path\Plugin\Validation\Constraint\UniquePathAliasConstraint;

/**
 * Constraint validator for a Domain unique path alias.
 *
 * @internal
 */
class DomainPathUniquePathAliasConstraint extends UniquePathAliasConstraint {

  /**
   * The domain violation message.
   */
  public string $messageDomain = 'The alias %alias is already in use in this domain (%domain).';

}
