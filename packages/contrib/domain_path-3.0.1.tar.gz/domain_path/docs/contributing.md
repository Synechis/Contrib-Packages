# Contributing

Submit bug reports and feature suggestions, or track changes in the
[issue queue](https://www.drupal.org/project/issues/domain_path).

## Local development setup

Domain Path requires a working multi-domain environment. You need multiple (or
wildcard) domains pointing to your Drupal installation. The Domain module test
base uses variants of `example.com` by default (`one.example.com`,
`two.example.com`, etc.).

## Running tests

The module has three test suites: **Kernel**, **Functional**, and
**FunctionalJavascript**.

Run all tests:

``` bash
cd /path/to/drupal/web
php -d memory_limit=-1 ../vendor/bin/phpunit \
  -c core/phpunit.xml \
  modules/contrib/domain_path
```

Run a specific test class:

``` bash
php -d memory_limit=-1 ../vendor/bin/phpunit \
  -c core/phpunit.xml \
  --filter DomainPathAliasManagerTest \
  modules/contrib/domain_path
```

!!! note
    FunctionalJavascript tests require a WebDriver-compatible browser
    (ChromeDriver or Selenium) running on the host configured in
    `phpunit.xml`.

## Test structure

### Kernel tests

| Test class | What it covers |
|---|---|
| `DomainPathAliasManagerTest` | Domain-scoped path/alias resolution |
| `DomainPathAliasProcessorTest` | Outbound path processing |
| `DomainPathConfigTest` | Configuration validation and cache clearing |
| `DomainPathDomainDeleteTest` | Alias cleanup on domain deletion |
| `DomainPathFieldConstraintsTest` | Slash, unique, and user access constraints |
| `DomainPathMultilingualTest` | Alias resolution across languages |
| `DomainPathNoDomainAccessTest` | Behavior without domain_access module |
| `DomainPathPostSaveTest` | Path alias entity creation/update/deletion |
| `DomainPathUniqueAliasTest` | Uniqueness constraints across domains |

### Functional tests

| Test class | What it covers |
|---|---|
| `DomainPathCreateTest` | Creating domain paths on new entities |
| `DomainPathDomainOptionTest` | Domain option rendering and selection |
| `DomainPathDomainTest` | Basic domain path functionality |
| `DomainPathFormTest` | Form rendering and multilingual aliases |
| `DomainPathNoDomainAccessTest` | UI without domain_access module |
| `DomainPathNodeAliasAutocompleteTest` | Autocomplete for path aliases |
| `DomainPathNodeAliasTest` | Alias creation and form interaction |
| `DomainPathSourceTest` | Integration with domain_source module |
| `DomainPathVisibilityWithDomainAccessTest` | Field visibility based on domain access |
| `DomainPathVisibilityWithDomainAccessAutocompleteTest` | Visibility with autocomplete widgets |
| `DomainPathWidgetDisplayTest` | Widget UI and field rendering |
| `DomainPathWithSourceAndPathautoTest` | Integration with domain_source and pathauto |

### FunctionalJavascript tests

| Test class | What it covers |
|---|---|
| `DomainPathStatesTest` | Form `#states` conditional visibility |

## Code standards

The following tools are used for code quality:

``` bash
# Auto-fix coding standards
vendor/bin/phpcbf web/modules/contrib/domain_path \
  --standard="Drupal,DrupalPractice" -n \
  --extensions="php,module,inc,install,test,profile,theme"

# Check coding standards
vendor/bin/phpcs web/modules/contrib/domain_path \
  --standard="Drupal,DrupalPractice" -n \
  --extensions="php,module,inc,install,test,profile,theme"

# Static analysis
vendor/bin/phpstan analyse web/modules/contrib/domain_path
```

## Compatibility

The module supports:

- **Drupal 10.3+** and **Drupal 11.x**
- **Domain 3.x** (the 2.x branch has API differences -- notably, the
  `domain_access.helper` service does not exist in 2.x)

When writing tests, use both PHPUnit attributes and annotations for backward
compatibility with Drupal 10.6 (PHPUnit 9):

``` php
#[Group('domain_path')]
/**
 * @group domain_path
 */
```
