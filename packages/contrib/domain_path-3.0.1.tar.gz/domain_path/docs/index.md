# Overview

The Domain Path module allows the creation of **domain-specific path aliases**
for content entities. While Drupal core provides a single URL alias per entity
per language, Domain Path lets you define a different alias for each domain in
a multi-domain installation.

For a full description of the module, visit the
[project page](https://www.drupal.org/project/domain_path).

Submit bug reports and feature suggestions, or track changes in the
[issue queue](https://www.drupal.org/project/issues/domain_path).

## How it works

When editing a node (or any enabled entity type), the form displays an alias
field for each domain. Each alias is stored as a standard Drupal `path_alias`
entity with an additional `domain_id` field. During outbound URL generation,
the module resolves the alias that matches the target domain instead of the
default alias.

For example, a node with the system path `/node/42` could have:

| Domain | Alias |
|---|---|
| `example.com` | `/products/widget` |
| `shop.example.com` | `/widget` |
| `de.example.com` | `/produkte/widget` |

## Requirements

- [Domain](https://www.drupal.org/project/domain) module (required)
- Drupal core Path module (required)
- [Domain Access](https://www.drupal.org/project/domain) (optional) --
  controls which domains a user can set aliases for
- [Pathauto](https://www.drupal.org/project/pathauto) (optional) --
  domain path aliases override pathauto-generated aliases per domain
- [Domain Source](https://www.drupal.org/project/domain) (optional) --
  sets the canonical domain for a node; Domain Path resolves the alias for
  that domain in outbound links

## Installation

Install via Composer:

``` bash
composer require drupal/domain_path
```

Then enable the module:

``` bash
drush en domain_path
```

## Quick start

1. **Configure entity types** -- Visit
   `/admin/config/domain_path/domain_path` and select which entity types
   should have domain path fields. By default, only *Node* is enabled.

2. **Create or edit a node** -- The node form will display a *Domain-specific
   aliases* section (in the advanced sidebar by default). Enter an alias for
   each domain where you want a custom URL.

3. **View the result** -- When a link to that node is rendered on a specific
   domain, the domain-specific alias is used instead of the default alias.

!!! tip
    If you use Domain Access, only the domains assigned to the current user
    will appear in the alias widget. Users without domain assignments will not
    see any alias fields (unless they have the *administer url aliases*
    permission).

## Further reading

- [Configuration](configuration.md) -- all module settings and integration
  options
- [Architecture](architecture.md) -- how alias resolution works under the hood
- [Contributing](contributing.md) -- running tests and submitting patches
