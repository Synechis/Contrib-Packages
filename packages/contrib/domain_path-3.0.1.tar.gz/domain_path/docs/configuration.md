# Configuration

All module settings are available at **Administration > Configuration >
Domain Path** (`/admin/config/domain_path/domain_path`).

## Settings

### Entity types

Select which entity types should have domain-specific path alias fields.
Only fieldable entity types that support path aliases are listed.

Default: **Node** only.

### Alias title

Controls how domain names are displayed in the alias widget on entity forms:

| Value | Example |
|---|---|
| **Domain name** (default) | `Example` |
| **Hostname** | `example.com` |
| **URL** | `https://example.com` |

### Hide path alias UI

When enabled, the default Drupal *URL alias* field is hidden on entity forms
to avoid confusion with the domain-specific alias fields.

Default: **enabled**.

### Use advanced group

When enabled, the domain path widget is placed in the *advanced* vertical tab
sidebar on entity forms (alongside fields like *Authoring information* and
*URL alias*). When disabled, the widget appears inline in the main form.

Default: **enabled**.

### Language method

Controls which language is used when resolving domain-specific aliases:

| Value | Description |
|---|---|
| **Content language** (default) | Uses the entity's language |
| **Interface language** | Uses the current interface language |
| **URL language** | Uses the language detected from the URL |

This setting matters in multilingual setups where the interface language and
content language may differ.

## Integration with Domain Access

When the [Domain Access](https://www.drupal.org/project/domain) module is
enabled:

- **Per-user domain assignment** -- Only domains assigned to the current user
  appear in the alias widget. A user assigned to `example.com` and
  `blog.example.com` will see alias fields for those two domains only.
- **Entity domain assignment** -- On save, aliases are only written for
  domains to which the entity is assigned. If a node is published to
  `example.com` and `shop.example.com`, aliases for other domains are
  ignored.
- **Admin override** -- Users with the *administer url aliases* permission
  see all domains regardless of their own domain assignments.

**Without Domain Access**: all domains are visible to all users who have the
*create url aliases* permission.

## Integration with Pathauto

When [Pathauto](https://www.drupal.org/project/pathauto) is installed,
it generates URL aliases automatically based on patterns. Domain Path aliases
**take precedence** over pathauto-generated aliases on a per-domain basis:

- If a node has a domain-specific alias for `shop.example.com`, that alias is
  used when generating links on that domain.
- If no domain-specific alias exists, the default pathauto alias is used.

This lets you have automatic aliases as the baseline while overriding specific
domains with hand-crafted URLs.

## Integration with Domain Source

[Domain Source](https://www.drupal.org/project/domain) assigns a canonical
domain to each node. When Domain Source generates an outbound link, it sets
the target domain in the URL options. Domain Path then resolves the
domain-specific alias for that domain.

The processing order is:

1. **Domain Source** (priority 310) -- sets `$options['domain']` to the
   node's canonical domain.
2. **Domain Path** (priority 305) -- looks up the alias for that domain and
   sets `$options['alias'] = TRUE`.
3. **Core alias processor** (priority 300) -- skipped because
   `$options['alias']` is already set.

This ensures that cross-domain links always use the correct domain-specific
alias.

## Multilingual setup

Domain Path supports per-language, per-domain aliases. For a node translated
into English and French, you can set different aliases for each language on
each domain:

| Domain | Language | Alias |
|---|---|---|
| `example.com` | English | `/products/widget` |
| `example.com` | French | `/produits/widget` |
| `fr.example.com` | English | `/widget` |
| `fr.example.com` | French | `/widget-fr` |

The **Language method** setting (see above) controls which language is used
during alias resolution at runtime.
