# Codebase metrics

A measured snapshot of the Domain Path codebase and its submodules,
counted with [`cloc`](https://github.com/AlDanial/cloc). Charts show *code* lines
(blank and comment lines excluded) unless stated otherwise.

!!! note "Snapshot"
    Measured on the `3.x` branch, 2026-07-02. **98 files**,
    **5,827 lines of code**, 2,635 comment lines,
    1,386 blank (9,848 lines in total). See
    [Methodology](#methodology) to reproduce.

## At a glance

| Code | Comment | Blank | Files | Production | Test |
|-----:|--------:|------:|------:|-----------:|-----:|
| 5,827 | 2,635 | 1,386 | 98 | 2,974 | 2,853 |

## Production vs test

Domain Path ships **2,853** lines of test code backing **2,974** lines of
production code, a **96%** test-to-production ratio.

<div style="margin:1.6rem 0">
<svg viewBox="0 0 560 46" width="100%" role="img" style="display:block;width:100%;height:auto;font-family:ui-monospace,SFMono-Regular,Menlo,monospace">
<rect x="0.0" y="0" width="285.8" height="46" fill="#b07d22"></rect>
<text x="12.0" y="18" font-size="12.5" fill="#fff" font-weight="600">Production</text>
<text x="12.0" y="34" font-size="12" fill="#fff" opacity="0.9">2,974 &#183; 51%</text>
<rect x="285.8" y="0" width="274.2" height="46" fill="#4d7a88"></rect>
<text x="297.8" y="18" font-size="12.5" fill="#fff" font-weight="600">Test</text>
<text x="297.8" y="34" font-size="12" fill="#fff" opacity="0.9">2,853 &#183; 49%</text>
</svg>
</div>

## Lines by language

<div style="margin:1.6rem 0">
<svg viewBox="0 0 560 208" width="100%" role="img" style="display:block;width:100%;height:auto;font-family:ui-monospace,SFMono-Regular,Menlo,monospace">
<text x="190" y="20.0" text-anchor="end" dominant-baseline="central" font-size="12.5" fill="currentColor">PHP</text>
<rect x="200.0" y="11.0" width="294.0" height="17" rx="2.5" fill="#b07d22"></rect>
<text x="502.0" y="20.0" dominant-baseline="central" font-size="12" fill="currentColor" opacity="0.75">4,807</text>
<text x="190" y="48.0" text-anchor="end" dominant-baseline="central" font-size="12.5" fill="currentColor">Markdown</text>
<rect x="200.0" y="39.0" width="28.4" height="17" rx="2.5" fill="#6b7488"></rect>
<text x="236.4" y="48.0" dominant-baseline="central" font-size="12" fill="currentColor" opacity="0.75">464</text>
<text x="190" y="76.0" text-anchor="end" dominant-baseline="central" font-size="12.5" fill="currentColor">YAML</text>
<rect x="200.0" y="67.0" width="16.0" height="17" rx="2.5" fill="#4d7a88"></rect>
<text x="224.0" y="76.0" dominant-baseline="central" font-size="12" fill="currentColor" opacity="0.75">261</text>
<text x="190" y="104.0" text-anchor="end" dominant-baseline="central" font-size="12.5" fill="currentColor">CSS</text>
<rect x="200.0" y="95.0" width="15.8" height="17" rx="2.5" fill="#7a5a78"></rect>
<text x="223.8" y="104.0" dominant-baseline="central" font-size="12" fill="currentColor" opacity="0.75">258</text>
<text x="190" y="132.0" text-anchor="end" dominant-baseline="central" font-size="12.5" fill="currentColor">Text</text>
<rect x="200.0" y="123.0" width="1.1" height="17" rx="2.5" fill="#9aa3b0"></rect>
<text x="209.1" y="132.0" dominant-baseline="central" font-size="12" fill="currentColor" opacity="0.75">18</text>
<text x="190" y="160.0" text-anchor="end" dominant-baseline="central" font-size="12.5" fill="currentColor">JSON</text>
<rect x="200.0" y="151.0" width="1.0" height="17" rx="2.5" fill="#9aa3b0"></rect>
<text x="209.0" y="160.0" dominant-baseline="central" font-size="12" fill="currentColor" opacity="0.75">16</text>
<text x="190" y="188.0" text-anchor="end" dominant-baseline="central" font-size="12.5" fill="currentColor">SVG</text>
<rect x="200.0" y="179.0" width="0.2" height="17" rx="2.5" fill="#9aa3b0"></rect>
<text x="208.2" y="188.0" dominant-baseline="central" font-size="12" fill="currentColor" opacity="0.75">3</text>
</svg>
</div>

| Language | Code | Comment | Blank | Files |
|----------|-----:|--------:|------:|------:|
| PHP | 4,807 | 2,570 | 1,198 | 74 |
| Markdown | 464 | 0 | 181 | 6 |
| YAML | 261 | 65 | 7 | 13 |
| CSS | 258 | 0 | 0 | 1 |
| Text | 18 | 0 | 0 | 2 |
| JSON | 16 | 0 | 0 | 1 |
| SVG | 3 | 0 | 0 | 1 |

## Composition

Across all languages, code is 59% of the lines, comments
27%, and blank lines 14%. The
comment share reflects Drupal's docblock conventions.

<div style="margin:1.6rem 0">
<svg viewBox="0 0 560 46" width="100%" role="img" style="display:block;width:100%;height:auto;font-family:ui-monospace,SFMono-Regular,Menlo,monospace">
<rect x="0.0" y="0" width="331.3" height="46" fill="#b07d22"></rect>
<text x="12.0" y="18" font-size="12.5" fill="#fff" font-weight="600">Code</text>
<text x="12.0" y="34" font-size="12" fill="#fff" opacity="0.9">5,827 &#183; 59%</text>
<rect x="331.3" y="0" width="149.8" height="46" fill="#4d7a88"></rect>
<text x="343.3" y="18" font-size="12.5" fill="#fff" font-weight="600">Comment</text>
<text x="343.3" y="34" font-size="12" fill="#fff" opacity="0.9">2,635 &#183; 27%</text>
<rect x="481.2" y="0" width="78.8" height="46" fill="#9aa3b0"></rect>
</svg>
</div>

## By submodule

Production (brass) and test (steel) code per submodule, largest first.

<div style="margin:1.6rem 0">
<svg viewBox="0 0 560 60" width="100%" role="img" style="display:block;width:100%;height:auto;font-family:ui-monospace,SFMono-Regular,Menlo,monospace">
<text x="240" y="18.0" text-anchor="end" dominant-baseline="central" font-size="12.5" fill="currentColor">domain path (core)</text>
<rect x="250.0" y="11.0" width="132.2" height="13" rx="2.5" fill="#b07d22"></rect>
<rect x="382.2" y="11.0" width="111.8" height="13" rx="2.5" fill="#4d7a88"></rect>
<text x="502.0" y="18.0" dominant-baseline="central" font-size="12" fill="currentColor" opacity="0.75">4,323</text>
<text x="240" y="42.0" text-anchor="end" dominant-baseline="central" font-size="12.5" fill="currentColor">domain_path_pathauto</text>
<rect x="250.0" y="35.0" width="35.6" height="13" rx="2.5" fill="#b07d22"></rect>
<rect x="285.6" y="35.0" width="49.3" height="13" rx="2.5" fill="#4d7a88"></rect>
<text x="342.9" y="42.0" dominant-baseline="central" font-size="12" fill="currentColor" opacity="0.75">1,504</text>
</svg>
</div>

| Submodule | Production | Test | Total |
|-----------|-----------:|-----:|------:|
| domain path (core) | 2,343 | 1,980 | 4,323 |
| domain_path_pathauto | 631 | 873 | 1,504 |

## Test suite

Domain Path ships **34** automated test classes
(93 test methods), counted by type below.

<div style="margin:1.6rem 0">
<svg viewBox="0 0 560 96" width="100%" role="img" style="display:block;width:100%;height:auto;font-family:ui-monospace,SFMono-Regular,Menlo,monospace">
<text x="190" y="20.0" text-anchor="end" dominant-baseline="central" font-size="12.5" fill="currentColor">Kernel</text>
<rect x="200.0" y="11.0" width="259.4" height="17" rx="2.5" fill="#4d7a88"></rect>
<text x="467.4" y="20.0" dominant-baseline="central" font-size="12" fill="currentColor" opacity="0.75">15</text>
<text x="190" y="48.0" text-anchor="end" dominant-baseline="central" font-size="12.5" fill="currentColor">Functional</text>
<rect x="200.0" y="39.0" width="294.0" height="17" rx="2.5" fill="#b07d22"></rect>
<text x="502.0" y="48.0" dominant-baseline="central" font-size="12" fill="currentColor" opacity="0.75">17</text>
<text x="190" y="76.0" text-anchor="end" dominant-baseline="central" font-size="12.5" fill="currentColor">FunctionalJavascript</text>
<rect x="200.0" y="67.0" width="34.6" height="17" rx="2.5" fill="#a9663f"></rect>
<text x="242.6" y="76.0" dominant-baseline="central" font-size="12" fill="currentColor" opacity="0.75">2</text>
</svg>
</div>

| Test type | Classes | Methods |
|-----------|--------:|--------:|
| Kernel | 15 | 67 |
| Functional | 17 | 21 |
| FunctionalJavascript | 2 | 5 |
| **Total** | **34** | **93** |

## Architecture surface

What the module contains, counted across Domain Path and its submodules:
the Drupal building blocks (services, plugins, hooks, routes, entities) that make
up its public and internal API.

| Element | Count |
|---------|------:|
| Services | 16 |
| Event subscribers | 0 |
| Hook implementations | 10 |
| Routes | 1 |
| Permissions | 1 |
| Forms | 2 |
| Controllers | 0 |
| Content entity types | 0 |
| Config entity types | 0 |
| Config schema types | 1 |
| Plugins | 11 |

Plugins break down by type as follows, largest first:

<div style="margin:1.6rem 0">
<svg viewBox="0 0 560 60" width="100%" role="img" style="display:block;width:100%;height:auto;font-family:ui-monospace,SFMono-Regular,Menlo,monospace">
<text x="200" y="18.0" text-anchor="end" dominant-baseline="central" font-size="12.5" fill="currentColor">Validation</text>
<rect x="210.0" y="11.0" width="284.0" height="13" rx="2.5" fill="#b07d22"></rect>
<text x="502.0" y="18.0" dominant-baseline="central" font-size="12" fill="currentColor" opacity="0.75">8</text>
<text x="200" y="42.0" text-anchor="end" dominant-baseline="central" font-size="12.5" fill="currentColor">Field</text>
<rect x="210.0" y="35.0" width="106.5" height="13" rx="2.5" fill="#b07d22"></rect>
<text x="324.5" y="42.0" dominant-baseline="central" font-size="12" fill="currentColor" opacity="0.75">3</text>
</svg>
</div>

## Methodology

Counts are produced with [`cloc`](https://github.com/AlDanial/cloc) from the
module root, excluding `node_modules`:

```bash
cloc --exclude-dir=node_modules .
```

Production and test totals split on the test directory:

```bash
# production
cloc --exclude-dir=node_modules --not-match-d='(^|/)tests(/|$)' .
# test
cloc --exclude-dir=node_modules --match-d='(^|/)tests(/|$)' .
```

Test classes are counted by their directory under `tests/src` (`Unit`, `Kernel`,
`Functional`, `FunctionalJavascript`); the method column counts `test`-prefixed
methods plus those annotated `@test` or `#[Test]`. The architecture surface counts
service definitions in `*.services.yml`, route and permission keys in
`*.routing.yml` and `*.permissions.yml`, `#[Hook]` attributes, plugin classes
under `src/Plugin/`, forms and controllers under `src/Form` and `src/Controller`,
entity-type attributes in `src/Entity`, and top-level types in
`config/schema/*.yml`, all summed across the module and its submodules.

The charts are static inline SVG generated from the JSON that cloc emits, so
they need no JavaScript or charting plugin. This page is refreshed periodically.
