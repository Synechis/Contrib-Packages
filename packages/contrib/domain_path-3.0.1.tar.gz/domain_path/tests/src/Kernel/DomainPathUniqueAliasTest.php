<?php

namespace Drupal\Tests\domain_path\Kernel;

use Drupal\domain_path\Plugin\Validation\Constraint\DomainPathUniquePathAliasConstraint;
use PHPUnit\Framework\Attributes\Group;

/**
 * Tests domain-scoped path alias uniqueness validation.
 *
 * @group domain_path
 */
#[Group('domain_path')]
class DomainPathUniqueAliasTest extends DomainPathKernelTestBase {

  /**
   * Tests same alias on different domains does not conflict.
   */
  public function testSameAliasOnDifferentDomainsIsAllowed(): void {
    $this->createPathAlias('/node/1', '/about', 'en', $this->domainIds[0]);

    $alias = $this->pathAliasStorage()->create([
      'path' => '/node/2',
      'alias' => '/about',
      'langcode' => 'en',
      'domain_id' => $this->domainIds[1],
    ]);
    $violations = $this->filterViolations(
      $alias->validate(),
      DomainPathUniquePathAliasConstraint::class,
    );
    $this->assertCount(0, $violations, 'Same alias on a different domain should not conflict.');
  }

  /**
   * Tests same alias on the same domain conflicts.
   */
  public function testSameAliasOnSameDomainConflicts(): void {
    $this->createPathAlias('/node/1', '/about', 'en', $this->domainIds[0]);

    $alias = $this->pathAliasStorage()->create([
      'path' => '/node/2',
      'alias' => '/about',
      'langcode' => 'en',
      'domain_id' => $this->domainIds[0],
    ]);
    $violations = $this->filterViolations(
      $alias->validate(),
      DomainPathUniquePathAliasConstraint::class,
    );
    $this->assertCount(1, $violations);
    $this->assertStringContainsString('already in use in this domain', (string) $violations[0]->getMessage());
  }

  /**
   * Tests global alias does not conflict with domain-scoped alias.
   */
  public function testGlobalAliasDoesNotConflictWithDomainAlias(): void {
    $this->createPathAlias('/node/1', '/about', 'en', $this->domainIds[0]);

    $alias = $this->pathAliasStorage()->create([
      'path' => '/node/2',
      'alias' => '/about',
      'langcode' => 'en',
    ]);
    $violations = $this->filterViolations(
      $alias->validate(),
      DomainPathUniquePathAliasConstraint::class,
    );
    $this->assertCount(0, $violations, 'Global alias should not conflict with a domain-scoped alias.');
  }

  /**
   * Tests domain-scoped alias does not conflict with global alias.
   */
  public function testDomainAliasDoesNotConflictWithGlobalAlias(): void {
    $this->createPathAlias('/node/1', '/about');

    $alias = $this->pathAliasStorage()->create([
      'path' => '/node/2',
      'alias' => '/about',
      'langcode' => 'en',
      'domain_id' => $this->domainIds[0],
    ]);
    $violations = $this->filterViolations(
      $alias->validate(),
      DomainPathUniquePathAliasConstraint::class,
    );
    $this->assertCount(0, $violations, 'Domain-scoped alias should not conflict with a global alias.');
  }

  /**
   * Tests duplicate global aliases conflict.
   */
  public function testDuplicateGlobalAliasesConflict(): void {
    $this->createPathAlias('/node/1', '/about');

    $alias = $this->pathAliasStorage()->create([
      'path' => '/node/2',
      'alias' => '/about',
      'langcode' => 'en',
    ]);
    $violations = $this->filterViolations(
      $alias->validate(),
      DomainPathUniquePathAliasConstraint::class,
    );
    $this->assertCount(1, $violations);
    $this->assertStringContainsString('already in use', (string) $violations[0]->getMessage());
  }

  /**
   * Tests editing an existing alias does not conflict with itself.
   */
  public function testEditingExistingAliasDoesNotSelfConflict(): void {
    $alias = $this->createPathAlias('/node/1', '/about', 'en', $this->domainIds[0]);

    $violations = $this->filterViolations(
      $alias->validate(),
      DomainPathUniquePathAliasConstraint::class,
    );
    $this->assertCount(0, $violations, 'Editing an existing alias should not conflict with itself.');
  }

}
