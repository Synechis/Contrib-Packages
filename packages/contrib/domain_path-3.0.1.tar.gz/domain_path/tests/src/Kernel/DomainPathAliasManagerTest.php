<?php

namespace Drupal\Tests\domain_path\Kernel;

use Drupal\domain_path\DomainAliasManagerInterface;
use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;

/**
 * Tests DomainPathAliasManager domain-scoped resolution.
 *
 * @group domain_path
 *
 * @phpstan-ignore-next-line
 */
#[Group('domain_path')]
#[RunTestsInSeparateProcesses]
class DomainPathAliasManagerTest extends DomainPathKernelTestBase {

  /**
   * The domain alias manager.
   *
   * @var \Drupal\domain_path\DomainAliasManagerInterface
   */
  protected DomainAliasManagerInterface $aliasManager;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->aliasManager = \Drupal::service('path_alias.manager');
  }

  /**
   * Tests getAliasByPathAndDomain resolves correctly.
   */
  public function testGetAliasByPathAndDomain(): void {
    $domain_a = $this->domainIds[0];

    $this->createPathAlias('/node/1', '/about', 'en', $domain_a);

    $alias = $this->aliasManager
      ->getAliasByPathAndDomain('/node/1', $domain_a, 'en');
    $this->assertEquals('/about', $alias);
  }

  /**
   * Tests getPathByAliasAndDomain resolves correctly.
   */
  public function testGetPathByAliasAndDomain(): void {
    $domain_a = $this->domainIds[0];

    $this->createPathAlias('/node/1', '/about', 'en', $domain_a);

    $path = $this->aliasManager
      ->getPathByAliasAndDomain('/about', $domain_a, 'en');
    $this->assertEquals('/node/1', $path);
  }

  /**
   * Tests domain alias does not leak across domains.
   */
  public function testDomainAliasDoesNotLeakAcrossDomains(): void {
    $domain_a = $this->domainIds[0];
    $domain_b = $this->domainIds[1];

    $this->createPathAlias('/node/1', '/about', 'en', $domain_a);

    // Lookup on domain B should not find the alias.
    $alias = $this->aliasManager
      ->getAliasByPathAndDomain('/node/1', $domain_b, 'en');
    $this->assertEquals('/node/1', $alias);
  }

  /**
   * Tests fallback to global alias when no domain alias exists.
   */
  public function testFallbackToGlobalAlias(): void {
    $domain_a = $this->domainIds[0];

    // Create a global alias (no domain).
    $this->createPathAlias('/node/1', '/global-about', 'en', NULL);

    // Reverse lookup falls back to global via core inner
    // manager. getPathByAlias does not depend on the alias
    // allowlist, so it works reliably in kernel tests.
    $path = $this->aliasManager
      ->getPathByAliasAndDomain('/global-about', $domain_a, 'en');
    $this->assertEquals('/node/1', $path);
  }

  /**
   * Tests domain alias takes priority over global alias.
   */
  public function testDomainAliasPriorityOverGlobal(): void {
    $domain_a = $this->domainIds[0];

    $this->createPathAlias('/node/1', '/global-about', 'en', NULL);
    $this->createPathAlias('/node/1', '/domain-about', 'en', $domain_a);

    $alias = $this->aliasManager
      ->getAliasByPathAndDomain('/node/1', $domain_a, 'en');
    $this->assertEquals('/domain-about', $alias);
  }

  /**
   * Tests cache clear invalidates lookups.
   */
  public function testCacheClearInvalidatesLookup(): void {
    $domain_a = $this->domainIds[0];

    $entity = $this->createPathAlias(
      '/node/1', '/cached-alias', 'en', $domain_a
    );

    // First lookup populates internal static cache.
    $alias = $this->aliasManager
      ->getAliasByPathAndDomain('/node/1', $domain_a, 'en');
    $this->assertEquals('/cached-alias', $alias);

    // Delete the alias entity and clear cache.
    $entity->delete();
    $this->aliasManager->cacheClear();

    // Fresh lookup returns the path (no alias found).
    $alias = $this->aliasManager
      ->getAliasByPathAndDomain('/node/1', $domain_a, 'en');
    $this->assertEquals('/node/1', $alias);
  }

  /**
   * Tests getPathByAlias returns domain path via core's AliasManager.
   *
   * The reverse of testGetAliasByPathAndDomain: when the
   * active domain has a domain-specific alias, getPathByAlias()
   * should resolve that alias to the system path.
   */
  public function testGetPathByAliasReturnsDomainPath(): void {
    $domain_a = $this->domainIds[0];

    $this->createPathAlias('/node/1', '/global-about', 'en', NULL);
    $this->createPathAlias('/node/1', '/domain-about', 'en', $domain_a);

    // Set the active domain.
    $domain_entity = $this->container->get('entity_type.manager')
      ->getStorage('domain')
      ->load($domain_a);
    $this->container->get('domain.negotiation_context')
      ->setDomain($domain_entity);

    // Clear alias manager static caches.
    $this->aliasManager->cacheClear();

    // getPathByAlias() should resolve the domain alias.
    $path = $this->aliasManager->getPathByAlias('/domain-about', 'en');
    $this->assertEquals('/node/1', $path);
  }

}
