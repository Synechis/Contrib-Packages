<?php

namespace Drupal\Tests\domain_path\Kernel;

use Drupal\domain_path\Plugin\Validation\Constraint\DomainPathUserAccessConstraint;
use Drupal\node\Entity\Node;
use Drupal\node\Entity\NodeType;
use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;

/**
 * Tests domain_path behavior without domain_access module.
 *
 * When domain_access is not installed, all users should be
 * able to set aliases on any domain without restriction.
 *
 * @group domain_path
 *
 * @phpstan-ignore-next-line
 */
#[Group('domain_path')]
#[RunTestsInSeparateProcesses]
class DomainPathNoDomainAccessTest extends DomainPathKernelTestBase {

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'domain',
    'domain_path',
    'field',
    'node',
    'path',
    'path_alias',
    'system',
    'text',
    'user',
  ];

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->installEntitySchema('node');
    $this->installSchema('node', ['node_access']);

    NodeType::create([
      'type' => 'article',
      'name' => 'Article',
    ])->save();
  }

  /**
   * Tests non-admin user passes access constraint.
   *
   * Without domain_access, userCanAccessDomain() returns TRUE
   * for all users, so the access constraint should not trigger.
   */
  public function testNonAdminPassesAccessConstraint(): void {
    $regular_user = $this->createUser(['create url aliases']);
    $regular_user->save();
    \Drupal::currentUser()->setAccount($regular_user);

    $node = Node::create([
      'type' => 'article',
      'title' => 'Test',
    ]);
    $items = $node->get('domain_path');

    // Set alias on any domain — should be allowed.
    foreach ($items as $item) {
      if ($item->get('domain_id')->getValue() === $this->domainIds[0]) {
        $item->set('alias', '/accessible');
        break;
      }
    }

    $violations = $this->filterViolations(
      $node->validate(),
      DomainPathUserAccessConstraint::class,
    );
    $this->assertCount(0, $violations);
  }

  /**
   * Tests non-admin user can save an alias without domain_access.
   */
  public function testNonAdminCanSaveAlias(): void {
    $regular_user = $this->createUser(['create url aliases']);
    $regular_user->save();
    \Drupal::currentUser()->setAccount($regular_user);

    $node = Node::create([
      'type' => 'article',
      'title' => 'Test',
    ]);
    $items = $node->get('domain_path');
    foreach ($items as $item) {
      if ($item->get('domain_id')->getValue() === $this->domainIds[0]) {
        $item->set('alias', '/my-alias');
        break;
      }
    }
    $node->save();

    $aliases = $this->pathAliasStorage()->loadByProperties([
      'path' => '/node/' . $node->id(),
      'domain_id' => $this->domainIds[0],
    ]);
    $this->assertCount(1, $aliases);
    $this->assertEquals('/my-alias', reset($aliases)->getAlias());
  }

  /**
   * Tests non-admin can set aliases on multiple domains.
   *
   * Without domain_access, there are no per-domain restrictions.
   */
  public function testNonAdminCanSetAliasesOnAllDomains(): void {
    $regular_user = $this->createUser(['create url aliases']);
    $regular_user->save();
    \Drupal::currentUser()->setAccount($regular_user);

    $node = Node::create([
      'type' => 'article',
      'title' => 'Test',
    ]);
    $items = $node->get('domain_path');

    // Set aliases on all available domains.
    foreach ($items as $item) {
      $domain_id = $item->get('domain_id')->getValue();
      $item->set('alias', '/alias-' . $domain_id);
    }

    $violations = $this->filterViolations(
      $node->validate(),
      DomainPathUserAccessConstraint::class,
    );
    $this->assertCount(0, $violations);
  }

}
