<?php

namespace Drupal\Tests\domain_path\Kernel;

use Drupal\domain_path\DomainAliasRepositoryInterface;
use Drupal\domain_path\Plugin\Validation\Constraint\DomainPathSlashConstraint;
use Drupal\domain_path\Plugin\Validation\Constraint\DomainPathUniqueConstraint;
use Drupal\domain_path\Plugin\Validation\Constraint\DomainPathUserAccessConstraint;
use Drupal\field\Entity\FieldConfig;
use Drupal\node\Entity\Node;
use Drupal\node\Entity\NodeType;
use PHPUnit\Framework\Attributes\Group;

/**
 * Tests DomainPathItem field-level validation constraints.
 *
 * @group domain_path
 */
#[Group('domain_path')]
class DomainPathFieldConstraintsTest extends DomainPathKernelTestBase {

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'domain',
    'domain_access',
    'domain_path',
    'field',
    'node',
    'path',
    'path_alias',
    'system',
    'text',
    'user',
  ];

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->installEntitySchema('node');
    $this->installSchema('node', ['node_access']);

    NodeType::create([
      'type' => 'article',
      'name' => 'Article',
    ])->save();
  }

  /**
   * Creates an unsaved test node.
   *
   * @return \Drupal\node\NodeInterface
   *   The created node entity (unsaved).
   */
  protected function createTestNode() {
    return Node::create([
      'type' => 'article',
      'title' => 'Test node',
    ]);
  }

  /**
   * Tests alias without leading slash triggers violation.
   */
  public function testSlashConstraintRejectsAliasWithoutSlash(): void {
    $node = $this->createTestNode();

    // Trigger field computation.
    $items = $node->get('domain_path');
    $this->assertGreaterThan(0, $items->count());

    // Set alias without leading slash on first item.
    $items->get(0)->set('alias', 'no-leading-slash');

    $violations = $this->filterViolations(
      $node->validate(),
      DomainPathSlashConstraint::class,
    );
    $this->assertCount(1, $violations);
    $this->assertStringContainsString(
      'needs to start with a slash',
      (string) $violations[0]->getMessage(),
    );
  }

  /**
   * Tests alias with leading slash passes validation.
   */
  public function testSlashConstraintAllowsAliasWithSlash(): void {
    $node = $this->createTestNode();
    $items = $node->get('domain_path');
    $items->get(0)->set('alias', '/valid-alias');

    $violations = $this->filterViolations(
      $node->validate(),
      DomainPathSlashConstraint::class,
    );
    $this->assertCount(0, $violations);
  }

  /**
   * Tests empty alias passes validation.
   */
  public function testSlashConstraintAllowsEmptyAlias(): void {
    $node = $this->createTestNode();

    // Don't set any alias — computed field items have empty alias by default.
    $violations = $this->filterViolations(
      $node->validate(),
      DomainPathSlashConstraint::class,
    );
    $this->assertCount(0, $violations);
  }

  /**
   * Tests duplicate alias on same domain triggers unique violation.
   */
  public function testUniqueConstraintRejectsDuplicateAlias(): void {
    // Create an existing path alias for domain A.
    $this->createPathAlias('/node/999', '/existing-alias', 'en', $this->domainIds[0]);

    // Create a new node and set the same alias for the same domain.
    $node = $this->createTestNode();
    $items = $node->get('domain_path');

    // Find the item for domain A and set the duplicate alias.
    foreach ($items as $item) {
      if ($item->get('domain_id')->getValue() === $this->domainIds[0]) {
        $item->set('alias', '/existing-alias');
        break;
      }
    }

    $violations = $this->filterViolations(
      $node->validate(),
      DomainPathUniqueConstraint::class,
    );
    $this->assertCount(1, $violations);
    $this->assertStringContainsString(
      'matches an existing domain path alias',
      (string) $violations[0]->getMessage(),
    );
  }

  /**
   * Tests new alias passes unique validation.
   */
  public function testUniqueConstraintAllowsNewAlias(): void {
    $node = $this->createTestNode();
    $items = $node->get('domain_path');
    $items->get(0)->set('alias', '/brand-new-alias');

    $violations = $this->filterViolations(
      $node->validate(),
      DomainPathUniqueConstraint::class,
    );
    $this->assertCount(0, $violations);
  }

  /**
   * Tests an item with a domain but no alias does not query the repository.
   *
   * Regression test: validating a domain path item that has a domain assigned
   * but an empty alias used to run the uniqueness lookup, which passed NULL to
   * the database escape function ("addcslashes(): Passing null to parameter #1
   * ($string) of type string is deprecated"). The validator must skip the
   * lookup entirely when there is no alias.
   *
   * @see https://www.drupal.org/project/domain_path/issues/3611433
   */
  public function testUniqueConstraintDoesNotQueryRepositoryForEmptyAlias(): void {
    // The uniqueness validator must not consult the repository when the alias
    // is empty; forbid the lookup so a regression that re-introduces it fails
    // here rather than only emitting a deprecation.
    $repository = $this->createMock(DomainAliasRepositoryInterface::class);
    $repository->expects($this->never())->method('lookupByAliasAndDomain');
    $this->container->set('domain_path.repository', $repository);

    // A freshly created node has one domain path item per domain, each with a
    // domain assigned but an empty alias.
    $node = $this->createTestNode();
    $violations = $this->filterViolations(
      $node->validate(),
      DomainPathUniqueConstraint::class,
    );
    $this->assertCount(0, $violations);
  }

  /**
   * Tests user without domain access triggers violation.
   */
  public function testUserAccessConstraintRejectsUnauthorizedUser(): void {
    // Create a regular user without domain access permissions.
    // Without 'publish to any domain' and without domain access
    // fields, userCanAccessDomain() returns FALSE for all domains.
    $regular_user = $this->createUser([
      'create url aliases',
    ]);
    $regular_user->save();
    \Drupal::currentUser()->setAccount($regular_user);

    $node = $this->createTestNode();
    $items = $node->get('domain_path');

    $items->appendItem([
      'alias' => '/unauthorized',
      'domain_id' => $this->domainIds[1],
      'langcode' => 'en',
    ]);

    $violations = $this->filterViolations(
      $node->validate(),
      DomainPathUserAccessConstraint::class,
    );
    $this->assertGreaterThan(0, count($violations));
    $this->assertStringContainsString(
      "don't have access",
      (string) $violations[0]->getMessage(),
    );
  }

  /**
   * Tests user with domain access passes validation.
   */
  public function testUserAccessConstraintAllowsAuthorizedUser(): void {
    // Uid 1 has access to all domains — set alias on any domain.
    $node = $this->createTestNode();
    $items = $node->get('domain_path');
    $items->get(0)->set('alias', '/accessible');

    $violations = $this->filterViolations(
      $node->validate(),
      DomainPathUserAccessConstraint::class,
    );
    $this->assertCount(0, $violations);
  }

  /**
   * Tests domain-scoped access with domain_access fields.
   *
   * When domain_access fields are installed on users, the
   * constraint uses field values to determine access: a user
   * assigned to domain A can set aliases for A but not for B.
   */
  public function testUserAccessWithDomainAccessFields(): void {
    // Install domain_access config (field storages for users).
    $this->installConfig(['domain_access']);

    // Create field instances on the user bundle.
    FieldConfig::create([
      'field_name' => 'field_domain_access',
      'entity_type' => 'user',
      'bundle' => 'user',
      'label' => 'Domain Access',
    ])->save();
    FieldConfig::create([
      'field_name' => 'field_domain_all_affiliates',
      'entity_type' => 'user',
      'bundle' => 'user',
      'label' => 'All affiliates',
    ])->save();

    // Create a user assigned to domain A only.
    $user = $this->createUser(['create url aliases']);
    $user->set('field_domain_access', [$this->domainIds[0]]);
    $user->set('field_domain_all_affiliates', FALSE);
    $user->save();
    \Drupal::currentUser()->setAccount($user);

    $node = $this->createTestNode();
    $items = $node->get('domain_path');

    // Setting an alias for domain A (assigned) should pass.
    foreach ($items as $item) {
      if ($item->get('domain_id')->getValue() === $this->domainIds[0]) {
        $item->set('alias', '/allowed');
        break;
      }
    }
    $violations = $this->filterViolations(
      $node->validate(),
      DomainPathUserAccessConstraint::class,
    );
    $this->assertCount(0, $violations);

    // Adding an alias for domain B (not assigned) should fail.
    $items->appendItem([
      'alias' => '/not-allowed',
      'domain_id' => $this->domainIds[1],
      'langcode' => 'en',
    ]);
    $violations = $this->filterViolations(
      $node->validate(),
      DomainPathUserAccessConstraint::class,
    );
    $this->assertCount(1, $violations);
    $this->assertStringContainsString(
      "don't have access",
      (string) $violations[0]->getMessage(),
    );
  }

  /**
   * Tests that an alias on domain A does not conflict with domain B.
   *
   * Creates a path alias on domain A, then validates a node with the
   * same alias on domain B. The unique constraint should not trigger
   * because uniquification is scoped per domain.
   */
  public function testUniqueConstraintAllowsSameAliasOnDifferentDomain(): void {
    // Create an existing path alias for domain A AND a core alias
    // (without domain). Pathauto generates both when auto-generating
    // aliases. The core alias is what triggers the false duplicate in
    // the old code, because the validator falls back to core's
    // getPathByAlias() which finds it regardless of domain.
    $this->createPathAlias('/node/999', '/shared-alias', 'en', $this->domainIds[0]);
    $this->createPathAlias('/node/999', '/shared-alias', 'en');

    // Create a new node and set the same alias for domain B.
    $node = $this->createTestNode();
    $items = $node->get('domain_path');

    foreach ($items as $item) {
      if ($item->get('domain_id')->getValue() === $this->domainIds[1]) {
        $item->set('alias', '/shared-alias');
        break;
      }
    }

    $violations = $this->filterViolations(
      $node->validate(),
      DomainPathUniqueConstraint::class,
    );
    $this->assertCount(0, $violations,
      'Same alias on a different domain should not trigger unique violation.');
  }

  /**
   * Tests that a duplicate alias on the same domain still triggers violation.
   *
   * Ensures the per-domain scoping did not break same-domain duplicate
   * detection.
   */
  public function testUniqueConstraintRejectsDuplicateOnSameDomain(): void {
    // Create an existing path alias for domain B.
    $this->createPathAlias('/node/999', '/taken-alias', 'en', $this->domainIds[1]);

    // Create a new node and set the same alias for the same domain B.
    $node = $this->createTestNode();
    $items = $node->get('domain_path');

    foreach ($items as $item) {
      if ($item->get('domain_id')->getValue() === $this->domainIds[1]) {
        $item->set('alias', '/taken-alias');
        break;
      }
    }

    $violations = $this->filterViolations(
      $node->validate(),
      DomainPathUniqueConstraint::class,
    );
    $this->assertCount(1, $violations,
      'Same alias on the same domain should still trigger unique violation.');
  }

}
