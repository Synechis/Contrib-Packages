<?php

namespace Drupal\Tests\domain_path\Kernel;

use Drupal\domain\Entity\Domain;
use Drupal\domain_path\HttpKernel\DomainPathAliasProcessor;
use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;

/**
 * Tests DomainPathAliasProcessor::processOutbound().
 *
 * @group domain_path
 *
 * @phpstan-ignore-next-line
 */
#[Group('domain_path')]
#[RunTestsInSeparateProcesses]
class DomainPathAliasProcessorTest extends DomainPathKernelTestBase {

  /**
   * The processor under test.
   *
   * @var \Drupal\domain_path\HttpKernel\DomainPathAliasProcessor
   */
  protected DomainPathAliasProcessor $processor;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->processor = \Drupal::service('domain_path.path_processor');
  }

  /**
   * Tests domain option resolves to domain-specific alias.
   */
  public function testDomainOptionResolvesAlias(): void {
    $domain_a = $this->domainIds[0];

    $this->createPathAlias('/node/1', '/about', 'en', $domain_a);

    $options = ['domain' => Domain::load($domain_a)];
    $result = $this->processor->processOutbound(
      '/node/1', $options
    );

    $this->assertEquals('/about', $result);
    $this->assertTrue($options['alias']);
  }

  /**
   * Tests fallback when no domain alias exists.
   */
  public function testNoDomainAliasFallsBackToPath(): void {
    $domain_a = $this->domainIds[0];

    // No alias created for this path.
    $options = ['domain' => Domain::load($domain_a)];
    $result = $this->processor->processOutbound(
      '/node/99', $options
    );

    $this->assertEquals('/node/99', $result);
    $this->assertTrue($options['alias']);
  }

  /**
   * Tests non-canonical path is not aliased.
   *
   * The edit path /node/1/edit has no alias, so the processor
   * returns it unchanged.
   */
  public function testNonCanonicalPathNotAliased(): void {
    $domain_a = $this->domainIds[0];

    // Alias exists for /node/1 but NOT for /node/1/edit.
    $this->createPathAlias('/node/1', '/about', 'en', $domain_a);

    $options = ['domain' => Domain::load($domain_a)];
    $result = $this->processor->processOutbound(
      '/node/1/edit', $options
    );

    $this->assertEquals('/node/1/edit', $result);
    $this->assertTrue($options['alias']);
  }

  /**
   * Tests skipping when no domain option is set.
   */
  public function testSkipsWithoutDomainOption(): void {
    $this->createPathAlias('/node/1', '/about', 'en', $this->domainIds[0]);

    $options = [];
    $result = $this->processor->processOutbound(
      '/node/1', $options
    );

    $this->assertEquals('/node/1', $result);
    $this->assertArrayNotHasKey('alias', $options);
  }

  /**
   * Tests skipping when domain option is not a DomainInterface.
   */
  public function testSkipsNonDomainInterface(): void {
    $this->createPathAlias('/node/1', '/about', 'en', $this->domainIds[0]);

    $options = ['domain' => 'not_a_domain_object'];
    $result = $this->processor->processOutbound(
      '/node/1', $options
    );

    $this->assertEquals('/node/1', $result);
    $this->assertArrayNotHasKey('alias', $options);
  }

  /**
   * Tests skipping external URLs.
   */
  public function testSkipsExternalUrls(): void {
    $domain_a = $this->domainIds[0];

    $this->createPathAlias('/node/1', '/about', 'en', $domain_a);

    $options = [
      'external' => TRUE,
      'domain' => Domain::load($domain_a),
    ];
    $result = $this->processor->processOutbound(
      '/node/1', $options
    );

    $this->assertEquals('/node/1', $result);
    $this->assertArrayNotHasKey('alias', $options);
  }

  /**
   * Tests domain alias takes priority over global alias.
   */
  public function testDomainAliasPriorityOverGlobal(): void {
    $domain_a = $this->domainIds[0];

    $this->createPathAlias('/node/1', '/global-about', 'en', NULL);
    $this->createPathAlias('/node/1', '/domain-about', 'en', $domain_a);

    $options = ['domain' => Domain::load($domain_a)];
    $result = $this->processor->processOutbound(
      '/node/1', $options
    );

    $this->assertEquals('/domain-about', $result);
  }

  /**
   * Tests alias isolation across domains.
   */
  public function testAliasDoesNotLeakAcrossDomains(): void {
    $domain_a = $this->domainIds[0];
    $domain_b = $this->domainIds[1];

    $this->createPathAlias('/node/1', '/about-a', 'en', $domain_a);

    $options = ['domain' => Domain::load($domain_b)];
    $result = $this->processor->processOutbound(
      '/node/1', $options
    );

    // Domain B has no alias, so path is returned unchanged.
    $this->assertEquals('/node/1', $result);
  }

}
