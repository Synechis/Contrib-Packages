<?php

namespace Drupal\Tests\domain_path\Kernel;

use Drupal\Core\Entity\EntityStorageInterface;
use Drupal\KernelTests\KernelTestBase;
use Drupal\Tests\domain\Traits\DomainTestTrait;
use Drupal\Tests\user\Traits\UserCreationTrait;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;
use Symfony\Component\Validator\ConstraintViolationListInterface;

/**
 * Base class for domain_path Kernel tests.
 *
 * @phpstan-ignore-next-line
 */
#[RunTestsInSeparateProcesses]
abstract class DomainPathKernelTestBase extends KernelTestBase {

  use DomainTestTrait;
  use UserCreationTrait;

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'domain',
    'domain_path',
    'path_alias',
    'system',
    'user',
  ];

  /**
   * The test domain IDs.
   *
   * @var string[]
   */
  protected array $domainIds;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->installEntitySchema('path_alias');
    $this->installEntitySchema('user');
    $this->installConfig(['domain_path']);

    $this->setUpCurrentUser(['uid' => 1]);

    $this->domainCreateTestDomains(2);
    $this->domainIds = array_keys($this->getDomains());
  }

  /**
   * Returns the path alias storage.
   *
   * @return \Drupal\Core\Entity\EntityStorageInterface
   *   The path alias entity storage.
   */
  protected function pathAliasStorage(): EntityStorageInterface {
    return $this->container->get('entity_type.manager')
      ->getStorage('path_alias');
  }

  /**
   * Filters violations by constraint class.
   *
   * @param \Symfony\Component\Validator\ConstraintViolationListInterface $violations
   *   The full violation list.
   * @param string $constraint_class
   *   The constraint class to filter by.
   *
   * @return \Symfony\Component\Validator\ConstraintViolationInterface[]
   *   Filtered violations.
   */
  protected function filterViolations(ConstraintViolationListInterface $violations, string $constraint_class): array {
    $filtered = [];
    foreach ($violations as $violation) {
      if ($violation->getConstraint() instanceof $constraint_class) {
        $filtered[] = $violation;
      }
    }
    return $filtered;
  }

  /**
   * Creates a path alias entity.
   *
   * @param string $path
   *   The source path.
   * @param string $alias
   *   The alias.
   * @param string $langcode
   *   The language code. Defaults to 'en'.
   * @param string|null $domain_id
   *   The domain ID, or NULL for a global alias.
   *
   * @return \Drupal\domain_path\DomainPathAliasInterface
   *   The saved path alias entity.
   */
  protected function createPathAlias(string $path, string $alias, string $langcode = 'en', ?string $domain_id = NULL) {
    $values = [
      'path' => $path,
      'alias' => $alias,
      'langcode' => $langcode,
    ];
    if ($domain_id !== NULL) {
      $values['domain_id'] = $domain_id;
    }
    $entity = $this->pathAliasStorage()->create($values);
    $entity->save();
    return $entity;
  }

}
