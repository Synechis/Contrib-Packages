<?php

namespace Drupal\Tests\domain_path\Kernel;

use Drupal\node\Entity\NodeType;
use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;

/**
 * Tests domain_path.settings configuration effects.
 *
 * @group domain_path
 *
 * @phpstan-ignore-next-line
 */
#[Group('domain_path')]
#[RunTestsInSeparateProcesses]
class DomainPathConfigTest extends DomainPathKernelTestBase {

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'domain',
    'domain_path',
    'field',
    'node',
    'path',
    'path_alias',
    'system',
    'text',
    'user',
  ];

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->installEntitySchema('node');
    $this->installSchema('node', ['node_access']);

    NodeType::create([
      'type' => 'article',
      'name' => 'Article',
    ])->save();
  }

  /**
   * Tests entity_types config controls field presence.
   */
  public function testEntityTypeConfigControlsFieldPresence(): void {
    $field_manager = \Drupal::service('entity_field.manager');

    // Default config has 'node' enabled.
    $definitions = $field_manager->getFieldDefinitions(
      'node', 'article'
    );
    $this->assertArrayHasKey('domain_path', $definitions);

    // Remove node from entity_types.
    \Drupal::configFactory()
      ->getEditable('domain_path.settings')
      ->set('entity_types', [])
      ->save();

    $definitions = $field_manager->getFieldDefinitions(
      'node', 'article'
    );
    $this->assertArrayNotHasKey('domain_path', $definitions);
  }

  /**
   * Tests adding an entity type enables the field.
   */
  public function testAddingEntityTypeEnablesField(): void {
    $field_manager = \Drupal::service('entity_field.manager');

    // Start with no entity types.
    \Drupal::configFactory()
      ->getEditable('domain_path.settings')
      ->set('entity_types', [])
      ->save();

    $definitions = $field_manager->getFieldDefinitions(
      'node', 'article'
    );
    $this->assertArrayNotHasKey('domain_path', $definitions);

    // Add node back.
    \Drupal::configFactory()
      ->getEditable('domain_path.settings')
      ->set('entity_types', ['node'])
      ->save();

    $definitions = $field_manager->getFieldDefinitions(
      'node', 'article'
    );
    $this->assertArrayHasKey('domain_path', $definitions);
  }

  /**
   * Tests alias_title and language_method config values.
   */
  public function testConfigValues(): void {
    $config = \Drupal::config('domain_path.settings');

    // Verify defaults.
    $this->assertEquals('name', $config->get('alias_title'));
    $this->assertEquals(
      'language_content', $config->get('language_method')
    );

    // Update values.
    \Drupal::configFactory()
      ->getEditable('domain_path.settings')
      ->set('alias_title', 'hostname')
      ->set('language_method', 'language_url')
      ->save();

    // Re-read config.
    $config = \Drupal::config('domain_path.settings');
    $this->assertEquals('hostname', $config->get('alias_title'));
    $this->assertEquals(
      'language_url', $config->get('language_method')
    );
  }

}
