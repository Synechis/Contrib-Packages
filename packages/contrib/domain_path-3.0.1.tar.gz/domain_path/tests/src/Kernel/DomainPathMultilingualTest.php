<?php

namespace Drupal\Tests\domain_path\Kernel;

use Drupal\domain_path\DomainAliasManagerInterface;
use Drupal\language\Entity\ConfigurableLanguage;
use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;

/**
 * Tests multilingual domain-scoped alias resolution.
 *
 * @group domain_path
 *
 * @phpstan-ignore-next-line
 */
#[Group('domain_path')]
#[RunTestsInSeparateProcesses]
class DomainPathMultilingualTest extends DomainPathKernelTestBase {

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'domain',
    'domain_path',
    'language',
    'path_alias',
    'system',
    'user',
  ];

  /**
   * The domain alias manager.
   *
   * @var \Drupal\domain_path\DomainAliasManagerInterface
   */
  protected DomainAliasManagerInterface $aliasManager;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->installConfig(['language']);
    ConfigurableLanguage::createFromLangcode('de')->save();

    $this->aliasManager = \Drupal::service('path_alias.manager');
  }

  /**
   * Tests domain alias resolution per language.
   */
  public function testDomainAliasResolutionPerLanguage(): void {
    $domain_a = $this->domainIds[0];

    // English alias.
    $this->createPathAlias('/node/1', '/about', 'en', $domain_a);

    // German alias via direct storage creation.
    $this->pathAliasStorage()->create([
      'path' => '/node/1',
      'alias' => '/ueber-uns',
      'langcode' => 'de',
      'domain_id' => $domain_a,
    ])->save();

    $en_alias = $this->aliasManager
      ->getAliasByPathAndDomain('/node/1', $domain_a, 'en');
    $this->assertEquals('/about', $en_alias);

    $de_alias = $this->aliasManager
      ->getAliasByPathAndDomain('/node/1', $domain_a, 'de');
    $this->assertEquals('/ueber-uns', $de_alias);
  }

  /**
   * Tests same alias allowed across languages.
   */
  public function testSameAliasAllowedAcrossLanguages(): void {
    $domain_a = $this->domainIds[0];

    // /about in English for node/1.
    $this->createPathAlias('/node/1', '/about', 'en', $domain_a);

    // /about in German for node/2 — no conflict.
    $this->pathAliasStorage()->create([
      'path' => '/node/2',
      'alias' => '/about',
      'langcode' => 'de',
      'domain_id' => $domain_a,
    ])->save();

    $en_path = $this->aliasManager
      ->getPathByAliasAndDomain('/about', $domain_a, 'en');
    $this->assertEquals('/node/1', $en_path);

    $de_path = $this->aliasManager
      ->getPathByAliasAndDomain('/about', $domain_a, 'de');
    $this->assertEquals('/node/2', $de_path);
  }

  /**
   * Tests language-neutral alias fallback.
   */
  public function testLanguageNotSpecifiedFallback(): void {
    $domain_a = $this->domainIds[0];

    // Create alias with language 'und' (not specified).
    $this->pathAliasStorage()->create([
      'path' => '/node/1',
      'alias' => '/universal',
      'langcode' => 'und',
      'domain_id' => $domain_a,
    ])->save();

    // Lookup with 'en' should find it via language fallback.
    $alias = $this->aliasManager
      ->getAliasByPathAndDomain('/node/1', $domain_a, 'en');
    $this->assertEquals('/universal', $alias);

    // Clear cache and lookup with 'de'.
    $this->aliasManager->cacheClear();
    $alias = $this->aliasManager
      ->getAliasByPathAndDomain('/node/1', $domain_a, 'de');
    $this->assertEquals('/universal', $alias);
  }

}
