<?php

namespace Drupal\Tests\domain_path\Kernel;

use Drupal\domain\Entity\Domain;
use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;

/**
 * Tests domain deletion cascade for domain path aliases.
 *
 * @group domain_path
 *
 * @phpstan-ignore-next-line
 */
#[Group('domain_path')]
#[RunTestsInSeparateProcesses]
class DomainPathDomainDeleteTest extends DomainPathKernelTestBase {

  /**
   * Tests deleting a domain removes its path aliases.
   */
  public function testDomainDeleteRemovesAssociatedAliases(): void {
    $domain_a = $this->domainIds[0];

    $this->createPathAlias('/node/1', '/alias-one', 'en', $domain_a);
    $this->createPathAlias('/node/2', '/alias-two', 'en', $domain_a);

    // Verify aliases exist.
    $aliases = $this->pathAliasStorage()
      ->loadByProperties(['domain_id' => $domain_a]);
    $this->assertCount(2, $aliases);

    // Delete domain A.
    Domain::load($domain_a)->delete();

    // Verify aliases are gone.
    $aliases = $this->pathAliasStorage()
      ->loadByProperties(['domain_id' => $domain_a]);
    $this->assertCount(0, $aliases);
  }

  /**
   * Tests deleting a domain preserves other domain aliases.
   */
  public function testDomainDeletePreservesOtherDomainAliases(): void {
    $domain_a = $this->domainIds[0];
    $domain_b = $this->domainIds[1];

    $this->createPathAlias('/node/1', '/alias-a', 'en', $domain_a);
    $this->createPathAlias('/node/2', '/alias-b', 'en', $domain_b);

    Domain::load($domain_a)->delete();

    // Domain B aliases survive.
    $aliases = $this->pathAliasStorage()
      ->loadByProperties(['domain_id' => $domain_b]);
    $this->assertCount(1, $aliases);
    $alias = reset($aliases);
    $this->assertEquals('/alias-b', $alias->getAlias());
  }

  /**
   * Tests deleting a domain preserves global aliases.
   */
  public function testDomainDeletePreservesGlobalAliases(): void {
    $domain_a = $this->domainIds[0];

    $this->createPathAlias('/node/1', '/global-alias', 'en', NULL);
    $this->createPathAlias('/node/2', '/domain-alias', 'en', $domain_a);

    Domain::load($domain_a)->delete();

    // Global alias survives (domain_id is NULL).
    $all_aliases = $this->pathAliasStorage()->loadMultiple();
    $this->assertCount(1, $all_aliases);
    $alias = reset($all_aliases);
    $this->assertEquals('/global-alias', $alias->getAlias());
  }

  /**
   * Tests deleting a domain with no aliases does not fail.
   */
  public function testDomainDeleteWithNoAliasesDoesNotFail(): void {
    $domain_a = $this->domainIds[0];

    // No aliases created — just delete the domain.
    Domain::load($domain_a)->delete();

    // No exception thrown, domain is gone.
    $this->assertNull(Domain::load($domain_a));
  }

}
