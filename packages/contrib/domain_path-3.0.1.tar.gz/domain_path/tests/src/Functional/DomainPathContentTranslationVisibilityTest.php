<?php

namespace Drupal\Tests\domain_path\Functional;

use Drupal\node\Entity\Node;
use Drupal\Tests\content_translation\Traits\ContentTranslationTestTrait;
use PHPUnit\Framework\Attributes\Group;
// @phpstan-ignore-next-line
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;

/**
 * Domain path visibility on content_translation translation forms.
 *
 * Two scenarios are covered:
 *
 *   - the domain access fields are non-translatable and the bundle
 *     has `untranslatable_fields_hide` enabled, so on a translation
 *     form `field_domain_access` is removed from the DOM and the JS
 *     States API cannot drive the path widgets' visibility — domain
 *     path must decide visibility server-side from the entity's
 *     stored values;
 *   - the domain access fields are translatable, so even with
 *     `untranslatable_fields_hide` enabled `field_domain_access` is
 *     present on the translation form — the existing JS States
 *     logic must keep working untouched.
 *
 * @see https://www.drupal.org/i/3588247
 *
 * @group domain_path
 *
 * @phpstan-ignore-next-line
 */
#[Group('domain_path')]
#[RunTestsInSeparateProcesses]
class DomainPathContentTranslationVisibilityTest extends DomainPathTestBase {

  use ContentTranslationTestTrait;

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'content_translation',
    'language',
  ];

  /**
   * {@inheritdoc}
   */
  protected function getAdminPermissions() {
    $permissions = parent::getAdminPermissions();
    $permissions[] = 'translate any entity';
    $permissions[] = 'create content translations';
    return $permissions;
  }

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    static::createLanguageFromLangcode('de');

    // Enable content translation on node:test_page and request that
    // untranslatable fields be hidden on translation forms — that is
    // the bundle setting that exposes the bug. Each test method then
    // configures the domain access fields' translatability and
    // rebuilds the container.
    $this->enableContentTranslation('node', 'test_page');
    $this->container->get('content_translation.manager')
      ->setBundleTranslationSettings('node', 'test_page', [
        'untranslatable_fields_hide' => TRUE,
      ]);
  }

  /**
   * Sets translatability on the domain access fields and rebuilds.
   *
   * Bundle info is cached after content_translation reads it; the
   * container must be rebuilt for the new translatability settings
   * to take effect on subsequent HTTP requests.
   *
   * @param bool $translatable
   *   Whether `field_domain_access` and `field_domain_all_affiliates`
   *   should be translatable.
   */
  protected function configureDomainAccessFields(bool $translatable): void {
    static::setFieldTranslatable('node', 'test_page', 'field_domain_access', $translatable);
    static::setFieldTranslatable('node', 'test_page', 'field_domain_all_affiliates', $translatable);
    $this->rebuildContainer();
  }

  /**
   * Creates an English page node assigned to a single domain.
   *
   * @param string $domain_id
   *   The domain machine id to assign the node to.
   *
   * @return \Drupal\node\NodeInterface
   *   The created page node, with a placeholder German translation
   *   added so we can land directly on the translation edit form.
   */
  protected function createTranslatableNode(string $domain_id) {
    $node = Node::create([
      'type' => 'test_page',
      'title' => $this->randomMachineName(),
      'langcode' => 'en',
      'field_domain_access' => [$domain_id],
    ]);
    $node->save();
    $node->addTranslation('de', [
      'title' => $this->randomMachineName(),
    ])->save();
    return $node;
  }

  /**
   * Server-side visibility when field_domain_access is hidden.
   *
   * Marks `field_domain_access` and `field_domain_all_affiliates` as
   * non-translatable so content_translation hides them on the
   * translation form. The JS States API can no longer drive the
   * path widgets' visibility — domain path has to decide it
   * server-side from the entity's stored values.
   *
   * Asserts that:
   *
   *   - field_domain_access is hidden by content_translation;
   *   - the domain_path widget for the assigned domain is visible
   *     (the bug under fix used to leave it with display:none);
   *   - the domain_path widget for the unassigned domain is absent;
   *   - submitting an alias from the translation form persists a
   *     path_alias entity scoped to the translation langcode.
   */
  public function testServerSideVisibilityWhenDomainAccessHidden(): void {
    $this->configureDomainAccessFields(translatable: FALSE);

    $domain_ids = array_keys($this->domains);
    $domain_a = $domain_ids[0];
    $domain_b = $domain_ids[1] ?? $domain_ids[0];

    $node = $this->createTranslatableNode($domain_a);

    $this->drupalGet('de/node/' . $node->id() . '/edit');
    $session = $this->assertSession();

    // content_translation must hide the untranslatable domain access
    // widget on the translation form.
    $session->fieldNotExists('field_domain_access[' . $domain_a . ']');
    $session->fieldNotExists('field_domain_access[' . $domain_b . ']');

    // Domain path widget for the assigned domain must be reachable
    // and have no inline display:none style left over from the
    // pre-#states flash hider (the regression).
    $session->fieldExists('domain_path[' . $domain_a . '][alias]');
    $alias_field = $this->getSession()->getPage()
      ->findField('domain_path[' . $domain_a . '][alias]');
    $this->assertNotNull($alias_field);
    $wrapper = $alias_field->find('xpath', 'ancestor::div[contains(@class, "field--name-domain-path") or @data-drupal-selector][1]');
    if ($wrapper !== NULL) {
      $style = (string) $wrapper->getAttribute('style');
      $this->assertStringNotContainsString('display:none', $style);
      $this->assertStringNotContainsString('display: none', $style);
    }

    // Domain path widget for the unassigned domain must be absent.
    $session->fieldNotExists('domain_path[' . $domain_b . '][alias]');

    // Submitting the translation form must persist the alias for the
    // translation language.
    $alias = '/' . $this->randomMachineName(8);
    $this->submitForm([
      'domain_path[' . $domain_a . '][alias]' => $alias,
    ], 'Save (this translation)');

    $aliases = $this->pathAliasStorage()->loadByProperties([
      'alias' => $alias,
      'langcode' => 'de',
    ]);
    $this->assertCount(1, $aliases);
    $alias_entity = reset($aliases);
    $this->assertEquals($domain_a, $alias_entity->get('domain_id')->target_id);
    $this->assertEquals('/node/' . $node->id(), $alias_entity->get('path')->value);
  }

  /**
   * Asserts JS States are preserved when field_domain_access stays visible.
   *
   * Leaves `field_domain_access` translatable, so even with
   * `untranslatable_fields_hide` enabled content_translation does
   * NOT hide the widget on translation forms. In that case the JS
   * States rule must still drive path widget visibility — checking a
   * new domain in the access widget should reveal the corresponding
   * path widget.
   *
   * Asserts that:
   *
   *   - field_domain_access is present on the translation form;
   *   - the domain_path widget for every domain accessible to the
   *     user is rendered with the inline `display:none` initial
   *     hider and a `data-drupal-states` attribute carrying the
   *     #states rule that the JS API consumes.
   */
  public function testStatesPreservedWhenDomainAccessTranslatable(): void {
    $this->configureDomainAccessFields(translatable: TRUE);

    $domain_ids = array_keys($this->domains);
    $domain_a = $domain_ids[0];
    $domain_b = $domain_ids[1] ?? $domain_ids[0];

    $node = $this->createTranslatableNode($domain_a);

    $this->drupalGet('de/node/' . $node->id() . '/edit');
    $session = $this->assertSession();

    // field_domain_access must be present on the form (translatable
    // field is not hidden by content_translation).
    $session->fieldExists('field_domain_access[' . $domain_a . ']');
    $session->fieldExists('field_domain_access[' . $domain_b . ']');

    // domain_path widgets for every accessible domain must exist —
    // both for the assigned and unassigned domains, since visibility
    // is driven client-side via #states.
    $session->fieldExists('domain_path[' . $domain_a . '][alias]');
    $session->fieldExists('domain_path[' . $domain_b . '][alias]');

    // The path widget for the unassigned domain must carry the
    // inline display:none hider AND a data-drupal-states attribute
    // referencing field_domain_access. The JS States API consumes
    // the latter to toggle visibility on checkbox change.
    $page = $this->getSession()->getPage();
    $field_b = $page->findField('domain_path[' . $domain_b . '][alias]');
    $this->assertNotNull($field_b);
    $wrapper_b = $field_b->find('xpath', 'ancestor::div[@data-drupal-states][1]');
    $this->assertNotNull($wrapper_b, 'Path widget wrapper carries data-drupal-states.');
    $this->assertStringContainsString(
      'field_domain_access[' . $domain_b . ']',
      (string) $wrapper_b->getAttribute('data-drupal-states'),
    );
    $style_b = (string) $wrapper_b->getAttribute('style');
    $this->assertTrue(
      str_contains($style_b, 'display:none') || str_contains($style_b, 'display: none'),
      'Path widget for unassigned domain has the pre-#states display:none hider.',
    );
  }

}
