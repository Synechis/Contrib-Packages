<?php

namespace Drupal\Tests\domain_path\Functional;

use Drupal\Core\Entity\EntityStorageInterface;
use Drupal\node\Entity\NodeType;
use Drupal\Tests\domain\Functional\DomainTestBase;
// @phpstan-ignore-next-line
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;

/**
 * Base class for Domain Path functional tests.
 *
 * @phpstan-ignore-next-line
 */
#[RunTestsInSeparateProcesses]
abstract class DomainPathNoAccessTestBase extends DomainTestBase {

  /**
   * The test domains list.
   *
   * @return \Drupal\domain\DomainInterface[]
   *   An array of domain entities.
   */
  protected array $domains;

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'domain_path',
    'field',
    'user',
    'path',
    'system',
  ];

  /**
   * {@inheritdoc}
   */
  protected $defaultTheme = 'stark';

  /**
   * The entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->entityTypeManager = $this->container->get('entity_type.manager');

    // Core 11.4's standard profile no longer ships the 'page' and 'article'
    // content types, so create a dedicated content type the tests can rely on
    // regardless of the install profile. Doing this after the modules are
    // installed lets Domain Access attach its fields to the new bundle.
    if (!NodeType::load('test_page')) {
      $this->drupalCreateContentType([
        'type' => 'test_page',
        'name' => 'Test page',
      ]);
    }

    // Domain Access attaches its fields when a node type is inserted, but on a
    // runtime-created bundle the default form display does not exist yet when
    // that hook runs, so the fields are created without a form display
    // component. Re-confirm them now that the bundle is fully set up.
    if ($this->container->get('module_handler')->moduleExists('domain_access')) {
      $this->container->get('domain_access.helper')
        ->confirmFields('node', 'test_page');
    }

    // Create domains.
    $this->domainCreateTestDomains(2);
    $this->domains = $this->getDomains();
    $this->domainPathBasicSetup();
  }

  /**
   * Returns the path alias storage.
   *
   * @return \Drupal\Core\Entity\EntityStorageInterface
   *   The path alias entity storage.
   */
  protected function pathAliasStorage(): EntityStorageInterface {
    return $this->entityTypeManager->getStorage('path_alias');
  }

  /**
   * Basic setup.
   */
  public function domainPathBasicSetup(): void {
    $admin = $this->drupalCreateUser($this->getAdminPermissions());

    $this->drupalLogin($admin);
    $this->container->get('entity_field.manager')->clearCachedFieldDefinitions();

    // Rebuild container to ensure the new field definitions are available.
    $this->rebuildContainer();
  }

  /**
   * Reusable test function for checking initial / empty table status.
   */
  public function pathAliasTableIsEmpty() {
    $domain_paths = $this->pathAliasStorage()->loadMultiple();
    $this->assertEmpty($domain_paths, 'No path aliases have been created.');
  }

  /**
   * Retrieves the list of permissions required for administrators.
   *
   * @return array
   *   An array of strings, each representing a permission assigned to
   *   administrators.
   */
  protected function getAdminPermissions() {
    return [
      'bypass node access',
      'administer content types',
      'administer users',
      'administer node fields',
      'administer node display',
      'administer domains',
      'administer url aliases',
      'administer domain paths',
    ];
  }

}
