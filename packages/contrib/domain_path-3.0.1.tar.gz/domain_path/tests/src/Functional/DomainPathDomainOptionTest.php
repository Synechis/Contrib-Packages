<?php

namespace Drupal\Tests\domain_path\Functional;

use PHPUnit\Framework\Attributes\Group;
// @phpstan-ignore-next-line
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;

/**
 * Tests domain path alias resolution via the domain URL option.
 *
 * When code sets $url->setOption('domain', $domain), the new
 * DomainPathAliasProcessor should re-alias the path for the
 * target domain.
 *
 * @group domain_path
 *
 * @phpstan-ignore-next-line
 */
#[Group('domain_path')]
#[RunTestsInSeparateProcesses]
class DomainPathDomainOptionTest extends DomainPathNoAccessTestBase {

  /**
   * Tests that the domain option triggers domain-specific aliasing.
   */
  public function testDomainOptionUsesAlias(): void {
    $this->pathAliasTableIsEmpty();

    $this->config('domain_path.settings')
      ->set('entity_types', ['node' => 'node'])
      ->save();

    $node = $this->drupalCreateNode([
      'type' => 'test_page',
    ]);

    $domains = array_values($this->getDomains());
    $domain_b = $domains[1];

    $alias_value = '/domain-b-alias';

    // Create a domain path alias for Domain B.
    $this->pathAliasStorage()->create([
      'path' => '/node/' . $node->id(),
      'alias' => $alias_value,
      'domain_id' => $domain_b->id(),
      'langcode' => $node->language()->getId(),
    ])->save();

    // Generate URL with the domain option set directly.
    $url = $node->toUrl('canonical', ['absolute' => TRUE]);
    $url->setOption('domain', $domain_b);
    $result = $url->toString();

    $expected = rtrim($domain_b->getPath(), '/') . $alias_value;
    $this->assertEquals($expected, $result, 'The URL uses the domain-specific alias when the domain option is set directly.');
  }

  /**
   * Tests that no domain alias falls back to the default path.
   */
  public function testDomainOptionWithoutAlias(): void {
    $this->pathAliasTableIsEmpty();

    $this->config('domain_path.settings')
      ->set('entity_types', ['node' => 'node'])
      ->save();

    $node = $this->drupalCreateNode([
      'type' => 'test_page',
    ]);

    $domains = array_values($this->getDomains());
    $domain_b = $domains[1];

    // No domain path alias created for Domain B.
    $url = $node->toUrl('canonical', ['absolute' => TRUE]);
    $url->setOption('domain', $domain_b);
    $result = $url->toString();

    // Should use the internal path (no domain-specific alias).
    $this->assertStringContainsString('/node/' . $node->id(), $result, 'The URL uses the internal path when no domain alias exists.');
    $this->assertStringStartsWith(rtrim($domain_b->getPath(), '/'), $result, 'The URL is on Domain B.');
  }

  /**
   * Tests that non-canonical routes are not aliased.
   */
  public function testDomainOptionNonCanonicalRoute(): void {
    $this->pathAliasTableIsEmpty();

    $this->config('domain_path.settings')
      ->set('entity_types', ['node' => 'node'])
      ->save();

    $node = $this->drupalCreateNode([
      'type' => 'test_page',
    ]);

    $domains = array_values($this->getDomains());
    $domain_b = $domains[1];

    $alias_value = '/domain-b-alias';

    // Create a domain path alias for Domain B (canonical only).
    $this->pathAliasStorage()->create([
      'path' => '/node/' . $node->id(),
      'alias' => $alias_value,
      'domain_id' => $domain_b->id(),
      'langcode' => $node->language()->getId(),
    ])->save();

    // Generate edit URL with the domain option.
    $url = $node->toUrl('edit-form', ['absolute' => TRUE]);
    $url->setOption('domain', $domain_b);
    $result = $url->toString();

    $this->assertStringNotContainsString($alias_value, $result, 'The edit URL does NOT use the domain-specific alias.');
    $this->assertStringContainsString('/node/' . $node->id() . '/edit', $result, 'The edit URL uses the internal edit path.');
  }

}
