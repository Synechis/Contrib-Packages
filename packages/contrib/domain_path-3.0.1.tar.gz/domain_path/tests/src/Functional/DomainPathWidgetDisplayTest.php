<?php

namespace Drupal\Tests\domain_path\Functional;

use PHPUnit\Framework\Attributes\Group;
// @phpstan-ignore-next-line
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;

/**
 * Tests the widget display options controlled by alias_title config.
 *
 * The alias_title setting determines what label appears for each
 * domain's alias field: the domain name, hostname, or URL.
 *
 * @group domain_path
 *
 * @phpstan-ignore-next-line
 */
#[Group('domain_path')]
#[RunTestsInSeparateProcesses]
class DomainPathWidgetDisplayTest extends DomainPathNoAccessTestBase {

  /**
   * Tests widget label changes with alias_title config.
   */
  public function testAliasTitleConfigChangesWidgetLabel(): void {
    $session = $this->assertSession();

    // Collect expected labels for each alias_title option.
    $expected = [];
    foreach ($this->domains as $domain) {
      $expected['name'][] = $domain->label();
      $expected['hostname'][] = $domain->getHostname();
      $expected['url'][] = $domain->getPath();
    }

    // Default: alias_title = 'name' — labels show domain name.
    $this->drupalGet('node/add/test_page');
    $session->statusCodeEquals(200);
    foreach ($expected['name'] as $label) {
      $session->fieldExists('URL alias for ' . $label);
    }

    // Change to 'hostname'.
    $this->config('domain_path.settings')
      ->set('alias_title', 'hostname')
      ->save();

    $this->drupalGet('node/add/test_page');
    foreach ($expected['hostname'] as $label) {
      $session->fieldExists('URL alias for ' . $label);
    }
    // Verify the name labels are no longer used.
    foreach ($expected['name'] as $label) {
      // Skip if name happens to equal hostname.
      if (!in_array($label, $expected['hostname'])) {
        $session->fieldNotExists('URL alias for ' . $label);
      }
    }

    // Change to 'url'.
    $this->config('domain_path.settings')
      ->set('alias_title', 'url')
      ->save();

    $this->drupalGet('node/add/test_page');
    foreach ($expected['url'] as $label) {
      $session->fieldExists('URL alias for ' . $label);
    }
  }

}
