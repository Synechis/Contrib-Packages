<?php

namespace Drupal\Tests\domain_path\Functional;

// @phpstan-ignore-next-line
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;

/**
 * Tests the domain path node aliases saving from edit form.
 *
 * @group domain_path
 *
 * @phpstan-ignore-next-line
 */
#[RunTestsInSeparateProcesses]
class DomainPathNodeAliasTest extends DomainPathTestBase {

  /**
   * Test domain path node aliases.
   */
  public function testDomainPathNodeAliasesFill() {
    // Set path from Node form.
    $edit = [];
    $domain_paths_check = [];
    $edit['title[0][value]'] = $this->randomMachineName(8);
    $edit['body[0][value]'] = $this->randomMachineName(16);
    foreach ($this->domains as $domain) {
      $domain_alias_value = '/' . $this->randomMachineName(8);
      $edit['domain_path[' . $domain->id() . '][alias]'] = $domain_alias_value;
      $domain_paths_check[$domain->id()] = $domain_alias_value;
    }
    $this->drupalGet('node/add/test_page');
    foreach ($this->domains as $domain) {
      $this->checkField('field_domain_access[' . $domain->id() . ']');
    }
    $this->submitForm($edit, t('Save'));
    $this->assertSession()->statusCodeEquals(200);

    foreach ($domain_paths_check as $domain_id => $domain_alias_value) {
      $this->assertCount(1, $this->pathAliasStorage()->loadByProperties([
        'domain_id' => $domain_id,
        'alias' => $domain_alias_value,
      ]));
    }

    // Check values on node form.
    $node = $this->drupalGetNodeByTitle($edit['title[0][value]']);
    $this->drupalGet('node/' . $node->id() . '/edit');
    $session = $this->assertSession();
    foreach ($domain_paths_check as $domain_id => $domain_alias_value) {
      $session->fieldValueEquals('domain_path[' . $domain_id . '][alias]', $domain_alias_value);
    }
    // Ensure aren't removed on second save.
    $page = $this->getSession()->getPage();
    $page->pressButton('Save');
    $node = $this->drupalGetNodeByTitle($edit['title[0][value]']);
    $this->drupalGet('node/' . $node->id() . '/edit');
    $session = $this->assertSession();
    foreach ($domain_paths_check as $domain_id => $domain_alias_value) {
      $session->fieldValueEquals('domain_path[' . $domain_id . '][alias]', $domain_alias_value);
    }
  }

  /**
   * Tests "Delete all aliases" checkbox deletes aliases.
   *
   * @see https://www.drupal.org/i/3576020
   */
  public function testDeleteAllAliasesDeletesEntities(): void {
    $domain_ids = array_keys($this->domains);

    // Create a node with aliases on both domains.
    $edit = [
      'title[0][value]' => 'Delete test ' . $this->randomMachineName(),
      'domain_path[' . $domain_ids[0] . '][alias]' => '/delete-a',
      'domain_path[' . $domain_ids[1] . '][alias]' => '/delete-b',
    ];
    $this->drupalGet('node/add/test_page');
    foreach ($domain_ids as $domain_id) {
      $this->checkField('field_domain_access[' . $domain_id . ']');
    }
    $this->submitForm($edit, 'Save');

    // Verify both aliases were created.
    $node = $this->drupalGetNodeByTitle($edit['title[0][value]']);
    $path = '/node/' . $node->id();
    $aliases = $this->pathAliasStorage()->loadByProperties([
      'path' => $path,
      'langcode' => $node->language()->getId(),
    ]);
    $this->assertCount(2, $aliases, 'Two aliases exist.');

    // Edit the node, check delete, submit.
    $this->drupalGet('node/' . $node->id() . '/edit');
    $this->submitForm([
      'domain_path_wrapper[domain_path_delete]' => TRUE,
    ], 'Save');

    // Verify all aliases were deleted.
    $this->pathAliasStorage()->resetCache();
    $aliases = $this->pathAliasStorage()->loadByProperties([
      'path' => $path,
      'langcode' => $node->language()->getId(),
    ]);
    $this->assertCount(0, $aliases, 'All aliases deleted.');
  }

}
