<?php

namespace Drupal\Tests\domain_path\FunctionalJavascript;

use Drupal\FunctionalJavascriptTests\WebDriverTestBase;
use Drupal\Tests\domain\Traits\DomainTestTrait;
use Drupal\Tests\node\Traits\ContentTypeCreationTrait;
// @phpstan-ignore-next-line
use PHPUnit\Framework\Attributes\Group;
// @phpstan-ignore-next-line
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;

/**
 * Tests #states interactions on the domain path widget.
 *
 * @group domain_path
 *
 * @phpstan-ignore-next-line
 */
#[Group('domain_path')]
#[RunTestsInSeparateProcesses]
class DomainPathStatesTest extends WebDriverTestBase {

  use ContentTypeCreationTrait;
  use DomainTestTrait;

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'domain',
    'domain_access',
    'domain_path',
    'field',
    'node',
    'path',
    'path_alias',
    'system',
    'text',
    'user',
  ];

  /**
   * {@inheritdoc}
   */
  protected $defaultTheme = 'stark';

  /**
   * We use the standard profile for testing.
   *
   * @var string
   */
  protected $profile = 'standard';

  /**
   * The test domains.
   *
   * @var \Drupal\domain\DomainInterface[]
   */
  protected array $domains;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $storage = \Drupal::entityTypeManager()->getStorage('domain');
    $this->baseHostname = $storage->createHostname();
    $this->setBaseDomain();

    $this->domainCreateTestDomains(2);
    $this->domains = $this->getDomains();

    // Core 11.4's standard profile no longer ships a content type, so create
    // one. Re-confirm the Domain Access fields afterwards so they are added to
    // the new bundle's form display (the node type insert hook runs before the
    // default form display exists).
    $this->createContentType(['type' => 'test_page', 'name' => 'Test page']);
    $this->container->get('domain_access.helper')
      ->confirmFields('node', 'test_page');

    // Keep fields in the main form body so they are
    // directly interactable (not in vertical tabs).
    \Drupal::configFactory()->getEditable('domain_access.settings')
      ->set('node_advanced_tab', FALSE)
      ->save();
    \Drupal::configFactory()->getEditable('domain_path.settings')
      ->set('use_advanced_group', FALSE)
      ->save();

    $admin = $this->drupalCreateUser([
      'bypass node access',
      'administer domains',
      'administer url aliases',
      'administer domain paths',
      'publish to any domain',
      'administer content types',
      'administer node fields',
      'administer node display',
    ]);
    $this->drupalLogin($admin);

    $this->container->get('entity_field.manager')
      ->clearCachedFieldDefinitions();
    $this->rebuildContainer();
  }

  /**
   * Tests domain access checkboxes toggle path visibility.
   */
  public function testDomainAccessCheckboxTogglesPathVisibility(): void {
    $page = $this->getSession()->getPage();
    $assert = $this->assertSession();

    $domain_ids = array_keys($this->domains);
    $domain_a = $domain_ids[0];
    $domain_b = $domain_ids[1];

    $alias_a = 'input[name="domain_path[' . $domain_a . '][alias]"]';
    $alias_b = 'input[name="domain_path[' . $domain_b . '][alias]"]';

    $this->drupalGet('node/add/test_page');

    // Domain A (default) is pre-checked, so path A is
    // visible after #states processes.
    $this->assertNotEmpty(
      $assert->waitForElementVisible('css', $alias_a)
    );

    // Domain B is not checked, so path B is hidden.
    $this->assertFalse($page->find('css', $alias_b)->isVisible());

    // Check domain B: B's path field becomes visible.
    $page->checkField('field_domain_access[' . $domain_b . ']');
    $this->assertNotEmpty(
      $assert->waitForElementVisible('css', $alias_b)
    );

    // Uncheck A: A's path field becomes hidden.
    $page->uncheckField('field_domain_access[' . $domain_a . ']');
    $result = $page->waitFor(5, function () use ($page, $alias_a) {
      $el = $page->find('css', $alias_a);
      return $el && !$el->isVisible();
    });
    $this->assertTrue($result);

    // B's path field should still be visible.
    $this->assertTrue($page->find('css', $alias_b)->isVisible());
  }

  /**
   * Tests all affiliates checkbox shows all path fields.
   */
  public function testAllAffiliatesShowsAllPaths(): void {
    $page = $this->getSession()->getPage();
    $assert = $this->assertSession();

    $domain_ids = array_keys($this->domains);
    $domain_a = $domain_ids[0];
    $alias_a = 'input[name="domain_path[' . $domain_ids[0] . '][alias]"]';
    $alias_b = 'input[name="domain_path[' . $domain_ids[1] . '][alias]"]';

    $this->drupalGet('node/add/test_page');

    // Uncheck default domain so both paths start hidden.
    $page->uncheckField('field_domain_access[' . $domain_a . ']');
    $page->waitFor(5, function () use ($page, $alias_a) {
      $el = $page->find('css', $alias_a);
      return $el && !$el->isVisible();
    });
    $this->assertFalse($page->find('css', $alias_a)->isVisible());
    $this->assertFalse($page->find('css', $alias_b)->isVisible());

    // Check "Send to all affiliates".
    $page->checkField('field_domain_all_affiliates[value]');

    // Both path fields should become visible.
    $this->assertNotEmpty(
      $assert->waitForElementVisible('css', $alias_a)
    );
    $this->assertTrue($page->find('css', $alias_b)->isVisible());
  }

  /**
   * Tests delete checkbox disables all alias fields.
   */
  public function testDeleteCheckboxDisablesAliasFields(): void {
    $page = $this->getSession()->getPage();
    $assert = $this->assertSession();

    $domain_ids = array_keys($this->domains);
    $domain_a = $domain_ids[0];
    $domain_b = $domain_ids[1];

    $alias_a = 'input[name="domain_path[' . $domain_a . '][alias]"]';
    $alias_b = 'input[name="domain_path[' . $domain_b . '][alias]"]';

    // Create a node with aliases on both domains.
    $title = 'Test Delete ' . $this->randomMachineName();
    $this->drupalGet('node/add/test_page');

    // Domain A is pre-checked; check domain B too.
    $page->checkField('field_domain_access[' . $domain_b . ']');
    $assert->waitForElementVisible('css', $alias_b);

    $page->fillField('title[0][value]', $title);
    $page->fillField('domain_path[' . $domain_a . '][alias]', '/alias-a');
    $page->fillField('domain_path[' . $domain_b . '][alias]', '/alias-b');
    $page->pressButton('Save');
    $assert->waitForText($title);

    // Edit the node.
    $node = $this->drupalGetNodeByTitle($title);
    $this->drupalGet('node/' . $node->id() . '/edit');
    $assert->waitForElementVisible('css', $alias_a);

    // Delete checkbox should be visible (2 aliases exist).
    $delete = 'domain_path_wrapper[domain_path_delete]';
    $delete_css = 'input[name="' . $delete . '"]';
    $this->assertTrue($page->find('css', $delete_css)->isVisible());

    // Both alias fields should be enabled initially.
    $this->assertNull(
      $page->find('css', $alias_a . ':disabled')
    );
    $this->assertNull(
      $page->find('css', $alias_b . ':disabled')
    );

    // Check delete: both fields become disabled.
    $page->checkField($delete);
    $this->assertNotEmpty(
      $assert->waitForElement('css', $alias_a . ':disabled')
    );
    $this->assertNotEmpty(
      $page->find('css', $alias_b . ':disabled')
    );

    // Uncheck delete: both fields become re-enabled.
    $page->uncheckField($delete);
    $result = $page->waitFor(5, function () use ($page, $alias_a) {
      return $page->find('css', $alias_a . ':disabled') === NULL;
    });
    $this->assertTrue($result);
    $this->assertNull(
      $page->find('css', $alias_b . ':disabled')
    );
  }

}
