# Domain Path

The Domain Path module allows the creation of domain-specific path aliases for
content entities in a multi-domain Drupal installation.

For full documentation, see the [Domain Path documentation](https://project.pages.drupalcode.org/domain_path/)
or build it locally:

```bash
cd web/modules/contrib/domain_path
pip install mkdocs-material
mkdocs serve
```

Then browse `http://localhost:8000`.

## Quick links

- [Project page](https://www.drupal.org/project/domain_path)
- [Issue queue](https://www.drupal.org/project/issues/domain_path)
- [Domain module](https://www.drupal.org/project/domain)
