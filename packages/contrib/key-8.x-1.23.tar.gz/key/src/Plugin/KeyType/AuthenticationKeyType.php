<?php

namespace Drupal\key\Plugin\KeyType;

use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\key\Attribute\KeyType;
use Drupal\key\Plugin\KeyTypeBase;

/**
 * Defines a generic key type for authentication.
 */
#[KeyType(
  id: 'authentication',
  label: new TranslatableMarkup('Authentication'),
  description: new TranslatableMarkup('A generic key type to use for a password or API key that does not belong to any other defined key type.'),
  group: 'authentication',
  key_value: [
    'plugin' => 'text_field',
  ],
)]
class AuthenticationKeyType extends KeyTypeBase {

  /**
   * {@inheritdoc}
   */
  public static function generateKeyValue(array $configuration) {
    $password = \Drupal::service('password_generator')->generate(16);

    return $password;
  }

  /**
   * {@inheritdoc}
   */
  public function validateKeyValue(array $form, FormStateInterface $form_state, $key_value) {
    // Validation of the key value is optional.
  }

}
