<?php

namespace Drupal\Tests\eca_content\Kernel;

use Drupal\Core\Language\LanguageInterface;
use Drupal\KernelTests\KernelTestBase;
use Drupal\language\Entity\ConfigurableLanguage;
use Drupal\language\Entity\ContentLanguageSettings;
use Drupal\language\Plugin\LanguageNegotiation\LanguageNegotiationUrl;
use Drupal\node\Entity\Node;
use Drupal\node\NodeInterface;
use Drupal\Tests\node\Traits\ContentTypeCreationTrait;
use Drupal\user\Entity\Role;
use Drupal\user\Entity\User;
use Drupal\user\Plugin\LanguageNegotiation\LanguageNegotiationUser;
use Drupal\user\RoleInterface;
use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;

/**
 * Kernel tests for the "eca_content.service.entity_loader" service.
 */
#[Group('eca')]
#[Group('eca_content')]
#[RunTestsInSeparateProcesses]
class EntityLoaderTest extends KernelTestBase {

  use ContentTypeCreationTrait;

  /**
   * The modules.
   *
   * @var string[]
   *   The modules.
   */
  protected static $modules = [
    'system',
    'user',
    'field',
    'filter',
    'text',
    'node',
    'eca',
    'eca_content',
    'modeler_api',
    'language',
    'content_translation',
  ];

  /**
   * {@inheritdoc}
   */
  public function setUp(): void {
    parent::setUp();
    $this->installEntitySchema('user');
    $this->installEntitySchema('node');
    $this->installSchema('node', ['node_access']);
    $this->installConfig(static::$modules);

    ConfigurableLanguage::create(['id' => 'de'])->save();
    // Set up language negotiation.
    $config = $this->config('language.types');
    $config->set('configurable', [
      LanguageInterface::TYPE_INTERFACE,
      LanguageInterface::TYPE_CONTENT,
    ]);
    $config->set('negotiation', [
      LanguageInterface::TYPE_INTERFACE => [
        'enabled' => [LanguageNegotiationUser::METHOD_ID => 0],
      ],
      LanguageInterface::TYPE_CONTENT => [
        'enabled' => [LanguageNegotiationUrl::METHOD_ID => 0],
      ],
    ]);
    $config->save();
    $config = $this->config('language.negotiation');
  }

  /**
   * Tests EntityLoader.
   */
  public function testEntityLoader(): void {
    // Create the Article content type with revisioning and translation enabled.
    $this->createContentType([
      'type' => 'article',
      'name' => 'Article',
      'new_revision' => TRUE,
    ]);
    ContentLanguageSettings::create([
      'id' => 'node.article',
      'target_entity_type_id' => 'node',
      'target_bundle' => 'article',
      'default_langcode' => LanguageInterface::LANGCODE_DEFAULT,
      'language_alterable' => TRUE,
    ])->save();

    /** @var \Drupal\eca_content\Service\EntityLoader $entity_loader */
    $entity_loader = \Drupal::service('eca_content.service.entity_loader');
    /** @var \Drupal\eca\Token\TokenInterface $token_services */
    $token_services = \Drupal::service('eca.token_services');
    $plugin_id = 'eca_token_load_entity';

    /** @var \Drupal\node\NodeInterface $node */
    $node = Node::create([
      'type' => 'article',
      'title' => '123',
      'langcode' => 'en',
      'uid' => 0,
      'status' => 0,
    ]);
    $node->save();
    $first_vid = $node->getRevisionId();
    $node->title = '456';
    $node->setNewRevision(TRUE);
    $node->save();

    // Create a plugin for evaluating entity existence.
    $defaults = [
      'from' => 'current',
      'entity_type' => '_none',
      'entity_id' => '',
      'revision_id' => '',
      'properties' => '',
      'langcode' => '_interface',
      'latest_revision' => FALSE,
      'unchanged' => FALSE,
    ];
    $this->assertTrue($entity_loader->loadEntity($node, $defaults, $plugin_id) instanceof NodeInterface, 'Entity must exist.');
    $this->assertEquals($node->id(), $entity_loader->loadEntity($node, $defaults, $plugin_id)->id(), 'Node ID must match up.');

    $this->assertTrue($entity_loader->loadEntity($node, ['revision_id' => $first_vid] + $defaults, $plugin_id) instanceof NodeInterface, 'Entity must exist.');
    $this->assertEquals($node->id(), $entity_loader->loadEntity($node, ['revision_id' => $first_vid] + $defaults, $plugin_id)->id(), 'Node ID must match up.');
    $this->assertEquals($first_vid, $entity_loader->loadEntity($node, ['revision_id' => $first_vid] + $defaults, $plugin_id)->getRevisionId(), 'Revision ID must match up (first revision ID).');

    $this->assertTrue($entity_loader->loadEntity($node, ['langcode' => 'en'] + $defaults, $plugin_id) instanceof NodeInterface, 'Entity must exist.');
    $this->assertEquals($node->id(), $entity_loader->loadEntity($node, ['langcode' => 'en'] + $defaults, $plugin_id)->id(), 'Node ID must match up.');
    $this->assertEquals('en', $entity_loader->loadEntity($node, ['langcode' => 'en'] + $defaults, $plugin_id)->language()->getId(), 'Language ID must match up (en).');

    $this->assertNull($entity_loader->loadEntity($node, ['langcode' => 'de'] + $defaults, $plugin_id), 'Entity must not exist as the translation (de) is not available.');

    $node->addTranslation('de', [
      'type' => 'article',
      'title' => 'ECA ist super!',
      'langcode' => 'de',
      'uid' => 1,
      'status' => 0,
    ])->save();
    $this->assertTrue($entity_loader->loadEntity($node, ['langcode' => 'de'] + $defaults, $plugin_id) instanceof NodeInterface, 'Entity must exist now as its translation (de) is now available.');
    $this->assertEquals($node->id(), $entity_loader->loadEntity($node, ['langcode' => 'de'] + $defaults, $plugin_id)->id(), 'Node ID must match up.');
    $this->assertEquals('de', $entity_loader->loadEntity($node, ['langcode' => 'de'] + $defaults, $plugin_id)->language()->getId(), 'Language ID must match up (de).');

    $token_services->addTokenData('mynode', $node);

    $entity = $entity_loader->loadEntity(NULL, [
      'langcode' => 'en',
      'from' => 'id',
      'entity_type' => 'node',
      'entity_id' => '[mynode:nid]',
      'latest_revision' => TRUE,
    ] + $defaults, $plugin_id);
    $this->assertTrue($entity instanceof NodeInterface, 'Entity must exist.');
    $this->assertEquals($node->id(), $entity->id(), 'Node ID must match up.');

    $node->title = 'Changed on runtime';
    $entity = $entity_loader->loadEntity($node, ['unchanged' => TRUE] + $defaults, $plugin_id);
    $this->assertTrue($entity instanceof NodeInterface, 'Entity must exist as it is stored in the database.');
    $this->assertEquals($node->id(), $entity->id(), 'Node ID must match up.');
    $this->assertEquals('456', $entity->label(), 'Node title must be the unchanged one.');

    // Load by properties. A lookup by properties only returns entities that
    // the current account may view, and the node above is unpublished, so
    // these assertions on the property matching itself run as a privileged
    // account. Access is covered by
    // self::testLoadByPropertiesAppliesViewAccess().
    User::create(['uid' => 1, 'name' => 'admin'])->save();
    /** @var \Drupal\Core\Session\AccountSwitcherInterface $account_switcher */
    $account_switcher = \Drupal::service('account_switcher');
    $account_switcher->switchTo(User::load(1));

    $entity = $entity_loader->loadEntity(NULL, [
      'from' => 'properties',
      'entity_type' => 'node',
      'properties' => "title: 456\nuid: 0",
    ] + $defaults, $plugin_id);
    $this->assertTrue($entity instanceof NodeInterface, 'Entity must exist.');
    $entity = $entity_loader->loadEntity(NULL, [
      'from' => 'properties',
      'entity_type' => 'node',
      'properties' => "title: 88888\nuid: 1",
    ] + $defaults, $plugin_id);
    $this->assertFalse($entity instanceof NodeInterface, 'Node must not exist.');

    $account_switcher->switchBack();
  }

  /**
   * Tests that loading by properties only selects entities that are viewable.
   *
   * The property lookup selects a single record. Without access filtering it
   * may select an entity that the current account may not view, even though
   * another entity matching the very same properties would have been viewable.
   * The calling plugin then denies access on that record and reports that no
   * entity exists, which is a false negative.
   */
  public function testLoadByPropertiesAppliesViewAccess(): void {
    $this->createContentType([
      'type' => 'article',
      'name' => 'Article',
    ]);

    /** @var \Drupal\eca_content\Service\EntityLoader $entity_loader */
    $entity_loader = \Drupal::service('eca_content.service.entity_loader');
    /** @var \Drupal\Core\Session\AccountSwitcherInterface $account_switcher */
    $account_switcher = \Drupal::service('account_switcher');
    $plugin_id = 'eca_token_load_entity';

    // Two nodes share the same title. The one that must not be viewable is
    // created first, so that a lookup without access filtering selects it.
    $unviewable = Node::create([
      'type' => 'article',
      'title' => 'Shared title',
      'langcode' => 'en',
      'uid' => 1,
      'status' => 0,
    ]);
    $unviewable->save();
    $viewable = Node::create([
      'type' => 'article',
      'title' => 'Shared title',
      'langcode' => 'en',
      'uid' => 1,
      'status' => 1,
    ]);
    $viewable->save();

    // This title is only held by a node that must not be viewable.
    $hidden = Node::create([
      'type' => 'article',
      'title' => 'Hidden title',
      'langcode' => 'en',
      'uid' => 1,
      'status' => 0,
    ]);
    $hidden->save();

    // An unprivileged account that may only view published content.
    /** @var \Drupal\user\RoleInterface $role */
    $role = Role::load(RoleInterface::AUTHENTICATED_ID);
    $role->grantPermission('access content');
    $role->save();
    $account = User::create([
      'uid' => 2,
      'name' => 'viewer',
      'status' => 1,
    ]);
    $account->save();
    $account_switcher->switchTo($account);

    $defaults = [
      'from' => 'properties',
      'entity_type' => 'node',
      'entity_id' => '',
      'revision_id' => '',
      'properties' => '',
      'langcode' => '_interface',
      'latest_revision' => FALSE,
      'unchanged' => FALSE,
    ];

    $entity = $entity_loader->loadEntity(NULL, [
      'properties' => 'title: Shared title',
    ] + $defaults, $plugin_id);
    $this->assertTrue($entity instanceof NodeInterface, 'A viewable node matching the properties must be found.');
    $this->assertEquals($viewable->id(), $entity->id(), 'The viewable node must be selected instead of the unviewable one.');

    $entity = $entity_loader->loadEntity(NULL, [
      'properties' => 'title: Hidden title',
    ] + $defaults, $plugin_id);
    $this->assertNull($entity, 'A node that the account may not view must not be returned.');

    $account_switcher->switchBack();
  }

}
