<?php

namespace Drupal\eca_misc\Plugin\Action;

use Drupal\Core\Access\AccessResult;
use Drupal\Core\Action\Attribute\Action;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Recipe\Recipe;
use Drupal\Core\Recipe\RecipeRunner;
use Drupal\Core\Session\AccountInterface;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\eca\Attribute\EcaAction;
use Drupal\eca\Plugin\Action\ConfigurableActionBase;
use Drupal\eca_misc\Plugin\RecipePathTrait;

/**
 * Loads a query argument from the request into the token environment.
 */
#[Action(
  id: 'eca_apply_recipe',
  label: new TranslatableMarkup('Recipe: apply'),
)]
#[EcaAction(
  description: new TranslatableMarkup('Applies a given recipe.'),
  version_introduced: '2.1.2',
)]
class ApplyRecipe extends ConfigurableActionBase {

  use RecipePathTrait;

  /**
   * {@inheritdoc}
   */
  public function access($object, ?AccountInterface $account = NULL, $return_as_object = FALSE) {
    // Applying a recipe installs modules and executes config actions, which
    // is at least as privileged as any other config operation in ECA, so it
    // requires the same permission.
    $result = AccessResult::forbidden('The user does not have the permission to administer site configuration.');
    $account = $account ?: $this->currentUser;
    if ($account->hasPermission('administer site configuration')) {
      $result = AccessResult::allowed();
      if ($this->getRecipePath($this->configuration['recipe_package_name']) === NULL) {
        $result = AccessResult::forbidden('The configured package name is invalid.');
      }
    }
    return $return_as_object ? $result : $result->isAllowed();
  }

  /**
   * {@inheritdoc}
   */
  public function execute(?object $object = NULL): void {
    $recipe = Recipe::createFromDirectory($this->getRecipePath($this->configuration['recipe_package_name']));
    RecipeRunner::processRecipe($recipe);
  }

  /**
   * {@inheritdoc}
   */
  public function defaultConfiguration(): array {
    return [
      'recipe_package_name' => '',
    ] + parent::defaultConfiguration();
  }

  /**
   * {@inheritdoc}
   */
  public function buildConfigurationForm(array $form, FormStateInterface $form_state): array {
    $form['recipe_package_name'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Recipe package name'),
      '#description' => $this->t('The Composer package name of the recipe, that should be applied, e.g. "drupal/drupal_cms_privacy_basic"'),
      '#default_value' => $this->configuration['recipe_package_name'],
      '#required' => TRUE,
      '#eca_token_replacement' => TRUE,
    ];
    return parent::buildConfigurationForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function submitConfigurationForm(array &$form, FormStateInterface $form_state): void {
    $this->configuration['recipe_package_name'] = $form_state->getValue('recipe_package_name');
    parent::submitConfigurationForm($form, $form_state);
  }

}
