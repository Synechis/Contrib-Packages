((Drupal, once) => {
  /**
   * Navigates to the URL associated with the selected option.
   * @param {Event} e - the event object
   */
  function navigateYou(e) {
    const selectedIndex = e.target.selectedIndex;
    const url = e.target.querySelectorAll('option')[selectedIndex].dataset.url;

    if (url) {
      window.location.href = url;
    }
  }

  /**
   * Initialize and set up event listeners.
   * @param {Element} el - The <select> element with all of the options.
   */
  function init(el) {
    el.addEventListener('change', navigateYou);
  }

  Drupal.behaviors.archiveSitesMenu = {
    attach(context) {
      once('archive-sites-menu', '.archive-sites-menu', context).forEach(init);
    },
  };
})(Drupal, once);
