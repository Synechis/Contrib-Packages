<?php

namespace Drupal\facet_bot_blocker\Form;

use Drupal\Component\Datetime\TimeInterface;
use Drupal\Core\Cache\CacheBackendInterface;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Extension\ModuleHandlerInterface;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Defines a form that configures Facet Bot Blocker settings.
 */
class FacetBotBlockerSettingsForm extends FormBase {

  /**
   * The config factory.
   *
   * @var \Drupal\Core\Config\ConfigFactoryInterface
   */
  protected $configFactory;

  /**
   * The cache backend.
   *
   * @var \Drupal\Core\Cache\CacheBackendInterface
   */
  protected $cacheBackend;

  /**
   * Module handler for checking if memcache or redis is installed.
   *
   * @var \Drupal\Core\Extension\ModuleHandlerInterface
   */
  protected $moduleHandler;

  /**
   * Time service.
   *
   * @var \Drupal\Component\Datetime\TimeInterface
   */
  protected $time;

  /**
   * Constructs a new FacetBotBlockerSettingsForm object.
   */
  public function __construct(ConfigFactoryInterface $configFactory, CacheBackendInterface $cacheBackend, ModuleHandlerInterface $moduleHandler, TimeInterface $time) {
    $this->configFactory = $configFactory;
    $this->cacheBackend = $cacheBackend;
    $this->moduleHandler = $moduleHandler;
    $this->time = $time;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container): self {
    return new static(
      $container->get('config.factory'),
      $container->get('cache.default'),
      $container->get('module_handler'),
      $container->get('datetime.time')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId(): string {
    return 'facet_bot_blocker.settings';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    // Load existing configuration.
    $config = $this->config('facet_bot_blocker.settings');

    $form['facets_bot_blocker_limit'] = [
      '#type' => 'number',
      '#title' => $this->t('Facet parameter limit'),
      '#description' => $this->t('Block requests if a facet query parameter with this index is found, e.g., f[@limit]. Default is 1.'),
      '#default_value' => $config->get('facets_bot_blocker_limit') ?? 1,
      '#min' => 1,
      '#required' => TRUE,
    ];

    $form['facet_bot_blocker_return_gone'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Return 410 Gone instead of 403 Forbidden'),
      '#default_value' => $config->get('facet_bot_blocker_return_gone') ?? FALSE,
      '#description' => $this->t('If enabled, blocked facet requests will return HTTP 410 Gone instead of 403 Forbidden.'),
    ];

    $form['facet_bot_blocker_html'] = [
      '#type' => 'textarea',
      '#title' => $this->t('Custom blocked message'),
      '#description' => $this->t('HTML message displayed when a request is blocked.'),
      '#default_value' => $config->get('facet_bot_blocker_html') ?? '<h1>Excessive crawling detected</h1><p>We have blocked your request.</p>',
    ];

    $form['actions']['#type'] = 'actions';
    $form['actions']['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Save configuration'),
      '#button_type' => 'primary',
    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $formState) {
    // Save values to config.
    $this->configFactory->getEditable('facet_bot_blocker.settings')
      ->set('facets_bot_blocker_limit', $formState->getValue('facets_bot_blocker_limit'))
      ->set('facet_bot_blocker_return_gone', $formState->getValue('facet_bot_blocker_return_gone'))
      ->set('facet_bot_blocker_html', $formState->getValue('facet_bot_blocker_html'))
      ->save();

    // If memcache or redis is installed, store limit in cache
    // to avoid excessive DB reads.
    $use_cache = (
      $this->moduleHandler->moduleExists('memcache') ||
      $this->moduleHandler->moduleExists('redis')
    );
    if ($use_cache) {
      $limit = $formState->getValue('facets_bot_blocker_limit');
      $this->cacheBackend->set('facet_bot_blocker.limit', $limit);
    }

    // Show a status message.
    $this->messenger()->addStatus($this->t('Facet Bot Blocker configuration saved.'));

    // Redirect to the same form.
    $formState->setRedirect('<current>');
  }

}
