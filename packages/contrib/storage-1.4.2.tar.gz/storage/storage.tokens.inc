<?php

/**
 * @file
 * Builds placeholder replacement tokens for "Storage entity"-related data.
 */

use Drupal\Core\Hook\Attribute\LegacyHook;
use Drupal\Core\Render\BubbleableMetadata;
use Drupal\storage\Hook\StorageTokensHooks;

/**
 * Implements hook_token_info().
 */
#[LegacyHook]
function storage_token_info() {
  return \Drupal::service(StorageTokensHooks::class)->tokenInfo();
}

/**
 * Implements hook_tokens().
 */
#[LegacyHook]
function storage_tokens($type, $tokens, array $data, array $options, BubbleableMetadata $bubbleable_metadata) {
  return \Drupal::service(StorageTokensHooks::class)->tokens($type, $tokens, $data, $options, $bubbleable_metadata);
}
