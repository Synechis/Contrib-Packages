<?php

namespace Drupal\storage\Hook;

use Drupal\Core\Datetime\DateFormatterInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\Core\Language\LanguageInterface;
use Drupal\Core\Language\LanguageManagerInterface;
use Drupal\Core\Render\BubbleableMetadata;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\Core\Utility\Token;

/**
 * Hook implementations for storage tokens.
 */
class StorageTokensHooks {

  use StringTranslationTrait;

  public function __construct(
    protected readonly Token $token,
    protected readonly LanguageManagerInterface $languageManager,
    protected readonly EntityTypeManagerInterface $entityTypeManager,
    protected readonly DateFormatterInterface $dateFormatter,
  ) {}

  /**
   * Implements hook_token_info().
   */
  #[Hook('token_info')]
  public function tokenInfo() {
    $type = [
      'name' => $this->t('Storage entities'),
      'description' => $this->t('Tokens related to individual storage entities.'),
      'needs-data' => 'storage',
    ];

    $storage = [];

    // Core tokens for storage entities.
    $storage['id'] = [
      'name' => $this->t("Storage ID"),
      'description' => $this->t('The unique ID of the Storage entity.'),
    ];
    $storage['vid'] = [
      'name' => $this->t("Storage revision ID"),
      'description' => $this->t("The unique ID of the Storage entity's latest revision."),
    ];
    $storage['type'] = [
      'name' => $this->t("Storage type"),
    ];
    $storage['type-name'] = [
      'name' => $this->t("Storage type name"),
      'description' => $this->t("The human-readable name of the storage type."),
    ];
    $storage['name'] = [
      'name' => $this->t("Name"),
    ];
    $storage['langcode'] = [
      'name' => $this->t('Language code'),
      'description' => $this->t('The language code of the language the Storage entity is written in.'),
    ];
    $storage['url'] = [
      'name' => $this->t("URL"),
      'description' => $this->t("The canonical URL of the Storage entity."),
    ];
    $storage['edit-url'] = [
      'name' => $this->t("Edit URL"),
      'description' => $this->t("The URL of the Storage entity's edit form."),
    ];

    // Chained tokens for storage entities.
    $storage['created'] = [
      'name' => $this->t("Date created"),
      'type' => 'date',
    ];
    $storage['changed'] = [
      'name' => $this->t("Date changed"),
      'type' => 'date',
    ];
    $storage['author'] = [
      'name' => $this->t("Author"),
      'type' => 'user',
    ];

    // Miscellaneous tokens for storage entities.
    $storage['string-representation'] = [
      'name' => $this->t("String representation"),
      'description' => $this->t("A generic string representation of this Storage entity. Warning: This might expose undesired field content."),
    ];

    return [
      'types' => ['storage' => $type],
      'tokens' => ['storage' => $storage],
    ];
  }

  /**
   * Implements hook_tokens().
   */
  #[Hook('tokens')]
  public function tokens($type, $tokens, array $data, array $options, BubbleableMetadata $bubbleable_metadata) {
    $token_service = $this->token;

    $url_options = ['absolute' => TRUE];
    if (isset($options['langcode'])) {
      $url_options['language'] = $this->languageManager->getLanguage($options['langcode']);
      $langcode = $options['langcode'];
    }
    else {
      $langcode = LanguageInterface::LANGCODE_DEFAULT;
    }
    $replacements = [];

    if ($type == 'storage' && !empty($data['storage'])) {
      /** @var \Drupal\storage\Entity\StorageInterface $storage */
      $storage = $data['storage'];
      if (isset($options['langcode']) && $storage->language()->getId() !== $options['langcode'] && $storage->hasTranslation($options['langcode'])) {
        $storage = $storage->getTranslation($options['langcode']);
      }
      $bubbleable_metadata->addCacheableDependency($storage);
      if ($config_id = $storage->bundle()) {
        if ($storage_type = $this->entityTypeManager->getStorage('storage_type')->load($config_id)) {
          $bubbleable_metadata->addCacheableDependency($storage_type);
        }
      }

      foreach ($tokens as $name => $original) {
        switch ($name) {
          case 'id':
            $replacements[$original] = $storage->id();
            break;

          case 'vid':
            $replacements[$original] = $storage->getRevisionId();
            break;

          case 'type':
            $replacements[$original] = $config_id;
            break;

          case 'type-name':
            $replacements[$original] = !empty($storage_type) ? $this->t('@label', ['@label' => $storage_type->label()]) : '';
            break;

          case 'name':
            $replacements[$original] = $storage->label();
            break;

          case 'langcode':
            $replacements[$original] = $storage->language()->getId();
            break;

          case 'url':
            $replacements[$original] = $storage->toUrl('canonical', $url_options)->toString();
            break;

          case 'edit-url':
            $replacements[$original] = $storage->toUrl('edit-form', $url_options)->toString();
            break;

          // Default values for the chained tokens handled below.
          case 'created':
            $date_format = $this->entityTypeManager->getStorage('date_format')->load('medium');
            $bubbleable_metadata->addCacheableDependency($date_format);
            $replacements[$original] = $this->dateFormatter->format($storage->getCreatedTime(), 'medium', '', NULL, $langcode);
            break;

          case 'changed':
            $date_format = $this->entityTypeManager->getStorage('date_format')->load('medium');
            $bubbleable_metadata->addCacheableDependency($date_format);
            $replacements[$original] = $this->dateFormatter->format($storage->getChangedTime(), 'medium', '', NULL, $langcode);
            break;

          case 'author':
            $account = $storage->getOwner() ?: $this->entityTypeManager->getStorage('user')->load(0);
            $bubbleable_metadata->addCacheableDependency($account);
            $replacements[$original] = $account->label();
            break;

          case 'string-representation':
            $replacements[$original] = $storage->getStringRepresentation();
            break;
        }
      }

      if ($author_tokens = $token_service->findWithPrefix($tokens, 'author')) {
        $replacements += $token_service->generate('user', $author_tokens, ['user' => $storage->getOwner()], $options, $bubbleable_metadata);
      }

      if ($created_tokens = $token_service->findWithPrefix($tokens, 'created')) {
        $replacements += $token_service->generate('date', $created_tokens, ['date' => $storage->getCreatedTime()], $options, $bubbleable_metadata);
      }

      if ($changed_tokens = $token_service->findWithPrefix($tokens, 'changed')) {
        $replacements += $token_service->generate('date', $changed_tokens, ['date' => $storage->getChangedTime()], $options, $bubbleable_metadata);
      }
    }

    return $replacements;
  }

}
