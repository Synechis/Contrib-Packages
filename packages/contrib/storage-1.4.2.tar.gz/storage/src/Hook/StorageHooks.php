<?php

namespace Drupal\storage\Hook;

use Drupal\Core\Database\Query\AlterableInterface;
use Drupal\Core\Database\Query\Condition;
use Drupal\Core\Database\Query\ConditionInterface;
use Drupal\Core\Database\Query\SelectInterface;
use Drupal\Core\Entity\EntityFormInterface;
use Drupal\Core\Entity\EntityTypeBundleInfoInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Entity\Sql\SqlEntityStorageInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\Core\Routing\RouteMatchInterface;
use Drupal\Core\Session\AccountInterface;
use Drupal\Core\Session\AccountProxyInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\views\ViewExecutable;

/**
 * Hook implementations for storage.
 */
class StorageHooks {

  use StringTranslationTrait;

  public function __construct(
    protected readonly EntityTypeBundleInfoInterface $bundleInfo,
    protected readonly EntityTypeManagerInterface $entityTypeManager,
    protected readonly AccountProxyInterface $currentUser,
  ) {
  }

  /**
   * Implements hook_help().
   */
  #[Hook('help')]
  public function help($route_name, RouteMatchInterface $route_match) {
    switch ($route_name) {
      // Main module help for the storage module.
      case 'help.page.storage':
        $output = '';
        $output .= '<h3>' . $this->t('About') . '</h3>';
        return $output;

      default:
    }
  }

  /**
   * Implements hook_theme().
   */
  #[Hook('theme')]
  public static function theme() {
    $theme = [];
    $theme['storage'] = [
      'render element' => 'elements',
      'file' => 'storage.page.inc',
      'template' => 'storage',
    ];
    $theme['storage_content_add_list'] = [
      'render element' => 'content',
      'variables' => ['content' => NULL],
      'file' => 'storage.page.inc',
    ];
    return $theme;
  }

  /**
   * Implements hook_theme_suggestions_HOOK().
   */
  #[Hook('theme_suggestions_storage')]
  public static function themeSuggestionsStorage(array $variables) {
    $suggestions = [];
    $entity = $variables['elements']['#storage'];
    $sanitized_view_mode = strtr($variables['elements']['#view_mode'], '.', '_');

    $suggestions[] = 'storage__' . $sanitized_view_mode;
    $suggestions[] = 'storage__' . $entity->bundle();
    $suggestions[] = 'storage__' . $entity->bundle() . '__' . $sanitized_view_mode;
    $suggestions[] = 'storage__' . $entity->id();
    $suggestions[] = 'storage__' . $entity->id() . '__' . $sanitized_view_mode;
    return $suggestions;
  }

  /**
   * Implements hook_form_FORM_ID_alter().
   *
   * Adds a button 'Save and manage fields' to the 'Create storage type' form.
   *
   * @see \Drupal\node\NodeTypeForm
   * @see field_ui_form_node_type_form_submit()
   */
  #[Hook('form_storage_type_add_form_alter')]
  public function formStorageTypeAddFormAlter(&$form, FormStateInterface $form_state) {
    // We want to display the button only on add page.
    $form_object = $form_state->getFormObject();
    if ($form_object instanceof EntityFormInterface && $form_object->getEntity()->isNew()) {
      $form['actions']['save_continue'] = $form['actions']['submit'];
      $form['actions']['save_continue']['#value'] = $this->t('Save and manage fields');
      $form['actions']['save_continue']['#weight'] = $form['actions']['save_continue']['#weight'] + 5;
      $form['actions']['save_continue']['#submit'][] = 'storage_form_storage_type_add_form_submit';
      // Hide the 'Save content type' button.
      $form['actions']['submit']['#access'] = FALSE;
    }
  }

  /**
   * Implements hook_views_query_substitutions().
   */
  #[Hook('views_query_substitutions')]
  public static function viewsQuerySubstitutions(ViewExecutable $view) {
    $account = \Drupal::currentUser();
    return [
      '***VIEW_OWN_UNPUBLISHED_STORAGE***' => (int) $account->hasPermission('view own unpublished storage entities'),
      '***ADMINISTER_STORAGE_ENTITIES***' => (int) $account->hasPermission('administer storage entities'),
    ];
  }

  /**
   * Implements hook_inline_entity_form_entity_form_alter().
   */
  #[Hook('inline_entity_form_entity_form_alter')]
  public static function inlineEntityFormEntityFormAlter(array &$entity_form, FormStateInterface &$form_state) {
    if (isset($entity_form['#entity_type']) && $entity_form['#entity_type'] === 'storage') {
      /** @var \Drupal\storage\Entity\StorageInterface $storage */
      $storage = $entity_form['#entity'];
      $form_class = $storage->getEntityType()->getFormClass('default');
      $entity_form['#entity_builders']['apply_name_pattern'] = [
        $form_class,
        'applyNamePattern',
      ];
    }
  }

  /**
   * Implements hook_query_TAG_alter() for the "storage_access" tag.
   *
   * Every EntityQuery against the storage entity type is automatically
   * tagged "storage_access" when accessCheck(TRUE) is used (see
   * \Drupal\Core\Entity\Query\Sql\Query::execute()), and Views declares the
   * same tag as the "access query tag" for the storage_field_data base
   * table (see \Drupal\views\EntityViewsData::getViewsData()). This
   * implementation is what actually acts on that tag, so both get the same
   * per-bundle, permission-based filtering StorageAccessControlHandler
   * applies to individually loaded entities.
   *
   * Mirrors the pattern node module uses for its own "node_access" tag; see
   * \Drupal\node\Hook\NodeDatabaseHooks::queryNodeAccessAlter().
   */
  #[Hook('query_storage_access_alter')]
  public function queryStorageAccessAlter(AlterableInterface $query): void {
    // The query system only ever passes a Select query to a
    // hook_query_TAG_alter() implementation, so this always holds — even
    // though AlterableInterface itself doesn't declare SelectInterface's
    // methods. Same assumption \Drupal\node\Hook\NodeDatabaseHooks makes.
    assert($query instanceof SelectInterface);

    $account = $query->getMetaData('account') ?: $this->currentUser;
    if ($account->hasPermission('administer storage entities')) {
      return;
    }

    $base_table = $this->getStorageBaseTable($query);
    if (!$base_table) {
      return;
    }

    $or = $query->orConditionGroup();
    foreach (array_keys($this->bundleInfo->getBundleInfo('storage')) as $bundle) {
      $this->addBundleConditions($or, $base_table, $bundle, $account);
    }
    $query->condition($or);
  }

  /**
   * Adds the view-access conditions for a single bundle to a condition group.
   */
  protected function addBundleConditions(ConditionInterface $or, string $base_table, string $bundle, AccountInterface $account): void {
    if ($account->hasPermission('view published storage entities') || $account->hasPermission("view published $bundle storage entities")) {
      $or->condition((new Condition('AND'))
        ->condition("$base_table.status", 1)
        ->condition("$base_table.type", $bundle));
    }
    if ($account->hasPermission('view unpublished storage entities') || $account->hasPermission("view unpublished $bundle storage entities")) {
      $or->condition((new Condition('AND'))
        ->condition("$base_table.status", 0)
        ->condition("$base_table.type", $bundle));
    }
    elseif ($account->isAuthenticated() && ($account->hasPermission('view own unpublished storage entities') || $account->hasPermission("view own unpublished $bundle storage entities"))) {
      $or->condition((new Condition('AND'))
        ->condition("$base_table.status", 0)
        ->condition("$base_table.type", $bundle)
        ->condition("$base_table.user_id", $account->id()));
    }
  }

  /**
   * Determines the alias of the storage base table used in the query.
   *
   * Views (and other callers) may join storage_field_data under an alias
   * other than its table name, so this can't assume a fixed identifier —
   * same problem node's query alter solves via $query->getTables().
   */
  protected function getStorageBaseTable(AlterableInterface $query): ?string {
    if ($base_table = $query->getMetaData('base_table')) {
      return $base_table;
    }
    assert($query instanceof SelectInterface);

    $storage = $this->entityTypeManager->getStorage('storage');
    assert($storage instanceof SqlEntityStorageInterface);
    $storage_tables = $storage->getTableMapping()->getTableNames();

    $found = NULL;
    foreach ($query->getTables() as $alias => $table_info) {
      if ($table_info instanceof SelectInterface) {
        continue;
      }
      $table = $table_info['table'];
      // Prefer the data table: it's the one guaranteed to carry 'type',
      // 'status' and 'user_id' for a translatable, revisionable entity.
      if ($table === 'storage_field_data') {
        return $alias;
      }
      if (in_array($table, $storage_tables, TRUE)) {
        $found = $alias;
      }
    }

    return $found;
  }

  /**
   * Implements hook_theme_suggestions_HOOK_alter() for Site Studio compatibility.
   */
  #[Hook('theme_suggestions_storage_alter')]
  public static function themeSuggestionsStorageAlter(array &$suggestions, array &$variables) {
    // @todo Test if this can be moved into storage_theme_suggestions_storage().
    if (function_exists('cohesion_templates_suggestions')) {
      cohesion_templates_suggestions($suggestions, $variables['elements']['#storage'], $variables['elements']['#view_mode'], 'storage');
    }
  }

}
