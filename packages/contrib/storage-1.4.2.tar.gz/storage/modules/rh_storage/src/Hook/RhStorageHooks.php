<?php

namespace Drupal\rh_storage\Hook;

use Drupal\Core\Entity\EntityTypeInterface;
use Drupal\Core\Hook\Attribute\Hook;

/**
 * Hook implementations for rh_storage.
 */
class RhStorageHooks {

  /**
   * Implements hook_entity_base_field_info().
   */
  #[Hook('entity_base_field_info')]
  public static function entityBaseFieldInfo(EntityTypeInterface $entity_type) {
    if ($entity_type->id() == 'storage') {
      return \Drupal::service('rabbit_hole.entity_extender')
        ->getRabbitHoleFields('storage');
    }
  }

}
