<?php

declare(strict_types=1);

namespace Drupal\Tests\storage\Kernel;

use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;
use Drupal\KernelTests\Core\Entity\EntityKernelTestBase;
use Drupal\storage\Entity\Storage;
use Drupal\storage\Entity\StorageType;
use PHPUnit\Framework\Attributes\Group;

/**
 * Tests behavior of the Storage content entity.
 */
#[Group('storage')]
#[RunTestsInSeparateProcesses]
class StorageEntityTest extends EntityKernelTestBase {

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'user',
    'system',
    'field',
    'text',
    'storage',
  ];

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->installEntitySchema('storage');
    $this->installConfig(['storage']);

    // Uid 1 bypasses all permission checks, so burn it on a throwaway user
    // before creating the users used by the actual assertions below.
    $this->createUser();

    StorageType::create([
      'id' => 'article',
      'label' => 'Article',
    ])->save();
  }

  /**
   * Tests that preCreate() defaults the owner to the current user.
   */
  public function testPreCreateDefaultsOwnerToCurrentUser(): void {
    $account = $this->createUser();
    $this->setCurrentUser($account);

    $storage = Storage::create([
      'type' => 'article',
      'name' => 'Test item',
    ]);

    $this->assertSame((int) $account->id(), (int) $storage->getOwnerId());
  }

  /**
   * Tests that preCreate() disables the name pattern when a name is given.
   */
  public function testPreCreateDisablesNamePatternWhenNameProvided(): void {
    $type = StorageType::load('article');
    $type->setNamePattern('Type:[storage:type]');
    $type->save();

    $storage = Storage::create([
      'type' => 'article',
      'name' => 'Explicit name',
    ]);
    $storage->save();

    $this->assertSame('Explicit name', $storage->getName());
  }

  /**
   * Tests that preSave() falls back to the anonymous user as owner.
   */
  public function testPreSaveDefaultsOwnerToAnonymous(): void {
    $storage = Storage::create([
      'type' => 'article',
      'name' => 'Test item',
      'user_id' => NULL,
    ]);
    $storage->save();

    $this->assertSame(0, $storage->getOwnerId());
  }

  /**
   * Tests that preSave() defaults the revision author to the entity owner.
   */
  public function testPreSaveDefaultsRevisionUserToOwner(): void {
    $owner = $this->createUser();

    $storage = Storage::create([
      'type' => 'article',
      'name' => 'Test item',
      'user_id' => $owner->id(),
    ]);
    $storage->save();

    $this->assertSame((int) $owner->id(), (int) $storage->getRevisionUser()->id());
  }

  /**
   * Tests that an explicit revision author is not overridden.
   */
  public function testPreSavePreservesExplicitRevisionUser(): void {
    $owner = $this->createUser();
    $editor = $this->createUser();

    $storage = Storage::create([
      'type' => 'article',
      'name' => 'Test item',
      'user_id' => $owner->id(),
    ]);
    $storage->setRevisionUserId($editor->id());
    $storage->save();

    $this->assertSame((int) $editor->id(), (int) $storage->getRevisionUser()->id());
  }

  /**
   * Tests that the bundle's configured name pattern is applied on save.
   */
  public function testApplyNamePatternUsesBundlePattern(): void {
    $type = StorageType::load('article');
    $type->setNamePattern('Type:[storage:type]');
    $type->save();

    $storage = Storage::create([
      'type' => 'article',
    ]);
    $storage->save();

    $this->assertSame('Type:article', $storage->getName());
  }

  /**
   * Tests that an entity-level name pattern overrides the bundle's pattern.
   */
  public function testApplyNamePatternEntityLevelOverridesBundle(): void {
    $type = StorageType::load('article');
    $type->setNamePattern('Bundle:[storage:type]');
    $type->save();

    $storage = Storage::create([
      'type' => 'article',
    ]);
    $storage->name_pattern = 'Override:[storage:type]';
    $storage->save();

    $this->assertSame('Override:article', $storage->getName());
  }

  /**
   * Tests that a generated name longer than 255 characters is truncated.
   */
  public function testApplyNamePatternTruncatesLongNames(): void {
    $type = StorageType::load('article');
    $type->setNamePattern(str_repeat('a', 300));
    $type->save();

    $storage = Storage::create([
      'type' => 'article',
    ]);
    $storage->save();

    $this->assertLessThanOrEqual(255, mb_strlen($storage->getName()));
    $this->assertNotSame(str_repeat('a', 300), $storage->getName());
  }

  /**
   * Tests that hasLinkTemplate('canonical') respects the bundle setting.
   */
  public function testHasLinkTemplateCanonicalRespectsBundleSetting(): void {
    $type = StorageType::load('article');

    $storage = Storage::create([
      'type' => 'article',
      'name' => 'Test item',
    ]);
    $storage->save();

    $this->assertFalse($storage->hasLinkTemplate('canonical'));

    $type->set('has_canonical', TRUE)->save();
    \Drupal::entityTypeManager()->getStorage('storage_type')->resetCache();

    $this->assertTrue($storage->hasLinkTemplate('canonical'));
  }

  /**
   * Tests that getStringRepresentation() falls back to the label.
   */
  public function testGetStringRepresentationFallsBackToLabel(): void {
    $storage = Storage::create([
      'type' => 'article',
      'name' => 'Fallback label',
    ]);
    $storage->save();

    $this->assertSame('Fallback label', $storage->getStringRepresentation());
    $this->assertSame('Fallback label', (string) $storage);
  }

}
