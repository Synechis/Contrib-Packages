<?php

declare(strict_types=1);

namespace Drupal\Tests\storage\Kernel;

use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;
use Drupal\KernelTests\KernelTestBase;
use Drupal\storage\Entity\StorageType;
use Drupal\storage\StoragePermissions;
use PHPUnit\Framework\Attributes\Group;

/**
 * Tests dynamic per-bundle permission generation for Storage entities.
 */
#[Group('storage')]
#[RunTestsInSeparateProcesses]
class StoragePermissionsTest extends KernelTestBase {

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'user',
    'system',
    'field',
    'text',
    'storage',
  ];

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    StorageType::create([
      'id' => 'article',
      'label' => 'Article',
    ])->save();
    StorageType::create([
      'id' => 'page',
      'label' => 'Page',
    ])->save();
  }

  /**
   * Tests that permissions are generated for every bundle.
   */
  public function testGeneratesPermissionsForEachBundle(): void {
    $permissions = (new StoragePermissions())->generatePermissions();

    $expected_keys = [];
    foreach (['article', 'page'] as $bundle) {
      $expected_keys[] = "add $bundle storage entities";
      $expected_keys[] = "view published $bundle storage entities";
      $expected_keys[] = "view unpublished $bundle storage entities";
      $expected_keys[] = "view own unpublished $bundle storage entities";
      $expected_keys[] = "edit own $bundle storage entities";
      $expected_keys[] = "edit any $bundle storage entities";
      $expected_keys[] = "delete own $bundle storage entities";
      $expected_keys[] = "delete any $bundle storage entities";
      $expected_keys[] = "view $bundle storage revisions";
      $expected_keys[] = "revert $bundle storage revisions";
      $expected_keys[] = "delete $bundle storage revisions";
    }

    sort($expected_keys);
    $actual_keys = array_keys($permissions);
    sort($actual_keys);

    $this->assertSame($expected_keys, $actual_keys);
  }

  /**
   * Tests that sensitive permissions are flagged with 'restrict access'.
   */
  public function testRestrictedPermissionsAreFlagged(): void {
    $permissions = (new StoragePermissions())->generatePermissions();

    $this->assertTrue($permissions['view unpublished article storage entities']['restrict access']);
    $this->assertTrue($permissions['edit any article storage entities']['restrict access']);
    $this->assertTrue($permissions['delete any article storage entities']['restrict access']);
    $this->assertTrue($permissions['delete article storage revisions']['restrict access']);

    $this->assertArrayNotHasKey('restrict access', $permissions['add article storage entities']);
    $this->assertArrayNotHasKey('restrict access', $permissions['view published article storage entities']);
  }

  /**
   * Tests that each permission declares a config dependency on its bundle.
   */
  public function testPermissionsDependOnTheirBundleConfig(): void {
    $permissions = (new StoragePermissions())->generatePermissions();
    $type = StorageType::load('article');

    foreach ($permissions as $name => $permission) {
      if (!str_contains($name, 'article')) {
        continue;
      }
      $this->assertSame(
        [$type->getConfigDependencyName()],
        $permission['dependencies'][$type->getConfigDependencyKey()],
        "Permission '$name' should depend on the article Storage type config."
      );
    }
  }

}
