<?php

declare(strict_types=1);

namespace Drupal\Tests\storage\Kernel;

use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;
use Drupal\KernelTests\Core\Entity\EntityKernelTestBase;
use Drupal\storage\Entity\Storage;
use Drupal\storage\Entity\StorageType;
use PHPUnit\Framework\Attributes\Group;

/**
 * Tests the Storage entity access control handler.
 */
#[Group('storage')]
#[RunTestsInSeparateProcesses]
class StorageAccessControlHandlerTest extends EntityKernelTestBase {

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'user',
    'system',
    'field',
    'text',
    'storage',
  ];

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->installEntitySchema('storage');
    $this->installConfig(['storage']);

    // Uid 1 bypasses all permission checks, so burn it on a throwaway user
    // before creating the users used by the actual assertions below.
    $this->createUser();

    StorageType::create([
      'id' => 'article',
      'label' => 'Article',
    ])->save();
    StorageType::create([
      'id' => 'page',
      'label' => 'Page',
    ])->save();
  }

  /**
   * Creates a Storage entity with the given owner and published status.
   */
  protected function createStorage(string $bundle, int $owner_id, bool $published): Storage {
    $storage = Storage::create([
      'type' => $bundle,
      'name' => $this->randomString(),
      'user_id' => $owner_id,
      'status' => $published,
    ]);
    $storage->save();
    return $storage;
  }

  /**
   * Tests that the admin permission bypasses all other checks.
   */
  public function testAdministerBypassesAllChecks(): void {
    $admin = $this->createUser(['administer storage entities']);
    $entity = $this->createStorage('article', 0, FALSE);

    $access_handler = $this->entityTypeManager->getAccessControlHandler('storage');
    $this->assertTrue($access_handler->access($entity, 'view', $admin));
    $this->assertTrue($access_handler->access($entity, 'update', $admin));
    $this->assertTrue($access_handler->access($entity, 'delete', $admin));
  }

  /**
   * Tests viewing published Storage entities.
   */
  public function testViewPublished(): void {
    $entity = $this->createStorage('article', 0, TRUE);
    $access_handler = $this->entityTypeManager->getAccessControlHandler('storage');

    $no_permission = $this->createUser([]);
    $this->assertFalse($access_handler->access($entity, 'view', $no_permission));

    $with_global = $this->createUser(['view published storage entities']);
    $this->assertTrue($access_handler->access($entity, 'view', $with_global));

    $with_wrong_bundle = $this->createUser(['view published page storage entities']);
    $this->assertFalse($access_handler->access($entity, 'view', $with_wrong_bundle));

    $with_bundle = $this->createUser(['view published article storage entities']);
    $this->assertTrue($access_handler->access($entity, 'view', $with_bundle));
  }

  /**
   * Tests viewing unpublished Storage entities.
   */
  public function testViewUnpublished(): void {
    $entity = $this->createStorage('article', 0, FALSE);
    $access_handler = $this->entityTypeManager->getAccessControlHandler('storage');

    $with_published_only = $this->createUser(['view published storage entities']);
    $this->assertFalse($access_handler->access($entity, 'view', $with_published_only));

    $with_unpublished = $this->createUser(['view unpublished storage entities']);
    $this->assertTrue($access_handler->access($entity, 'view', $with_unpublished));

    $with_bundle_unpublished = $this->createUser(['view unpublished article storage entities']);
    $this->assertTrue($access_handler->access($entity, 'view', $with_bundle_unpublished));

    $with_wrong_bundle_unpublished = $this->createUser(['view unpublished page storage entities']);
    $this->assertFalse($access_handler->access($entity, 'view', $with_wrong_bundle_unpublished));
  }

  /**
   * Tests the 'view own unpublished' permissions.
   */
  public function testViewOwnUnpublished(): void {
    $owner = $this->createUser(['view own unpublished storage entities']);
    $entity = $this->createStorage('article', (int) $owner->id(), FALSE);
    $access_handler = $this->entityTypeManager->getAccessControlHandler('storage');

    $this->assertTrue($access_handler->access($entity, 'view', $owner));

    $non_owner = $this->createUser(['view own unpublished storage entities']);
    $this->assertFalse($access_handler->access($entity, 'view', $non_owner));

    $bundle_owner = $this->createUser(['view own unpublished article storage entities']);
    $bundle_entity = $this->createStorage('article', (int) $bundle_owner->id(), FALSE);
    $this->assertTrue($access_handler->access($bundle_entity, 'view', $bundle_owner));

    $wrong_bundle_owner = $this->createUser(['view own unpublished page storage entities']);
    $wrong_bundle_entity = $this->createStorage('article', (int) $wrong_bundle_owner->id(), FALSE);
    $this->assertFalse($access_handler->access($wrong_bundle_entity, 'view', $wrong_bundle_owner));
  }

  /**
   * Tests that an anonymously-owned entity never matches "own" permissions.
   */
  public function testOwnPermissionsIgnoreAnonymousOwnership(): void {
    // Anonymous-owned (uid 0) unpublished entity.
    $entity = $this->createStorage('article', 0, FALSE);
    $access_handler = $this->entityTypeManager->getAccessControlHandler('storage');

    $authenticated = $this->createUser(['view own unpublished storage entities']);
    $this->assertFalse($access_handler->access($entity, 'view', $authenticated));
  }

  /**
   * Tests updating Storage entities.
   */
  public function testUpdate(): void {
    $access_handler = $this->entityTypeManager->getAccessControlHandler('storage');

    $owner = $this->createUser(['edit own storage entities']);
    $own_entity = $this->createStorage('article', (int) $owner->id(), TRUE);
    $this->assertTrue($access_handler->access($own_entity, 'update', $owner));

    $non_owner = $this->createUser(['edit own storage entities']);
    $this->assertFalse($access_handler->access($own_entity, 'update', $non_owner));

    $with_any = $this->createUser(['edit storage entities']);
    $this->assertTrue($access_handler->access($own_entity, 'update', $with_any));

    $with_bundle_any = $this->createUser(['edit any article storage entities']);
    $this->assertTrue($access_handler->access($own_entity, 'update', $with_bundle_any));

    $with_wrong_bundle_any = $this->createUser(['edit any page storage entities']);
    $this->assertFalse($access_handler->access($own_entity, 'update', $with_wrong_bundle_any));
  }

  /**
   * Tests deleting Storage entities.
   */
  public function testDelete(): void {
    $access_handler = $this->entityTypeManager->getAccessControlHandler('storage');

    $owner = $this->createUser(['delete own storage entities']);
    $own_entity = $this->createStorage('article', (int) $owner->id(), TRUE);
    $this->assertTrue($access_handler->access($own_entity, 'delete', $owner));

    $non_owner = $this->createUser(['delete own storage entities']);
    $this->assertFalse($access_handler->access($own_entity, 'delete', $non_owner));

    $with_any = $this->createUser(['delete storage entities']);
    $this->assertTrue($access_handler->access($own_entity, 'delete', $with_any));

    $with_bundle_any = $this->createUser(['delete any article storage entities']);
    $this->assertTrue($access_handler->access($own_entity, 'delete', $with_bundle_any));
  }

  /**
   * Tests create access for Storage entities.
   */
  public function testCreateAccess(): void {
    $access_handler = $this->entityTypeManager->getAccessControlHandler('storage');

    $no_permission = $this->createUser([]);
    $this->assertFalse($access_handler->createAccess('article', $no_permission));

    $with_global = $this->createUser(['add storage entities']);
    $this->assertTrue($access_handler->createAccess('article', $with_global));

    $with_bundle = $this->createUser(['add article storage entities']);
    $this->assertTrue($access_handler->createAccess('article', $with_bundle));

    $with_wrong_bundle = $this->createUser(['add page storage entities']);
    $this->assertFalse($access_handler->createAccess('article', $with_wrong_bundle));

    $admin = $this->createUser(['administer storage entities']);
    $this->assertTrue($access_handler->createAccess('article', $admin));
  }

}
