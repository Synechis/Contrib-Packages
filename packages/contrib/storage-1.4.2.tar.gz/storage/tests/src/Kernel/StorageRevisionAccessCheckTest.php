<?php

declare(strict_types=1);

namespace Drupal\Tests\storage\Kernel;

use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;
use Drupal\KernelTests\Core\Entity\EntityKernelTestBase;
use Drupal\storage\Access\StorageRevisionAccessCheck;
use Drupal\storage\Entity\Storage;
use Drupal\storage\Entity\StorageType;
use Drupal\storage\StorageStorageInterface;
use PHPUnit\Framework\Attributes\Group;

/**
 * Tests access checking for Storage entity revisions.
 */
#[Group('storage')]
#[RunTestsInSeparateProcesses]
class StorageRevisionAccessCheckTest extends EntityKernelTestBase {

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'user',
    'system',
    'field',
    'text',
    'storage',
  ];

  /**
   * The revision access checker under test.
   */
  protected StorageRevisionAccessCheck $accessCheck;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->installEntitySchema('storage');
    $this->installConfig(['storage']);

    // Uid 1 bypasses all permission checks, so burn it on a throwaway user
    // before creating the users used by the actual assertions below.
    $this->createUser();

    StorageType::create([
      'id' => 'article',
      'label' => 'Article',
    ])->save();

    $this->accessCheck = new StorageRevisionAccessCheck($this->entityTypeManager);
  }

  /**
   * Tests that basic permissions are required regardless of revision state.
   */
  public function testBasicPermissionIsRequired(): void {
    $account = $this->createUser([]);
    $storage = $this->createSavedStorage();

    $this->assertFalse($this->accessCheck->checkAccess($storage, $account, 'view'));
    $this->assertFalse($this->accessCheck->checkAccess($storage, $account, 'update'));
    $this->assertFalse($this->accessCheck->checkAccess($storage, $account, 'delete'));
  }

  /**
   * Tests that the default revision can never be reverted or deleted.
   *
   * Even administrators cannot "revert" a storage item to its own current
   * revision, or delete the only/current revision.
   */
  public function testDefaultRevisionCannotBeRevertedOrDeleted(): void {
    $admin = $this->createUser(['administer storage entities']);
    $storage = $this->createSavedStorage();

    $this->assertTrue($storage->isDefaultRevision());
    $this->assertFalse($this->accessCheck->checkAccess($storage, $admin, 'update'));
    $this->assertFalse($this->accessCheck->checkAccess($storage, $admin, 'delete'));
  }

  /**
   * Tests that viewing the sole revision requires more than base permission.
   *
   * This applies when the bundle does not create new revisions by default.
   */
  public function testViewingSoleRevisionDeniedWhenBundleDoesNotVersionByDefault(): void {
    $type = StorageType::load('article');
    $type->setNewRevision(FALSE);
    $type->save();

    $account = $this->createUser(['view all storage revisions']);
    $storage = $this->createSavedStorage();

    $this->assertFalse($this->accessCheck->checkAccess($storage, $account, 'view'));
  }

  /**
   * Tests that viewing is allowed once the bundle creates new revisions.
   *
   * When a bundle's default is to create a new revision on every save, the
   * basic "view" permission is sufficient even for a single-revision item.
   */
  public function testViewingAllowedWhenBundleVersionsByDefault(): void {
    // The 'article' type keeps its default new_revision = TRUE setting.
    $account = $this->createUser(['view all storage revisions']);
    $storage = $this->createSavedStorage();

    $this->assertTrue($this->accessCheck->checkAccess($storage, $account, 'view'));
  }

  /**
   * Tests deleting a genuinely old (non-default) revision.
   */
  public function testDeletingAnOldRevision(): void {
    $type = StorageType::load('article');
    $type->setNewRevision(FALSE);
    $type->save();

    $storage = $this->createSavedStorage();
    $old_vid = $storage->getRevisionId();

    // Force a second revision so the first one becomes non-default.
    $storage->setNewRevision(TRUE);
    $storage->setName('Updated name');
    $storage->save();

    $old_revision = $this->getStorageHandler()->loadRevision($old_vid);
    $this->assertFalse($old_revision->isDefaultRevision());

    $admin = $this->createUser(['administer storage entities']);
    $this->assertTrue($this->accessCheck->checkAccess($old_revision, $admin, 'delete'));

    $with_permission_only = $this->createUser(['delete all storage revisions']);
    $this->assertFalse(
      $this->accessCheck->checkAccess($old_revision, $with_permission_only, 'delete'),
      'A user with only the revision permission but no entity delete access should be denied.'
    );

    $with_both = $this->createUser([
      'delete all storage revisions',
      'delete storage entities',
    ]);
    $this->assertTrue($this->accessCheck->checkAccess($old_revision, $with_both, 'delete'));
  }

  /**
   * Returns the Storage entity storage handler, typed for revision access.
   */
  protected function getStorageHandler(): StorageStorageInterface {
    /** @var \Drupal\storage\StorageStorageInterface $storage_handler */
    $storage_handler = $this->entityTypeManager->getStorage('storage');
    return $storage_handler;
  }

  /**
   * Creates and saves a Storage entity, returning the loaded entity.
   */
  protected function createSavedStorage(): Storage {
    $storage = Storage::create([
      'type' => 'article',
      'name' => $this->randomString(),
      'status' => TRUE,
    ]);
    $storage->save();
    return $storage;
  }

}
