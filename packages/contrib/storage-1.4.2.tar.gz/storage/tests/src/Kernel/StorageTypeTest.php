<?php

declare(strict_types=1);

namespace Drupal\Tests\storage\Kernel;

use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;
use Drupal\KernelTests\KernelTestBase;
use Drupal\storage\Entity\Storage;
use Drupal\storage\Entity\StorageType;
use PHPUnit\Framework\Attributes\Group;

/**
 * Tests the Storage type config entity.
 */
#[Group('storage')]
#[RunTestsInSeparateProcesses]
class StorageTypeTest extends KernelTestBase {

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'user',
    'system',
    'field',
    'text',
    'storage',
  ];

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();
    $this->installEntitySchema('user');
    $this->installEntitySchema('storage');
    $this->installConfig(['storage']);
  }

  /**
   * Tests default values for a newly created Storage type.
   */
  public function testDefaultValues(): void {
    $type = StorageType::create([
      'id' => 'article',
      'label' => 'Article',
    ]);

    $this->assertTrue($type->getStatus());
    $this->assertTrue($type->shouldCreateNewRevision());
    $this->assertFalse($type->shouldShowRevisionToggle());
    $this->assertFalse($type->shouldShowRevisionLog());
    $this->assertFalse($type->hasCanonical());
    $this->assertSame('', $type->getNamePattern());
  }

  /**
   * Tests that config export/import round-trips all exported properties.
   */
  public function testConfigExportRoundTrip(): void {
    StorageType::create([
      'id' => 'article',
      'label' => 'Article',
      'description' => 'An article Storage type.',
      'help' => 'Help text.',
      'new_revision' => FALSE,
      'revision_expose' => TRUE,
      'revision_log' => TRUE,
      'name_pattern' => '[storage:type]',
      'status' => FALSE,
      'has_canonical' => TRUE,
    ])->save();

    // Reload from config storage to ensure nothing was lost on save.
    \Drupal::entityTypeManager()->getStorage('storage_type')->resetCache();
    $type = StorageType::load('article');

    $this->assertSame('An article Storage type.', $type->getDescription());
    $this->assertSame('Help text.', $type->getHelp());
    $this->assertFalse($type->shouldCreateNewRevision());
    $this->assertTrue($type->shouldShowRevisionToggle());
    $this->assertTrue($type->shouldShowRevisionLog());
    $this->assertSame('[storage:type]', $type->getNamePattern());
    $this->assertFalse($type->getStatus());
    $this->assertTrue($type->hasCanonical());
  }

  /**
   * Tests that deleting a Storage type resets the config entity cache.
   */
  public function testPostDeleteResetsCache(): void {
    StorageType::create([
      'id' => 'article',
      'label' => 'Article',
    ])->save();

    $storage_handler = \Drupal::entityTypeManager()->getStorage('storage_type');
    // Prime the static cache.
    $storage_handler->loadMultiple(['article']);

    StorageType::load('article')->delete();

    $this->assertNull(StorageType::load('article'));
  }

  /**
   * Tests that the Storage entity type is wired up to its bundle type.
   */
  public function testBundleOfRelationship(): void {
    $entity_type = \Drupal::entityTypeManager()->getDefinition('storage');
    $this->assertSame('storage_type', $entity_type->getBundleEntityType());
    $this->assertSame(Storage::class, $entity_type->getClass());
  }

}
