<?php

declare(strict_types=1);

namespace Drupal\Tests\storage\Functional;

use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;
use Drupal\Tests\BrowserTestBase;
use Drupal\storage\Entity\Storage;
use Drupal\storage\Entity\StorageType;
use Drupal\storage\StorageStorageInterface;
use PHPUnit\Framework\Attributes\Group;

/**
 * Tests the revision UI (overview, revert, delete) for Storage entities.
 */
#[Group('storage')]
#[RunTestsInSeparateProcesses]
class StorageRevisionUiTest extends BrowserTestBase {

  /**
   * {@inheritdoc}
   */
  protected static $modules = ['storage'];

  /**
   * {@inheritdoc}
   */
  protected $defaultTheme = 'stark';

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    // Keep the default 'new_revision' setting (TRUE) so every save through
    // the UI creates a new revision automatically.
    StorageType::create([
      'id' => 'article',
      'label' => 'Article',
    ])->save();
  }

  /**
   * Tests that the revisions overview requires a distinct permission.
   *
   * 'administer storage entities' alone does not grant access: the route
   * requires the distinct 'view all storage revisions' permission.
   */
  public function testRevisionOverviewRequiresDedicatedPermission(): void {
    $storage = Storage::create([
      'type' => 'article',
      'name' => 'Item',
      'status' => TRUE,
    ]);
    $storage->save();

    $admin_only = $this->drupalCreateUser(['administer storage entities']);
    $this->drupalLogin($admin_only);
    $this->drupalGet('/storage/' . $storage->id() . '/revisions');
    $this->assertSession()->statusCodeEquals(403);

    $with_revisions = $this->drupalCreateUser([
      'administer storage entities',
      'view all storage revisions',
    ]);
    $this->drupalLogin($with_revisions);
    $this->drupalGet('/storage/' . $storage->id() . '/revisions');
    $this->assertSession()->statusCodeEquals(200);
  }

  /**
   * Tests reverting to an earlier revision and deleting an old revision.
   */
  public function testRevertAndDeleteRevision(): void {
    $admin = $this->drupalCreateUser([
      'administer storage entities',
      'view all storage revisions',
      'revert all storage revisions',
      'delete all storage revisions',
    ]);
    $this->drupalLogin($admin);

    $this->drupalGet('/storage/add/article');
    $this->submitForm(['name[0][value]' => 'Version 1'], 'Save');
    $storage = $this->loadStorageByName('Version 1');
    $this->assertNotNull($storage);

    $this->drupalGet('/storage/' . $storage->id() . '/edit');
    $this->submitForm(['name[0][value]' => 'Version 2'], 'Save');

    $storage_handler = $this->getStorageHandler();
    $vids = $storage_handler->revisionIds($storage);
    $this->assertCount(2, $vids);
    [$old_vid] = $vids;

    $this->drupalGet('/storage/' . $storage->id() . '/revisions');
    $this->assertSession()->statusCodeEquals(200);
    $this->assertSession()->pageTextContains('Current revision');
    $this->assertSession()->linkExists('Revert');

    $this->drupalGet('/storage/' . $storage->id() . '/revisions/' . $old_vid . '/revert');
    $this->assertSession()->statusCodeEquals(200);
    $this->submitForm([], 'Revert');
    $this->assertSession()->pageTextContains('Storage Version 1 has been reverted');

    $storage_handler->resetCache([$storage->id()]);
    $reloaded = $this->loadStorage($storage_handler, $storage->id());
    $this->assertSame('Version 1', $reloaded->getName());

    $vids_after_revert = $storage_handler->revisionIds($reloaded);
    $this->assertCount(3, $vids_after_revert);
    $vid_to_delete = $vids_after_revert[0];

    $this->drupalGet('/storage/' . $storage->id() . '/revisions/' . $vid_to_delete . '/delete');
    $this->assertSession()->statusCodeEquals(200);
    $this->submitForm([], 'Delete');
    $this->assertSession()->pageTextContains('has been deleted');

    $storage_handler->resetCache([$storage->id()]);
    $vids_after_delete = $storage_handler->revisionIds($this->loadStorage($storage_handler, $storage->id()));
    $this->assertCount(2, $vids_after_delete);
  }

  /**
   * Returns the Storage entity storage handler, typed for revision access.
   */
  protected function getStorageHandler(): StorageStorageInterface {
    /** @var \Drupal\storage\StorageStorageInterface $storage_handler */
    $storage_handler = \Drupal::entityTypeManager()->getStorage('storage');
    return $storage_handler;
  }

  /**
   * Loads a single Storage entity by ID.
   */
  protected function loadStorage(StorageStorageInterface $storage_handler, int|string $id): Storage {
    /** @var \Drupal\storage\Entity\Storage $entity */
    $entity = $storage_handler->load($id);
    return $entity;
  }

  /**
   * Loads a Storage entity by its name field.
   */
  protected function loadStorageByName(string $name): ?Storage {
    $storage_handler = $this->getStorageHandler();
    $ids = $storage_handler->getQuery()
      ->condition('name', $name)
      ->accessCheck(FALSE)
      ->execute();
    return $ids ? $this->loadStorage($storage_handler, (int) reset($ids)) : NULL;
  }

}
