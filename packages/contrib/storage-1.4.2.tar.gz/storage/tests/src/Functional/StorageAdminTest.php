<?php

declare(strict_types=1);

namespace Drupal\Tests\storage\Functional;

use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;
use Drupal\Tests\BrowserTestBase;
use Drupal\storage\Entity\Storage;
use Drupal\storage\Entity\StorageType;
use PHPUnit\Framework\Attributes\Group;

/**
 * Tests the administrative UI for Storage entities.
 */
#[Group('storage')]
#[RunTestsInSeparateProcesses]
class StorageAdminTest extends BrowserTestBase {

  /**
   * {@inheritdoc}
   */
  protected static $modules = ['storage', 'field_ui'];

  /**
   * {@inheritdoc}
   */
  protected $defaultTheme = 'stark';

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    StorageType::create([
      'id' => 'article',
      'label' => 'Article',
    ])->save();
  }

  /**
   * Tests the full add/view/edit/delete cycle for an administrator.
   */
  public function testAdminCanCreateEditAndDeleteStorage(): void {
    $admin = $this->drupalCreateUser(['administer storage entities']);
    $this->drupalLogin($admin);

    $this->drupalGet('/storage/add/article');
    $this->assertSession()->statusCodeEquals(200);

    $this->submitForm(['name[0][value]' => 'My Storage Item'], 'Save');
    $this->assertSession()->pageTextContains('Article My Storage Item has been created.');

    $storage = $this->loadStorageByName('My Storage Item');
    $this->assertNotNull($storage);

    $this->drupalGet('/storage/' . $storage->id() . '/edit');
    $this->assertSession()->statusCodeEquals(200);
    $this->submitForm(['name[0][value]' => 'Renamed Item'], 'Save');
    $this->assertSession()->pageTextContains('Article Renamed Item has been saved.');

    $this->drupalGet('/storage/' . $storage->id() . '/delete');
    $this->assertSession()->statusCodeEquals(200);
    $this->submitForm([], 'Delete');
    $this->assertSession()->pageTextContains('The Article Renamed Item has been deleted.');
    $this->assertNull($this->loadStorageByName('Renamed Item'));
  }

  /**
   * Tests that the add form is only reachable with the right permission.
   */
  public function testAddFormRequiresPermission(): void {
    $no_permission = $this->drupalCreateUser([]);
    $this->drupalLogin($no_permission);

    $this->drupalGet('/storage/add/article');
    $this->assertSession()->statusCodeEquals(403);

    $with_permission = $this->drupalCreateUser(['add article storage entities']);
    $this->drupalLogin($with_permission);

    $this->drupalGet('/storage/add/article');
    $this->assertSession()->statusCodeEquals(200);
  }

  /**
   * Tests canonical URL behavior when the bundle has no canonical page.
   *
   * With no canonical page enabled, visiting the canonical URL should
   * redirect editors to the edit form and 404 for everyone else.
   */
  public function testCanonicalRedirectsToEditFormWhenDisabled(): void {
    $owner = $this->drupalCreateUser(['edit own storage entities']);
    $storage = Storage::create([
      'type' => 'article',
      'name' => 'No canonical item',
      'user_id' => $owner->id(),
      'status' => TRUE,
    ]);
    $storage->save();

    $this->drupalLogin($owner);
    $this->drupalGet('/storage/' . $storage->id());
    $this->assertStringContainsString('/storage/' . $storage->id() . '/edit', $this->getUrl());
    $this->assertSession()->statusCodeEquals(200);

    $viewer = $this->drupalCreateUser(['view published storage entities']);
    $this->drupalLogin($viewer);
    $this->drupalGet('/storage/' . $storage->id());
    $this->assertSession()->statusCodeEquals(404);
  }

  /**
   * Tests canonical URL access once the bundle has canonical pages enabled.
   */
  public function testCanonicalViewWhenEnabled(): void {
    StorageType::load('article')->set('has_canonical', TRUE)->save();

    $storage = Storage::create([
      'type' => 'article',
      'name' => 'Canonical item',
      'status' => TRUE,
    ]);
    $storage->save();

    $viewer = $this->drupalCreateUser(['view published storage entities']);
    $this->drupalLogin($viewer);
    $this->drupalGet('/storage/' . $storage->id());
    $this->assertSession()->statusCodeEquals(200);
    $this->assertSession()->pageTextContains('Canonical item');

    $no_permission = $this->drupalCreateUser([]);
    $this->drupalLogin($no_permission);
    $this->drupalGet('/storage/' . $storage->id());
    $this->assertSession()->statusCodeEquals(403);
  }

  /**
   * Tests the "Save and manage fields" button on the type add form.
   */
  public function testStorageTypeAddFormSaveAndManageFields(): void {
    $admin = $this->drupalCreateUser(['administer site configuration', 'administer storage fields']);
    $this->drupalLogin($admin);

    $this->drupalGet('/admin/structure/storage_types/add');
    $this->assertSession()->statusCodeEquals(200);
    $this->assertSession()->buttonExists('Save and manage fields');

    $this->submitForm([
      'label' => 'Note',
      'id' => 'note',
    ], 'Save and manage fields');

    $this->assertStringContainsString('/admin/structure/storage_types/note/edit/fields', $this->getUrl());
  }

  /**
   * Loads a Storage entity by its name field.
   */
  protected function loadStorageByName(string $name): ?Storage {
    $storage_handler = \Drupal::entityTypeManager()->getStorage('storage');
    $ids = $storage_handler->getQuery()
      ->condition('name', $name)
      ->accessCheck(FALSE)
      ->execute();
    return $ids ? $storage_handler->load(reset($ids)) : NULL;
  }

}
