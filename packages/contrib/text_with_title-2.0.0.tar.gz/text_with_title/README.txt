Text with Title Field
