<?php

namespace Drupal\event_platform_details\Plugin\Block;

use Drupal\content_moderation\ModerationInformationInterface;
use Drupal\Component\Serialization\Json;
use Drupal\Core\Block\BlockBase;
use Drupal\Core\Block\BlockPluginInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Language\LanguageInterface;
use Drupal\Core\Language\LanguageManagerInterface;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\Core\Url;
use Drupal\event_platform_details\EventHelper;
use Drupal\storage\Entity\Storage;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\RequestStack;

/**
 * Provides an event platform header cta block.
 *
 * @Block(
 *   id = "event_platform_header_cta",
 *   admin_label = @Translation("Event Platform Header CTA"),
 *   category = @Translation("Event Platform")
 * )
 */
class EventPlatformHeaderCtaBlock extends BlockBase implements BlockPluginInterface, ContainerFactoryPluginInterface {

  /**
   * The entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * The event helper service.
   *
   * @var \Drupal\event_platform_details\EventHelper
   */
  protected $eventHelper;

  /**
   * The language manager service.
   *
   * @var \Drupal\Core\Language\LanguageManagerInterface
   */
  protected $languageManager;

  /**
   * The moderation information service.
   *
   * @var \Drupal\content_moderation\ModerationInformationInterface
   */
  protected $moderationInfo;

  /**
   * The request stack.
   *
   * @var \Symfony\Component\HttpFoundation\RequestStack
   */
  protected $requestStack;

  /**
   * Constructs a new MyCustomBlock instance.
   *
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   * @param string $plugin_id
   *   The plugin ID for the plugin instance.
   * @param mixed $plugin_definition
   *   The plugin definition for the plugin instance.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The entity type manager.
   * @param \Drupal\event_platform_details\EventHelper $event_helper
   *   The event helper service.
   * @param \Drupal\Core\Language\LanguageManagerInterface $language_manager
   *   The language manager service.
   * @param \Drupal\content_moderation\ModerationInformationInterface $moderation_info
   *   The moderation information service.
   * @param \Symfony\Component\HttpFoundation\RequestStack $request_stack
   *   The request stack.
   */
  public function __construct(array $configuration, $plugin_id, $plugin_definition, EntityTypeManagerInterface $entity_type_manager, EventHelper $event_helper, LanguageManagerInterface $language_manager, ModerationInformationInterface $moderation_info, RequestStack $request_stack) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
    $this->entityTypeManager = $entity_type_manager;
    $this->eventHelper = $event_helper;
    $this->languageManager = $language_manager;
    $this->moderationInfo = $moderation_info;
    $this->requestStack = $request_stack;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('entity_type.manager'),
      $container->get('event_platform_details.event_helper'),
      $container->get('language_manager'),
      $container->get('content_moderation.moderation_information'),
      $container->get('request_stack')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function blockForm($form, FormStateInterface $form_state) {
    $options = [
      '' => '- Select -',
    ];
    // Retrieve available CTAs and add as options.
    $ctas = $this->entityTypeManager->getStorage('storage')->loadByProperties(['type' => 'cta']);
    foreach ($ctas as $id => $cta) {
      $options[$id] = $cta->get('field_link')->first()->getString();
    }

    // Retrieve available workflow states for events.
    $moderation_info = $this->moderationInfo;
    $workflow = $moderation_info->getWorkflowForEntityTypeAndBundle('taxonomy_term', 'event');
    $type_settings = $workflow->get('type_settings');
    uasort($type_settings['states'], ['Drupal\Component\Utility\SortArray', 'sortByWeightElement']);

    // Keep an array of processed states to aid in saving to configuration.
    $state_options = [];
    foreach ($type_settings['states'] as $type => $settings) {
      if ($type === 'draft') {
        // Draft state isn't really used, so set a default CTA instead.
        $type = 'default';
        $label = $this->t('Default');
        $description = $this->t('Choose which link to use as a default.');
        $required = TRUE;
      }
      else {
        $label = $settings['label'];
        $description = $this->t('Choose which link to use for the @state moderation state.', ['@state' => $settings['label']]);
        $required = FALSE;
      }
      $state_options[] = $type;
      $form[$type . '_state_link'] = [
        '#type' => 'select',
        '#title' => $this->t('@state link', ['@state' => $label]),
        '#description' => $description,
        '#default_value' => $this->configuration[$type . '_state_link'] ?? '',
        '#options' => $options,
        '#required' => $required,
      ];
    }

    $form['states'] = [
      '#type' => 'value',
      '#value' => $state_options,
    ];

    $current_path = $path = $this->requestStack->getCurrentRequest()->getPathInfo();

    // Add a link to create a new CTA.
    $form['add_cta'] = [
      '#type' => 'link',
      '#url' => Url::fromRoute('entity.storage.add_form', ['storage_type' => 'cta', 'destination' => $current_path]),
      '#title' => 'Add a CTA',
      '#attributes' => [
        'id' => 'add-cta-dialog',
        'class' => ['use-ajax', 'button', 'button-secondary'],
        'data-dialog-type' => 'modal',
        'data-dialog-options' => Json::encode([
          'width' => 700,
          'minHeight' => 500,
          'title' => $this->t('New CTA'),
        ]),
      ],
    ];

    // Add a link to manage CTAs.
    $form['manage_ctas'] = [
      '#type' => 'link',
      '#url' => Url::fromRoute('view.ctas.page_1', ['destination' => $current_path]),
      '#title' => 'Manage CTAs',
      '#attributes' => [
        'id' => 'add-cta-dialog',
        'class' => ['use-ajax', 'button', 'button-secondary'],
        'data-dialog-type' => 'modal',
        'data-dialog-options' => Json::encode([
          'width' => 700,
          'minHeight' => 500,
          'title' => $this->t('Manage CTAs'),
        ]),
      ],
    ];
    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function blockSubmit($form, FormStateInterface $form_state) {
    $states = $form_state->getValue('states');
    if (!is_array($states)) {
      return;
    }
    foreach ($states as $state) {
      $this->configuration[$state . '_state_link'] = $form_state->getValue($state . '_state_link');
    }
  }

  /**
   * {@inheritdoc}
   */
  public function build() {
    $build = [];
    $event = $this->eventHelper->determineEvent();
    if (!$event) {
      return $this->getEmptyMarkup();
    }
    $state = $event->get('moderation_state')->value;
    $link = $this->configuration[$state . '_state_link'];
    if (empty($link) && !empty($this->configuration['default_state_link'])) {
      $link = $this->configuration['default_state_link'];
    }

    if ($link) {
      $langcode = $this->languageManager
        ->getCurrentLanguage(LanguageInterface::TYPE_CONTENT)
        ->getId();

      $link_entity = Storage::load($link);
      if ($link_entity->hasTranslation($langcode)) {
        $link_entity = $link_entity->getTranslation($langcode);
      }
      $cta_url = $link_entity->get('field_link')->uri ?? NULL;
      $cta_title = $link_entity->get('field_link')->title ?? NULL;
    }
    if (!$link || !$cta_url || !$cta_title) {
      // Invalid input so return an empty array.
      return $this->getEmptyMarkup();
    }

    $url = Url::fromUri($cta_url);
    $block = [
      '#theme' => 'event_platform_header_cta_block',
      '#attributes' => [
        'class' => ['site-header__register'],
        'id' => 'header-cta-block',
      ],
      '#url'  => $url,
      '#title'  => $cta_title,
      '#cache' => [
        'tags' => ['storage:' . $link, 'taxonomy_term:' . $event->id()],
        'context' => ['url.path'],
      ],
    ];
    $build['event_platform_header_cta'] = $block;
    return $build;
  }

  /**
   * Returns a render array for an empty value.
   *
   * @return array
   *   The empty markup.
   */
  protected function getEmptyMarkup() {
    return [
      'event_platform_header_cta' => [
        '#cache' => [
          'tags' => ['storage_list:cta'],
        ],
      ],
    ];
  }

}
