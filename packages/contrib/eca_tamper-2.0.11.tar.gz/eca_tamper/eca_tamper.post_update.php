<?php

/**
 * @file
 * Contains post_update hooks for eca_tamper.
 */

/**
 * Corrects where stored models keep the wrapped tamper plugin ID.
 *
 * ECA writes "original_id" onto the action or condition item itself, next to
 * "label", "plugin", "configuration" and "successors", and both schema
 * sections of this module read it from there through
 * "tamper.[%parent.original_id]". This update brings stored models into that
 * shape. Each tamper item is treated on its own, and the two halves below are
 * independent of one another: a model can need either, both, or neither.
 *
 * A copy of the key inside "configuration" is removed. Such a copy is of no
 * use to anyone: the wrapped tamper plugin does not know the key, no schema
 * section declares it, and configuration validation consequently reports it as
 * a key without a schema. No tagged release of this module ever wrote one, so
 * the only sites that can have it are those that tracked the 2.0.x branch
 * while the change which introduced it was on it.
 *
 * A missing item level key is filled in. That is the shape of a model authored
 * as YAML by hand, and of one stored before ECA began writing the key. Without
 * it the type expression collapses to the literal "tamper.", no such section
 * exists, the wrapped tamper plugin's schema is never inherited, and its own
 * keys keep being reported as having no schema until somebody happens to
 * re-save that model. A key that is already there is left alone, whatever it
 * says: this update closes a gap, it does not audit the models it walks over.
 *
 * The value is derived from the stored plugin ID rather than from the plugin
 * definition. Both derivers key their derivatives by the tamper plugin ID and
 * core builds a derivative plugin ID as "<base plugin ID>:<derivative key>",
 * so the segment behind the prefix is exactly what "original_id" has to carry.
 * Not consulting the definition also keeps this update working for a model
 * that references a tamper plugin which is no longer installed - such a model
 * needs attention either way, but this update is not what should fail over it.
 *
 * Only the plugins of this module are touched. Items of other providers can
 * lack the item level key just as well, but they are not this module's to fix.
 *
 * @return string
 *   The message about which models were corrected.
 *
 * @see \Drupal\eca\Entity\Eca::addAction()
 * @see \Drupal\eca\Entity\Eca::addCondition()
 * @see \Drupal\eca_tamper\Plugin\Action\TamperDeriver::getDerivativeDefinitions()
 * @see \Drupal\eca_tamper\Plugin\ECA\Condition\TamperDeriver::getDerivativeDefinitions()
 * @see \Drupal\Component\Plugin\Discovery\DerivativeDiscoveryDecorator::encodePluginId()
 * @see https://www.drupal.org/project/eca_tamper/issues/3582653
 */
function eca_tamper_post_update_fix_original_id(): string {
  // The property of an ECA model holding plugin items, mapped to the plugin ID
  // prefix that identifies a wrapped tamper plugin in it. The separator is part
  // of the prefix on purpose: without it, an unrelated plugin whose ID merely
  // begins with "eca_tamper" would be touched as well, and the action prefix
  // would swallow the condition one.
  $prefixes = [
    'actions' => 'eca_tamper:',
    'conditions' => 'eca_tamper_condition:',
  ];

  $configFactory = \Drupal::configFactory();
  $updated = [];
  $prefixLength = strlen('eca.eca.');

  foreach ($configFactory->listAll('eca.eca.') as $name) {
    // Work on the raw configuration. Going through the config entity would
    // instantiate every plugin of every model, which turns an unrelated broken
    // model into a failure of this update, and it would rewrite properties that
    // have nothing to do with the key being corrected here.
    $config = $configFactory->getEditable($name);
    $changed = FALSE;

    foreach ($prefixes as $property => $prefix) {
      $items = $config->get($property);
      if (!is_array($items)) {
        continue;
      }
      $propertyChanged = FALSE;
      foreach ($items as $id => $item) {
        $plugin = $item['plugin'] ?? NULL;
        if (!is_string($plugin) || !str_starts_with($plugin, $prefix)) {
          continue;
        }

        $configuration = $item['configuration'] ?? NULL;
        if (is_array($configuration) && array_key_exists('original_id', $configuration)) {
          unset($configuration['original_id']);
          $items[$id]['configuration'] = $configuration;
          $propertyChanged = TRUE;
        }

        // An empty string is as unusable to the schema as no key at all - both
        // leave the type expression at the literal "tamper." - so both count as
        // the key being absent.
        $originalId = $item['original_id'] ?? NULL;
        if (!is_string($originalId) || $originalId === '') {
          // Appended rather than inserted, which is where ECA itself puts the
          // key: it assigns it after "configuration" and "successors".
          $items[$id]['original_id'] = substr($plugin, strlen($prefix));
          $propertyChanged = TRUE;
        }
      }
      if ($propertyChanged) {
        $config->set($property, $items);
        $changed = TRUE;
      }
    }

    if ($changed) {
      // Saved as trusted data, so that core does not re-cast the whole object
      // against the schema on the way out. That casting rebuilds every mapping
      // in schema order, which would leave site owners who keep their
      // configuration in version control with a reordering of each touched
      // model instead of the one or two lines this update is responsible for.
      // The data being written is what was read back out of the same store,
      // give or take a string.
      $config->save(TRUE);
      $updated[] = substr($name, $prefixLength);
    }
  }

  return $updated === []
    ? 'No ECA model needed the tamper plugin ID to be corrected.'
    : sprintf('Corrected the tamper plugin ID in %d ECA model(s): %s.', count($updated), implode(', ', $updated));
}
