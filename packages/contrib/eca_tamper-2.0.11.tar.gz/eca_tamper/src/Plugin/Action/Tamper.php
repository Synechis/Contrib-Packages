<?php

namespace Drupal\eca_tamper\Plugin\Action;

use Drupal\Core\Action\Attribute\Action;
use Drupal\Core\Form\FormStateInterface;
use Drupal\eca\Attribute\EcaAction;
use Drupal\eca\Plugin\Action\ConfigurableActionBase;
use Drupal\eca_tamper\Plugin\TamperTrait;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Provide all tamper plugins as ECA actions.
 */
#[Action(
  id: 'eca_tamper',
  deriver: 'Drupal\eca_tamper\Plugin\Action\TamperDeriver',
)]
#[EcaAction(
  version_introduced: '1.0.0',
)]
class Tamper extends ConfigurableActionBase {

  use TamperTrait;

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition): static {
    $instance = parent::create($container, $configuration, $plugin_id, $plugin_definition);
    $instance->tamperManager = $container->get('plugin.manager.tamper');
    return $instance;
  }

  /**
   * {@inheritdoc}
   *
   * @throws \Drupal\Component\Plugin\Exception\PluginException
   * @throws \Drupal\Core\TypedData\Exception\MissingDataException
   */
  public function execute(): void {
    $value = $this->doTamper('eca_data', 'eca_token_name');
    if ($value instanceof \stdClass) {
      $value = $this->convertPlainObject($value);
    }
    $this->tokenService->addTokenData($this->configuration['eca_token_name'], $value);
  }

  /**
   * Converts a plain object into a nested associative array.
   *
   * A tamper plugin may return an object, currently only "encode" in
   * "unserialize" mode, and the token service has nowhere to put one: a value
   * without a token type is wrapped in a DataTransferObject, which accepts an
   * associative array and nothing else.
   *
   * Only \stdClass is offered to this method, and that narrowing is the point.
   * An object of any other class either has a token type already, an entity
   * being the common case, and is then stored and resolved as itself, or it
   * converts in a way that is lossy and particular to its class. Converting on
   * "is_object()" instead loses those objects: an entity keeps its values
   * behind field objects rather than in public properties and would arrive as
   * an empty array.
   *
   * The conversion has to be recursive, because an object restored by
   * unserialize() can hold further objects and a "(array)" cast converts only
   * the outermost level, leaving the ones below it to be rejected as well. The
   * rejection then comes from the check the DTO makes on an individual value
   * rather than the one it makes on the value as a whole, so the message
   * differs, but the outcome is the same InvalidArgumentException and the same
   * unusable token. A round trip through JSON recurses for free, and it also
   * declines the two inputs that a hand written recursion would get wrong: an
   * object that refers to itself, which such a recursion would follow until it
   * runs out of memory, and a string that is not valid UTF-8. Both raise a
   * JsonException here instead.
   *
   * @param \stdClass $value
   *   The plain object returned by the tamper plugin.
   *
   * @return array|\stdClass
   *   The converted value, or the object unchanged if it cannot be converted.
   */
  protected function convertPlainObject(\stdClass $value): array|\stdClass {
    try {
      $converted = json_decode(json_encode($value, JSON_THROW_ON_ERROR), TRUE, 512, JSON_THROW_ON_ERROR);
    }
    catch (\JsonException $e) {
      // The value is deliberately returned unchanged. Substituting NULL here
      // would discard what the user asked to be tampered without telling them,
      // while leaving the object in place keeps the token service's own
      // complaint about it, so the failure stays visible.
      $this->logger->error('The tamper plugin %plugin returned an object that cannot be converted into token data for %token: @message. The value is passed on unchanged.', [
        '%plugin' => $this->pluginDefinition['original_id'] ?? $this->getPluginId(),
        '%token' => $this->configuration['eca_token_name'],
        '@message' => $e->getMessage(),
      ]);
      return $value;
    }
    return is_array($converted) ? $converted : $value;
  }

  /**
   * {@inheritdoc}
   */
  public function defaultConfiguration(): array {
    return [
      'eca_data' => '',
      'eca_token_name' => '',
    ] + $this->tamperDefaultConfiguration();
  }

  /**
   * {@inheritdoc}
   */
  public function buildConfigurationForm(array $form, FormStateInterface $form_state): array {
    $form['eca_data'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Data to be tampered'),
      '#default_value' => $this->configuration['eca_data'],
      '#required' => TRUE,
      '#weight' => -10,
      '#eca_token_replacement' => TRUE,
    ];
    $form['eca_token_name'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Result token name'),
      '#description' => $this->t('Provide a token name under which the tampered result will be made available for subsequent actions.'),
      '#default_value' => $this->configuration['eca_token_name'],
      '#required' => TRUE,
      '#weight' => 99,
    ];
    return $this->buildTamperConfigurationForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function validateConfigurationForm(array &$form, FormStateInterface $form_state): void {
    $this->validateTamperConfigurationForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function submitConfigurationForm(array &$form, FormStateInterface $form_state): void {
    $this->configuration['eca_data'] = $form_state->getValue('eca_data');
    $this->configuration['eca_token_name'] = $form_state->getValue('eca_token_name');
    $this->submitTamperConfigurationForm($form, $form_state);
    $this->configuration = $this->tamperPlugin()->getConfiguration() + $this->configuration;
  }

}
