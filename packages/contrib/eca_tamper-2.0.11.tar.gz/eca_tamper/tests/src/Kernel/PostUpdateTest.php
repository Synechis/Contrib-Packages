<?php

namespace Drupal\Tests\eca_tamper\Kernel;

use Drupal\Core\Config\ConfigCrudEvent;
use Drupal\Core\Config\ConfigEvents;
use Drupal\Core\Config\StorageInterface;
use Drupal\Core\Config\TypedConfigManagerInterface;
use Drupal\Tests\SchemaCheckTestTrait;

/**
 * Tests that stored models get the tamper plugin ID put where it belongs.
 *
 * ECA keeps "original_id" on the action or condition item, and both schema
 * sections of this module read it from there. The update has two halves, and
 * this covers both of them.
 *
 * A copy of the key inside "configuration" is declared by no schema and means
 * nothing to the wrapped tamper plugin, so a model carrying one is reported as
 * having a key without a schema. Only 2.0.x development sites can have such a
 * model, and the update cleans them up.
 *
 * A model missing the item level key leaves the type expression unresolved, so
 * the wrapped tamper plugin's own keys are the ones reported as having no
 * schema. Any model authored as YAML by hand is in that state, and the update
 * fills the key in from the stored plugin ID.
 *
 * @see eca_tamper_post_update_fix_original_id()
 */
class PostUpdateTest extends EcaTamperKernelTestBase {

  use SchemaCheckTestTrait;

  /**
   * The tamper plugin used as the probe throughout this test.
   *
   * The "encode" plugin ships its own schema section "tamper.encode" which
   * declares the key "mode", and its "itemUsage" is "ignored" rather than
   * "required", so both TamperDeriver classes derive it into ECA.
   */
  protected const TAMPER_PLUGIN_ID = 'encode';

  /**
   * The schema key that the "tamper.encode" section contributes.
   */
  protected const TAMPER_PLUGIN_KEY = 'mode';

  /**
   * The ID of the model that stands in for one stored on a site.
   */
  protected const MODEL_ID = 'eca_tamper_stray';

  /**
   * The configuration name of that model.
   */
  protected const MODEL_NAME = 'eca.eca.' . self::MODEL_ID;

  /**
   * The key of the tamper action inside the model.
   */
  protected const ACTION_ID = 'Activity_tamper';

  /**
   * The key of the tamper condition inside the model.
   */
  protected const CONDITION_ID = 'Flow_tamper';

  /**
   * The message the update returns when it found nothing to do.
   */
  protected const MESSAGE_UNCHANGED = 'No ECA model needed the tamper plugin ID to be corrected.';

  /**
   * The typed config manager.
   */
  protected TypedConfigManagerInterface $typedConfig;

  /**
   * The active configuration storage.
   */
  protected StorageInterface $configStorage;

  /**
   * The names of the configuration objects saved so far.
   *
   * The update has to save a model it actually changed and nothing else, and a
   * save is not observable in the stored data. Recording the save events is,
   * and it also makes the strict schema check of the test base part of the
   * assertion: a save of configuration the update left invalid would fail here.
   *
   * @var string[]
   */
  protected array $saved = [];

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->typedConfig = \Drupal::service('config.typed');
    $this->configStorage = \Drupal::service('config.storage');

    // Update files are not autoloaded, so pull it in the same way core does
    // before it invokes a post-update function.
    // @see update_invoke_post_update()
    \Drupal::moduleHandler()->loadInclude('eca_tamper', 'php', 'eca_tamper.post_update');

    \Drupal::service('event_dispatcher')->addListener(
      ConfigEvents::SAVE,
      function (ConfigCrudEvent $event): void {
        $this->saved[] = $event->getConfig()->getName();
      }
    );
  }

  /**
   * Tests that a model carrying the stray key becomes valid.
   *
   * The before and after schema checks are the point of this test: the stray
   * key is a key without a schema, and afterwards the model has none.
   */
  public function testStrayKeyIsRemoved(): void {
    $this->skipUnlessEcaValidatesPluginConfiguration();

    $this->store(self::MODEL_NAME, $this->strayModelData());

    // Before: the copy inside the configuration is declared nowhere, on either
    // ECA side.
    $before = $this->schemaErrors(self::MODEL_NAME);
    foreach ($this->strayKeyPaths() as $path) {
      $key = self::MODEL_NAME . ':' . $path;
      $this->assertArrayHasKey($key, $before,
        'The stray key at ' . $path . ' is reported as having no schema before the update.');
      $this->assertSame('missing schema', $before[$key]);
    }

    $this->assertSame(
      'Corrected the tamper plugin ID in 1 ECA model(s): ' . self::MODEL_ID . '.',
      eca_tamper_post_update_fix_original_id()
    );

    // After: the copy is gone from both sides...
    $data = $this->configStorage->read(self::MODEL_NAME);
    $this->assertArrayNotHasKey('original_id', $data['actions'][self::ACTION_ID]['configuration']);
    $this->assertArrayNotHasKey('original_id', $data['conditions'][self::CONDITION_ID]['configuration']);
    // ...the item level key that the schema reads is untouched...
    $this->assertSame(self::TAMPER_PLUGIN_ID, $data['actions'][self::ACTION_ID]['original_id']);
    $this->assertSame(self::TAMPER_PLUGIN_ID, $data['conditions'][self::CONDITION_ID]['original_id']);
    // ...the model validates as a whole...
    $this->assertSame([], $this->schemaErrors(self::MODEL_NAME),
      'The stored model matches the schema after the update.');
    // ...and the model that changed is the one that was saved.
    $this->assertSame([self::MODEL_NAME], $this->saved);
  }

  /**
   * Tests that a model missing the item level key gets it.
   *
   * This is the other half of the update, and the one that applies to models
   * nobody ever mistreated: the key is what the schema resolves the wrapped
   * tamper plugin through, and a model authored as YAML by hand never has it.
   * Before the update it is the tamper plugin's own keys that have no schema,
   * which is the opposite end of the same problem.
   */
  public function testMissingItemKeyIsAdded(): void {
    $this->skipUnlessEcaValidatesPluginConfiguration();

    $this->store(self::MODEL_NAME, $this->legacyModelData());

    // Before: the type expression stays unresolved, so the keys the wrapped
    // tamper plugin declares are the ones without a schema.
    $before = $this->schemaErrors(self::MODEL_NAME);
    foreach ($this->tamperKeyPaths() as $path) {
      $key = self::MODEL_NAME . ':' . $path;
      $this->assertArrayHasKey($key, $before,
        'The wrapped tamper plugin key at ' . $path . ' has no schema before the update.');
      $this->assertSame('missing schema', $before[$key]);
    }

    $this->assertSame(
      'Corrected the tamper plugin ID in 1 ECA model(s): ' . self::MODEL_ID . '.',
      eca_tamper_post_update_fix_original_id()
    );

    // After: the key sits on the item, on both ECA sides...
    $data = $this->configStorage->read(self::MODEL_NAME);
    $this->assertSame(self::TAMPER_PLUGIN_ID, $data['actions'][self::ACTION_ID]['original_id']);
    $this->assertSame(self::TAMPER_PLUGIN_ID, $data['conditions'][self::CONDITION_ID]['original_id']);
    // ...it was not put inside the configuration on the way...
    $this->assertArrayNotHasKey('original_id', $data['actions'][self::ACTION_ID]['configuration']);
    $this->assertArrayNotHasKey('original_id', $data['conditions'][self::CONDITION_ID]['configuration']);
    // ...the model validates as a whole...
    $this->assertSame([], $this->schemaErrors(self::MODEL_NAME),
      'The stored model matches the schema after the update.');
    // ...and the result is the shape ECA itself produces, key order included.
    $this->assertSame($this->cleanModelData(), $data);
    $this->assertSame([self::MODEL_NAME], $this->saved);
  }

  /**
   * Tests a model that needs both halves of the update at once.
   *
   * This is what a 2.0.x development site is left with when the model it saved
   * was authored as YAML in the first place: the stray copy was merged into the
   * configuration, while the item level key was never written.
   */
  public function testStrayKeyAndMissingItemKeyAreBothFixed(): void {
    $this->skipUnlessEcaValidatesPluginConfiguration();

    $this->store(self::MODEL_NAME, $this->legacyStrayModelData());

    $this->assertSame(
      'Corrected the tamper plugin ID in 1 ECA model(s): ' . self::MODEL_ID . '.',
      eca_tamper_post_update_fix_original_id()
    );

    $this->assertSame($this->cleanModelData(), $this->configStorage->read(self::MODEL_NAME));
    $this->assertSame([], $this->schemaErrors(self::MODEL_NAME),
      'The stored model matches the schema after the update.');
    $this->assertSame([self::MODEL_NAME], $this->saved);
  }

  /**
   * Tests that the key is filled in for a tamper plugin that is not installed.
   *
   * The value is taken from the stored plugin ID, not from the plugin
   * definition, which is what makes this work at all. A model referencing a
   * tamper plugin that has since been removed needs attention either way, and
   * this update is not what should fail over it.
   *
   * The configuration deliberately holds nothing but the keys this module
   * declares itself. An unresolvable "tamper.<id>" falls back to "tamper.*",
   * which is an empty mapping, so the model is still schema valid afterwards -
   * and it has to be, because the update saves it.
   */
  public function testItemKeyIsAddedForUninstalledTamperPlugin(): void {
    $this->skipUnlessEcaValidatesPluginConfiguration();

    $missing = 'no_such_tamper_plugin';
    $data = $this->cleanModelData();
    $data['conditions'] = [];
    $data['actions'] = [
      self::ACTION_ID => [
        'plugin' => 'eca_tamper:' . $missing,
        'label' => 'Tamper action',
        'configuration' => [
          'eca_data' => '[data]',
          'eca_token_name' => 'encoded',
        ],
        'successors' => [],
      ],
    ];
    $this->store(self::MODEL_NAME, $data);

    $this->assertSame(
      'Corrected the tamper plugin ID in 1 ECA model(s): ' . self::MODEL_ID . '.',
      eca_tamper_post_update_fix_original_id()
    );

    $this->assertSame(
      $missing,
      $this->configStorage->read(self::MODEL_NAME)['actions'][self::ACTION_ID]['original_id']
    );
    $this->assertSame([self::MODEL_NAME], $this->saved);
  }

  /**
   * Tests that an item level key which is already there is left alone.
   *
   * The update closes a gap, it does not audit the models it walks over. A key
   * that disagrees with the plugin ID is somebody's doing, and overwriting it
   * would be this update making a decision that is not its to make. Nothing is
   * saved either, because nothing changed.
   */
  public function testExistingItemKeyIsNotOverwritten(): void {
    $data = $this->cleanModelData();
    $data['conditions'][self::CONDITION_ID]['original_id'] = 'convert_case';
    $data['actions'][self::ACTION_ID]['original_id'] = 'convert_case';
    $this->store(self::MODEL_NAME, $data);

    $this->assertSame(
      self::MESSAGE_UNCHANGED,
      eca_tamper_post_update_fix_original_id()
    );
    $this->assertSame($data, $this->configStorage->read(self::MODEL_NAME));
    $this->assertSame([], $this->saved);
  }

  /**
   * Tests that nothing beyond the tamper plugin ID is rewritten.
   *
   * The comparison is strict and therefore also sensitive to key order, which
   * is deliberate: an ordinary configuration save re-casts the whole object
   * against the schema and rebuilds every mapping in schema order, and a site
   * owner who keeps this configuration in version control would then see each
   * touched model reshuffled instead of the one line this update is
   * responsible for.
   */
  public function testNothingElseIsRewritten(): void {
    $this->skipUnlessEcaValidatesPluginConfiguration();

    $expected = $this->cleanModelData();
    $this->store(self::MODEL_NAME, $this->strayModelData());

    eca_tamper_post_update_fix_original_id();

    $this->assertSame($expected, $this->configStorage->read(self::MODEL_NAME));
  }

  /**
   * Tests that a model already in the right shape is left alone and not saved.
   *
   * This is the state every site that only ever ran tagged releases and saved
   * its models through ECA is in, so it is also the outcome the update has for
   * nearly everyone who runs it.
   */
  public function testCleanModelIsUntouched(): void {
    $clean = $this->cleanModelData();
    $this->store(self::MODEL_NAME, $clean);

    $this->assertSame(
      self::MESSAGE_UNCHANGED,
      eca_tamper_post_update_fix_original_id()
    );
    $this->assertSame($clean, $this->configStorage->read(self::MODEL_NAME));
    $this->assertSame([], $this->saved);
  }

  /**
   * Tests that running the update again changes nothing and saves nothing.
   */
  public function testUpdateIsIdempotent(): void {
    $this->skipUnlessEcaValidatesPluginConfiguration();

    $this->store(self::MODEL_NAME, $this->legacyStrayModelData());

    eca_tamper_post_update_fix_original_id();
    $cleaned = $this->configStorage->read(self::MODEL_NAME);
    $this->saved = [];

    $this->assertSame(
      self::MESSAGE_UNCHANGED,
      eca_tamper_post_update_fix_original_id()
    );
    $this->assertSame($cleaned, $this->configStorage->read(self::MODEL_NAME));
    $this->assertSame([], $this->saved,
      'A second run saves nothing, because it changes nothing.');
  }

  /**
   * Tests that items which do not wrap a tamper plugin are left alone.
   *
   * The near misses matter more than the obvious ones. "eca_tamper_condition"
   * is a prefix of nothing on the action side and an action plugin is not a
   * condition plugin, so the two ECA sides must not be mixed up; and
   * "eca_tamper_no_colon" shows why the separator belongs in the prefix that is
   * matched, rather than being left to a bare "eca_tamper" comparison.
   *
   * Every item here carries an "original_id" in its configuration and none on
   * the item, so a prefix that matched too eagerly would be caught twice over:
   * it would strip a key out of another module's plugin, and it would stamp one
   * onto an item that is not this module's to stamp.
   */
  public function testNonTamperItemsAreLeftAlone(): void {
    $data = [
      'langcode' => 'en',
      'status' => TRUE,
      'id' => self::MODEL_ID,
      'weight' => 0,
      'template' => FALSE,
      'events' => [],
      'conditions' => [
        // The action side prefix must not match on the condition side.
        'Flow_action_prefix' => [
          'plugin' => 'eca_tamper:' . self::TAMPER_PLUGIN_ID,
          'label' => 'Not a condition of this module',
          'configuration' => ['negate' => FALSE, 'original_id' => 'keep_me'],
        ],
        'Flow_plain' => [
          'plugin' => 'eca_scalar',
          'label' => 'Plain condition',
          'configuration' => ['negate' => FALSE, 'original_id' => 'keep_me'],
        ],
      ],
      'gateways' => [],
      'actions' => [
        // The condition side prefix must not match on the action side.
        'Activity_condition_prefix' => [
          'plugin' => 'eca_tamper_condition:' . self::TAMPER_PLUGIN_ID,
          'label' => 'Not an action of this module',
          'configuration' => ['original_id' => 'keep_me'],
          'successors' => [],
        ],
        'Activity_no_colon' => [
          'plugin' => 'eca_tamper_no_colon',
          'label' => 'Merely starts with the base plugin ID',
          'configuration' => ['original_id' => 'keep_me'],
          'successors' => [],
        ],
        'Activity_plain' => [
          'plugin' => 'action_message_action',
          'label' => 'Plain action',
          'configuration' => ['message' => 'Hello', 'original_id' => 'keep_me'],
          'successors' => [],
        ],
      ],
    ];
    $this->store(self::MODEL_NAME, $data);

    $this->assertSame(
      self::MESSAGE_UNCHANGED,
      eca_tamper_post_update_fix_original_id()
    );
    $this->assertSame($data, $this->configStorage->read(self::MODEL_NAME));
    $this->assertSame([], $this->saved);
  }

  /**
   * Tests that only the models that need correcting are saved.
   */
  public function testOnlyChangedModelsAreSaved(): void {
    $this->skipUnlessEcaValidatesPluginConfiguration();

    $this->store(self::MODEL_NAME, $this->strayModelData());
    $untouched = [
      'langcode' => 'en',
      'status' => TRUE,
      'id' => 'eca_tamper_other',
      'weight' => 0,
      'template' => FALSE,
      'events' => [],
      'conditions' => [],
      'gateways' => [],
      'actions' => [
        'Activity_plain' => [
          'plugin' => 'action_message_action',
          'label' => 'Plain action',
          'configuration' => ['message' => 'Hello'],
          'successors' => [],
        ],
      ],
    ];
    $this->store('eca.eca.eca_tamper_other', $untouched);

    $this->assertSame(
      'Corrected the tamper plugin ID in 1 ECA model(s): ' . self::MODEL_ID . '.',
      eca_tamper_post_update_fix_original_id()
    );
    $this->assertSame([self::MODEL_NAME], $this->saved);
    $this->assertSame($untouched, $this->configStorage->read('eca.eca.eca_tamper_other'));
  }

  /**
   * Writes configuration the way it would already be sitting on a site.
   *
   * The active storage is written to directly, rather than through the
   * configuration factory. A factory save would run the strict schema check of
   * the test base over data that is deliberately invalid, which is the whole
   * premise of these tests, and it would also record a save event that no
   * assertion about the update should have to account for.
   *
   * @param string $name
   *   The configuration name.
   * @param array $data
   *   The configuration data.
   */
  protected function store(string $name, array $data): void {
    $this->configStorage->write($name, $data);
    \Drupal::configFactory()->reset($name);
  }

  /**
   * Returns the schema errors of a stored configuration object.
   *
   * @param string $name
   *   The configuration name.
   *
   * @return array
   *   The reported errors, keyed by property path. Empty when there are none.
   */
  protected function schemaErrors(string $name): array {
    $result = $this->checkConfigSchema(
      $this->typedConfig,
      $name,
      $this->configStorage->read($name)
    );
    // A clean check returns TRUE rather than an empty list.
    return is_array($result) ? $result : [];
  }

  /**
   * Returns the property paths of the stray key on both ECA sides.
   *
   * @return string[]
   *   The path on the action side and the one on the condition side.
   */
  protected function strayKeyPaths(): array {
    return [
      'actions.' . self::ACTION_ID . '.configuration.original_id',
      'conditions.' . self::CONDITION_ID . '.configuration.original_id',
    ];
  }

  /**
   * Returns the property paths of the wrapped tamper plugin's own key.
   *
   * @return string[]
   *   The path on the action side and the one on the condition side.
   */
  protected function tamperKeyPaths(): array {
    return [
      'actions.' . self::ACTION_ID . '.configuration.' . self::TAMPER_PLUGIN_KEY,
      'conditions.' . self::CONDITION_ID . '.configuration.' . self::TAMPER_PLUGIN_KEY,
    ];
  }

  /**
   * Builds a model in the shape ECA produces.
   *
   * @return array
   *   The configuration data of an "eca.eca.*" config entity. There is no
   *   top-level "label": ECA keeps it in "third_party_settings".
   */
  protected function cleanModelData(): array {
    return [
      'langcode' => 'en',
      'status' => TRUE,
      'id' => self::MODEL_ID,
      'weight' => 0,
      'template' => FALSE,
      'events' => [],
      'conditions' => [
        self::CONDITION_ID => [
          'plugin' => 'eca_tamper_condition:' . self::TAMPER_PLUGIN_ID,
          'label' => 'Tamper condition',
          'configuration' => [
            'left' => '[data]',
            'right' => 'expected',
            'operator' => 'equal',
            'type' => 'value',
            'case' => FALSE,
            'negate' => FALSE,
            self::TAMPER_PLUGIN_KEY => 'json_encode',
          ],
          'original_id' => self::TAMPER_PLUGIN_ID,
        ],
      ],
      'gateways' => [],
      'actions' => [
        self::ACTION_ID => [
          'plugin' => 'eca_tamper:' . self::TAMPER_PLUGIN_ID,
          'label' => 'Tamper action',
          'configuration' => [
            'eca_data' => '[data]',
            'eca_token_name' => 'encoded',
            self::TAMPER_PLUGIN_KEY => 'json_encode',
          ],
          'successors' => [],
          'original_id' => self::TAMPER_PLUGIN_ID,
        ],
      ],
    ];
  }

  /**
   * Builds the same model with the stray copy inside the configuration.
   *
   * The copy is appended to each configuration, which is where merging it into
   * a plugin's defaults put it, so that removing it leaves exactly
   * cleanModelData() behind - key order included.
   *
   * @return array
   *   The configuration data of an "eca.eca.*" config entity.
   */
  protected function strayModelData(): array {
    $data = $this->cleanModelData();
    $data['conditions'][self::CONDITION_ID]['configuration']['original_id'] = self::TAMPER_PLUGIN_ID;
    $data['actions'][self::ACTION_ID]['configuration']['original_id'] = self::TAMPER_PLUGIN_ID;
    return $data;
  }

  /**
   * Builds the same model without the item level key.
   *
   * This is the shape of a model authored as YAML by hand, and of one stored
   * before ECA began writing the key. Because ECA appends "original_id" after
   * "configuration" and "successors", and the update does the same, adding it
   * back leaves exactly cleanModelData() behind - key order included.
   *
   * @return array
   *   The configuration data of an "eca.eca.*" config entity.
   */
  protected function legacyModelData(): array {
    $data = $this->cleanModelData();
    unset($data['conditions'][self::CONDITION_ID]['original_id']);
    unset($data['actions'][self::ACTION_ID]['original_id']);
    return $data;
  }

  /**
   * Builds the model that needs both halves of the update.
   *
   * @return array
   *   The configuration data of an "eca.eca.*" config entity.
   */
  protected function legacyStrayModelData(): array {
    $data = $this->legacyModelData();
    $data['conditions'][self::CONDITION_ID]['configuration']['original_id'] = self::TAMPER_PLUGIN_ID;
    $data['actions'][self::ACTION_ID]['configuration']['original_id'] = self::TAMPER_PLUGIN_ID;
    return $data;
  }

}
