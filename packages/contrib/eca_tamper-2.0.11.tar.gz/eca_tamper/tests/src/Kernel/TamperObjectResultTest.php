<?php

namespace Drupal\Tests\eca_tamper\Kernel;

use Drupal\Core\Action\ActionManager;
use Drupal\Core\Database\Connection;
use Drupal\eca\Token\TokenInterface;
use Drupal\tamper\Plugin\Tamper\Encode;
use Drupal\user\Entity\User;
use Drupal\user\UserInterface;

/**
 * Tests how the tamper action passes an object result on to the token service.
 *
 * A tamper plugin may return an object, and the action used to hand that
 * straight to the token service. Nothing there accepts an arbitrary object: a
 * value with no token type is wrapped in a DataTransferObject, and that only
 * takes an associative array, so the result was an InvalidArgumentException
 * instead of a usable token.
 *
 * The only plugin in tamper that returns a plain object is "encode" in
 * "unserialize" mode, which is therefore the probe used throughout. Its
 * "json_decode" mode is covered as well because that is the mode the original
 * issue reported: the plugin called PHP's own json_decode() with no second
 * argument back then, so a JSON object came back as a \stdClass. It goes
 * through \Drupal\Component\Serialization\Json now, which decodes to an
 * associative array, so the reported mode no longer reaches the conversion at
 * all and its test here passes with or without it. That test guards the mode
 * against regressing to an object again; it is not what demonstrates the fix.
 *
 * The conversion is deliberately narrow, and two of the tests below exist to
 * keep it that way. Only \stdClass is converted, because that is the one class
 * with no meaning of its own beyond its properties. Every other object either
 * already has a token type, which the token service resolves far better than
 * an array ever could, or converts in a lossy way that is particular to its
 * class.
 *
 * @see \Drupal\eca_tamper\Plugin\Action\Tamper::execute()
 * @see \Drupal\eca\Plugin\DataType\DataTransferObject::setValue()
 */
class TamperObjectResultTest extends EcaTamperKernelTestBase {

  /**
   * {@inheritdoc}
   *
   * The conversion is not allowed to fail quietly, so two tests assert that a
   * message was recorded. dblog is the cheapest real log to read back, and
   * reading the table it writes keeps those assertions about what an
   * administrator would actually find rather than about a mocked call.
   */
  protected static $modules = [
    'dblog',
  ];

  /**
   * The token name the tamper action writes its result to.
   */
  protected const TOKEN_NAME = 'result';

  /**
   * The logger channel that the action is expected to report failures on.
   *
   * The module has no channel of its own, and adding one for a single message
   * would split its logging away from the rest of the processing that this
   * action takes part in.
   */
  protected const LOGGER_CHANNEL = 'eca';

  /**
   * The distinctive part of the message the action logs on a failed conversion.
   *
   * The channel is shared with the rest of ECA, so the assertions below match
   * on the message as well. Counting everything on the channel would let an
   * unrelated message satisfy assertConversionFailureLogged() without the
   * action having reported anything, and would let one break
   * assertNoConversionFailureLogged() without anything having gone wrong.
   *
   * @see \Drupal\eca_tamper\Plugin\Action\Tamper::convertPlainObject()
   */
  protected const FAILURE_MESSAGE = 'cannot be converted into token data';

  /**
   * The action manager.
   */
  protected ActionManager $actionManager;

  /**
   * The token service.
   */
  protected TokenInterface $tokenService;

  /**
   * The database connection, used to read back log messages.
   */
  protected Connection $database;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->installEntitySchema('user');
    $this->installSchema('dblog', ['watchdog']);
    // ECA's logger channel is decorated by one that drops anything below the
    // severity configured in eca.settings. That decorator reads the setting
    // once when it is constructed and has no subscriber to refresh it, and it
    // is constructed here before this test can install any configuration, at
    // which point the setting does not exist yet and nothing above an
    // emergency would be recorded. Installing ECA's configuration and then
    // handing the channel the value from it leaves the shipped default in
    // effect, so the assertions below are about what a site running ECA's own
    // default records rather than about a severity chosen here.
    $this->installConfig(['eca']);
    /** @var \Drupal\eca\ConfigurableLoggerChannel $logger */
    $logger = \Drupal::service('logger.channel.eca');
    $logger->updateLogLevel((int) $this->config('eca.settings')->get('log_level'));

    $this->actionManager = \Drupal::service('plugin.manager.action');
    $this->tokenService = \Drupal::service('eca.token_services');
    $this->database = \Drupal::database();
  }

  /**
   * Tests that a nested plain object becomes resolvable tokens.
   *
   * This is the actual bug. Without the conversion in the action, the call
   * into the token service throws, so no assertion here is reached at all.
   *
   * The object is nested on purpose. A plain "(array)" cast converts only the
   * outermost level and leaves any object below it in place, which the token
   * service rejects just as firmly, through the check it makes on an
   * individual value rather than the one it makes on the value as a whole. A
   * test with a flat object would pass without the conversion being recursive.
   */
  public function testPlainObjectFromUnserializeResolvesAsTokens(): void {
    $this->executeEncode('unserialize', serialize((object) [
      'label' => 'outer',
      'child' => (object) [
        'label' => 'inner',
        'count' => 7,
      ],
    ]));

    $this->assertSame('outer', $this->replace('label'));
    $this->assertSame('inner', $this->replace('child:label'));
    $this->assertSame('7', $this->replace('child:count'));
  }

  /**
   * Tests that an object which is not a plain object is left alone.
   *
   * An entity survives serialization, so the same plugin and mode as the bug
   * itself reach the action with an object that must not be touched. The token
   * service has a token type for it and stores it as it is, which is what
   * makes the entity's own tokens resolve.
   *
   * Converting on "is_object()" rather than on the class passes every other
   * test in this file and breaks this one: an entity holds its values behind
   * field objects rather than in public properties, so it converts to an empty
   * array and the entity is gone entirely.
   */
  public function testEntityFromUnserializeIsNotConverted(): void {
    $user = User::create(['name' => 'tamper_probe']);
    $user->save();

    $this->executeEncode('unserialize', serialize($user));

    $result = $this->tokenService->getTokenData(self::TOKEN_NAME);
    $this->assertInstanceOf(UserInterface::class, $result, 'An entity returned by a tamper plugin is handed to the token service unchanged.');
    $this->assertSame('tamper_probe', $result->getAccountName());
    $this->assertSame('tamper_probe', $this->replace('account-name'));
    $this->assertNoConversionFailureLogged();
  }

  /**
   * Tests that decoding JSON keeps working.
   *
   * This is the mode the issue was originally reported against. It no longer
   * produces an object, so it passes with or without the conversion. What is
   * asked for here is that it keeps decoding into tokens directly, rather than
   * regressing to an object and leaning on the conversion to recover.
   */
  public function testJsonDecodeStillResolvesAsTokens(): void {
    $this->executeEncode('json_decode', '{"label":"outer","child":{"label":"inner"}}');

    $this->assertSame('outer', $this->replace('label'));
    $this->assertSame('inner', $this->replace('child:label'));
    $this->assertNoConversionFailureLogged();
  }

  /**
   * Tests that an object referring to itself is reported rather than dropped.
   *
   * A hand written recursion would follow this input until it ran out of
   * memory. The conversion used instead refuses it, and the object is then
   * left exactly as it was.
   *
   * That the token service still rejects it is the assertion, because that is
   * what shows the object arrived unconverted and was not replaced. Handing
   * NULL over instead would throw nothing at all and would lose the data
   * without anyone noticing, which is the outcome being guarded against.
   */
  public function testCircularReferenceIsLoggedAndNotSubstituted(): void {
    $circular = new \stdClass();
    $circular->self = $circular;

    $this->expectException(\InvalidArgumentException::class);
    $this->expectExceptionMessage('Invalid values given.');
    try {
      $this->executeEncode('unserialize', serialize($circular));
    }
    finally {
      $this->assertConversionFailureLogged();
    }
  }

  /**
   * Tests that a property which is not valid UTF-8 is reported.
   *
   * The other input the conversion cannot represent. It is refused for the
   * whole object rather than the offending property being dropped from it, and
   * the outcome is the same as for a circular reference.
   */
  public function testInvalidUtf8IsLoggedAndNotSubstituted(): void {
    $invalid = (object) ['broken' => "\xB1\x31"];

    $this->expectException(\InvalidArgumentException::class);
    $this->expectExceptionMessage('Invalid values given.');
    try {
      $this->executeEncode('unserialize', serialize($invalid));
    }
    finally {
      $this->assertConversionFailureLogged();
    }
  }

  /**
   * Runs the encode tamper action as an ECA action.
   *
   * The ECA action supplies the tamper plugin's source definition itself, so
   * the configuration here is only what the action and the plugin ask for.
   *
   * @param string $mode
   *   The conversion mode of the encode plugin.
   * @param string $data
   *   The data to be tampered.
   */
  protected function executeEncode(string $mode, string $data): void {
    /** @var \Drupal\eca_tamper\Plugin\Action\Tamper $action */
    $action = $this->actionManager->createInstance('eca_tamper:encode', [
      'eca_data' => $data,
      'eca_token_name' => self::TOKEN_NAME,
      Encode::SETTING_MODE => $mode,
    ]);
    $this->assertTrue($action->access(NULL));
    $action->execute();
  }

  /**
   * Resolves a token below the result token of the tamper action.
   *
   * @param string $property
   *   The token property, which may be chained with a colon.
   *
   * @return string
   *   The replaced value.
   */
  protected function replace(string $property): string {
    return (string) $this->tokenService->replaceClear('[' . self::TOKEN_NAME . ':' . $property . ']');
  }

  /**
   * Counts the messages the action logged about a failed conversion.
   *
   * @return int
   *   The number of matching messages on the ECA logger channel.
   */
  protected function countConversionFailureMessages(): int {
    return (int) $this->database->select('watchdog', 'w')
      ->condition('w.type', self::LOGGER_CHANNEL)
      ->condition('w.message', '%' . $this->database->escapeLike(self::FAILURE_MESSAGE) . '%', 'LIKE')
      ->countQuery()
      ->execute()
      ->fetchField();
  }

  /**
   * Asserts that the action reported a failed conversion.
   */
  protected function assertConversionFailureLogged(): void {
    $this->assertGreaterThan(0, $this->countConversionFailureMessages(), 'A conversion that cannot be completed is reported on the ECA logger channel.');
  }

  /**
   * Asserts that the action had no failed conversion to report.
   */
  protected function assertNoConversionFailureLogged(): void {
    $this->assertSame(0, $this->countConversionFailureMessages(), 'Nothing is logged when there is no failed conversion.');
  }

}
