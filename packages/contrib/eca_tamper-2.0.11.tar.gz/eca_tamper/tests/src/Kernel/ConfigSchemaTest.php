<?php

namespace Drupal\Tests\eca_tamper\Kernel;

use Drupal\Core\Action\ActionManager;
use Drupal\Core\Config\Schema\Undefined;
use Drupal\Core\Config\TypedConfigManagerInterface;
use Drupal\Core\TypedData\MapDataDefinition;
use Drupal\eca\PluginManager\Condition;
use Drupal\Tests\SchemaCheckTestTrait;

/**
 * Tests the configuration schema of ECA tamper actions and conditions.
 *
 * Both schema sections inherit the wrapped tamper plugin's own schema through
 * the dynamic type "tamper.[%parent.original_id]", where "%parent" is the
 * surrounding ECA action or condition item. A bare definition lookup cannot
 * exercise that, because there is no data in one, so these tests go through
 * typed configuration with a real model instead.
 */
class ConfigSchemaTest extends EcaTamperKernelTestBase {

  use SchemaCheckTestTrait;

  /**
   * The tamper plugin used as the probe throughout this test.
   *
   * The "encode" plugin ships its own schema section "tamper.encode" which
   * declares the key "mode", and its "itemUsage" is "ignored" rather than
   * "required", so both TamperDeriver classes derive it into ECA.
   */
  protected const TAMPER_PLUGIN_ID = 'encode';

  /**
   * The schema key that the "tamper.encode" section contributes.
   */
  protected const TAMPER_PLUGIN_KEY = 'mode';

  /**
   * The ID of the model configuration entity the tests validate.
   */
  protected const MODEL_ID = 'eca_tamper_test';

  /**
   * The configuration name of that model.
   */
  protected const MODEL_NAME = 'eca.eca.' . self::MODEL_ID;

  /**
   * The key of the tamper action inside the model.
   */
  protected const ACTION_ID = 'Activity_tamper';

  /**
   * The key of the tamper condition inside the model.
   */
  protected const CONDITION_ID = 'Flow_tamper';

  /**
   * The typed config manager.
   */
  protected TypedConfigManagerInterface $typedConfig;

  /**
   * The action manager.
   */
  protected ActionManager $actionManager;

  /**
   * The ECA condition manager.
   */
  protected Condition $conditionManager;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->typedConfig = \Drupal::service('config.typed');
    $this->actionManager = \Drupal::service('plugin.manager.action');
    $this->conditionManager = \Drupal::service('plugin.manager.eca.condition');
  }

  /**
   * Tests that a model in the shape ECA produces has valid schema.
   *
   * The fixture carries "original_id" on the action and condition item, which
   * is where \Drupal\eca\Entity\Eca::addAction() and ::addCondition() put it,
   * and nowhere else.
   */
  public function testModelConfigSchema(): void {
    $this->skipUnlessEcaValidatesPluginConfiguration();

    $this->assertConfigSchema($this->typedConfig, self::MODEL_NAME, $this->modelData());
  }

  /**
   * Tests that the wrapped tamper plugin's own keys really are inherited.
   *
   * The test above covers this implicitly - a key that was not inherited would
   * be reported as having no schema - but only as long as the fixture keeps
   * carrying one. This asserts the inheritance itself: the resolved mapping of
   * each tamper configuration holds the keys this module declares next to the
   * ones "tamper.encode" declares, on both ECA sides.
   */
  public function testWrappedTamperPluginKeysAreInherited(): void {
    $this->skipUnlessEcaValidatesPluginConfiguration();

    /** @var \Drupal\Core\Config\Schema\TypedConfigInterface $schema */
    $schema = $this->typedConfig->createFromNameAndData(self::MODEL_NAME, $this->modelData());

    $ownKeys = [
      'actions.' . self::ACTION_ID . '.configuration' => 'eca_data',
      'conditions.' . self::CONDITION_ID . '.configuration' => 'operator',
    ];
    foreach ($ownKeys as $path => $ownKey) {
      $definition = $schema->get($path)->getDataDefinition();
      // The declared keys are the "mapping" of the definition array, and only
      // a mapping definition carries one. Core reads a mapping out of a
      // definition the same way, in
      // \Drupal\Core\Config\TypedConfigManager::getStaticTypeRoot().
      $this->assertInstanceOf(MapDataDefinition::class, $definition,
        'The section at ' . $path . ' resolves to a mapping.');
      $mapping = $definition->toArray()['mapping'] ?? [];
      $this->assertArrayHasKey($ownKey, $mapping,
        'The section at ' . $path . ' contributes its own keys.');
      $this->assertArrayHasKey(self::TAMPER_PLUGIN_KEY, $mapping,
        'The section at ' . $path . ' inherits the wrapped tamper plugin keys.');
    }

    // Declared in the merged definition is one thing, resolving to a usable
    // element is what the validation of a stored model actually needs.
    foreach ($this->tamperKeyPaths() as $path) {
      $this->assertNotInstanceOf(Undefined::class, $schema->get($path),
        'The wrapped tamper plugin key at ' . $path . ' has a schema.');
    }
  }

  /**
   * Tests that unknown keys inside the tamper configuration are still caught.
   *
   * The negative control for the two tests above. Were the tamper
   * configuration to end up not being validated at all - for instance because
   * it resolved to an "ignore" type - then they would pass without proving
   * anything. This pins that the section really is checked.
   */
  public function testUnknownTamperKeyIsReported(): void {
    $this->skipUnlessEcaValidatesPluginConfiguration();

    $errors = $this->schemaErrors($this->modelData(['not_a_tamper_setting' => 'x']));

    $expected = self::MODEL_NAME . ':actions.' . self::ACTION_ID . '.configuration.not_a_tamper_setting';
    $this->assertArrayHasKey($expected, $errors,
      'An unknown key inside the tamper configuration is reported as missing schema.');
    $this->assertSame('missing schema', $errors[$expected]);
  }

  /**
   * Tests that a model without the item level key is the one that fails.
   *
   * This is the defect the issue is about. A model authored as YAML by hand, or
   * saved before ECA started writing "original_id" onto the item, leaves
   * "tamper.[%parent.original_id]" unresolved. Core then falls back to
   * "tamper.*", which is a plain mapping carrying no plugin keys at all, so the
   * wrapped tamper plugin's own keys are reported as having no schema.
   *
   * The keys this module declares itself are unaffected, and asserting that is
   * the point of the second half of this test: the failure is specific to the
   * inherited part of the section, which is what makes the item level key the
   * thing that has to be fixed rather than these sections.
   */
  public function testModelWithoutItemOriginalIdCannotResolve(): void {
    $this->skipUnlessEcaValidatesPluginConfiguration();

    $errors = $this->schemaErrors($this->modelData(itemOriginalId: FALSE));

    foreach ($this->tamperKeyPaths() as $path) {
      $key = self::MODEL_NAME . ':' . $path;
      $this->assertArrayHasKey($key, $errors,
        'Without the item level "original_id" the wrapped tamper plugin key at ' . $path . ' has no schema.');
      $this->assertSame('missing schema', $errors[$key]);
    }

    $this->assertArrayNotHasKey(
      self::MODEL_NAME . ':actions.' . self::ACTION_ID . '.configuration.eca_data',
      $errors,
      'The keys these sections declare themselves keep their schema regardless.'
    );
    $this->assertArrayNotHasKey(
      self::MODEL_NAME . ':conditions.' . self::CONDITION_ID . '.configuration.operator',
      $errors,
      'The keys these sections declare themselves keep their schema regardless.'
    );
  }

  /**
   * Tests that the tamper sections accept a token where a number is declared.
   *
   * \Drupal\eca_tamper\Hook\ConfigSchemaHooks::configSchemaInfoAlter() rewrites
   * the scalar number types of every "tamper.*" section into ECA's token aware
   * counterparts, because a value in an ECA model may be a token instead of a
   * literal. That is also the only observable effect the hook has, which makes
   * this the one test covering the procedural wrapper in eca_tamper.module:
   * core 10 has no hook class discovery, so the #[Hook] attribute on that
   * method is never looked at there and the wrapper is what runs it instead.
   * Without this the previous major test job asserts nothing about the very
   * thing it was opted in for.
   *
   * The tamper plugins are not named here on purpose. Which of them declares a
   * number is tamper's business and changes between its releases; that none of
   * them is left with a raw one is this module's business.
   */
  public function testNumericTamperKeysAcceptTokens(): void {
    $converted = [];
    $unconverted = [];
    foreach ($this->typedConfig->getDefinitions() as $name => $definition) {
      if (!str_starts_with($name, 'tamper.')) {
        continue;
      }
      foreach ($definition['mapping'] ?? [] as $key => $schema) {
        $type = $schema['type'] ?? '';
        if (in_array($type, ['float', 'integer'], TRUE)) {
          $unconverted[] = $name . ':' . $key;
        }
        elseif (in_array($type, ['eca_float_or_token', 'eca_integer_or_token'], TRUE)) {
          $converted[] = $name . ':' . $key;
        }
      }
    }

    $this->assertNotEmpty($converted,
      'The hook implementation ran and rewrote at least one numeric tamper key.');
    $this->assertSame([], $unconverted,
      'No tamper section is left with a numeric type that would reject a token.');
  }

  /**
   * Tests what an instantiated tamper condition puts into its configuration.
   *
   * The wrapped tamper plugin's own defaults belong there - they are the
   * settings a model stores. The tamper plugin ID does not: it is the item
   * level "original_id" that the schema reads, ECA maintains that key itself,
   * and a copy of it inside the configuration would be a second, undeclared
   * key that the wrapped plugin knows nothing about.
   */
  public function testConditionConfiguration(): void {
    /** @var \Drupal\eca_tamper\Plugin\ECA\Condition\Tamper $condition */
    $condition = $this->conditionManager->createInstance('eca_tamper_condition:' . self::TAMPER_PLUGIN_ID, []);
    $configuration = $condition->getConfiguration();

    $this->assertArrayHasKey(self::TAMPER_PLUGIN_KEY, $configuration,
      'The wrapped tamper plugin contributes its own defaults.');
    $this->assertArrayNotHasKey('original_id', $configuration);
  }

  /**
   * Tests that an instantiated tamper action does not store the plugin ID.
   *
   * The action is the other construction path: ECA builds it before the tamper
   * plugin manager is injected, so the manager is absent exactly when the
   * defaults are merged into the configuration that later gets stored.
   */
  public function testActionConfiguration(): void {
    /** @var \Drupal\eca_tamper\Plugin\Action\Tamper $action */
    $action = $this->actionManager->createInstance('eca_tamper:' . self::TAMPER_PLUGIN_ID, []);

    $this->assertArrayNotHasKey('original_id', $action->getConfiguration());
  }

  /**
   * Returns the schema errors of configuration data.
   *
   * @param array $data
   *   The configuration data to check.
   *
   * @return array
   *   The reported errors, keyed by property path. Empty when there are none.
   */
  protected function schemaErrors(array $data): array {
    $result = $this->checkConfigSchema($this->typedConfig, self::MODEL_NAME, $data);
    // A clean check returns TRUE rather than an empty list.
    return is_array($result) ? $result : [];
  }

  /**
   * Returns the property paths of the wrapped tamper plugin's own key.
   *
   * @return string[]
   *   The path on the action side and the one on the condition side.
   */
  protected function tamperKeyPaths(): array {
    return [
      'actions.' . self::ACTION_ID . '.configuration.' . self::TAMPER_PLUGIN_KEY,
      'conditions.' . self::CONDITION_ID . '.configuration.' . self::TAMPER_PLUGIN_KEY,
    ];
  }

  /**
   * Builds an ECA model using a tamper action and a tamper condition.
   *
   * @param array $extraActionConfiguration
   *   Additional keys to place in the tamper action's configuration, used to
   *   introduce a key that no schema section declares.
   * @param bool $itemOriginalId
   *   Whether the action and condition item carry "original_id", the way ECA
   *   writes it. FALSE builds the shape of a model that predates that, which is
   *   also the shape of a model authored as YAML by hand.
   *
   * @return array
   *   The configuration data of an "eca.eca.*" config entity. There is no
   *   top-level "label": ECA keeps it in "third_party_settings".
   */
  protected function modelData(array $extraActionConfiguration = [], bool $itemOriginalId = TRUE): array {
    $condition = [
      'plugin' => 'eca_tamper_condition:' . self::TAMPER_PLUGIN_ID,
      'label' => 'Tamper condition',
      'configuration' => [
        'left' => '[data]',
        'right' => 'expected',
        'operator' => 'equal',
        'type' => 'value',
        'case' => FALSE,
        'negate' => FALSE,
        self::TAMPER_PLUGIN_KEY => 'json_encode',
      ],
    ];
    $action = [
      'plugin' => 'eca_tamper:' . self::TAMPER_PLUGIN_ID,
      'label' => 'Tamper action',
      'configuration' => $extraActionConfiguration + [
        'eca_data' => '[data]',
        'eca_token_name' => 'encoded',
        self::TAMPER_PLUGIN_KEY => 'json_encode',
      ],
      'successors' => [],
    ];
    if ($itemOriginalId) {
      $condition['original_id'] = self::TAMPER_PLUGIN_ID;
      $action['original_id'] = self::TAMPER_PLUGIN_ID;
    }

    return [
      'langcode' => 'en',
      'status' => TRUE,
      'id' => self::MODEL_ID,
      'weight' => 0,
      'template' => FALSE,
      'events' => [],
      'conditions' => [self::CONDITION_ID => $condition],
      'gateways' => [],
      'actions' => [self::ACTION_ID => $action],
    ];
  }

}
