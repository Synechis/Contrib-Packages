<?php

namespace Drupal\Tests\eca_tamper\Kernel;

use Drupal\Core\Extension\ExtensionDiscovery;
use Drupal\KernelTests\KernelTestBase;

/**
 * Base class for the kernel tests of this module.
 *
 * This module declares support for ECA 2 as well as ECA 3, and the two are far
 * enough apart that a kernel test has to account for it. ECA 3 requires core
 * 11.3, so the previous major test job resolves ECA 2, and everything in here
 * exists because of that job.
 */
abstract class EcaTamperKernelTestBase extends KernelTestBase {

  /**
   * The module that only exists alongside ECA 3.
   */
  protected const OPTIONAL_MODULE = 'modeler_api';

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'system',
    'user',
    'eca',
    'eca_tamper',
    'tamper',
  ];

  /**
   * {@inheritdoc}
   *
   * ECA 3 injects "@modeler_api.template_token_resolver" into its processor
   * service, so a container that has ECA 3 in it but not modeler_api cannot be
   * compiled at all. Enabling the module from setUp() is therefore too late,
   * and simply naming it in $modules makes every test here error out with
   * "Unavailable module" wherever ECA 2 is installed, because modeler_api is
   * then not in the code base to be found. ECA 2 has no such dependency, so
   * there is nothing to enable in that case either.
   *
   * This is the seam for amending the list. bootKernel() is what reads it, and
   * bootEnvironment() runs immediately before that with $this->root and the
   * settings already in place, so extensions can be discovered here in exactly
   * the way the test base itself discovers them. Overriding
   * getModulesToEnable() would read better but is not an option: it is private
   * in core 10.4 and only became protected in 10.6.
   *
   * @see \Drupal\KernelTests\KernelTestBase::setUp()
   * @see \Drupal\KernelTests\KernelTestBase::getExtensionsForModules()
   * @see \Drupal\FunctionalJavascriptTests\WebDriverTestBase::installModulesFromClassProperty()
   */
  protected function bootEnvironment(): void {
    parent::bootEnvironment();

    if (!in_array(self::OPTIONAL_MODULE, static::$modules, TRUE) && $this->moduleIsAvailable(self::OPTIONAL_MODULE)) {
      static::$modules[] = self::OPTIONAL_MODULE;
    }
  }

  /**
   * Determines whether a module is present in the code base.
   *
   * The discovery is set up the same way the test base sets it up when it turns
   * the module list into extensions, so a module this reports as available is
   * one that can really be installed.
   *
   * @param string $module
   *   The machine name of the module.
   *
   * @return bool
   *   TRUE if the module was found, FALSE otherwise.
   *
   * @see \Drupal\KernelTests\KernelTestBase::getExtensionsForModules()
   */
  protected function moduleIsAvailable(string $module): bool {
    $discovery = new ExtensionDiscovery($this->root);
    $discovery->setProfileDirectories([]);
    return isset($discovery->scan('module')[$module]);
  }

  /**
   * Skips the running test unless ECA validates plugin configuration at all.
   *
   * ECA 2 declares the "configuration" of every event, condition and action
   * inside a model as "type: ignore", and it describes the model itself with
   * the older "eca.eca.*" mapping, which has neither "template" nor a label on
   * a condition. Nothing ever descends into a stored model there: no schema
   * section of this module is consulted for one, an unknown key inside a tamper
   * configuration cannot be reported either way, and the models these tests
   * build do not match that mapping in the first place.
   *
   * The subject of the tests guarded by this is therefore absent on ECA 2
   * rather than broken on it. What is asked for is that property rather than a
   * version number, so an ECA 2 release that started validating plugin
   * configuration would be picked up without a change here.
   */
  protected function skipUnlessEcaValidatesPluginConfiguration(): void {
    $definition = \Drupal::service('config.typed')->getDefinition('eca.eca.schema_probe');
    $type = $definition['mapping']['actions']['sequence']['mapping']['configuration']['type'] ?? 'ignore';
    if ($type === 'ignore') {
      $this->markTestSkipped('This version of ECA does not validate the configuration of the plugins inside a model, so there is no schema resolution for this test to be about.');
    }
  }

}
