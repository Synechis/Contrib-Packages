/**
 * @file
 * Location Signpost block behaviour.
 *
 * Provides address autocomplete via a server-side proxy endpoint and maps
 * MSOA codes to configured areas. All configuration is supplied via
 * drupalSettings.location_signpost — no hardcoded values.
 */

(function (Drupal, drupalSettings) {
  'use strict';

  // Setup the EPSG:27700 (British National Grid) projection for Leaflet.
  const crs = (typeof L !== 'undefined' && typeof proj4 !== 'undefined')
    ? new L.Proj.CRS(
        'EPSG:27700',
        '+proj=tmerc +lat_0=49 +lon_0=-2 +k=0.9996012717 +x_0=400000 +y_0=-100000 +ellps=airy +towgs84=446.448,-125.157,542.06,0.15,0.247,0.842,-20.489 +units=m +no_defs',
        {
          resolutions: [896.0, 448.0, 224.0, 112.0, 56.0, 28.0, 14.0, 7.0, 3.5, 1.75],
          origin: [-238375.0, 1376256.0],
        }
      )
    : null;

  const transformCoords = (arr) => proj4('EPSG:27700', 'EPSG:4326', arr).reverse();

  let map;
  let myMarker;
  let numHits = 0;
  let selectedItem = -1;
  let item = -1;
  let timeoutId = 0;

  // Populated from drupalSettings on init.
  let settings = {};
  let msoaToArea = {};    // { 'E02003965': { custodianCode, label, ... } }
  let custodianToArea = {}; // { '905': { label, organisationName, ... } }

  /**
   * Builds lookup structures from drupalSettings.location_signpost.areas.
   */
  function buildAreaMaps(areas) {
    Object.entries(areas).forEach(([custodianCode, area]) => {
      custodianToArea[custodianCode] = area;
      (area.msoaCodes || []).forEach((msoa) => {
        msoaToArea[msoa] = area;
        msoaToArea[msoa].custodianCode = custodianCode;
      });
    });
  }

  /**
   * Initialises event listeners and optional map.
   */
  function init() {
    const s = drupalSettings.location_signpost;
    if (!s) {
      return;
    }

    settings = s;
    buildAreaMaps(s.areas || {});

    const searchButton = document.getElementById('location-signpost-search-button');
    if (!searchButton) {
      return;
    }

    searchButton.addEventListener('click', async () => {
      await new Promise((r) => setTimeout(r, 500));
      const firstResult = document.getElementById('ls-result-0');
      if (firstResult) {
        selectAddress('ls-result-0');
      }
      else {
        showNoAddressFound();
      }
    });

    const locationField = document.getElementById('location-signpost-location');
    locationField.addEventListener('blur', clearDropdown);

    const searchAgain = document.getElementById('location-signpost-search-again');
    searchAgain.addEventListener('click', resetSearch);
    searchAgain.addEventListener('keyup', (e) => {
      if (e.key === 'Enter') {
        resetSearch();
      }
    });

    locationField.onkeyup = function (evt) {
      const textInput = locationField.value;
      switch (evt.key) {
        case 'ArrowDown':
          if (isDropdownOpen() && selectedItem < (numHits - 1)) {
            selectedItem++;
            setFocus(selectedItem);
          }
          break;
        case 'ArrowUp':
          if (isDropdownOpen()) {
            if (selectedItem > 0) {
              selectedItem--;
              setFocus(selectedItem);
            }
            else {
              selectedItem = -1;
              clearFocusHighlight();
            }
          }
          break;
        case 'Enter':
          if (isDropdownOpen()) {
            if (selectedItem > -1) {
              selectAddress('ls-result-' + selectedItem);
            }
            else {
              searchButton.click();
              clearDropdown();
            }
          }
          else {
            searchButton.click();
            clearDropdown();
          }
          break;
        case 'Escape':
          clearDropdown();
          break;
        default:
          if (textInput.length > 3) {
            clearTimeout(timeoutId);
            timeoutId = setTimeout(() => findAddress(textInput), 500);
          }
          else {
            clearDropdownFull();
          }
      }
    };

    if (s.showMap && typeof L !== 'undefined' && crs) {
      initMap();
    }
  }

  /**
   * Initialises the Leaflet map.
   */
  function initMap() {
    const mapEl = document.getElementById('location-signpost-map');
    if (!mapEl) {
      return;
    }

    map = L.map('location-signpost-map', {
      crs: crs,
      minZoom: 7,
      maxZoom: 20,
      zoom: 9,
      maxBounds: [
        transformCoords([-238375.0, 0.0]),
        transformCoords([900000.0, 1376256.0]),
      ],
      attributionControl: false,
    });

    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 22,
      maxNativeZoom: 19,
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
    }).addTo(map);

    map.setView(transformCoords([337297, 523695]), 9);

    if (typeof L.Control.Fullscreen !== 'undefined') {
      map.addControl(new L.Control.Fullscreen({
        title: { false: Drupal.t('View Fullscreen'), true: Drupal.t('Exit Fullscreen') },
      }));
    }
  }

  /**
   * Fetches address suggestions from the server-side proxy endpoint.
   */
  function findAddress(query) {
    clearDropdownFull();
    document.getElementById('location-signpost-services').innerHTML = '&nbsp;';

    fetch(settings.autocompleteUrl + '?q=' + encodeURIComponent(query))
      .then((response) => response.json())
      .then((data) => {
        if (Array.isArray(data) && data.length > 0) {
          renderDropdown(data);
        }
        else {
          document.getElementById('location-signpost-aria').innerHTML =
            Drupal.t('No matching results found');
        }
      })
      .catch(() => {
        document.getElementById('location-signpost-aria').innerHTML =
          Drupal.t('Address lookup failed. Please try again.');
      });
  }

  /**
   * Renders address results into the dropdown list.
   */
  function renderDropdown(results) {
    const list = document.getElementById('location-signpost-address-list');
    list.innerHTML = '';
    numHits = 0;
    item = -1;

    results.forEach((result) => {
      item++;
      list.innerHTML +=
        '<li class="ls-address-result">' +
        '<a data-x="' + escapeAttr(result.x) + '" ' +
        'data-y="' + escapeAttr(result.y) + '" ' +
        'data-postcode="' + escapeAttr(result.postcode) + '" ' +
        'class="ls-address-link" ' +
        'id="ls-result-' + item + '" ' +
        'role="option" ' +
        'onmousedown="void(0)">' +
        escapeHtml(result.address) +
        '</a></li>';
      numHits++;
    });

    list.style.display = 'block';

    // Wire up mousedown events after insertion.
    list.querySelectorAll('.ls-address-link').forEach((el) => {
      el.addEventListener('mousedown', () => selectAddress(el.id));
    });

    document.getElementById('location-signpost-aria').innerHTML =
      Drupal.formatPlural(numHits, '1 result found, use up and down arrows to review', '@count results found, use up and down arrows to review');
  }

  /**
   * Handles selection of an address from the dropdown.
   */
  function selectAddress(elementId) {
    const el = document.getElementById(elementId);
    if (!el) {
      return;
    }
    document.getElementById('location-signpost-location').value = el.textContent;
    clearDropdownFull();
    lookupPostcode(el);
  }

  /**
   * Calls postcodes.io to get the MSOA code for the selected address postcode.
   */
  function lookupPostcode(addressEl) {
    const postcode = addressEl.dataset.postcode;
    const addressString = addressEl.textContent;
    const x = parseFloat(addressEl.dataset.x);
    const y = parseFloat(addressEl.dataset.y);

    document.getElementById('location-signpost-services').innerHTML = '&nbsp;';

    if (!postcode) {
      showAddress(addressString, x, y, null);
      return;
    }

    fetch('https://api.postcodes.io/postcodes/' + encodeURIComponent(postcode))
      .then((r) => r.json())
      .then((data) => {
        const msoa = data.result && data.result.codes && data.result.codes.msoa;
        const area = msoa ? msoaToArea[msoa] : null;
        showAddress(addressString, x, y, area ? area.custodianCode : null);
      })
      .catch(() => showAddress(addressString, x, y, null));
  }

  /**
   * Displays the result for a selected address.
   */
  function showAddress(addressString, x, y, custodianCode) {
    const area = custodianCode ? custodianToArea[custodianCode] : null;
    const str = settings.strings || {};

    const resultsTitle = document.getElementById('location-signpost-results-title');
    const services = document.getElementById('location-signpost-services');
    const servicesLinks = document.getElementById('location-signpost-services-links');

    resultsTitle.innerHTML =
      '<p><strong>' + escapeHtml(str.closestMatchLabel || 'Closest match') + ': </strong>' +
      escapeHtml(addressString) + '</p>';

    if (!area) {
      services.innerHTML = escapeHtml(str.noMatchMessage || '');
    }
    else {
      services.innerHTML = '';

      if (settings.showMap) {
        services.innerHTML +=
          escapeHtml(str.organisationLabel || '') + ' <strong><a href="' +
          escapeAttr(area.organisationUrl) + '">' +
          escapeHtml(area.organisationName) + '</a></strong><br>';

        if (area.links && area.links.length > 0) {
          document.getElementById('location-signpost-search')
            .classList.add('location-signpost--show-links');
          document.getElementById('location-signpost-wrapper').style.width = '100%';

          let linksHtml = '<h3>' + escapeHtml(str.servicesHeading || '') + '</h3><ul>';
          area.links.forEach((link) => {
            linksHtml += '<li><a href="' + escapeAttr(link.uri) + '">' + escapeHtml(link.title) + '</a></li>';
          });
          linksHtml += '</ul>';

          servicesLinks.innerHTML = linksHtml;
          servicesLinks.style.display = 'block';
        }
        else {
          document.getElementById('location-signpost-search')
            .classList.remove('location-signpost--show-links');
          servicesLinks.style.display = 'none';
        }
      }

      services.innerHTML +=
        escapeHtml(str.areaLabel || '') + ' <strong>' + escapeHtml(area.label) + '</strong>';
    }

    resultsTitle.style.display = 'block';
    document.getElementById('location-signpost-results').style.display = 'block';
    document.getElementById('location-signpost-input').style.display = 'none';
    document.getElementById('location-signpost-search-again').style.display = 'block';

    if (settings.showMap && map && area) {
      if (myMarker) {
        map.removeLayer(myMarker);
      }
      const latlng = transformCoords([x, y]);
      myMarker = L.marker(latlng, {
        title: addressString,
        alt: Drupal.t('Your location'),
        draggable: false,
      }).addTo(map);

      document.getElementById('location-signpost-map').style.display = 'block';
      map.invalidateSize();
      map.setView(latlng, 14);
      myMarker.bindPopup('<strong>' + escapeHtml(addressString) + '</strong>').openPopup();
    }
  }

  /**
   * Shows a no-match message without a selected area.
   */
  function showNoAddressFound() {
    document.getElementById('location-signpost-results').style.display = 'block';
    const services = document.getElementById('location-signpost-services');
    services.innerHTML = escapeHtml((settings.strings || {}).noMatchMessage || '');
    services.style.display = 'block';
  }

  /**
   * Resets the UI back to the search state.
   */
  function resetSearch() {
    const mapEl = document.getElementById('location-signpost-map');
    if (mapEl) {
      mapEl.style.display = 'none';
    }
    document.getElementById('location-signpost-results-title').style.display = 'none';
    document.getElementById('location-signpost-results').style.display = 'none';
    document.getElementById('location-signpost-input').style.display = 'block';
    document.getElementById('location-signpost-search-again').style.display = 'none';
    document.getElementById('location-signpost-search')
      .classList.remove('location-signpost--show-links');
    document.getElementById('location-signpost-wrapper').style.width = '';
    document.getElementById('location-signpost-location').value = '';
    document.getElementById('location-signpost-services-links').innerHTML = '';
    clearDropdownFull();
    document.getElementById('location-signpost-location').focus();
  }

  // --- Dropdown helpers ---

  function isDropdownOpen() {
    const list = document.getElementById('location-signpost-address-list');
    return list && list.style.display === 'block';
  }

  function clearDropdown() {
    document.getElementById('location-signpost-aria').innerHTML = '';
    numHits = 0;
    selectedItem = -1;
    item = -1;
  }

  function clearDropdownFull() {
    const list = document.getElementById('location-signpost-address-list');
    if (list) {
      list.style.display = 'none';
      list.innerHTML = '';
    }
    clearDropdown();
  }

  function setFocus(index) {
    const links = Array.from(document.getElementsByClassName('ls-address-link'));
    const list = document.getElementById('location-signpost-address-list');
    const selected = links[index];
    const locationInput = document.getElementById('location-signpost-location');

    links.forEach((el) => el.classList.remove('ls-address-link--focused'));
    selected.classList.add('ls-address-link--focused');
    locationInput.setAttribute('aria-activedescendant', selected.id);
    selected.focus();

    const itemOffset = selected.offsetTop;
    const itemHeight = selected.offsetHeight;
    const listHeight = list.offsetHeight;
    const listScrollOffset = list.scrollTop;

    if ((itemOffset + itemHeight) > (listHeight + listScrollOffset)) {
      list.scrollTop += (itemHeight + 1);
    }
    else if (itemOffset < listScrollOffset) {
      list.scrollTop -= (itemHeight + 1);
    }
  }

  function clearFocusHighlight() {
    Array.from(document.getElementsByClassName('ls-address-link'))
      .forEach((el) => el.classList.remove('ls-address-link--focused'));
  }

  // --- Security helpers ---

  function escapeHtml(str) {
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  function escapeAttr(str) {
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/"/g, '&quot;');
  }

  Drupal.behaviors.locationSignpost = {
    attach(context) {
      const wrapper = context.querySelector
        ? context.querySelector('#location-signpost-wrapper')
        : document.getElementById('location-signpost-wrapper');

      if (!wrapper || wrapper.dataset.lsInitialised) {
        return;
      }
      wrapper.dataset.lsInitialised = '1';
      init();
    },
  };

}(Drupal, drupalSettings));
