<?php

namespace Drupal\Tests\location_signpost\Unit\Plugin\LocationSignpostGeocoder;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Config\ImmutableConfig;
use Drupal\Core\Extension\ModuleHandlerInterface;
use Drupal\location_signpost\Plugin\LocationSignpostGeocoder\OsPlaces;
use Drupal\Tests\UnitTestCase;
use GuzzleHttp\ClientInterface;
use GuzzleHttp\Exception\RequestException;
use GuzzleHttp\Psr7\Response;
use Psr\Http\Message\RequestInterface;
use Psr\Log\LoggerInterface;

/**
 * @coversDefaultClass \Drupal\location_signpost\Plugin\LocationSignpostGeocoder\OsPlaces
 * @group location_signpost
 */
class OsPlacesTest extends UnitTestCase {

  protected ClientInterface $httpClient;
  protected ConfigFactoryInterface $configFactory;
  protected ImmutableConfig $config;
  protected ModuleHandlerInterface $moduleHandler;
  protected LoggerInterface $logger;

  protected function setUp(): void {
    parent::setUp();

    $this->config = $this->createMock(ImmutableConfig::class);
    $this->configFactory = $this->createMock(ConfigFactoryInterface::class);
    $this->configFactory->method('get')->with('location_signpost.settings')->willReturn($this->config);

    $this->httpClient = $this->createMock(ClientInterface::class);
    $this->moduleHandler = $this->createMock(ModuleHandlerInterface::class);
    $this->moduleHandler->method('moduleExists')->with('key')->willReturn(FALSE);
    $this->logger = $this->createMock(LoggerInterface::class);
  }

  protected function makePlugin(): OsPlaces {
    return new OsPlaces(
      [],
      'os_places',
      [],
      $this->configFactory,
      $this->httpClient,
      $this->moduleHandler,
      NULL,
      $this->logger,
    );
  }

  /**
   * @covers ::findAddresses
   */
  public function testReturnsEmptyArrayWhenApiKeyMissing(): void {
    $this->config->method('get')->willReturnMap([
      ['os_api_key', ''],
      ['geographic_filter', ''],
    ]);

    $plugin = $this->makePlugin();
    $this->assertSame([], $plugin->findAddresses('high street', ''));
  }

  /**
   * @covers ::findAddresses
   */
  public function testBuildsCorrectQueryParams(): void {
    $this->config->method('get')->willReturnMap([
      ['os_api_key', 'TEST-KEY-123'],
      ['geographic_filter', ''],
    ]);

    $capturedOptions = [];
    $this->httpClient
      ->expects($this->once())
      ->method('get')
      ->with(
        OsPlaces::ENDPOINT,
        $this->callback(function ($options) use (&$capturedOptions) {
          $capturedOptions = $options;
          return TRUE;
        })
      )
      ->willReturn(new Response(200, [], '{"results":[]}'));

    $this->makePlugin()->findAddresses('station road', '');

    $this->assertSame('TEST-KEY-123', $capturedOptions['query']['key']);
    $this->assertSame('station road', $capturedOptions['query']['query']);
    $this->assertSame(50, $capturedOptions['query']['maxresults']);
    $this->assertSame(0.3, $capturedOptions['query']['minmatch']);
    $this->assertSame('DPA', $capturedOptions['query']['dataset']);
  }

  /**
   * @covers ::findAddresses
   */
  public function testAppliesGeographicFilterAsCustodianCodes(): void {
    $this->config->method('get')->willReturnMap([
      ['os_api_key', 'TEST-KEY'],
      ['geographic_filter', '1000 1001'],
    ]);

    $capturedOptions = [];
    $this->httpClient
      ->expects($this->once())
      ->method('get')
      ->with(OsPlaces::ENDPOINT, $this->callback(function ($o) use (&$capturedOptions) {
        $capturedOptions = $o;
        return TRUE;
      }))
      ->willReturn(new Response(200, [], '{"results":[]}'));

    $this->makePlugin()->findAddresses('high street', '1000 1001');

    $this->assertStringContainsString('LOCAL_CUSTODIAN_CODE:1000', $capturedOptions['query']['fq']);
    $this->assertStringContainsString('LOCAL_CUSTODIAN_CODE:1001', $capturedOptions['query']['fq']);
  }

  /**
   * @covers ::findAddresses
   */
  public function testReturnsEmptyArrayAndLogsOnRequestException(): void {
    $this->config->method('get')->willReturnMap([
      ['os_api_key', 'KEY'],
      ['geographic_filter', ''],
    ]);

    $this->httpClient
      ->method('get')
      ->willThrowException(new RequestException(
        'Connection refused',
        $this->createMock(RequestInterface::class)
      ));

    $this->logger
      ->expects($this->once())
      ->method('error');

    $result = $this->makePlugin()->findAddresses('test query', '');
    $this->assertSame([], $result);
  }

  /**
   * @covers ::findAddresses
   */
  public function testReturnsEmptyArrayWhenResponseHasNoResults(): void {
    $this->config->method('get')->willReturnMap([
      ['os_api_key', 'KEY'],
      ['geographic_filter', ''],
    ]);

    $this->httpClient
      ->method('get')
      ->willReturn(new Response(200, [], '{"header":{"totalresults":0}}'));

    $this->assertSame([], $this->makePlugin()->findAddresses('anywhere', ''));
  }

  /**
   * @covers ::findAddresses
   */
  public function testSkipsMalformedResultItems(): void {
    $this->config->method('get')->willReturnMap([
      ['os_api_key', 'KEY'],
      ['geographic_filter', ''],
    ]);

    $body = json_encode(['results' => [
      'not-an-array',
      ['missing_dpa' => TRUE],
      ['DPA' => 'not-an-array'],
    ]]);

    $this->httpClient
      ->method('get')
      ->willReturn(new Response(200, [], $body));

    $this->assertSame([], $this->makePlugin()->findAddresses('test', ''));
  }

  /**
   * @covers ::findAddresses
   */
  public function testParsesValidDpaResult(): void {
    $this->config->method('get')->willReturnMap([
      ['os_api_key', 'KEY'],
      ['geographic_filter', ''],
    ]);

    $body = json_encode(['results' => [[
      'DPA' => [
        'BUILDING_NUMBER' => '1',
        'THOROUGHFARE_NAME' => 'HIGH STREET',
        'POST_TOWN' => 'ANYTOWN',
        'POSTCODE' => 'AA1 2BB',
        'X_COORDINATE' => 400000.0,
        'Y_COORDINATE' => 400000.0,
      ],
    ]]]);

    $this->httpClient
      ->method('get')
      ->willReturn(new Response(200, [], $body));

    $results = $this->makePlugin()->findAddresses('high street', '');

    $this->assertCount(1, $results);
    $this->assertSame('AA1 2BB', $results[0]['postcode']);
    $this->assertSame(400000.0, $results[0]['x']);
    $this->assertSame(400000.0, $results[0]['y']);
    $this->assertStringContainsString('High Street', $results[0]['address']);
    $this->assertStringContainsString('Anytown', $results[0]['address']);
  }

  /**
   * @covers ::findAddresses
   */
  public function testHandlesNullDpaFields(): void {
    $this->config->method('get')->willReturnMap([
      ['os_api_key', 'KEY'],
      ['geographic_filter', ''],
    ]);

    $body = json_encode(['results' => [[
      'DPA' => [
        'THOROUGHFARE_NAME' => 'SAMPLE ROAD',
        'POST_TOWN' => 'SAMPLEVILLE',
        'POSTCODE' => 'ZZ9 9ZZ',
        'X_COORDINATE' => 350000.0,
        'Y_COORDINATE' => 350000.0,
      ],
    ]]]);

    $this->httpClient
      ->method('get')
      ->willReturn(new Response(200, [], $body));

    $results = $this->makePlugin()->findAddresses('sample road', '');
    $this->assertNotEmpty($results);
  }

  /**
   * @covers ::findAddresses
   */
  public function testUsesKeyRepositoryWhenKeyModulePresent(): void {
    $this->config->method('get')->willReturnMap([
      ['os_api_key', 'my-key-entity-id'],
      ['geographic_filter', ''],
    ]);

    $keyRepository = $this->getMockBuilder(\stdClass::class)
      ->addMethods(['getKeyValue'])
      ->getMock();
    $keyRepository->method('getKeyValue')->with('my-key-entity-id')->willReturn('RESOLVED-KEY');

    $this->moduleHandler->method('moduleExists')->with('key')->willReturn(TRUE);

    $capturedOptions = [];
    $this->httpClient
      ->method('get')
      ->with(OsPlaces::ENDPOINT, $this->callback(function ($o) use (&$capturedOptions) {
        $capturedOptions = $o;
        return TRUE;
      }))
      ->willReturn(new Response(200, [], '{"results":[]}'));

    $plugin = new OsPlaces(
      [],
      'os_places',
      [],
      $this->configFactory,
      $this->httpClient,
      $this->moduleHandler,
      $keyRepository,
      $this->logger,
    );

    $plugin->findAddresses('test', '');
    $this->assertSame('RESOLVED-KEY', $capturedOptions['query']['key']);
  }

}
