<?php

namespace Drupal\Tests\location_signpost\Unit\Entity;

use Drupal\location_signpost\Entity\LocationSignpostArea;
use Drupal\Tests\UnitTestCase;

/**
 * @coversDefaultClass \Drupal\location_signpost\Entity\LocationSignpostArea
 * @group location_signpost
 */
class LocationSignpostAreaTest extends UnitTestCase {

  /**
   * Returns a partially-constructed area entity for testing getters.
   *
   * ConfigEntityBase requires a lot of infrastructure for a full instantiation,
   * so we use reflection to set protected properties directly.
   */
  protected function createArea(array $values = []): LocationSignpostArea {
    $area = (new \ReflectionClass(LocationSignpostArea::class))
      ->newInstanceWithoutConstructor();

    foreach ($values as $property => $value) {
      $ref = new \ReflectionProperty(LocationSignpostArea::class, $property);
      $ref->setAccessible(TRUE);
      $ref->setValue($area, $value);
    }

    return $area;
  }

  /**
   * @covers ::getOrganisationName
   */
  public function testGetOrganisationName(): void {
    $area = $this->createArea(['organisation_name' => 'Example Authority']);
    $this->assertSame('Example Authority', $area->getOrganisationName());
  }

  /**
   * @covers ::getOrganisationName
   */
  public function testGetOrganisationNameDefaultsToEmptyString(): void {
    $area = $this->createArea();
    $this->assertSame('', $area->getOrganisationName());
  }

  /**
   * @covers ::getOrganisationUrl
   */
  public function testGetOrganisationUrl(): void {
    $area = $this->createArea(['organisation_url' => 'https://www.example.gov.uk']);
    $this->assertSame('https://www.example.gov.uk', $area->getOrganisationUrl());
  }

  /**
   * @covers ::getOrganisationUrl
   */
  public function testGetOrganisationUrlDefaultsToEmptyString(): void {
    $area = $this->createArea();
    $this->assertSame('', $area->getOrganisationUrl());
  }

  /**
   * @covers ::getCustodianCode
   */
  public function testGetCustodianCode(): void {
    $area = $this->createArea(['custodian_code' => '1000']);
    $this->assertSame('1000', $area->getCustodianCode());
  }

  /**
   * @covers ::getCustodianCode
   */
  public function testGetCustodianCodeDefaultsToEmptyString(): void {
    $area = $this->createArea();
    $this->assertSame('', $area->getCustodianCode());
  }

  /**
   * @covers ::getMsoaCodes
   */
  public function testGetMsoaCodes(): void {
    $codes = ['E02000001', 'E02000002', 'E02000003'];
    $area = $this->createArea(['msoa_codes' => $codes]);
    $this->assertSame($codes, $area->getMsoaCodes());
  }

  /**
   * @covers ::getMsoaCodes
   */
  public function testGetMsoaCodesDefaultsToEmptyArray(): void {
    $area = $this->createArea();
    $this->assertIsArray($area->getMsoaCodes());
    $this->assertEmpty($area->getMsoaCodes());
  }

  /**
   * @covers ::getMsoaCodes
   */
  public function testGetMsoaCodesDoesNotMutateInput(): void {
    $codes = ['E02000001', 'E02000002'];
    $area = $this->createArea(['msoa_codes' => $codes]);

    $returned = $area->getMsoaCodes();
    $returned[] = 'E02000099';

    $this->assertCount(2, $area->getMsoaCodes());
  }

}
