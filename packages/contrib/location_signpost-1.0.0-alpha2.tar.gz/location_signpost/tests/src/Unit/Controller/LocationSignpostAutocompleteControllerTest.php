<?php

namespace Drupal\Tests\location_signpost\Unit\Controller;

use Drupal\Core\Config\ImmutableConfig;
use Drupal\location_signpost\Controller\LocationSignpostAutocompleteController;
use Drupal\location_signpost\Plugin\LocationSignpostGeocoder\LocationSignpostGeocoderInterface;
use Drupal\location_signpost\Plugin\LocationSignpostGeocoder\LocationSignpostGeocoderManager;
use Drupal\Tests\UnitTestCase;
use Symfony\Component\HttpFoundation\InputBag;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;

/**
 * @coversDefaultClass \Drupal\location_signpost\Controller\LocationSignpostAutocompleteController
 * @group location_signpost
 */
class LocationSignpostAutocompleteControllerTest extends UnitTestCase {

  protected LocationSignpostGeocoderManager $geocoderManager;
  protected ImmutableConfig $config;

  protected function setUp(): void {
    parent::setUp();

    $this->config = $this->createMock(ImmutableConfig::class);
    $this->config->method('get')->willReturnMap([
      ['geocoder_plugin', 'os_places'],
      ['geographic_filter', ''],
    ]);

    $this->geocoderManager = $this->createMock(LocationSignpostGeocoderManager::class);
  }

  /**
   * Returns a partial mock of the controller with config() stubbed out.
   *
   * ControllerBase::config() uses the DI container internally; stubbing it
   * keeps these tests fast and container-free.
   */
  protected function makeController(ImmutableConfig $config = NULL): LocationSignpostAutocompleteController {
    $controller = $this->getMockBuilder(LocationSignpostAutocompleteController::class)
      ->setConstructorArgs([$this->geocoderManager])
      ->onlyMethods(['config'])
      ->getMock();

    $controller->method('config')
      ->with('location_signpost.settings')
      ->willReturn($config ?? $this->config);

    return $controller;
  }

  protected function makeRequest(string $q): Request {
    $request = $this->createMock(Request::class);
    $bag = $this->createMock(InputBag::class);
    $bag->method('get')->with('q', '')->willReturn($q);
    $request->query = $bag;
    return $request;
  }

  /**
   * @covers ::autocomplete
   * @dataProvider shortQueryProvider
   */
  public function testReturnsEmptyForShortQuery(string $q): void {
    $this->geocoderManager->expects($this->never())->method('createInstance');

    $response = $this->makeController()->autocomplete($this->makeRequest($q));

    $this->assertInstanceOf(JsonResponse::class, $response);
    $this->assertSame('[]', $response->getContent());
  }

  public static function shortQueryProvider(): array {
    return [[''], ['a'], ['ab']];
  }

  /**
   * @covers ::autocomplete
   */
  public function testReturnsEmptyForOverlongQuery(): void {
    $this->geocoderManager->expects($this->never())->method('createInstance');

    $q = str_repeat('x', 201);
    $response = $this->makeController()->autocomplete($this->makeRequest($q));

    $this->assertSame('[]', $response->getContent());
  }

  /**
   * @covers ::autocomplete
   */
  public function testCallsConfiguredGeocoderPlugin(): void {
    $geocoder = $this->createMock(LocationSignpostGeocoderInterface::class);
    $geocoder->expects($this->once())
      ->method('findAddresses')
      ->with('station road', '')
      ->willReturn([]);

    $this->geocoderManager
      ->expects($this->once())
      ->method('createInstance')
      ->with('os_places')
      ->willReturn($geocoder);

    $this->makeController()->autocomplete($this->makeRequest('station road'));
  }

  /**
   * @covers ::autocomplete
   */
  public function testReturnsGeocoderResults(): void {
    $results = [
      ['address' => '1 High Street, Anytown, AA1 2BB', 'postcode' => 'AA1 2BB', 'x' => 400000.0, 'y' => 400000.0],
    ];

    $geocoder = $this->createMock(LocationSignpostGeocoderInterface::class);
    $geocoder->method('findAddresses')->willReturn($results);
    $this->geocoderManager->method('createInstance')->willReturn($geocoder);

    $response = $this->makeController()->autocomplete($this->makeRequest('station road'));

    $this->assertSame(json_encode($results), $response->getContent());
  }

  /**
   * @covers ::autocomplete
   */
  public function testReturns500OnGeocoderException(): void {
    $geocoder = $this->createMock(LocationSignpostGeocoderInterface::class);
    $geocoder->method('findAddresses')->willThrowException(new \RuntimeException('timeout'));
    $this->geocoderManager->method('createInstance')->willReturn($geocoder);

    $response = $this->makeController()->autocomplete($this->makeRequest('station road'));

    $this->assertSame(500, $response->getStatusCode());
  }

  /**
   * @covers ::autocomplete
   */
  public function testPassesGeographicFilterFromConfig(): void {
    $config = $this->createMock(ImmutableConfig::class);
    $config->method('get')->willReturnMap([
      ['geocoder_plugin', 'os_places'],
      ['geographic_filter', '1000 1001'],
    ]);

    $geocoder = $this->createMock(LocationSignpostGeocoderInterface::class);
    $geocoder->expects($this->once())
      ->method('findAddresses')
      ->with('road', '1000 1001')
      ->willReturn([]);

    $this->geocoderManager->method('createInstance')->willReturn($geocoder);

    $this->makeController($config)->autocomplete($this->makeRequest('road'));
  }

}
