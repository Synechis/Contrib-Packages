<?php

namespace Drupal\Tests\location_signpost\Functional;

use Drupal\location_signpost\Entity\LocationSignpostArea;
use Drupal\Tests\BrowserTestBase;

/**
 * Tests the Location Signpost Area add/edit/delete forms.
 *
 * @group location_signpost
 */
class LocationSignpostAreaFormTest extends BrowserTestBase {

  protected static $modules = ['location_signpost'];

  protected $defaultTheme = 'stark';

  protected function setUp(): void {
    parent::setUp();
    $this->drupalLogin($this->drupalCreateUser(['administer location signpost']));
  }

  /**
   * Area list page is accessible.
   */
  public function testAreaListAccessible(): void {
    $this->drupalGet('/admin/structure/location-signpost/areas');
    $this->assertSession()->statusCodeEquals(200);
  }

  /**
   * Add form is accessible and submission creates the entity.
   */
  public function testAddAreaCreatesEntity(): void {
    $this->drupalGet('/admin/structure/location-signpost/areas/add');
    $this->assertSession()->statusCodeEquals(200);

    $this->submitForm([
      'label' => 'North District',
      'id' => 'north_district',
      'organisation_name' => 'Example Authority',
      'organisation_url' => 'https://www.example.gov.uk',
      'custodian_code' => '1000',
      'msoa_codes' => "E02000001\nE02000002",
    ], 'Save');

    $area = LocationSignpostArea::load('north_district');
    $this->assertNotNull($area);
    $this->assertSame('North District', $area->label());
    $this->assertSame('Example Authority', $area->getOrganisationName());
    $this->assertSame('1000', $area->getCustodianCode());
    $this->assertSame(['E02000001', 'E02000002'], $area->getMsoaCodes());
  }

  /**
   * MSOA codes textarea is split on newlines and trimmed.
   */
  public function testMsoaCodesTextareaRoundTrips(): void {
    $this->drupalGet('/admin/structure/location-signpost/areas/add');
    $this->submitForm([
      'label' => 'South Borough',
      'id' => 'south_borough',
      'organisation_name' => 'Sample Council',
      'msoa_codes' => "  E02000010  \nE02000011\n\nE02000012",
    ], 'Save');

    $area = LocationSignpostArea::load('south_borough');
    // Blank lines and surrounding whitespace should be stripped.
    $this->assertSame(['E02000010', 'E02000011', 'E02000012'], $area->getMsoaCodes());
  }

  /**
   * Editing an existing area updates its values.
   */
  public function testEditAreaUpdatesValues(): void {
    LocationSignpostArea::create([
      'id' => 'east_town',
      'label' => 'East Town',
      'organisation_name' => 'Old Org',
    ])->save();

    $this->drupalGet('/admin/structure/location-signpost/areas/east_town');
    $this->submitForm([
      'organisation_name' => 'Example Authority',
    ], 'Save');

    $area = LocationSignpostArea::load('east_town');
    $this->assertSame('Example Authority', $area->getOrganisationName());
  }

  /**
   * Machine name field is disabled when editing an existing area.
   */
  public function testMachineNameDisabledOnEdit(): void {
    LocationSignpostArea::create(['id' => 'west_parish', 'label' => 'West Parish'])->save();

    $this->drupalGet('/admin/structure/location-signpost/areas/west_parish');
    $this->assertSession()->fieldDisabled('id');
  }

  /**
   * Deleting an area removes it from storage.
   */
  public function testDeleteAreaRemovesEntity(): void {
    LocationSignpostArea::create(['id' => 'to_delete', 'label' => 'Delete Me'])->save();

    $this->drupalGet('/admin/structure/location-signpost/areas/to_delete/delete');
    $this->submitForm([], 'Delete');

    $this->assertNull(LocationSignpostArea::load('to_delete'));
  }

  /**
   * After save the user is redirected to the area list.
   */
  public function testSaveRedirectsToList(): void {
    $this->drupalGet('/admin/structure/location-signpost/areas/add');
    $this->submitForm([
      'label' => 'Central Vale',
      'id' => 'central_vale',
      'organisation_name' => 'Example Authority',
    ], 'Save');

    $this->assertSession()->addressEquals('/admin/structure/location-signpost/areas');
  }

}
