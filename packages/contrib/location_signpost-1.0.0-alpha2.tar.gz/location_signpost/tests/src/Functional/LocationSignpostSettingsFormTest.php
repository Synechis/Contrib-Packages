<?php

namespace Drupal\Tests\location_signpost\Functional;

use Drupal\Tests\BrowserTestBase;

/**
 * Tests the Location Signpost admin settings form.
 *
 * @group location_signpost
 */
class LocationSignpostSettingsFormTest extends BrowserTestBase {

  protected static $modules = ['location_signpost'];

  protected $defaultTheme = 'stark';

  /**
   * Admin user with the module permission.
   */
  protected $adminUser;

  protected function setUp(): void {
    parent::setUp();
    $this->adminUser = $this->drupalCreateUser(['administer location signpost']);
  }

  /**
   * Settings page is accessible to privileged users.
   */
  public function testSettingsPageAccessible(): void {
    $this->drupalLogin($this->adminUser);
    $this->drupalGet('/admin/config/services/location-signpost');
    $this->assertSession()->statusCodeEquals(200);
  }

  /**
   * Unprivileged users are denied access.
   */
  public function testSettingsPageDeniedWithoutPermission(): void {
    $user = $this->drupalCreateUser([]);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/services/location-signpost');
    $this->assertSession()->statusCodeEquals(403);
  }

  /**
   * All expected fields are present on the form.
   */
  public function testSettingsFormRendersAllFields(): void {
    $this->drupalLogin($this->adminUser);
    $this->drupalGet('/admin/config/services/location-signpost');

    $this->assertSession()->fieldExists('os_api_key');
    $this->assertSession()->fieldExists('geographic_filter');
    $this->assertSession()->fieldExists('block_heading');
    $this->assertSession()->fieldExists('input_label');
    $this->assertSession()->fieldExists('search_button_label');
    $this->assertSession()->fieldExists('search_again_label');
    $this->assertSession()->fieldExists('closest_match_label');
    $this->assertSession()->fieldExists('organisation_label');
    $this->assertSession()->fieldExists('area_label');
    $this->assertSession()->fieldExists('services_heading');
    $this->assertSession()->fieldExists('no_match_message');
  }

  /**
   * Submitting the form saves values to config.
   */
  public function testSettingsFormSavesConfig(): void {
    $this->drupalLogin($this->adminUser);
    $this->drupalGet('/admin/config/services/location-signpost');

    $this->submitForm([
      'os_api_key' => 'TEST-KEY-FUNCTIONAL',
      'block_heading' => 'Find where you live',
      'no_match_message' => 'Sorry, nothing found.',
    ], 'Save configuration');

    $this->assertSession()->statusCodeEquals(200);

    $config = $this->config('location_signpost.settings');
    $this->assertSame('TEST-KEY-FUNCTIONAL', $config->get('os_api_key'));
    $this->assertSame('Find where you live', $config->get('block_heading'));
    $this->assertSame('Sorry, nothing found.', $config->get('no_match_message'));
  }

  /**
   * Saved values are reflected when the form is reloaded.
   */
  public function testSavedValuesShownOnReload(): void {
    $this->drupalLogin($this->adminUser);
    $this->drupalGet('/admin/config/services/location-signpost');
    $this->submitForm(['block_heading' => 'Custom heading'], 'Save configuration');

    $this->drupalGet('/admin/config/services/location-signpost');
    $this->assertSession()->fieldValueEquals('block_heading', 'Custom heading');
  }

}
