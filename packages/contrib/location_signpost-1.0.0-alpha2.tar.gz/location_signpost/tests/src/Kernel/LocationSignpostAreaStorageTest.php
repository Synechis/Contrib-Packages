<?php

namespace Drupal\Tests\location_signpost\Kernel;

use Drupal\KernelTests\KernelTestBase;
use Drupal\location_signpost\Entity\LocationSignpostArea;

/**
 * Config entity CRUD and schema validation for LocationSignpostArea.
 *
 * @group location_signpost
 */
class LocationSignpostAreaStorageTest extends KernelTestBase {

  protected static $modules = ['location_signpost', 'system', 'user'];

  /**
   * @covers \Drupal\location_signpost\Entity\LocationSignpostArea
   */
  public function testStorageIsRegistered(): void {
    $storage = $this->container
      ->get('entity_type.manager')
      ->getStorage('location_signpost_area');

    $this->assertNotNull($storage);
  }

  /**
   * @covers \Drupal\location_signpost\Entity\LocationSignpostArea
   */
  public function testCreateAndReloadRoundTrip(): void {
    $values = [
      'id' => 'north_district',
      'label' => 'North District',
      'organisation_name' => 'Example Authority',
      'organisation_url' => 'https://www.example.gov.uk',
      'custodian_code' => '1000',
      'msoa_codes' => ['E02000001', 'E02000002'],
    ];

    $area = LocationSignpostArea::create($values);
    $area->save();

    /** @var \Drupal\location_signpost\Entity\LocationSignpostAreaInterface $loaded */
    $loaded = LocationSignpostArea::load('north_district');

    $this->assertNotNull($loaded);
    $this->assertSame('North District', $loaded->label());
    $this->assertSame('Example Authority', $loaded->getOrganisationName());
    $this->assertSame('https://www.example.gov.uk', $loaded->getOrganisationUrl());
    $this->assertSame('1000', $loaded->getCustodianCode());
    $this->assertSame(['E02000001', 'E02000002'], $loaded->getMsoaCodes());
  }

  /**
   * @covers \Drupal\location_signpost\Entity\LocationSignpostArea
   */
  public function testDeleteRemovesEntity(): void {
    LocationSignpostArea::create(['id' => 'to_delete', 'label' => 'Delete me'])->save();

    $area = LocationSignpostArea::load('to_delete');
    $this->assertNotNull($area);

    $area->delete();

    $this->assertNull(LocationSignpostArea::load('to_delete'));
  }

  /**
   * @covers \Drupal\location_signpost\Entity\LocationSignpostArea
   */
  public function testMsoaCodesDefaultToEmptyArray(): void {
    LocationSignpostArea::create(['id' => 'no_msoa', 'label' => 'No MSOA'])->save();

    $loaded = LocationSignpostArea::load('no_msoa');
    $this->assertIsArray($loaded->getMsoaCodes());
    $this->assertEmpty($loaded->getMsoaCodes());
  }

  /**
   * @covers \Drupal\location_signpost\LocationSignpostAreaListBuilder
   */
  public function testListBuilderReturnsRenderArray(): void {
    LocationSignpostArea::create([
      'id' => 'list_test',
      'label' => 'List Test',
      'organisation_name' => 'Test Authority',
      'custodian_code' => '1001',
    ])->save();

    $list_builder = $this->container
      ->get('entity_type.manager')
      ->getListBuilder('location_signpost_area');

    $build = $list_builder->render();

    $this->assertIsArray($build);
    $this->assertArrayHasKey('#type', $build);
  }

}
