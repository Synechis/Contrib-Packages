<?php

namespace Drupal\Tests\location_signpost\Kernel;

use Drupal\block\Entity\Block;
use Drupal\KernelTests\KernelTestBase;
use Drupal\location_signpost\Entity\LocationSignpostArea;
use Drupal\location_signpost\Plugin\Block\LocationSignpostBlock;

/**
 * Kernel tests for the Location Signpost block plugin.
 *
 * @group location_signpost
 */
class LocationSignpostBlockKernelTest extends KernelTestBase {

  protected static $modules = [
    'location_signpost',
    'block',
    'system',
    'user',
    'node',
    'link',
    'field',
    'text',
  ];

  protected function setUp(): void {
    parent::setUp();
    $this->installConfig(['location_signpost']);
    $this->installEntitySchema('node');
    $this->installEntitySchema('user');
  }

  /**
   * Returns an instantiated block plugin with the given configuration.
   */
  protected function makeBlock(array $config = []): LocationSignpostBlock {
    return $this->container
      ->get('plugin.manager.block')
      ->createInstance('location_signpost', $config);
  }

  /**
   * @covers \Drupal\location_signpost\Plugin\Block\LocationSignpostBlock::defaultConfiguration
   */
  public function testBlockIsDiscoverable(): void {
    $definitions = $this->container
      ->get('plugin.manager.block')
      ->getDefinitions();

    $this->assertArrayHasKey('location_signpost', $definitions);
  }

  /**
   * @covers \Drupal\location_signpost\Plugin\Block\LocationSignpostBlock::defaultConfiguration
   */
  public function testDefaultConfiguration(): void {
    $block = $this->makeBlock();
    $config = $block->defaultConfiguration();

    $this->assertFalse($config['show_map']);
    $this->assertSame('default', $config['link_group']);
  }

  /**
   * @covers \Drupal\location_signpost\Plugin\Block\LocationSignpostBlock::blockSubmit
   */
  public function testBlockSubmitCastsShowMapToBool(): void {
    $block = $this->makeBlock();
    $form_state = new \Drupal\Core\Form\FormState();
    $form_state->setValues(['show_map' => 1, 'link_group' => 'default']);
    $block->blockSubmit([], $form_state);

    $this->assertTrue($block->getConfiguration()['show_map']);
  }

  /**
   * @covers \Drupal\location_signpost\Plugin\Block\LocationSignpostBlock::blockSubmit
   */
  public function testBlockSubmitTrimsLinkGroup(): void {
    $block = $this->makeBlock();
    $form_state = new \Drupal\Core\Form\FormState();
    $form_state->setValues(['show_map' => 0, 'link_group' => '  council_tax  ']);
    $block->blockSubmit([], $form_state);

    $this->assertSame('council_tax', $block->getConfiguration()['link_group']);
  }

  /**
   * @covers \Drupal\location_signpost\Plugin\Block\LocationSignpostBlock::blockSubmit
   */
  public function testBlockSubmitDefaultsEmptyLinkGroupToDefault(): void {
    $block = $this->makeBlock();
    $form_state = new \Drupal\Core\Form\FormState();
    $form_state->setValues(['show_map' => 0, 'link_group' => '']);
    $block->blockSubmit([], $form_state);

    $this->assertSame('default', $block->getConfiguration()['link_group']);
  }

  /**
   * @covers \Drupal\location_signpost\Plugin\Block\LocationSignpostBlock::build
   */
  public function testBuildReturnsCorrectTheme(): void {
    $block = $this->makeBlock();
    $build = $block->build();

    $this->assertSame('location_signpost_block', $build['#theme']);
  }

  /**
   * @covers \Drupal\location_signpost\Plugin\Block\LocationSignpostBlock::build
   */
  public function testBuildSetsAutocompleteUrl(): void {
    $block = $this->makeBlock();
    $build = $block->build();

    $this->assertArrayHasKey('autocompleteUrl', $build['#attached']['drupalSettings']['location_signpost']);
    $this->assertStringContainsString('autocomplete', $build['#attached']['drupalSettings']['location_signpost']['autocompleteUrl']);
  }

  /**
   * @covers \Drupal\location_signpost\Plugin\Block\LocationSignpostBlock::build
   */
  public function testBuildReturnsEmptyAreasWhenNoEntitiesExist(): void {
    $block = $this->makeBlock();
    $build = $block->build();

    $this->assertSame([], $build['#attached']['drupalSettings']['location_signpost']['areas']);
  }

  /**
   * @covers \Drupal\location_signpost\Plugin\Block\LocationSignpostBlock::build
   */
  public function testBuildIndexesAreasByCustodianCode(): void {
    LocationSignpostArea::create([
      'id' => 'test_area',
      'label' => 'Test Area',
      'organisation_name' => 'Test Council',
      'custodian_code' => '999',
      'msoa_codes' => ['E02009999'],
    ])->save();

    $block = $this->makeBlock();
    $build = $block->build();

    $areas = $build['#attached']['drupalSettings']['location_signpost']['areas'];
    $this->assertArrayHasKey('999', $areas);
    $this->assertSame('Test Area', $areas['999']['label']);
  }

}
