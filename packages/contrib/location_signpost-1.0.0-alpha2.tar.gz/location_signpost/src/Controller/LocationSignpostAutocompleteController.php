<?php

namespace Drupal\location_signpost\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\location_signpost\Plugin\LocationSignpostGeocoder\LocationSignpostGeocoderManager;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;

/**
 * Server-side proxy for address autocomplete — keeps the API key off the browser.
 */
class LocationSignpostAutocompleteController extends ControllerBase {

  public function __construct(
    protected LocationSignpostGeocoderManager $geocoderManager,
  ) {}

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container): static {
    return new static(
      $container->get('plugin.manager.location_signpost_geocoder'),
    );
  }

  /**
   * Returns JSON address suggestions for a search query.
   */
  public function autocomplete(Request $request): JsonResponse {
    $query = trim($request->query->get('q', ''));

    if (strlen($query) < 3 || strlen($query) > 200) {
      return new JsonResponse([]);
    }

    $settings = $this->config('location_signpost.settings');
    $plugin_id = $settings->get('geocoder_plugin') ?: 'os_places';
    $geographic_filter = $settings->get('geographic_filter') ?? '';

    try {
      /** @var \Drupal\location_signpost\Plugin\LocationSignpostGeocoder\LocationSignpostGeocoderInterface $geocoder */
      $geocoder = $this->geocoderManager->createInstance($plugin_id);
      $results = $geocoder->findAddresses($query, $geographic_filter);
    }
    catch (\Exception $e) {
      return new JsonResponse([], 500);
    }

    return new JsonResponse($results);
  }

}
