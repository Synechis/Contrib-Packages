<?php

namespace Drupal\location_signpost;

use Drupal\Core\Config\Entity\ConfigEntityListBuilder;
use Drupal\Core\Entity\EntityInterface;

/**
 * List builder for Location Signpost Area config entities.
 */
class LocationSignpostAreaListBuilder extends ConfigEntityListBuilder {

  /**
   * {@inheritdoc}
   */
  public function buildHeader(): array {
    $header['label'] = $this->t('Area');
    $header['organisation_name'] = $this->t('Organisation');
    $header['custodian_code'] = $this->t('Custodian code');
    return $header + parent::buildHeader();
  }

  /**
   * {@inheritdoc}
   */
  public function buildRow(EntityInterface $entity): array {
    /** @var \Drupal\location_signpost\Entity\LocationSignpostAreaInterface $entity */
    $row['label'] = $entity->label();
    $row['organisation_name'] = $entity->getOrganisationName();
    $row['custodian_code'] = $entity->getCustodianCode();
    return $row + parent::buildRow($entity);
  }

}
