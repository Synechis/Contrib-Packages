<?php

namespace Drupal\location_signpost\Entity;

use Drupal\Core\Config\Entity\ConfigEntityInterface;

/**
 * @see \Drupal\location_signpost\Entity\LocationSignpostArea
 */
interface LocationSignpostAreaInterface extends ConfigEntityInterface {

  /**
   * Organisation name (e.g. "Example Authority").
   */
  public function getOrganisationName(): string;

  /**
   * Organisation website URL.
   */
  public function getOrganisationUrl(): string;

  /**
   * OS local custodian code (e.g. "905").
   */
  public function getCustodianCode(): string;

  /**
   * ONS MSOA codes that map to this area.
   *
   * @return string[]
   */
  public function getMsoaCodes(): array;

}
