<?php

namespace Drupal\location_signpost\Entity;

use Drupal\Core\Config\Entity\ConfigEntityBase;
use Drupal\Core\Entity\EntityStorageInterface;

/**
 * @ConfigEntityType(
 *   id = "location_signpost_area",
 *   label = @Translation("Location signpost area"),
 *   label_collection = @Translation("Location signpost areas"),
 *   label_singular = @Translation("location signpost area"),
 *   label_plural = @Translation("location signpost areas"),
 *   label_count = @PluralTranslation(
 *     singular = "@count location signpost area",
 *     plural = "@count location signpost areas",
 *   ),
 *   handlers = {
 *     "list_builder" = "Drupal\location_signpost\LocationSignpostAreaListBuilder",
 *     "form" = {
 *       "add" = "Drupal\location_signpost\Form\LocationSignpostAreaForm",
 *       "edit" = "Drupal\location_signpost\Form\LocationSignpostAreaForm",
 *       "delete" = "Drupal\Core\Entity\EntityDeleteForm",
 *     },
 *   },
 *   config_prefix = "location_signpost_area",
 *   admin_permission = "administer location signpost",
 *   entity_keys = {
 *     "id" = "id",
 *     "label" = "label",
 *   },
 *   links = {
 *     "collection" = "/admin/structure/location-signpost/areas",
 *     "add-form" = "/admin/structure/location-signpost/areas/add",
 *     "edit-form" = "/admin/structure/location-signpost/areas/{location_signpost_area}",
 *     "delete-form" = "/admin/structure/location-signpost/areas/{location_signpost_area}/delete",
 *   },
 *   config_export = {
 *     "id",
 *     "label",
 *     "organisation_name",
 *     "organisation_url",
 *     "custodian_code",
 *     "msoa_codes",
 *   }
 * )
 */
class LocationSignpostArea extends ConfigEntityBase implements LocationSignpostAreaInterface {

  /**
   * The area machine name.
   */
  protected string $id = '';

  /**
   * The area human-readable label shown to visitors (e.g. "North District").
   */
  protected string $label = '';

  /**
   * The name of the responsible organisation (e.g. "Example Authority").
   */
  protected string $organisation_name = '';

  /**
   * The URL for the responsible organisation.
   */
  protected string $organisation_url = '';

  /**
   * The OS custodian code for this area (e.g. "1234").
   */
  protected string $custodian_code = '';

  /**
   * ONS MSOA codes that map to this area.
   *
   * @var string[]
   */
  protected array $msoa_codes = [];

  /**
   * {@inheritdoc}
   */
  public function getOrganisationName(): string {
    return $this->organisation_name;
  }

  /**
   * {@inheritdoc}
   */
  public function getOrganisationUrl(): string {
    return $this->organisation_url;
  }

  /**
   * {@inheritdoc}
   */
  public function getCustodianCode(): string {
    return $this->custodian_code;
  }

  /**
   * {@inheritdoc}
   */
  public function getMsoaCodes(): array {
    return $this->msoa_codes;
  }

}
