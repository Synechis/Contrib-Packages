<?php

namespace Drupal\location_signpost\Annotation;

use Drupal\Component\Annotation\Plugin;

/**
 * @Annotation
 */
class LocationSignpostGeocoder extends Plugin {

  /**
   * The plugin ID.
   */
  public string $id;

  /**
   * The human-readable name of the geocoder.
   *
   * @ingroup plugin_translatable
   */
  public string $label;

}
