<?php

namespace Drupal\location_signpost\Form;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Extension\ModuleHandlerInterface;
use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * @see \Drupal\location_signpost\LocationSignpostSettingsForm
 */
class LocationSignpostSettingsForm extends ConfigFormBase {

  /**
   * The module handler.
   */
  protected ModuleHandlerInterface $moduleHandler;

  public function __construct(ConfigFactoryInterface $config_factory, ModuleHandlerInterface $module_handler) {
    parent::__construct($config_factory);
    $this->moduleHandler = $module_handler;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container): static {
    return new static(
      $container->get('config.factory'),
      $container->get('module_handler'),
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId(): string {
    return 'location_signpost_settings';
  }

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames(): array {
    return ['location_signpost.settings'];
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state): array {
    $config = $this->config('location_signpost.settings');

    $form['api'] = [
      '#type' => 'details',
      '#title' => $this->t('API configuration'),
      '#open' => TRUE,
    ];

    if ($this->moduleHandler->moduleExists('key')) {
      $form['api']['os_api_key'] = [
        '#type' => 'key_select',
        '#title' => $this->t('OS Places API key'),
        '#description' => $this->t('Select the Key entity that stores your Ordnance Survey Places API key.'),
        '#default_value' => $config->get('os_api_key'),
        '#required' => TRUE,
      ];
    }
    else {
      $form['api']['os_api_key'] = [
        '#type' => 'textfield',
        '#title' => $this->t('OS Places API key'),
        '#description' => $this->t('Your Ordnance Survey Places API key. For better security, install the <a href="https://www.drupal.org/project/key">Key module</a> to store API keys outside of configuration.'),
        '#default_value' => $config->get('os_api_key'),
        '#required' => TRUE,
      ];

      $this->messenger()->addWarning(
        $this->t('Consider installing the <a href="https://www.drupal.org/project/key">Key module</a> to store API keys securely outside of exported configuration.')
      );
    }

    $form['api']['geographic_filter'] = [
      '#type' => 'textarea',
      '#title' => $this->t('Geographic filter (custodian codes)'),
      '#description' => $this->t('Optionally restrict address searches to specific local authority boundaries. Enter OS local custodian codes one per line (e.g. 905, 910). Leave empty to search all of Great Britain.'),
      '#default_value' => $config->get('geographic_filter'),
      '#rows' => 4,
    ];

    $form['text'] = [
      '#type' => 'details',
      '#title' => $this->t('Display text'),
      '#description' => $this->t('Customise the text shown to visitors. All strings are translatable via the Translation interface.'),
      '#open' => FALSE,
    ];

    $strings = [
      'block_heading' => [$this->t('Block heading'), $this->t('The main heading above the search input.')],
      'input_label' => [$this->t('Input label'), $this->t('The label for the address/postcode text input.')],
      'search_button_label' => [$this->t('Search button label'), $this->t('The text on the search button.')],
      'search_again_label' => [$this->t('Search again label'), $this->t('The text for the "search again" reset link shown after a result.')],
      'closest_match_label' => [$this->t('Closest match label'), $this->t('Label shown before the matched address in results.')],
      'organisation_label' => [$this->t('Organisation label'), $this->t('Label shown before the organisation name in results (e.g. "Your council is").')],
      'area_label' => [$this->t('Area label'), $this->t('Label shown before the area name in results (e.g. "Your local area is").')],
      'services_heading' => [$this->t('Services heading'), $this->t('Heading above the area-specific signpost links.')],
      'no_match_message' => [$this->t('No match message'), $this->t('Message shown when no matching area is found for the entered address.')],
    ];

    foreach ($strings as $key => [$label, $description]) {
      $form['text'][$key] = [
        '#type' => 'textfield',
        '#title' => $label,
        '#description' => $description,
        '#default_value' => $config->get($key),
      ];
    }

    return parent::buildForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state): void {
    $config = $this->config('location_signpost.settings');

    $keys = [
      'os_api_key',
      'geographic_filter',
      'block_heading',
      'input_label',
      'search_button_label',
      'search_again_label',
      'closest_match_label',
      'organisation_label',
      'area_label',
      'services_heading',
      'no_match_message',
    ];

    foreach ($keys as $key) {
      $config->set($key, $form_state->getValue($key));
    }

    $config->save();

    parent::submitForm($form, $form_state);
  }

}
