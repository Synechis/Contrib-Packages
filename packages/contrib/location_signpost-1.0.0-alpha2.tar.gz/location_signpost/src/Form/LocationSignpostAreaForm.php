<?php

namespace Drupal\location_signpost\Form;

use Drupal\Core\Entity\EntityForm;
use Drupal\Core\Form\FormStateInterface;

/**
 * @see \Drupal\location_signpost\Entity\LocationSignpostArea
 */
class LocationSignpostAreaForm extends EntityForm {

  /**
   * {@inheritdoc}
   */
  public function form(array $form, FormStateInterface $form_state): array {
    $form = parent::form($form, $form_state);

    /** @var \Drupal\location_signpost\Entity\LocationSignpostAreaInterface $area */
    $area = $this->entity;

    $form['label'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Area name'),
      '#description' => $this->t('The name shown to visitors when their address matches this area (e.g. "North District", "South Borough").'),
      '#default_value' => $area->label(),
      '#required' => TRUE,
    ];

    $form['id'] = [
      '#type' => 'machine_name',
      '#default_value' => $area->id(),
      '#machine_name' => [
        'exists' => '\Drupal\location_signpost\Entity\LocationSignpostArea::load',
      ],
      '#disabled' => !$area->isNew(),
    ];

    $form['organisation_name'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Organisation name'),
      '#description' => $this->t('The responsible organisation for this area (e.g. "Example Authority", "NHS Greater Manchester ICB").'),
      '#default_value' => $area->getOrganisationName(),
      '#required' => TRUE,
    ];

    $form['organisation_url'] = [
      '#type' => 'url',
      '#title' => $this->t('Organisation URL'),
      '#description' => $this->t('The website URL for the responsible organisation.'),
      '#default_value' => $area->getOrganisationUrl(),
    ];

    $form['custodian_code'] = [
      '#type' => 'textfield',
      '#title' => $this->t('OS custodian code'),
      '#description' => $this->t('The Ordnance Survey local custodian code for this area. Used to filter address searches to a specific authority boundary (e.g. "1234"). Leave empty if no geographic filtering is needed.'),
      '#default_value' => $area->getCustodianCode(),
      '#size' => 10,
    ];

    $form['msoa_codes'] = [
      '#type' => 'textarea',
      '#title' => $this->t('MSOA codes'),
      '#description' => $this->t('ONS Middle Layer Super Output Area (MSOA) codes that map to this area. Enter one code per line. These are used to identify which area a postcode belongs to (e.g. "E02000001"). MSOA codes can be found via the postcodes.io API.'),
      '#default_value' => implode("\n", $area->getMsoaCodes()),
      '#rows' => 6,
    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function save(array $form, FormStateInterface $form_state): int {
    /** @var \Drupal\location_signpost\Entity\LocationSignpostAreaInterface $area */
    $area = $this->entity;

    // Convert the textarea newline-separated MSOA codes to an array.
    $raw = $form_state->getValue('msoa_codes');
    $codes = array_filter(array_map('trim', explode("\n", $raw)));
    $area->set('msoa_codes', array_values($codes));

    $status = $area->save();

    if ($status === SAVED_NEW) {
      $this->messenger()->addStatus($this->t('Area %label has been created.', ['%label' => $area->label()]));
    }
    else {
      $this->messenger()->addStatus($this->t('Area %label has been updated.', ['%label' => $area->label()]));
    }

    $form_state->setRedirectUrl($area->toUrl('collection'));

    return $status;
  }

}
