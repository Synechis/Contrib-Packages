<?php

namespace Drupal\location_signpost\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\Core\Url;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Provides the Location Signpost block.
 *
 * @Block(
 *   id = "location_signpost",
 *   admin_label = @Translation("Location Signpost"),
 *   category = @Translation("Location Signpost"),
 * )
 */
class LocationSignpostBlock extends BlockBase implements ContainerFactoryPluginInterface {

  public function __construct(
    array $configuration,
    string $plugin_id,
    mixed $plugin_definition,
    protected ConfigFactoryInterface $configFactory,
    protected EntityTypeManagerInterface $entityTypeManager,
  ) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition): static {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('config.factory'),
      $container->get('entity_type.manager'),
    );
  }

  /**
   * {@inheritdoc}
   */
  public function defaultConfiguration(): array {
    return [
      'show_map' => FALSE,
      'link_group' => 'default',
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function blockForm($form, FormStateInterface $form_state): array {
    $config = $this->getConfiguration();

    $form['show_map'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Show map'),
      '#description' => $this->t('Display an interactive map showing the matched address location.'),
      '#default_value' => $config['show_map'] ?? FALSE,
    ];

    $form['link_group'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Link group'),
      '#description' => $this->t('The link group to use for area-specific signpost links. Create <em>Location Signpost Links</em> nodes with a matching group value. Use different values for different block instances (e.g. <code>council_tax</code>, <code>parking</code>). Defaults to <code>default</code>.'),
      '#default_value' => $config['link_group'] ?? 'default',
      '#size' => 40,
    ];

    $form['settings_link'] = [
      '#markup' => $this->t('<p>Configure the OS Places API key and display text at <a href=":url">Location Signpost Settings</a>.</p>', [
        ':url' => Url::fromRoute('location_signpost.settings')->toString(),
      ]),
    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function blockSubmit($form, FormStateInterface $form_state): void {
    $this->configuration['show_map'] = (bool) $form_state->getValue('show_map');
    $this->configuration['link_group'] = trim($form_state->getValue('link_group')) ?: 'default';
  }

  /**
   * {@inheritdoc}
   */
  public function build(): array {
    $settings = $this->configFactory->get('location_signpost.settings');
    $block_config = $this->getConfiguration();
    $link_group = $block_config['link_group'] ?? 'default';
    $show_map = (bool) ($block_config['show_map'] ?? FALSE);

    $strings = [
      'blockHeading' => $settings->get('block_heading'),
      'inputLabel' => $settings->get('input_label'),
      'searchButtonLabel' => $settings->get('search_button_label'),
      'searchAgainLabel' => $settings->get('search_again_label'),
      'closestMatchLabel' => $settings->get('closest_match_label'),
      'organisationLabel' => $settings->get('organisation_label'),
      'areaLabel' => $settings->get('area_label'),
      'servicesHeading' => $settings->get('services_heading'),
      'noMatchMessage' => $settings->get('no_match_message'),
    ];

    $areas = $this->buildAreasData($link_group);

    return [
      '#theme' => 'location_signpost_block',
      '#strings' => $strings,
      '#show_map' => $show_map,
      '#attached' => [
        'library' => ['location_signpost/signpost'],
        'drupalSettings' => [
          'location_signpost' => [
            'autocompleteUrl' => Url::fromRoute('location_signpost.autocomplete')->toString(),
            'showMap' => $show_map,
            'strings' => $strings,
            'areas' => $areas,
          ],
        ],
      ],
    ];
  }

  /**
   * Builds the areas array for drupalSettings from config entities and link nodes.
   */
  protected function buildAreasData(string $link_group): array {
    $areas = [];

    // Load all LocationSignpostArea config entities — used for MSOA lookup
    // regardless of whether link nodes exist for them.
    $area_entities = $this->entityTypeManager
      ->getStorage('location_signpost_area')
      ->loadMultiple();

    // Index config entities by custodian code for easy lookup.
    $by_custodian = [];
    foreach ($area_entities as $area) {
      /** @var \Drupal\location_signpost\Entity\LocationSignpostAreaInterface $area */
      $code = $area->getCustodianCode();
      if ($code !== '') {
        $by_custodian[$code] = $area;
      }
    }

    // Build the base areas array from config entities (no links yet).
    foreach ($area_entities as $area) {
      /** @var \Drupal\location_signpost\Entity\LocationSignpostAreaInterface $area */
      $areas[$area->id()] = [
        'label' => $area->label(),
        'organisationName' => $area->getOrganisationName(),
        'organisationUrl' => $area->getOrganisationUrl(),
        'custodianCode' => $area->getCustodianCode(),
        'msoaCodes' => $area->getMsoaCodes(),
        'links' => [],
      ];
    }

    // Check whether the location_signpost_links content type is installed.
    if (!$this->entityTypeManager->hasDefinition('node')) {
      return $this->indexByCustodianCode($areas);
    }

    $node_storage = $this->entityTypeManager->getStorage('node');
    $query = $node_storage->getQuery()
      ->accessCheck(TRUE)
      ->condition('type', 'location_signpost_links')
      ->condition('status', 1)
      ->condition('field_location_signpost_group', $link_group);

    $nids = $query->execute();

    if (empty($nids)) {
      return $this->indexByCustodianCode($areas);
    }

    $nodes = $node_storage->loadMultiple($nids);

    foreach ($nodes as $node) {
      /** @var \Drupal\node\NodeInterface $node */
      $area_field = $node->get('field_location_signpost_area');
      if ($area_field->isEmpty()) {
        continue;
      }

      $area_id = $area_field->target_id;
      if (!isset($areas[$area_id])) {
        continue;
      }

      foreach ($node->get('field_location_signpost_link') as $link_item) {
        if (empty($link_item->uri) || empty($link_item->title)) {
          continue;
        }
        $url = $link_item->getUrl()->toString();
        if (preg_match('#^(javascript|data|vbscript):#i', $url)) {
          continue;
        }
        $areas[$area_id]['links'][] = [
          'title' => $link_item->title,
          'uri' => $url,
        ];
      }
    }

    return $this->indexByCustodianCode($areas);
  }

  /**
   * Re-indexes the areas array by custodian code (used by the JS MSOA lookup).
   *
   * Areas without a custodian code are also included, keyed by their entity ID,
   * so the JS can still display their name/organisation when area is found via
   * other means.
   *
   * @param array $areas
   *   Areas array keyed by entity ID.
   *
   * @return array
   *   Areas array keyed by custodian code (or entity ID if code is empty).
   */
  protected function indexByCustodianCode(array $areas): array {
    $indexed = [];
    foreach ($areas as $id => $data) {
      $key = ($data['custodianCode'] !== '') ? $data['custodianCode'] : $id;
      $indexed[$key] = $data;
    }
    return $indexed;
  }

}
