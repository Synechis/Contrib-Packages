<?php

namespace Drupal\location_signpost\Plugin\LocationSignpostGeocoder;

use Drupal\Core\Cache\CacheBackendInterface;
use Drupal\Core\Extension\ModuleHandlerInterface;
use Drupal\Core\Plugin\DefaultPluginManager;

/**
 * Plugin manager for LocationSignpostGeocoder plugins.
 */
class LocationSignpostGeocoderManager extends DefaultPluginManager {

  /**
   * Constructs the geocoder plugin manager.
   */
  public function __construct(
    \Traversable $namespaces,
    CacheBackendInterface $cache_backend,
    ModuleHandlerInterface $module_handler,
  ) {
    parent::__construct(
      'Plugin/LocationSignpostGeocoder',
      $namespaces,
      $module_handler,
      LocationSignpostGeocoderInterface::class,
      'Drupal\location_signpost\Annotation\LocationSignpostGeocoder',
    );

    $this->alterInfo('location_signpost_geocoder_info');
    $this->setCacheBackend($cache_backend, 'location_signpost_geocoder_plugins');
  }

}
