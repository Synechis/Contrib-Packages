<?php

namespace Drupal\location_signpost\Plugin\LocationSignpostGeocoder;

use Drupal\Component\Plugin\PluginBase;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Extension\ModuleHandlerInterface;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use GuzzleHttp\ClientInterface;
use GuzzleHttp\Exception\RequestException;
use Psr\Log\LoggerInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * OS Places API geocoder plugin.
 *
 * @LocationSignpostGeocoder(
 *   id = "os_places",
 *   label = @Translation("Ordnance Survey Places API")
 * )
 */
class OsPlaces extends PluginBase implements LocationSignpostGeocoderInterface, ContainerFactoryPluginInterface {

  /**
   * The OS Places API endpoint.
   */
  const ENDPOINT = 'https://api.os.uk/search/places/v1/find';

  public function __construct(
    array $configuration,
    string $plugin_id,
    mixed $plugin_definition,
    protected ConfigFactoryInterface $configFactory,
    protected ClientInterface $httpClient,
    protected ModuleHandlerInterface $moduleHandler,
    protected ?object $keyRepository,
    protected LoggerInterface $logger,
  ) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition): static {
    $key_repository = NULL;
    if ($container->get('module_handler')->moduleExists('key')) {
      $key_repository = $container->get('key.repository');
    }

    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('config.factory'),
      $container->get('http_client'),
      $container->get('module_handler'),
      $key_repository,
      $container->get('logger.factory')->get('location_signpost'),
    );
  }

  /**
   * Returns the resolved OS Places API key.
   */
  protected function getApiKey(): string {
    $settings = $this->configFactory->get('location_signpost.settings');
    $stored = $settings->get('os_api_key') ?? '';

    if ($stored && $this->keyRepository) {
      $value = $this->keyRepository->getKeyValue($stored);
      return $value ?? '';
    }

    return $stored;
  }

  /**
   * {@inheritdoc}
   */
  public function findAddresses(string $query, string $geographicFilter): array {
    $api_key = $this->getApiKey();

    if (empty($api_key)) {
      $this->logger->warning('Location Signpost: OS Places API key is not configured.');
      return [];
    }

    $params = [
      'key' => $api_key,
      'query' => $query,
      'maxresults' => 50,
      'minmatch' => 0.3,
      'dataset' => 'DPA',
    ];

    if (!empty($geographicFilter)) {
      $codes = array_filter(array_map('trim', preg_split('/[\s,]+/', $geographicFilter)));
      if (!empty($codes)) {
        $fq = implode(' ', array_map(
          static fn(string $code) => 'LOCAL_CUSTODIAN_CODE:' . $code,
          $codes,
        ));
        $params['fq'] = $fq;
      }
    }

    try {
      $response = $this->httpClient->get(static::ENDPOINT, ['query' => $params]);
      $data = json_decode((string) $response->getBody(), TRUE);
    }
    catch (RequestException $e) {
      $this->logger->error('Location Signpost: OS Places API request failed: @message', ['@message' => $e->getMessage()]);
      return [];
    }

    if (empty($data['results'])) {
      return [];
    }

    $results = [];
    foreach ($data['results'] as $item) {
      if (!is_array($item) || !isset($item['DPA']) || !is_array($item['DPA'])) {
        continue;
      }
      $dpa = $item['DPA'];
      $address = $this->formatAddress($dpa);
      if ($address) {
        $results[] = [
          'address' => $address,
          'postcode' => $dpa['POSTCODE'] ?? '',
          'x' => (float) ($dpa['X_COORDINATE'] ?? 0),
          'y' => (float) ($dpa['Y_COORDINATE'] ?? 0),
        ];
      }
    }

    return $results;
  }

  /**
   * Formats a DPA address record into a human-readable string.
   */
  protected function formatAddress(array $dpa): string {
    $parts = [];

    $building = implode(' ', array_filter([
      $dpa['BUILDING_NUMBER'] ?? '',
      $this->titleCase($dpa['BUILDING_NAME'] ?? ''),
    ]));

    if ($building !== '') {
      $parts[] = $building;
    }

    foreach (['DEPENDENT_THOROUGHFARE_NAME', 'THOROUGHFARE_NAME', 'DEPENDENT_LOCALITY', 'POST_TOWN'] as $field) {
      if (!empty($dpa[$field])) {
        $parts[] = $this->titleCase($dpa[$field]);
      }
    }

    if (!empty($dpa['POSTCODE'])) {
      $parts[] = $dpa['POSTCODE'];
    }

    return implode(', ', array_filter($parts));
  }

  /**
   * Converts a string to title case (first letter upper, rest lower).
   */
  protected function titleCase(string $string): string {
    if ($string === '') {
      return '';
    }
    return mb_strtoupper(mb_substr($string, 0, 1)) . mb_strtolower(mb_substr($string, 1));
  }

}
