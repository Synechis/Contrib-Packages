<?php

namespace Drupal\location_signpost\Plugin\LocationSignpostGeocoder;

/**
 * Address lookup backend. Implement to provide an alternative geocoding source.
 */
interface LocationSignpostGeocoderInterface {

  /**
   * Finds addresses matching the given query.
   *
   * @param string $query
   *   The user-entered search string (postcode, street, place name).
   * @param string $geographicFilter
   *   Optional whitespace/comma-separated OS custodian codes to restrict
   *   results to specific local authority boundaries.
   *
   * @return array
   *   Associative array of results, each containing:
   *   - address (string): Human-readable formatted address.
   *   - postcode (string): Postcode for the result.
   *   - x (float): Easting coordinate (EPSG:27700).
   *   - y (float): Northing coordinate (EPSG:27700).
   */
  public function findAddresses(string $query, string $geographicFilter): array;

}
