# Location Signpost

Adds a block and paragraph type that let visitors find their local area by
entering a postcode or address. The module identifies the area from the
postcode, then shows area-specific signpost links.

Address autocomplete comes from the Ordnance Survey Places API. Area
identification uses postcodes.io (free, no key required) to look up the ONS
MSOA code for a postcode, which is then matched against the MSOA codes
configured for each area.


## Requirements

- Drupal 10 or 11
- An [Ordnance Survey Places API](https://osdatahub.os.uk/) key
- The [Key module](https://www.drupal.org/project/key) is strongly recommended
  for keeping the API key out of configuration exports


## Quick start

**1. Install**

```
composer require drupal/location_signpost
drush en location_signpost
```

For paragraph support (requires the Paragraphs module):

```
drush en location_signpost_paragraph
```

**2. Configure the API key**

Go to Admin → Configuration → Services → Location Signpost. Enter your OS
Places API key, or — if the Key module is installed — select the Key entity
that holds it.

The geographic filter field accepts OS local custodian codes (one per line) to
restrict address searches to specific authority boundaries. Leave it empty to
search all of Great Britain.

All visitor-facing text (block heading, button labels, result messages) is
editable on the same form.

**3. Create areas**

Go to Admin → Structure → Location Signpost Areas and add an area for each
sub-region you need. Each area holds the OS custodian code and the ONS MSOA
codes that map to it.

**4. Add signpost links (block usage)**

Enable the `location_signpost_links` content type by importing the optional
config, then create nodes of that type — one per area per link group. Set the
`Link group` field on each node to match the `Link group` setting on your block
instance (default: `default`). Different block instances with different link
groups will show different links, which is useful if the block appears on pages
with different subject contexts.

**5. Place the block**

Place the Location Signpost block via the standard block layout UI. The block
settings let you enable the map and set the link group.


## Paragraph type

The `location_signpost_paragraph` submodule provides a paragraph type that
stores its area links directly as sub-paragraphs, rather than pulling from
the global link nodes. Add one sub-paragraph per area and enter the links for
that area. This is suited to pages where the signpost links should match the
page topic rather than a site-wide set.


## External libraries

The optional map feature loads Leaflet, proj4js, proj4leaflet, and the OS API
branding script from external CDNs. To use local copies, override
`location_signpost/signpost` in your theme or a custom module's libraries YAML.


## Geocoding

The module ships an OS Places geocoder plugin (`os_places`). Other modules can
provide alternative backends by implementing the `LocationSignpostGeocoder`
plugin type and declaring the plugin class with the `@LocationSignpostGeocoder`
annotation. Select the active plugin on the settings form.


## Credits

Originally developed by Bob Bulman at Cumberland Council.

Additional development by Rohallion, sponsored by Cumberland Council.

Contrib release by Rohallion.
