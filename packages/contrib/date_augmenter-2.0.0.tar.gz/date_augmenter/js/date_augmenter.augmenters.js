/**
 * @file
 * Attaches show/hide functionality to checkboxes in the "Augmenter" form.
 */

(function (Drupal) {
  Drupal.behaviors.dateAugmenter = {
    attach(context, settings) {
      // Helper function to toggle the visibility of dependent elements.
      function toggleCheckBox(element) {
        const processorId = element.dataset.id;
        const $wrapper = element.closest(
          '.date-augmenter-status-wrapper',
        ).parentElement;
        const $rows = $wrapper.querySelector(
          `.date-augmenter-weight--${processorId}`,
        );
        const $tab = $wrapper.querySelector(
          `.date-augmenter-settings-${processorId}`,
        );

        if (element.checked) {
          $rows.style.display = '';
          if ($tab) {
            $tab.style.display = '';
          }
        } else {
          $rows.style.display = 'none';
          if ($tab) {
            $tab.style.display = 'none';
          }
        }
      }

      document
        .querySelectorAll(
          '.date-augmenter-status-wrapper input.form-checkbox',
          context,
        )
        .forEach(function (element) {
          element.addEventListener('click', (e) => {
            toggleCheckBox(element);
          });

          // Trigger our helper function to update elements to initial state.
          toggleCheckBox(element);
        });
    },
  };
})(Drupal);
