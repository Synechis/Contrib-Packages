<?php

declare(strict_types=1);

namespace Drupal\Tests\date_augmenter\Kernel;

use Drupal\date_augmenter\DateAugmenter\DateAugmenterInterface;
use Drupal\date_augmenter\Plugin\DateAugmenterManager;
use Drupal\KernelTests\KernelTestBase;
use PHPUnit\Framework\Attributes\CoversClass;
use PHPUnit\Framework\Attributes\Group;

/**
 * Tests DateAugmenterManager plugin discovery and getActivePlugins().
 */
#[CoversClass(DateAugmenterManager::class)]
#[Group('date_augmenter')]
class DateAugmenterManagerTest extends KernelTestBase {

  /**
   * {@inheritdoc}
   */
  protected static $modules = ['date_augmenter', 'date_augmenter_test'];

  /**
   * The date augmenter plugin manager under test.
   *
   * @var \Drupal\date_augmenter\Plugin\DateAugmenterManager
   */
  protected DateAugmenterManager $manager;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();
    $this->manager = $this->container->get('plugin.manager.dateaugmenter');
  }

  /**
   * Tests that the plugin manager discovers test plugins.
   */
  public function testPluginDiscovery(): void {
    $definitions = $this->manager->getDefinitions();
    $this->assertArrayHasKey('date_augmenter_test', $definitions);
    $this->assertArrayHasKey('date_augmenter_test_weighted', $definitions);
  }

  /**
   * Tests that discovered plugins implement DateAugmenterInterface.
   */
  public function testDiscoveredPluginsImplementInterface(): void {
    $plugin = $this->manager->createInstance('date_augmenter_test');
    $this->assertInstanceOf(DateAugmenterInterface::class, $plugin);
  }

  /**
   * Tests that getActivePlugins() returns an empty array for NULL config.
   */
  public function testGetActivePluginsWithNullConfigReturnsEmpty(): void {
    $this->assertSame([], $this->manager->getActivePlugins(NULL));
  }

  /**
   * Tests that getActivePlugins() returns an empty array for empty status.
   */
  public function testGetActivePluginsWithEmptyStatusReturnsEmpty(): void {
    $this->assertSame([], $this->manager->getActivePlugins(['status' => []]));
  }

  /**
   * Tests that getActivePlugins() returns an empty array when all are disabled.
   */
  public function testGetActivePluginsWithAllDisabledReturnsEmpty(): void {
    $config = [
      'status' => [
        'date_augmenter_test' => FALSE,
        'date_augmenter_test_weighted' => FALSE,
      ],
    ];
    $this->assertSame([], $this->manager->getActivePlugins($config));
  }

  /**
   * Tests that getActivePlugins() returns only the enabled plugin.
   */
  public function testGetActivePluginsReturnsOnlyEnabledPlugins(): void {
    $config = [
      'status' => [
        'date_augmenter_test' => TRUE,
        'date_augmenter_test_weighted' => FALSE,
      ],
    ];
    $plugins = $this->manager->getActivePlugins($config);
    $this->assertCount(1, $plugins);
    $this->assertArrayHasKey('date_augmenter_test', $plugins);
    $this->assertInstanceOf(
      DateAugmenterInterface::class,
      $plugins['date_augmenter_test'],
    );
  }

  /**
   * Tests that getActivePlugins() returns plugins sorted by ascending weight.
   *
   * Provides a config where the weighted augmenter has a lower weight value
   * than the standard test augmenter, so it should appear first.
   */
  public function testGetActivePluginsReturnPluginsInWeightOrder(): void {
    $config = [
      'status' => [
        'date_augmenter_test' => TRUE,
        'date_augmenter_test_weighted' => TRUE,
      ],
      'weights' => [
        'order' => [
          'date_augmenter_test' => ['weight' => 10],
          'date_augmenter_test_weighted' => ['weight' => 2],
        ],
      ],
    ];
    $plugins = $this->manager->getActivePlugins($config);
    $this->assertCount(2, $plugins);
    $keys = array_keys($plugins);
    $this->assertSame('date_augmenter_test_weighted', $keys[0]);
    $this->assertSame('date_augmenter_test', $keys[1]);
  }

  /**
   * Tests that getActivePlugins() uses weight 0 as default when not specified.
   */
  public function testGetActivePluginsDefaultsToWeightZero(): void {
    $config = [
      'status' => [
        'date_augmenter_test' => TRUE,
        'date_augmenter_test_weighted' => TRUE,
      ],
      'weights' => [
        'order' => [
          'date_augmenter_test' => ['weight' => 0],
          // No weight for date_augmenter_test_weighted; defaults to 0.
        ],
      ],
    ];
    $plugins = $this->manager->getActivePlugins($config);
    // Both have effective weight 0; both should be returned.
    $this->assertCount(2, $plugins);
  }

}
