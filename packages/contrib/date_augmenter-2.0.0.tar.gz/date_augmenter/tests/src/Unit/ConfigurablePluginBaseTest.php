<?php

declare(strict_types=1);

namespace Drupal\Tests\date_augmenter\Unit;

use Drupal\Component\Plugin\ConfigurableInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Plugin\PluginFormInterface;
use Drupal\date_augmenter\Plugin\ConfigurablePluginBase;
use Drupal\date_augmenter\Plugin\PluginFormTrait;
use Drupal\Tests\UnitTestCase;
use PHPUnit\Framework\Attributes\CoversClass;
use PHPUnit\Framework\Attributes\Group;

/**
 * Tests ConfigurablePluginBase and PluginFormTrait.
 */
#[CoversClass(ConfigurablePluginBase::class)]
#[CoversClass(PluginFormTrait::class)]
#[Group('date_augmenter')]
class ConfigurablePluginBaseTest extends UnitTestCase {

  /**
   * Creates a concrete anonymous subclass of ConfigurablePluginBase.
   *
   * @param array $configuration
   *   Initial plugin configuration.
   * @param array $definition
   *   Plugin definition array.
   *
   * @return \Drupal\date_augmenter\Plugin\ConfigurablePluginBase
   *   An instantiable plugin instance.
   */
  protected function createPlugin(
    array $configuration = [],
    array $definition = [],
  ): ConfigurablePluginBase {
    $definition += [
      'label' => 'Test plugin',
      'description' => 'A test plugin description.',
    ];
    return new class(
      $configuration,
      'test_plugin',
      $definition,
    ) extends ConfigurablePluginBase {
    };
  }

  /**
   * Tests that defaultConfiguration() returns an empty array.
   */
  public function testDefaultConfigurationReturnsEmptyArray(): void {
    $plugin = $this->createPlugin();
    $this->assertSame([], $plugin->defaultConfiguration());
  }

  /**
   * Tests that the constructor merges provided config with defaults.
   */
  public function testConstructorMergesConfigurationWithDefaults(): void {
    $plugin = $this->createPlugin(['custom_key' => 'custom_value']);
    $config = $plugin->getConfiguration();
    $this->assertSame('custom_value', $config['custom_key']);
  }

  /**
   * Tests that getConfiguration() returns the current configuration.
   */
  public function testGetConfigurationReturnsConfiguration(): void {
    $plugin = $this->createPlugin(['key' => 'value']);
    $this->assertSame(['key' => 'value'], $plugin->getConfiguration());
  }

  /**
   * Tests that setConfiguration() replaces and merges with defaults.
   */
  public function testSetConfigurationReplacesConfiguration(): void {
    $plugin = $this->createPlugin(['old_key' => 'old_value']);
    $plugin->setConfiguration(['new_key' => 'new_value']);
    $this->assertSame(
      ['new_key' => 'new_value'],
      $plugin->getConfiguration(),
    );
  }

  /**
   * Tests that calculateDependencies() returns an empty array.
   */
  public function testCalculateDependenciesReturnsEmptyArray(): void {
    $plugin = $this->createPlugin();
    $this->assertSame([], $plugin->calculateDependencies());
  }

  /**
   * Tests that onDependencyRemoval() returns FALSE.
   */
  public function testOnDependencyRemovalReturnsFalse(): void {
    $plugin = $this->createPlugin();
    $removed = $plugin->onDependencyRemoval(['module' => ['some_module']]);
    $this->assertFalse($removed);
  }

  /**
   * Tests that label() returns the value from the plugin definition.
   */
  public function testLabelReturnsFromPluginDefinition(): void {
    $plugin = $this->createPlugin([], ['label' => 'My label']);
    $this->assertSame('My label', $plugin->label());
  }

  /**
   * Tests that getDescription() returns the value from the plugin definition.
   */
  public function testGetDescriptionReturnsFromPluginDefinition(): void {
    $plugin = $this->createPlugin([], ['description' => 'My description']);
    $this->assertSame('My description', $plugin->getDescription());
  }

  /**
   * Tests that getDescription() returns empty string when absent.
   */
  public function testGetDescriptionReturnsEmptyStringWhenAbsent(): void {
    $plugin = new class(
      [],
      'test_plugin',
      ['label' => 'Test'],
    ) extends ConfigurablePluginBase {
    };
    $this->assertSame('', $plugin->getDescription());
  }

  /**
   * Tests that PluginFormTrait::validateConfigurationForm() runs without error.
   */
  public function testValidateConfigurationFormDoesNothing(): void {
    $plugin = $this->createPluginWithFormTrait();
    $form = [];
    $form_state = $this->createMock(FormStateInterface::class);
    // Assert no exception is thrown.
    $plugin->validateConfigurationForm($form, $form_state);
    $this->addToAssertionCount(1);
  }

  /**
   * Tests that PluginFormTrait::submitConfigurationForm() sets configuration.
   */
  public function testSubmitConfigurationFormSetsConfiguration(): void {
    $plugin = $this->createPluginWithFormTrait(['key' => 'old_value']);
    $form = [];
    $form_state = $this->createMock(FormStateInterface::class);
    $form_state->expects($this->once())
      ->method('getValues')
      ->willReturn(['key' => 'new_value']);

    $plugin->submitConfigurationForm($form, $form_state);
    $this->assertInstanceOf(ConfigurableInterface::class, $plugin);
    $this->assertSame(
      ['key' => 'new_value'],
      $plugin->getConfiguration(),
    );
  }

  /**
   * Creates a concrete anonymous subclass that also uses PluginFormTrait.
   *
   * @param array $configuration
   *   Initial plugin configuration.
   *
   * @return \Drupal\Core\Plugin\PluginFormInterface
   *   An instantiable plugin instance.
   */
  protected function createPluginWithFormTrait(
    array $configuration = [],
  ): PluginFormInterface {
    $definition = [
      'label' => 'Test',
      'description' => '',
    ];
    return new class(
      $configuration,
      'test_plugin',
      $definition,
    ) extends ConfigurablePluginBase implements PluginFormInterface {
      use PluginFormTrait;

      /**
       * {@inheritdoc}
       */
      public function buildConfigurationForm(
        array $form,
        FormStateInterface $form_state,
      ): array {
        return $form;
      }

    };
  }

}
