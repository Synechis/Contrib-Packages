<?php

declare(strict_types=1);

namespace Drupal\Tests\date_augmenter\Unit;

use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\date_augmenter\DateAugmenter\DateAugmenterPluginBase;
use Drupal\Tests\UnitTestCase;
use PHPUnit\Framework\Attributes\CoversClass;
use PHPUnit\Framework\Attributes\Group;

/**
 * Tests DateAugmenterPluginBase weight methods.
 */
#[CoversClass(DateAugmenterPluginBase::class)]
#[Group('date_augmenter')]
class DateAugmenterPluginBaseTest extends UnitTestCase {

  /**
   * Creates a concrete anonymous subclass of DateAugmenterPluginBase.
   *
   * @param array $configuration
   *   Initial plugin configuration.
   * @param array $definition
   *   Plugin definition array.
   *
   * @return \Drupal\date_augmenter\DateAugmenter\DateAugmenterPluginBase
   *   An instantiable plugin instance.
   */
  protected function createPlugin(
    array $configuration = [],
    array $definition = [],
  ): DateAugmenterPluginBase {
    $definition += [
      'label' => 'Test augmenter',
      'description' => 'A test augmenter.',
      'weight' => 0,
    ];
    return new class(
      $configuration,
      'test_augmenter',
      $definition,
    ) extends DateAugmenterPluginBase {

      /**
       * {@inheritdoc}
       */
      public function augmentOutput(
        array &$output,
        DrupalDateTime $start,
        ?DrupalDateTime $end = NULL,
        array $options = [],
      ): void {
      }

    };
  }

  /**
   * Tests that getWeight() falls back to the plugin definition weight.
   */
  public function testGetWeightUsesPluginDefinitionWeight(): void {
    $plugin = $this->createPlugin([], ['weight' => 5]);
    $this->assertSame(5, $plugin->getWeight());
  }

  /**
   * Tests that getWeight() returns 0 when no weight is set anywhere.
   */
  public function testGetWeightDefaultsToZero(): void {
    $plugin = $this->createPlugin([], ['weight' => 0]);
    $this->assertSame(0, $plugin->getWeight());
  }

  /**
   * Tests that getWeight() prefers configuration weight over definition.
   */
  public function testGetWeightPrefersConfigurationWeight(): void {
    $plugin = $this->createPlugin(['weight' => 3], ['weight' => 7]);
    $this->assertSame(3, $plugin->getWeight());
  }

  /**
   * Tests that setWeight() stores the weight in the plugin configuration.
   */
  public function testSetWeightStoresWeightInConfiguration(): void {
    $plugin = $this->createPlugin();
    $plugin->setWeight(42);
    $this->assertSame(42, $plugin->getWeight());
  }

  /**
   * Tests that setWeight() returns the plugin instance for chaining.
   */
  public function testSetWeightReturnsSelf(): void {
    $plugin = $this->createPlugin();
    $result = $plugin->setWeight(1);
    $this->assertSame($plugin, $result);
  }

  /**
   * Tests that setWeight() overrides the plugin definition weight.
   */
  public function testSetWeightOverridesDefinitionWeight(): void {
    $plugin = $this->createPlugin([], ['weight' => 10]);
    $plugin->setWeight(2);
    $this->assertSame(2, $plugin->getWeight());
  }

}
