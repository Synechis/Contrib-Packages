<?php

declare(strict_types=1);

namespace Drupal\Tests\date_augmenter\Unit;

use Drupal\date_augmenter\Plugin\DateAugmenterManager;
use Drupal\Tests\UnitTestCase;
use PHPUnit\Framework\Attributes\CoversClass;
use PHPUnit\Framework\Attributes\Group;

/**
 * Tests DateAugmenterManager static utility methods.
 */
#[CoversClass(DateAugmenterManager::class)]
#[Group('date_augmenter')]
class DateAugmenterManagerTest extends UnitTestCase {

  /**
   * Tests getThirdPartyFallback() with getThirdPartySetting() present.
   */
  public function testGetThirdPartyFallbackUsesGetThirdPartySetting(): void {
    $entity = new class {

      /**
       * Returns a stored third-party setting value.
       */
      public function getThirdPartySetting(
        string $module,
        string $key,
        mixed $default = NULL,
      ): mixed {
        return 'stored_value';
      }

    };
    $result = DateAugmenterManager::getThirdPartyFallback(
      $entity,
      'some_key',
      'default',
    );
    $this->assertSame('stored_value', $result);
  }

  /**
   * Tests getThirdPartyFallback() falls back to getSetting().
   */
  public function testGetThirdPartyFallbackUsesGetSetting(): void {
    $entity = new class {

      /**
       * Returns a setting value.
       */
      public function getSetting(string $key): mixed {
        return 'setting_value';
      }

    };
    $result = DateAugmenterManager::getThirdPartyFallback(
      $entity,
      'some_key',
      'default',
    );
    $this->assertSame('setting_value', $result);
  }

  /**
   * Tests getThirdPartyFallback() returns the default when no method exists.
   */
  public function testGetThirdPartyFallbackReturnsDefaultWhenNoMethod(): void {
    $entity = new \stdClass();
    $result = DateAugmenterManager::getThirdPartyFallback(
      $entity,
      'some_key',
      'my_default',
    );
    $this->assertSame('my_default', $result);
  }

  /**
   * Tests getThirdPartyFallback() returns NULL as the default.
   */
  public function testGetThirdPartyFallbackDefaultIsNull(): void {
    $entity = new \stdClass();
    $result = DateAugmenterManager::getThirdPartyFallback(
      $entity,
      'some_key',
    );
    $this->assertNull($result);
  }

  /**
   * Tests getThirdPartyFallback() prefers getThirdPartySetting().
   *
   * When an entity has both getThirdPartySetting() and getSetting(), the
   * third-party setting method takes precedence.
   */
  public function testGetThirdPartyFallbackPreference(): void {
    $entity = new class {

      /**
       * Returns a third-party setting value.
       */
      public function getThirdPartySetting(
        string $module,
        string $key,
        mixed $default = NULL,
      ): mixed {
        return 'third_party_value';
      }

      /**
       * Returns a setting value.
       */
      public function getSetting(string $key): mixed {
        return 'setting_value';
      }

    };
    $result = DateAugmenterManager::getThirdPartyFallback(
      $entity,
      'some_key',
      'default',
    );
    $this->assertSame('third_party_value', $result);
  }

}
