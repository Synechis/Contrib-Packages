<?php

declare(strict_types=1);

namespace Drupal\date_augmenter_test\Plugin\DateAugmenter;

use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\date_augmenter\Attribute\DateAugmenter;
use Drupal\date_augmenter\DateAugmenter\DateAugmenterPluginBase;

/**
 * A test date augmenter plugin with a higher default weight.
 */
#[DateAugmenter(
  id: 'date_augmenter_test_weighted',
  label: new TranslatableMarkup('Test weighted augmenter'),
  description: new TranslatableMarkup('A weighted test augmenter.'),
  weight: 10,
)]
class TestWeightedAugmenter extends DateAugmenterPluginBase {

  /**
   * {@inheritdoc}
   */
  public function augmentOutput(
    array &$output,
    DrupalDateTime $start,
    ?DrupalDateTime $end = NULL,
    array $options = [],
  ): void {
    $output['#test_weighted_augmented'] = TRUE;
  }

}
