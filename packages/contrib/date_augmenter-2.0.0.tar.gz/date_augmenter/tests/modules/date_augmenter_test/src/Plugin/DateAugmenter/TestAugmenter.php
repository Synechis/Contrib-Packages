<?php

declare(strict_types=1);

namespace Drupal\date_augmenter_test\Plugin\DateAugmenter;

use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\date_augmenter\Attribute\DateAugmenter;
use Drupal\date_augmenter\DateAugmenter\DateAugmenterPluginBase;

/**
 * A test date augmenter plugin with default weight.
 */
#[DateAugmenter(
  id: 'date_augmenter_test',
  label: new TranslatableMarkup('Test augmenter'),
  description: new TranslatableMarkup('A test date augmenter plugin.'),
  weight: 0,
)]
class TestAugmenter extends DateAugmenterPluginBase {

  /**
   * {@inheritdoc}
   */
  public function augmentOutput(
    array &$output,
    DrupalDateTime $start,
    ?DrupalDateTime $end = NULL,
    array $options = [],
  ): void {
    $output['#test_augmented'] = TRUE;
  }

}
