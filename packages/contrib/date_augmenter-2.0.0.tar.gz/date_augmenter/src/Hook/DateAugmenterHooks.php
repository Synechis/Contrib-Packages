<?php

declare(strict_types=1);

namespace Drupal\date_augmenter\Hook;

use Drupal\Component\Utility\Html;
use Drupal\Core\Field\BaseFieldDefinition;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\Core\Plugin\PluginFormInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\date_augmenter\Plugin\DateAugmenterManager;
use Symfony\Component\DependencyInjection\Attribute\Autowire;

/**
 * Hook implementations for date_augmenter.
 */
class DateAugmenterHooks {

  use StringTranslationTrait;

  /**
   * {@inheritdoc}
   */
  public function __construct(
    #[Autowire(service: 'plugin.manager.dateaugmenter')]
    private readonly DateAugmenterManager $dateAugmenterManager,
  ) {}

  /**
   * Implements hook_field_formatter_third_party_settings_form().
   *
   * Adds extra configuration fields to compatible date fields.
   */
  #[Hook('field_formatter_third_party_settings_form')]
  public function fieldFormatterThirdPartySettingsForm($plugin, $field_definition, $form_mode, $form, $form_state): array {
    if (!method_exists($plugin, 'supportsDateAugmenter') || !$sets = $plugin->supportsDateAugmenter()) {
      return [];
    }

    $augmenters = $this->dateAugmenterManager->getDefinitions();

    if ($field_definition instanceof BaseFieldDefinition) {
      // @todo populate $config for custom entities.
      $config = $field_definition->getSetting('augmenters');
    }
    else {
      /** @var \Drupal\Core\Field\FormatterInterface $plugin */
      $config = $plugin->getThirdPartySettings('date_augmenter');
    }

    if (is_array($sets) && $sets) {
      $element = [];
      foreach ($sets as $set_id => $set_label) {
        $set_config = $config[$set_id] ?? $config;
        $element[$set_id] = $this->makeConfigFields($set_config, $augmenters, $field_definition);
        $element[$set_id] += [
          '#type' => 'fieldset',
          '#title' => $set_label,
        ];
      }
    }
    else {
      $element = $this->makeConfigFields($config, $augmenters, $field_definition);
    }
    $element['#attached']['library'][] = 'date_augmenter/augmenters';
    return $element;
  }

  /**
   * Builds status, weights, and augmenter_settings configuration fields.
   */
  private function makeConfigFields(mixed $config, array $augmenters, mixed $field_definition): array {
    $active_augmenters = $config['status'] ?? [];

    $element['status'] = [
      '#type' => 'fieldset',
      '#title' => $this->t('Enabled Date Augmenters'),
      '#attributes' => [
        'class' => ['date-augmenter-status-wrapper'],
      ],
    ];
    foreach ($augmenters as $augmenter_id => $augmenter) {
      $clean_css_id = Html::cleanCssIdentifier($augmenter_id);
      $element['status'][$augmenter_id] = [
        '#type' => 'checkbox',
        '#title' => $augmenter['label'],
        '#default_value' => !empty($active_augmenters[$augmenter_id]),
        '#description' => $augmenter['description'],
        '#attributes' => [
          'class' => ['date-augmenter-status-' . $clean_css_id],
          'data-id' => $clean_css_id,
        ],
      ];
    }

    $element['weights'] = [
      '#type' => 'fieldset',
      '#title' => $this->t('Augmenting order'),
    ];
    $element['weights']['order'] = ['#type' => 'table'];
    $element['weights']['order']['#tabledrag'][] = [
      'action' => 'order',
      'relationship' => 'sibling',
      'group' => 'date-augmenter-weight',
    ];

    $augmenter_weights = [];
    foreach ($augmenters as $augmenter_id => $augmenter) {
      $augmenter_weights[$augmenter_id] = $config['weights']['order'][$augmenter_id]['weight'] ?? 0;
    }
    asort($augmenter_weights);

    foreach ($augmenter_weights as $augmenter_id => $weight) {
      $augmenter = $augmenters[$augmenter_id];
      $element['weights']['order'][$augmenter_id]['#attributes']['class'][] = 'draggable';
      $element['weights']['order'][$augmenter_id]['#attributes']['class'][] = 'date-augmenter-weight--' . Html::cleanCssIdentifier($augmenter_id);
      $element['weights']['order'][$augmenter_id]['#weight'] = $weight;
      $element['weights']['order'][$augmenter_id]['label']['#plain_text'] = $augmenter['label'];
      $element['weights']['order'][$augmenter_id]['weight'] = [
        '#type' => 'weight',
        '#title' => $this->t('Weight for augmenter %title', ['%title' => $augmenter['label']]),
        '#title_display' => 'invisible',
        '#delta' => 50,
        '#default_value' => $weight,
        '#attributes' => [
          'class' => ['date-augmenter-weight'],
        ],
      ];
    }

    $element['augmenter_settings'] = [
      '#title' => $this->t('Augmenter settings'),
      '#type' => 'vertical_tabs',
    ];

    foreach ($augmenters as $augmenter_id => $augmenter) {
      $aug_plugin = $this->dateAugmenterManager->createInstance($augmenter_id);
      if ($aug_plugin instanceof PluginFormInterface) {
        $element['settings'][$augmenter_id] = [
          '#type' => 'details',
          '#title' => $augmenter['label'],
          '#group' => 'augmenter_settings',
          '#attributes' => [
            'class' => ['date-augmenter-settings-' . Html::cleanCssIdentifier($augmenter_id)],
          ],
        ];
        $settings = $config['settings'][$augmenter_id] ?? [];
        /** @var \Drupal\date_augmenter\Plugin\PluginWithConfigFieldsInterface $aug_plugin */
        $element['settings'][$augmenter_id] += $aug_plugin->configurationFields($element['settings'][$augmenter_id], $settings, $field_definition);
      }
      else {
        unset($element['settings'][$augmenter_id]);
      }
    }
    return $element;
  }

}
