<?php

namespace Drupal\date_augmenter\Plugin;

use Drupal\Core\Plugin\PluginFormInterface;

/**
 * Interface for date augmenter plugins that provide configuration fields.
 */
interface PluginWithConfigFieldsInterface extends PluginFormInterface {

  /**
   * Builds configuration fields for the augmenter settings form.
   *
   * @param array $element
   *   The form element to add fields to.
   * @param array $settings
   *   The current settings for this augmenter.
   * @param mixed $field_definition
   *   The field definition for the field being configured.
   *
   * @return array
   *   The form element with augmenter-specific fields added.
   */
  public function configurationFields(array &$element, array $settings, mixed $field_definition): array;

}
