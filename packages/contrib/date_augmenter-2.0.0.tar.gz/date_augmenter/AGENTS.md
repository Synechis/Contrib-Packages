# Date Augmenter — Agent Guide

## Purpose

Date Augmenter is a **Drupal plugin API module** — it defines no UI or output of its own. Its sole job is to provide a standard plugin system that date field formatters (e.g. Smart Date) can opt into, allowing third-party modules to extend formatter output by chaining lightweight "augmenter" plugins.

## How it works

1. A date field formatter declares support by implementing a `supportsDateAugmenter()` method.
2. `hook_field_formatter_third_party_settings_form()` (in `src/Hook/DateAugmenterHooks.php`) detects this and injects the augmenter configuration UI into the formatter's settings form.
3. Augmenter config is stored in the formatter's third-party settings under `date_augmenter` with up to two named sets: `instances` and `rule` (for recurring dates).
4. At render time, consuming formatters call `plugin.manager.dateaugmenter → getActivePlugins($config)` to get enabled plugins sorted by weight, then call `$plugin->augmentOutput(&$output, $start, $end, $options)` on each one.

## Plugin system

| Item | Value |
|---|---|
| Service | `plugin.manager.dateaugmenter` |
| Manager class | `src/Plugin/DateAugmenterManager.php` |
| Discovery namespace | `Drupal\<module>\Plugin\DateAugmenter\` |
| Attribute | `#[DateAugmenter(id, label, description?, weight?)]` |
| Annotation (legacy) | `@DateAugmenter(id, label, description, weight)` |
| Cache bin | `date_augmenter_plugins` |
| Alter hook | `hook_date_augmenter_plugin_info_alter` |

Prefer the PHP attribute form for any new plugins.

## Key classes and interfaces

- **`src/Plugin/DateAugmenterInterface.php`** — minimal interface; the single required method is `augmentOutput(array &$output, DrupalDateTime $start, ?DrupalDateTime $end, array $options)`. Plugins modify the render array in place.
- **`src/Plugin/ConfigurablePluginInterface.php`** — extends the minimal interface with `label()`, `getDescription()`, config management, and dependency handling. Implement this for any plugin that needs settings.
- **`src/DateAugmenter/DateAugmenterInterface.php`** — further adds `getWeight()` / `setWeight()` for ordering; most concrete plugins should extend from this hierarchy.
- **`src/DateAugmenter/DateAugmenterPluginBase.php`** — the recommended base class for new plugins. Extends `ConfigurablePluginBase`, implements weight management.
- **`src/Plugin/PluginFormTrait.php`** — default no-op `validateConfigurationForm()` and a `submitConfigurationForm()` that calls `setConfiguration()`. Include in any plugin that exposes settings.

## Adding a new augmenter plugin

1. Create `src/Plugin/DateAugmenter/MyPlugin.php` in the consumer module.
2. Declare the attribute: `#[DateAugmenter(id: 'my_plugin', label: new TranslatableMarkup('...'), weight: 0)]`.
3. Extend `DateAugmenterPluginBase` (namespace `Drupal\date_augmenter\DateAugmenter`).
4. Implement `augmentOutput()` to mutate `$output`.
5. Optionally implement `PluginFormInterface` and use `PluginFormTrait` to add per-instance settings.

## Configuration schema

Defined in `config/schema/date_augmenter.schema.yml`. Formatter third-party settings are keyed under `field.formatter.third_party.date_augmenter` and contain one or more named sets (`instances`, `rule`), each with `status` (enabled flags), `weights.order`, and `settings` keyed by plugin ID.

## CI checks (all required to pass)

| Check | Tool |
|---|---|
| Coding standards | PHPCS (Drupal standard) |
| Static analysis | PHPStan level 2 (`phpstan.neon`) |
| JavaScript linting | ESLint |
| Spell checking | CSpell |

Run `phpstan analyse` before committing PHP changes; the baseline is `phpstan-baseline.neon`.

## What this module does NOT contain

- No field formatters, field types, or widgets.
- No content entities or config entities.
- No automated test suite (tests live in consumer modules such as Smart Date).
- No routing, forms, or admin pages of its own.

## Drupal version requirements

Drupal 11.1+ (`core: ^11.1`). Hooks use the modern PHP `#[Hook]` attribute pattern in `src/Hook/DateAugmenterHooks.php`. No procedural `.module` file hook implementations exist.
