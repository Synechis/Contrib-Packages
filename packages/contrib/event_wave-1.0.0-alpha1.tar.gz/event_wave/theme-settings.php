<?php

/**
 * @file
 * Theme settings form for Event Wave.
 */

declare(strict_types=1);

use Drupal\Core\Form\FormStateInterface;
use Drupal\event_wave\Hook\ThemeHooks;

/**
 * Implements hook_form_system_theme_settings_alter().
 */
function event_wave_form_system_theme_settings_alter(array &$form, FormStateInterface $form_state): void {
  $form['palette'] = [
    '#type' => 'select',
    '#title' => t('Default palette'),
    '#description' => t('Site-wide palette. A hero, feature or section can override it on a page.'),
    '#default_value' => theme_get_setting('palette', 'event_wave') ?? 'camp',
    '#options' => [
      'camp' => t('Camp'),
      'summit' => t('Summit'),
    ],
  ];

  $form['social'] = [
    '#type' => 'details',
    '#title' => t('Social links'),
    '#open' => TRUE,
    '#tree' => TRUE,
  ];
  foreach (ThemeHooks::SOCIAL_NETWORKS as $key => $label) {
    $form['social'][$key] = [
      '#type' => 'url',
      '#title' => $label,
      '#default_value' => theme_get_setting('social.' . $key, 'event_wave') ?? '',
    ];
  }
}
