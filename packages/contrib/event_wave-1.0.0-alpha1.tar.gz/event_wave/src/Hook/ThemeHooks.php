<?php

declare(strict_types=1);

namespace Drupal\event_wave\Hook;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Controller\TitleResolverInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Extension\ThemeExtensionList;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\Core\Routing\RouteMatchInterface;
use Drupal\node\NodeInterface;
use Symfony\Component\HttpFoundation\RequestStack;

/**
 * Theme hooks.
 */
final class ThemeHooks {

  public const SOCIAL_NETWORKS = [
    'bluesky' => 'Bluesky',
    'mastodon' => 'Mastodon',
    'linkedin' => 'LinkedIn',
    'youtube' => 'YouTube',
  ];

  private const PALETTES = ['camp', 'summit'];

  private const ROUTES_WITH_OWN_TITLE = [
    'entity.node.canonical',
    'entity.user.canonical',
    'entity.taxonomy_term.canonical',
    'node.add',
    'entity.node.edit_form',
  ];

  public function __construct(
    private readonly ConfigFactoryInterface $configFactory,
    private readonly RouteMatchInterface $routeMatch,
    private readonly RequestStack $requestStack,
    private readonly TitleResolverInterface $titleResolver,
    private readonly ThemeExtensionList $themeList,
    private readonly EntityTypeManagerInterface $entityTypeManager,
  ) {}

  /**
   * Implements hook_preprocess_html().
   */
  #[Hook('preprocess_html')]
  public function preprocessHtml(array &$variables): void {
    $palette = theme_get_setting('palette', 'event_wave') ?? 'camp';
    if (!in_array($palette, self::PALETTES, TRUE)) {
      $palette = 'camp';
    }
    $variables['html_attributes']->setAttribute('data-palette', $palette);
    $variables['#cache']['tags'][] = 'config:event_wave.settings';
    $variables['attributes']['class'][] = 'page';
  }

  /**
   * Implements hook_preprocess_page().
   */
  #[Hook('preprocess_page')]
  public function preprocessPage(array &$variables): void {
    $variables['site_name'] = $this->configFactory->get('system.site')->get('name');
    $variables['social_sprite'] = '/' . $this->themeList->getPath('event_wave') . '/images/social-icons.svg';

    $variables['social_links'] = [];
    foreach (self::SOCIAL_NETWORKS as $key => $label) {
      $url = theme_get_setting('social.' . $key, 'event_wave');
      if (!empty($url)) {
        $variables['social_links'][] = ['id' => $key, 'label' => $label, 'url' => $url];
      }
    }

    $variables['title'] = [
      '#type' => 'page_title',
      '#title' => $variables['page']['#title'] ?? $this->titleResolver->getTitle(
        $this->requestStack->getCurrentRequest(),
        $this->routeMatch->getRouteObject(),
      ),
    ];
    $variables['show_title'] = !in_array($this->routeMatch->getRouteName() ?? '', self::ROUTES_WITH_OWN_TITLE, TRUE);
    $variables['rendered_by_canvas'] = $this->isRenderedByCanvas();
  }

  /**
   * Implements hook_theme_suggestions_form_alter().
   *
   * Core offers no per-form-ID template suggestion.
   */
  #[Hook('theme_suggestions_form_alter')]
  public function themeSuggestionsFormAlter(array &$suggestions, array $variables): void {
    if (!empty($variables['element']['#form_id'])) {
      $suggestions[] = 'form__' . $variables['element']['#form_id'];
    }
  }

  /**
   * Whether Canvas owns the full layout of the current route.
   */
  private function isRenderedByCanvas(): bool {
    $route_name = $this->routeMatch->getRouteName();
    if ($route_name === 'entity.canvas_page.canonical' || str_starts_with($this->routeMatch->getRouteObject()?->getPath() ?? '', '/canvas/')) {
      return TRUE;
    }
    if ($route_name !== 'entity.node.canonical') {
      return FALSE;
    }
    $node = $this->routeMatch->getParameter('node');
    if (!$node instanceof NodeInterface) {
      return FALSE;
    }
    return (bool) $this->entityTypeManager
      ->getStorage('content_template')
      ->getQuery()
      ->accessCheck(FALSE)
      ->count()
      ->condition('content_entity_type_id', 'node')
      ->condition('content_entity_type_bundle', $node->getType())
      ->condition('content_entity_type_view_mode', 'full')
      ->condition('status', TRUE)
      ->execute();
  }

}
