# Event Wave

BEM theme with single directory components for Drupal Canvas.

- `css/base` tokens and element defaults; `css/layout` page frame, header, footer, containers; `css/components` content, forms, webform, views, messages
- `components/` one folder per component; CSS attaches only when the component renders
- `src/Hook/ThemeHooks.php` hooks; `theme-settings.php` palette and social links
- Blocks are named after their component; props and slots carry the component name as prefix
- Palette role tokens (`--brand`, `--surface-alt`, `--hero-mask`, …) are keyed on `[data-palette]`; components read only role tokens

Regions: `primary_menu`, `breadcrumb`, `content`, `footer_primary`, `footer_secondary`.
