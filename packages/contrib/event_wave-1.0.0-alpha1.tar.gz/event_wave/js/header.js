(function (Drupal, once) {
  Drupal.behaviors.eventWaveHeader = {
    attach(context) {
      once('main-nav', '.main-nav', context).forEach((nav) => {
        const toggle = nav.querySelector('.main-nav__toggle');
        if (!toggle) return;

        const setOpen = (open) => {
          nav.classList.toggle('main-nav--open', open);
          toggle.setAttribute('aria-expanded', String(open));
        };

        toggle.addEventListener('click', () => {
          setOpen(!nav.classList.contains('main-nav--open'));
        });

        document.addEventListener('keydown', (event) => {
          if (event.key === 'Escape' && nav.classList.contains('main-nav--open')) {
            setOpen(false);
            toggle.focus();
          }
        });
      });

      once('site-header', '.site-header', context).forEach((header) => {
        const update = () => {
          header.classList.toggle('site-header--scrolled', window.scrollY > 40);
        };
        update();
        window.addEventListener('scroll', update, { passive: true });
      });
    },
  };
})(Drupal, once);
