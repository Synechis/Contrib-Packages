<?php

namespace Drupal\ginvite\Plugin\Validation\Constraint;

use Drupal\Core\DependencyInjection\ContainerInjectionInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\ginvite\GroupInvitationLoader;
use Drupal\group\Entity\GroupMembership;
use Drupal\group\Entity\GroupRelationshipInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\Validator\Constraint;
use Symfony\Component\Validator\ConstraintValidator;

/**
 * Validates the PreventDuplicated constraint.
 */
class PreventDuplicatedConstraintValidator extends ConstraintValidator implements ContainerInjectionInterface {

  use StringTranslationTrait;

  /**
   * Group invitations loader.
   *
   * @var \Drupal\ginvite\GroupInvitationLoader
   */
  protected $groupInvitationLoader;

  /**
   * Constructs PreventDuplicatedConstraintValidator.
   *
   * @param \Drupal\ginvite\GroupInvitationLoader $invitation_loader
   *   Invitations loader service.
   */
  public function __construct(GroupInvitationLoader $invitation_loader) {
    $this->groupInvitationLoader = $invitation_loader;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('ginvite.invitation_loader')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function validate($group_relationship, Constraint $constraint) {
    // Validate only group_invitation bundle.
    if (!($group_relationship instanceof GroupRelationshipInterface) || $group_relationship->getPluginId() != 'group_invitation') {
      return;
    }

    $group = $group_relationship->gid->entity;

    $mail = $group_relationship->invitee_mail->value;
    $invitee = $group_relationship->get('entity_id')->entity;

    // Skip validation if email is empty.
    if (!empty($mail)) {
      if ($user = user_load_by_mail($mail)) {
        // Check if user already a member.
        $membership = GroupMembership::loadSingle($group, $user);
        if (!empty($membership)) {
          $this->context->addViolation($this->t('User with such email is already a member of @group.', ['@group' => $group->label()]));
          return;
        }
      }

      if ($this->groupInvitationLoader->loadByGroup($group, NULL, $mail)) {
        $this->context->addViolation($this->t('Invitation to this user has been already sent.'));
      }
    }
    elseif (!empty($invitee)) {
      // If user was invited using entity reference field.
      $membership = GroupMembership::loadSingle($group, $invitee);
      if (!empty($membership)) {
        $this->context->addViolation($this->t('User with such email is already a member of @group.', ['@group' => $group->label()]));
        return;
      }

      if ($this->groupInvitationLoader->loadByGroup($group, NULL, $invitee->getEmail())) {
        $this->context->addViolation($this->t('Invitation to this user has been already sent.'));
      }
    }
  }

}
