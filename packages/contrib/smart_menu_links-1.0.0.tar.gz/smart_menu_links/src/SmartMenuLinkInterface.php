<?php

declare(strict_types=1);

namespace Drupal\smart_menu_links;

use Drupal\Core\Config\Entity\ConfigEntityInterface;

/**
 * Provides an interface defining a smart menu links entity type.
 */
interface SmartMenuLinkInterface extends ConfigEntityInterface {

  /**
   * Returns the plugin definition for this menu link.
   */
  public function getPluginDefinition();

  /**
   * Returns whether this menu link is enabled.
   *
   * @return bool
   *   TRUE if enabled, FALSE otherwise.
   */
  public function isEnabled(): bool;

  /**
   * Returns the link text for this menu link.
   *
   * @return string
   *   The link text.
   */
  public function getTitle(): string;

  /**
   * Returns the full plugin ID for this menu link.
   *
   * @return string
   *   The plugin ID in the form 'smart_menu_links:{id}'.
   */
  public function getPluginId(): string;

}
