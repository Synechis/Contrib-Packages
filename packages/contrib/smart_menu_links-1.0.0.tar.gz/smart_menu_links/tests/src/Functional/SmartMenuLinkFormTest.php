<?php

declare(strict_types=1);

namespace Drupal\Tests\smart_menu_links\Functional;

use Drupal\node\Entity\NodeType;
use Drupal\Tests\BrowserTestBase;
use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;

/**
 * Tests the SmartMenuLink admin UI.
 */
#[Group('smart_menu_links')]
#[RunTestsInSeparateProcesses]
class SmartMenuLinkFormTest extends BrowserTestBase {

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'smart_menu_links',
    'system',
    'user',
    'node',
    'field',
    'text',
    'filter',
    'menu_ui',
    'link',
  ];

  /**
   * {@inheritdoc}
   */
  protected $defaultTheme = 'stark';

  /**
   * User with permission to administer smart menu links.
   *
   * @var \Drupal\user\UserInterface
   */
  protected $adminUser;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();
    NodeType::create(['type' => 'article', 'name' => 'Article'])->save();
    $this->adminUser = $this->drupalCreateUser([
      'administer smart_menu_link',
    ]);
  }

  /**
   * Creates a smart menu link entity via the admin form.
   *
   * @param string $id
   *   The machine name.
   * @param string $label
   *   The label.
   * @param array $extra
   *   Additional form values to override defaults.
   */
  protected function createViaForm(string $id, string $label, array $extra = []): void {
    $this->drupalGet('/admin/structure/smart-menu-link/add');
    $this->submitForm(array_merge([
      'id' => $id,
      'label' => $label,
      'link_text' => $label . ' text',
      // link_suffix is required — provide a non-empty default.
      'link_suffix' => 'view',
      'target_entity_type' => 'node',
      'source_id_or_name' => 'id',
      'source_path_segment' => 1,
    ], $extra), 'Save');
    // Verify the save succeeded (redirect to collection page).
    $this->assertSession()->addressEquals('/admin/structure/smart-menu-link');
  }

  /**
   * Anonymous users are denied access to the collection page.
   */
  public function testAdminPageAccessDeniedForAnonymous(): void {
    $this->drupalGet('/admin/structure/smart-menu-link');
    $this->assertSession()->statusCodeEquals(403);
  }

  /**
   * Admin user can load the collection page.
   */
  public function testAdminPageAccessGrantedForAdmin(): void {
    $this->drupalLogin($this->adminUser);
    $this->drupalGet('/admin/structure/smart-menu-link');
    $this->assertSession()->statusCodeEquals(200);
    $this->assertSession()->pageTextContains('Smart menu links');
  }

  /**
   * Admin user can load the add form.
   */
  public function testAddFormLoads(): void {
    $this->drupalLogin($this->adminUser);
    $this->drupalGet('/admin/structure/smart-menu-link/add');
    $this->assertSession()->statusCodeEquals(200);
  }

  /**
   * Admin user can create a smart menu link via the add form.
   */
  public function testCreateSmartMenuLink(): void {
    $this->drupalLogin($this->adminUser);
    $this->createViaForm('my_test_link', 'My test link', [
      'link_text' => 'Click here',
      'link_suffix' => 'details',
    ]);

    // After save, should redirect to collection and show success message.
    $this->assertSession()->addressEquals('/admin/structure/smart-menu-link');
    $this->assertSession()->pageTextContains('Created new link My test link.');

    // Config entity should now exist in storage.
    $entity = \Drupal::entityTypeManager()
      ->getStorage('smart_menu_link')
      ->load('my_test_link');
    $this->assertNotNull($entity);
    $this->assertSame('Click here', $entity->get('link_text'));
  }

  /**
   * Admin user can save advanced smart menu link settings.
   */
  public function testAdvancedSettingsPersist(): void {
    $this->drupalLogin($this->adminUser);
    $this->createViaForm('advanced_link', 'Advanced link');

    $this->drupalGet('/admin/structure/smart-menu-link/advanced_link');
    $this->submitForm([
      'expanded' => TRUE,
      'target_bundle' => 'article',
      'source_id_or_name' => 'name',
      'source_path_segment' => 2,
      'fallback' => '13',
      'validate_segment_id' => 1,
      'validate_segment_value' => 'node',
    ], 'Save');

    /** @var \Drupal\smart_menu_links\SmartMenuLinkInterface $entity */
    $entity = \Drupal::entityTypeManager()
      ->getStorage('smart_menu_link')
      ->load('advanced_link');
    $this->assertNotNull($entity, 'Entity was saved');
    $this->assertTrue((bool) $entity->get('expanded'));
    $this->assertSame('article', $entity->get('target_bundle'));
    $this->assertSame('name', $entity->get('source_id_or_name'));
    $this->assertSame(2, (int) $entity->get('source_path_segment'));
    $this->assertSame('13', $entity->get('fallback'));
    $this->assertSame(1, (int) $entity->get('validate_segment_id'));
    $this->assertSame('node', $entity->get('validate_segment_value'));
  }

  /**
   * Admin user can edit an existing smart menu link.
   */
  public function testEditSmartMenuLink(): void {
    $this->drupalLogin($this->adminUser);
    $this->createViaForm('edit_me', 'Edit me', ['link_text' => 'Original text']);

    // Navigate to edit form — path has no /edit suffix per the routing config.
    $this->drupalGet('/admin/structure/smart-menu-link/edit_me');
    $this->assertSession()->statusCodeEquals(200);

    // Machine name field should be disabled on edit.
    $this->assertSession()->fieldDisabled('id');

    $this->submitForm(['link_text' => 'Updated text'], 'Save');

    $this->assertSession()->addressEquals('/admin/structure/smart-menu-link');
    $this->assertSession()->pageTextContains('Updated link Edit me.');

    $entity = \Drupal::entityTypeManager()
      ->getStorage('smart_menu_link')
      ->loadUnchanged('edit_me');
    $this->assertSame('Updated text', $entity->get('link_text'));
  }

  /**
   * Admin user can delete a smart menu link.
   */
  public function testDeleteSmartMenuLink(): void {
    $this->drupalLogin($this->adminUser);
    $this->createViaForm('delete_me', 'Delete me');

    $this->drupalGet('/admin/structure/smart-menu-link/delete_me/delete');
    $this->assertSession()->statusCodeEquals(200);
    $this->submitForm([], 'Delete');

    $entity = \Drupal::entityTypeManager()
      ->getStorage('smart_menu_link')
      ->load('delete_me');
    $this->assertNull($entity);
  }

  /**
   * The weight field is saved and preserved correctly.
   *
   * Regression test for commit b8d2014 (menu weight ignored by
   * smart_menu_links).
   */
  public function testWeightIsSavedCorrectly(): void {
    $this->drupalLogin($this->adminUser);
    $this->createViaForm('weighted_link', 'Weighted link', ['weight' => -5]);

    $entity = \Drupal::entityTypeManager()
      ->getStorage('smart_menu_link')
      ->load('weighted_link');
    $this->assertNotNull($entity, 'Entity was saved');
    $this->assertSame(-5, (int) $entity->get('weight'));
  }

  /**
   * The enabled checkbox controls the entity's enabled state.
   */
  public function testEnabledCheckboxPersists(): void {
    $this->drupalLogin($this->adminUser);
    $this->createViaForm('enabled_test', 'Enabled test', ['status' => FALSE]);

    $entity = \Drupal::entityTypeManager()
      ->getStorage('smart_menu_link')
      ->load('enabled_test');
    $this->assertNotNull($entity, 'Entity was saved');
    $this->assertFalse((bool) $entity->status());
  }

  /**
   * Collection page lists existing entities with status.
   */
  public function testCollectionPageListsEntities(): void {
    $this->drupalLogin($this->adminUser);
    $this->createViaForm('alpha_link', 'Alpha link');
    $this->createViaForm('beta_link', 'Beta link', ['status' => FALSE]);

    $this->drupalGet('/admin/structure/smart-menu-link');
    $this->assertSession()->pageTextContains('Alpha link');
    $this->assertSession()->pageTextContains('Beta link');
    $this->assertSession()->pageTextContains('Enabled');
    $this->assertSession()->pageTextContains('Disabled');
  }

}
