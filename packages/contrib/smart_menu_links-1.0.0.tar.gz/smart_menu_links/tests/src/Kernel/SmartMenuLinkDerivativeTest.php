<?php

declare(strict_types=1);

namespace Drupal\Tests\smart_menu_links\Kernel;

use Drupal\KernelTests\KernelTestBase;
use Drupal\smart_menu_links\Entity\SmartMenuLink;
use Drupal\smart_menu_links\Plugin\Derivative\SmartMenuLink as SmartMenuLinkDerivative;
use PHPUnit\Framework\Attributes\CoversClass;
use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;

/**
 * Tests the SmartMenuLink derivative class.
 */
#[CoversClass(SmartMenuLinkDerivative::class)]
#[Group('smart_menu_links')]
#[RunTestsInSeparateProcesses]
class SmartMenuLinkDerivativeTest extends KernelTestBase {

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'smart_menu_links',
    'system',
    'user',
    'link',
  ];

  /**
   * The derivative instance.
   *
   * @var \Drupal\smart_menu_links\Plugin\Derivative\SmartMenuLink
   */
  protected SmartMenuLinkDerivative $derivative;

  /**
   * Base plugin definition used in derivative merging.
   *
   * @var array
   */
  protected array $baseDefinition = [
    'id' => 'smart_menu_links',
    'deriver' => SmartMenuLinkDerivative::class,
    'class' => 'Drupal\smart_menu_links\Plugin\Menu\SmartMenuLink',
    'provider' => 'smart_menu_links',
  ];

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();
    $this->derivative = SmartMenuLinkDerivative::create(
      $this->container,
      'smart_menu_links'
    );
  }

  /**
   * Returns an empty array when no config entities exist.
   */
  public function testNoEntitiesProducesEmptyDefinitions(): void {
    $definitions = $this->derivative->getDerivativeDefinitions($this->baseDefinition);
    $this->assertSame([], $definitions);
  }

  /**
   * A single entity produces one definition keyed by entity ID.
   */
  public function testSingleEntityProducesDefinition(): void {
    SmartMenuLink::create([
      'id' => 'my_link',
      'label' => 'My Link',
      'link_text' => 'Click',
      'link_suffix' => 'details',
      'menu_name' => 'main',
      'parent' => '',
      'weight' => 0,
      'target_entity_type' => 'node',
      'source_path_segment' => 1,
      'source_id_or_name' => 'id',
    ])->save();

    $definitions = $this->derivative->getDerivativeDefinitions($this->baseDefinition);

    $this->assertCount(1, $definitions);
    $this->assertArrayHasKey('my_link', $definitions);
    $this->assertSame('Click', $definitions['my_link']['title']);
    $this->assertSame('main', $definitions['my_link']['menu_name']);
  }

  /**
   * Multiple entities each produce a separate definition.
   */
  public function testMultipleEntitiesProduceDefinitions(): void {
    foreach (['alpha', 'beta', 'gamma'] as $id) {
      SmartMenuLink::create([
        'id' => $id,
        'label' => ucfirst($id),
        'link_text' => ucfirst($id) . ' link',
        'link_suffix' => 'view',
        'menu_name' => 'main',
        'parent' => '',
        'weight' => 0,
        'target_entity_type' => 'node',
        'source_path_segment' => 1,
        'source_id_or_name' => 'id',
      ])->save();
    }

    $definitions = $this->derivative->getDerivativeDefinitions($this->baseDefinition);

    $this->assertCount(3, $definitions);
    $this->assertArrayHasKey('alpha', $definitions);
    $this->assertArrayHasKey('beta', $definitions);
    $this->assertArrayHasKey('gamma', $definitions);
  }

  /**
   * Each definition's metadata.entity_id matches the entity ID.
   */
  public function testDefinitionMetadataEntityId(): void {
    SmartMenuLink::create([
      'id' => 'check_meta',
      'label' => 'Check Meta',
      'link_text' => 'Check',
      'link_suffix' => '',
      'menu_name' => 'main',
      'parent' => '',
      'weight' => 0,
      'target_entity_type' => 'node',
      'source_path_segment' => 1,
      'source_id_or_name' => 'id',
    ])->save();

    $definitions = $this->derivative->getDerivativeDefinitions($this->baseDefinition);

    $this->assertSame('check_meta', $definitions['check_meta']['metadata']['entity_id']);
  }

  /**
   * Entity plugin definition values override matching base definition keys.
   */
  public function testEntityDefinitionMergedWithBase(): void {
    SmartMenuLink::create([
      'id' => 'merged',
      'label' => 'Merged',
      'link_text' => 'Merged link',
      'link_suffix' => '',
      'menu_name' => 'footer',
      'parent' => '',
      'weight' => 10,
      'target_entity_type' => 'node',
      'source_path_segment' => 2,
      'source_id_or_name' => 'id',
    ])->save();

    $definitions = $this->derivative->getDerivativeDefinitions($this->baseDefinition);
    $def = $definitions['merged'];

    // Entity-specific values should be present.
    $this->assertSame('footer', $def['menu_name']);
    $this->assertSame(10, $def['weight']);
    // Base definition values should be merged in where entity did not override.
    $this->assertSame('smart_menu_links', $def['provider']);
  }

}
