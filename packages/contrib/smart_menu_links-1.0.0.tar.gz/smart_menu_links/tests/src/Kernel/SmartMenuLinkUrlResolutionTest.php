<?php

declare(strict_types=1);

namespace Drupal\Tests\smart_menu_links\Kernel;

use Drupal\KernelTests\KernelTestBase;
use Drupal\node\Entity\Node;
use Drupal\node\Entity\NodeType;
use Drupal\smart_menu_links\Entity\SmartMenuLink;
use Drupal\smart_menu_links\Plugin\Menu\SmartMenuLink as SmartMenuLinkPlugin;
use Drupal\taxonomy\Entity\Term;
use Drupal\taxonomy\Entity\Vocabulary;
use Drupal\Tests\content_moderation\Traits\ContentModerationTestTrait;
use PHPUnit\Framework\Attributes\CoversClass;
use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\RequestStack;

/**
 * Tests SmartMenuLink plugin URL resolution logic.
 */
#[CoversClass(SmartMenuLinkPlugin::class)]
#[Group('smart_menu_links')]
#[RunTestsInSeparateProcesses]
class SmartMenuLinkUrlResolutionTest extends KernelTestBase {

  use ContentModerationTestTrait;

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'content_moderation',
    'field',
    'filter',
    'node',
    'smart_menu_links',
    'system',
    'taxonomy',
    'text',
    'user',
    'link',
    'workflows',
  ];

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->installEntitySchema('content_moderation_state');
    $this->installEntitySchema('node');
    $this->installEntitySchema('taxonomy_term');
    $this->installEntitySchema('user');
    $this->installConfig(['content_moderation', 'filter', 'node']);

    NodeType::create([
      'type' => 'article',
      'name' => 'Article',
    ])->save();
    NodeType::create([
      'type' => 'page',
      'name' => 'Page',
    ])->save();

    Vocabulary::create([
      'vid' => 'tags',
      'name' => 'Tags',
    ])->save();
    Vocabulary::create([
      'vid' => 'topics',
      'name' => 'Topics',
    ])->save();

    $workflow = $this->createEditorialWorkflow();
    $this->addEntityTypeAndBundleToWorkflow($workflow, 'node', 'article');
  }

  /**
   * Creates a SmartMenuLink config entity and returns a plugin instance for it.
   *
   * The plugin is constructed with real container services so the entity
   * storage is live, while the request path is controlled by the caller.
   *
   * @param array $entity_values
   *   Config entity field values (merged with sensible defaults).
   * @param string $path
   *   The simulated request path.
   *
   * @return \Drupal\smart_menu_links\Plugin\Menu\SmartMenuLink
   *   A plugin instance bound to the given request path.
   */
  protected function createPluginForPath(array $entity_values, string $path): SmartMenuLinkPlugin {
    $defaults = [
      'id' => 'test_link',
      'label' => 'Test Link',
      'link_text' => 'Click',
      'link_suffix' => 'details',
      'menu_name' => 'main',
      'parent' => '',
      'weight' => 0,
      'enabled' => TRUE,
      'target_entity_type' => 'node',
      'target_bundle' => '',
      'moderation_states' => [],
      'source_path_segment' => 1,
      'source_id_or_name' => 'id',
      'fallback' => '',
      'validate_segment_id' => NULL,
      'validate_segment_value' => '',
    ];
    $values = array_merge($defaults, $entity_values);

    SmartMenuLink::create($values)->save();

    /** @var \Drupal\smart_menu_links\SmartMenuLinkInterface $entity */
    $entity = $this->container->get('entity_type.manager')
      ->getStorage('smart_menu_link')
      ->load($values['id']);

    $plugin_definition = $entity->getPluginDefinition() + [
      'provider' => 'smart_menu_links',
      'deriver' => 'Drupal\smart_menu_links\Plugin\Derivative\SmartMenuLink',
    ];

    $request_stack = new RequestStack();
    $request_stack->push(Request::create($path));

    return new SmartMenuLinkPlugin(
      [],
      'smart_menu_links:' . $values['id'],
      $plugin_definition,
      $this->container->get('entity_type.manager'),
      $request_stack,
      $this->container->get('language_manager'),
      $this->container->get('entity.repository'),
      NULL,
    );
  }

  /**
   * Creates a published node with sensible defaults.
   *
   * @param array $values
   *   Node values to merge with defaults.
   *
   * @return \Drupal\node\Entity\Node
   *   The saved node.
   */
  protected function createNode(array $values = []): Node {
    $node = Node::create($values + [
      'type' => 'article',
      'title' => 'Referenced node',
      'status' => 1,
      'moderation_state' => 'published',
    ]);
    $node->save();
    return $node;
  }

  /**
   * Creates a published taxonomy term with sensible defaults.
   *
   * @param array $values
   *   Term values to merge with defaults.
   *
   * @return \Drupal\taxonomy\Entity\Term
   *   The saved term.
   */
  protected function createTerm(array $values = []): Term {
    $term = Term::create($values + [
      'vid' => 'tags',
      'name' => 'shared-name',
      'status' => 1,
    ]);
    $term->save();
    return $term;
  }

  /**
   * Path segment IDs resolve to the entity canonical URL plus suffix.
   */
  public function testPathSegmentIdResolvesEntityUrl(): void {
    $node = $this->createNode();
    $plugin = $this->createPluginForPath([
      'source_path_segment' => 2,
    ], '/node/' . $node->id());

    $url = $plugin->getUrlObject();

    $this->assertSame(
      'base:node/' . $node->id() . '/details',
      $url->toUriString(),
    );
  }

  /**
   * Name lookups can resolve a matching entity in the configured bundle.
   */
  public function testNameLookupResolvesMatchingBundle(): void {
    $matching = $this->createTerm(['vid' => 'tags']);
    $this->createTerm(['vid' => 'topics']);
    $plugin = $this->createPluginForPath([
      'target_entity_type' => 'taxonomy_term',
      'target_bundle' => 'tags',
      'source_id_or_name' => 'name',
      'source_path_segment' => 2,
      'link_suffix' => 'overview',
    ], '/topic/shared-name');

    $url = $plugin->getUrlObject();

    $this->assertSame(
      'base:taxonomy/term/' . $matching->id() . '/overview',
      $url->toUriString(),
    );
  }

  /**
   * Name lookups ignore entities outside the configured bundle.
   */
  public function testNameLookupWrongBundleReturnsNoLink(): void {
    $this->createTerm(['vid' => 'topics']);
    $plugin = $this->createPluginForPath([
      'target_entity_type' => 'taxonomy_term',
      'target_bundle' => 'tags',
      'source_id_or_name' => 'name',
      'source_path_segment' => 2,
    ], '/topic/shared-name');

    $url = $plugin->getUrlObject();

    $this->assertSame('<nolink>', $url->getRouteName());
  }

  /**
   * Name lookups ignore unpublished target entities.
   */
  public function testNameLookupUnpublishedEntityReturnsNoLink(): void {
    $this->createTerm(['status' => 0]);
    $plugin = $this->createPluginForPath([
      'target_entity_type' => 'taxonomy_term',
      'target_bundle' => 'tags',
      'source_id_or_name' => 'name',
      'source_path_segment' => 2,
    ], '/topic/shared-name');

    $url = $plugin->getUrlObject();

    $this->assertSame('<nolink>', $url->getRouteName());
  }

  /**
   * Fallback values are used when the configured path segment does not resolve.
   */
  public function testFallbackValueResolvesEntityUrl(): void {
    $node = $this->createNode();
    $plugin = $this->createPluginForPath([
      'fallback' => (string) $node->id(),
      'source_path_segment' => 3,
    ], '/node');

    $url = $plugin->getUrlObject();

    $this->assertSame(
      'base:node/' . $node->id() . '/details',
      $url->toUriString(),
    );
  }

  /**
   * Resolved moderation state can keep an allowed smart menu link enabled.
   */
  public function testResolvedModerationStateMatchIsEnabled(): void {
    $node = $this->createNode(['moderation_state' => 'published']);
    $plugin = $this->createPluginForPath([
      'moderation_states' => ['published' => 'published'],
      'source_path_segment' => 2,
    ], '/node/' . $node->id());

    $plugin->getUrlObject();

    $this->assertTrue($plugin->isEnabled());
  }

  /**
   * Resolved moderation state can disable a smart menu link.
   */
  public function testResolvedModerationStateMismatchIsDisabled(): void {
    $node = $this->createNode([
      'moderation_state' => 'draft',
      'status' => 0,
    ]);
    $plugin = $this->createPluginForPath([
      'moderation_states' => ['published' => 'published'],
      'source_path_segment' => 2,
    ], '/node/' . $node->id());

    $plugin->getUrlObject();

    $this->assertFalse($plugin->isEnabled());
  }

  /**
   * Homepage with no fallback configured returns NULL.
   */
  public function testHomepageWithNoFallbackReturnsNull(): void {
    $plugin = $this->createPluginForPath([
      'fallback' => '',
    ], '/');

    $url = $plugin->getUrlObject();
    $this->assertNull($url);
  }

  /**
   * Path validation failure returns nolink route.
   */
  public function testPathValidationFailureReturnsNoLink(): void {
    // Validate that segment 1 equals 'node'; path has 'article' at segment 1.
    $plugin = $this->createPluginForPath([
      'validate_segment_id' => 1,
      'validate_segment_value' => 'node',
    ], '/article/5');

    $url = $plugin->getUrlObject();
    $this->assertNotNull($url);
    $this->assertSame('<nolink>', $url->getRouteName());
  }

  /**
   * Path segment present but zero-value ID returns nolink.
   */
  public function testZeroEntityIdReturnsNoLink(): void {
    // Path segment 1 is '0', which after (int) cast is falsy.
    $plugin = $this->createPluginForPath([
      'source_path_segment' => 1,
    ], '/0/extra');

    $url = $plugin->getUrlObject();
    $this->assertSame('<nolink>', $url->getRouteName());
  }

  /**
   * Path segment is absent returns nolink.
   */
  public function testMissingPathSegmentReturnsNoLink(): void {
    // source_path_segment=3 but path only has 2 real segments.
    $plugin = $this->createPluginForPath([
      'source_path_segment' => 3,
    ], '/node/1');

    $url = $plugin->getUrlObject();
    $this->assertSame('<nolink>', $url->getRouteName());
  }

  /**
   * Missing config entity returns nolink.
   */
  public function testMissingConfigEntityReturnsNoLink(): void {
    // Manually build a plugin that points to a non-existent config entity.
    $plugin_definition = [
      'metadata' => ['entity_id' => 'does_not_exist'],
      'title' => 'Ghost',
      'menu_name' => 'main',
      'parent' => '',
      'weight' => 0,
      'enabled' => 1,
      'expanded' => 0,
      'provider' => 'smart_menu_links',
      'id' => 'smart_menu_links:does_not_exist',
      'class' => SmartMenuLinkPlugin::class,
      'target_entity_type' => 'node',
      'target_bundle' => '',
      'moderation_states' => [],
      'source_path_segment' => 1,
      'source_id_or_name' => 'id',
      'fallback' => '',
      'validate_segment_id' => NULL,
      'validate_segment_value' => '',
      'link_suffix' => '',
    ];

    $request_stack = new RequestStack();
    $request_stack->push(Request::create('/node/1'));

    $plugin = new SmartMenuLinkPlugin(
      [],
      'smart_menu_links:does_not_exist',
      $plugin_definition,
      $this->container->get('entity_type.manager'),
      $request_stack,
      $this->container->get('language_manager'),
      $this->container->get('entity.repository'),
      NULL,
    );

    $url = $plugin->getUrlObject();
    $this->assertSame('<nolink>', $url->getRouteName());
  }

  /**
   * IsEnabled() returns FALSE when the config entity is missing.
   */
  public function testIsEnabledReturnsFalseForMissingEntity(): void {
    $plugin_definition = [
      'metadata' => ['entity_id' => 'ghost'],
      'title' => 'Ghost',
      'menu_name' => 'main',
      'parent' => '',
      'weight' => 0,
      'enabled' => 1,
      'expanded' => 0,
      'provider' => 'smart_menu_links',
      'id' => 'smart_menu_links:ghost',
      'class' => SmartMenuLinkPlugin::class,
      'target_entity_type' => 'node',
      'target_bundle' => '',
      'moderation_states' => [],
      'source_path_segment' => 1,
      'source_id_or_name' => 'id',
      'fallback' => '',
      'validate_segment_id' => NULL,
      'validate_segment_value' => '',
      'link_suffix' => '',
    ];

    $request_stack = new RequestStack();
    $request_stack->push(Request::create('/node/1'));

    $plugin = new SmartMenuLinkPlugin(
      [],
      'smart_menu_links:ghost',
      $plugin_definition,
      $this->container->get('entity_type.manager'),
      $request_stack,
      $this->container->get('language_manager'),
      $this->container->get('entity.repository'),
      NULL,
    );

    $this->assertFalse($plugin->isEnabled());
  }

  /**
   * Cache contexts include url.path for a live plugin instance.
   */
  public function testCacheContextsIncludeUrlPath(): void {
    $plugin = $this->createPluginForPath([], '/node/1');
    $this->assertContains('url.path', $plugin->getCacheContexts());
  }

  /**
   * Cache tags include the config entity's specific tag.
   */
  public function testCacheTagsIncludeConfigEntityTag(): void {
    $plugin = $this->createPluginForPath(['id' => 'tagged_link'], '/node/1');
    $tags = $plugin->getCacheTags();
    $this->assertContains(
      'config:smart_menu_links.smart_menu_link.tagged_link',
      $tags,
    );
  }

  /**
   * A disabled config entity causes isEnabled() to return FALSE.
   */
  public function testDisabledEntityIsDisabled(): void {
    $plugin = $this->createPluginForPath(['enabled' => FALSE], '/node/1');
    $this->assertFalse($plugin->isEnabled());
  }

  /**
   * An enabled config entity with no moderation filter causes isEnabled TRUE.
   */
  public function testEnabledEntityWithNoModerationIsEnabled(): void {
    $plugin = $this->createPluginForPath([
      'enabled' => TRUE,
      'moderation_states' => [],
    ], '/node/1');
    $this->assertTrue($plugin->isEnabled());
  }

  /**
   * Weight is persisted correctly through updateLink with persist=FALSE.
   *
   * Regression test for commit b8d2014 (menu weight ignored by
   * smart_menu_links).
   */
  public function testUpdateLinkWeightNotPersisted(): void {
    $plugin = $this->createPluginForPath(['weight' => 0], '/node/1');
    $result = $plugin->updateLink(['weight' => 7], FALSE);
    $this->assertSame(7, $result['weight']);

    // With persist=FALSE, the stored entity weight must not change.
    /** @var \Drupal\smart_menu_links\SmartMenuLinkInterface $stored */
    $stored = $this->container->get('entity_type.manager')
      ->getStorage('smart_menu_link')
      ->load('test_link');
    $this->assertSame(0, (int) $stored->get('weight'));
  }

  /**
   * Weight is persisted correctly through updateLink with persist=TRUE.
   */
  public function testUpdateLinkWeightPersisted(): void {
    $plugin = $this->createPluginForPath(['weight' => 0], '/node/1');
    $result = $plugin->updateLink(['weight' => 7], TRUE);
    $this->assertSame(7, $result['weight']);

    /** @var \Drupal\smart_menu_links\SmartMenuLinkInterface $stored */
    $stored = $this->container->get('entity_type.manager')
      ->getStorage('smart_menu_link')
      ->loadUnchanged('test_link');
    $this->assertSame(7, (int) $stored->get('weight'));
  }

}
