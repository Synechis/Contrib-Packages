<?php

declare(strict_types=1);

namespace Drupal\Tests\smart_menu_links\Kernel;

use Drupal\KernelTests\KernelTestBase;
use Drupal\smart_menu_links\Entity\SmartMenuLink;
use Drupal\Tests\SchemaCheckTestTrait;
use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;

/**
 * Tests SmartMenuLink config schema.
 */
#[Group('smart_menu_links')]
#[RunTestsInSeparateProcesses]
class SmartMenuLinkConfigSchemaTest extends KernelTestBase {

  use SchemaCheckTestTrait;

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'smart_menu_links',
    'system',
    'user',
    'link',
  ];

  /**
   * Smart menu link config validates against schema after export.
   */
  public function testSmartMenuLinkConfigSchema(): void {
    SmartMenuLink::create([
      'id' => 'schema_test',
      'label' => 'Schema test',
      'link_text' => 'Read more',
      'link_suffix' => 'details',
      'menu_name' => 'main',
      'parent' => '',
      'weight' => -3,
      'expanded' => TRUE,
      'enabled' => TRUE,
      'target_entity_type' => 'node',
      'target_bundle' => 'article',
      'moderation_states' => ['published'],
      'source_path_segment' => 2,
      'source_id_or_name' => 'id',
      'fallback' => '1',
      'validate_segment_id' => 1,
      'validate_segment_value' => 'node',
    ])->save();

    $config = $this->config('smart_menu_links.smart_menu_link.schema_test');
    $this->assertConfigSchema(
      $this->container->get('config.typed'),
      $config->getName(),
      $config->get(),
    );
  }

}
