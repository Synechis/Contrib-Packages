<?php

declare(strict_types=1);

namespace Drupal\Tests\smart_menu_links\Unit\Entity;

use Drupal\smart_menu_links\Entity\SmartMenuLink;
use Drupal\Tests\UnitTestCase;
use PHPUnit\Framework\Attributes\CoversClass;
use PHPUnit\Framework\Attributes\Group;

/**
 * Tests the SmartMenuLink config entity class.
 */
#[CoversClass(SmartMenuLink::class)]
#[Group('smart_menu_links')]
class SmartMenuLinkEntityTest extends UnitTestCase {

  /**
   * Creates a SmartMenuLink entity with default values for testing.
   *
   * @param array $values
   *   Field values to set on the entity.
   *
   * @return \Drupal\smart_menu_links\Entity\SmartMenuLink
   *   The entity instance.
   */
  protected function createEntity(array $values = []): SmartMenuLink {
    $defaults = [
      'id' => 'test_link',
      'label' => 'Test Link',
      'link_text' => 'Click here',
      'link_suffix' => 'details',
      'menu_name' => 'main',
      'parent' => '',
      'weight' => 0,
      'expanded' => FALSE,
      'enabled' => TRUE,
      'target_entity_type' => 'node',
      'target_bundle' => 'article',
      'moderation_states' => [],
      'source_path_segment' => 1,
      'source_id_or_name' => 'id',
      'fallback' => '',
      'validate_segment_id' => NULL,
      'validate_segment_value' => '',
    ];
    $all = array_merge($defaults, $values);
    $entity = new SmartMenuLink($all, 'smart_menu_link');
    return $entity;
  }

  // -------------------------------------------------------------------------
  // getPluginDefinition() tests
  // -------------------------------------------------------------------------

  /**
   * Enabled entity maps to integer 1 in plugin definition.
   */
  public function testGetPluginDefinitionEnabledIsOne(): void {
    $entity = $this->createEntity(['enabled' => TRUE]);
    $definition = $entity->getPluginDefinition();
    $this->assertSame(1, $definition['enabled']);
  }

  /**
   * Disabled entity maps to integer 0 in plugin definition.
   */
  public function testGetPluginDefinitionDisabledIsZero(): void {
    $entity = $this->createEntity(['enabled' => FALSE]);
    $definition = $entity->getPluginDefinition();
    $this->assertSame(0, $definition['enabled']);
  }

  /**
   * Plugin definition contains all required keys.
   */
  public function testGetPluginDefinitionContainsAllKeys(): void {
    $entity = $this->createEntity();
    $definition = $entity->getPluginDefinition();

    $required_keys = [
      'title',
      'link_suffix',
      'menu_name',
      'parent',
      'enabled',
      'expanded',
      'weight',
      'target_entity_type',
      'target_bundle',
      'moderation_states',
      'source_path_segment',
      'fallback',
      'validate_segment_id',
      'validate_segment_value',
      'class',
      'form_class',
    ];
    foreach ($required_keys as $key) {
      $this->assertArrayHasKey($key, $definition, "Missing key: $key");
    }
    $this->assertArrayHasKey('entity_id', $definition['metadata']);
  }

  /**
   * Plugin definition entity_id in metadata matches entity ID.
   */
  public function testGetPluginDefinitionMetadataEntityId(): void {
    $entity = $this->createEntity(['id' => 'my_smart_link']);
    $definition = $entity->getPluginDefinition();
    $this->assertSame('my_smart_link', $definition['metadata']['entity_id']);
  }

  /**
   * Plugin definition class references the SmartMenuLink plugin class.
   */
  public function testGetPluginDefinitionClass(): void {
    $entity = $this->createEntity();
    $definition = $entity->getPluginDefinition();
    $this->assertSame('Drupal\smart_menu_links\Plugin\Menu\SmartMenuLink', $definition['class']);
  }

  /**
   * Plugin definition title matches link_text field.
   */
  public function testGetPluginDefinitionTitle(): void {
    $entity = $this->createEntity(['link_text' => 'View product']);
    $definition = $entity->getPluginDefinition();
    $this->assertSame('View product', $definition['title']);
  }

  // -------------------------------------------------------------------------
  // getPluginId() tests
  // -------------------------------------------------------------------------

  /**
   * Plugin ID is prefixed with the namespace.
   */
  public function testGetPluginId(): void {
    $entity = $this->createEntity(['id' => 'my_smart_link']);
    $this->assertSame('smart_menu_links:my_smart_link', $entity->getPluginId());
  }

  // -------------------------------------------------------------------------
  // getTitle() tests
  // -------------------------------------------------------------------------

  /**
   * GetTitle() returns the link_text field value.
   */
  public function testGetTitle(): void {
    $entity = $this->createEntity(['link_text' => 'Buy now']);
    $this->assertSame('Buy now', $entity->getTitle());
  }

  // -------------------------------------------------------------------------
  // isEnabled() tests
  // -------------------------------------------------------------------------

  /**
   * Returns TRUE when enabled is TRUE.
   */
  public function testIsEnabledTrue(): void {
    $entity = $this->createEntity(['enabled' => TRUE]);
    $this->assertTrue($entity->isEnabled());
  }

  /**
   * Returns FALSE when enabled is FALSE.
   */
  public function testIsEnabledFalse(): void {
    $entity = $this->createEntity(['enabled' => FALSE]);
    $this->assertFalse($entity->isEnabled());
  }

}
