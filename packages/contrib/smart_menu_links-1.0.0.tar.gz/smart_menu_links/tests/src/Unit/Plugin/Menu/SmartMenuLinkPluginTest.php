<?php

declare(strict_types=1);

namespace Drupal\Tests\smart_menu_links\Unit\Plugin\Menu;

use Drupal\Core\Entity\ContentEntityInterface;
use Drupal\Core\Entity\EntityRepositoryInterface;
use Drupal\Core\Entity\EntityStorageInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Language\LanguageManagerInterface;
use Drupal\smart_menu_links\Plugin\Menu\SmartMenuLink;
use Drupal\smart_menu_links\SmartMenuLinkInterface;
use Drupal\Tests\UnitTestCase;
use PHPUnit\Framework\Attributes\CoversClass;
use PHPUnit\Framework\Attributes\Group;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\RequestStack;

/**
 * Tests SmartMenuLink plugin logic.
 */
#[CoversClass(SmartMenuLink::class)]
#[Group('smart_menu_links')]
class SmartMenuLinkPluginTest extends UnitTestCase {

  /**
   * Creates a SmartMenuLink plugin instance for testing.
   *
   * @param array $plugin_definition
   *   Plugin definition values to merge with defaults.
   * @param string $path
   *   The request path to simulate.
   * @param \Drupal\smart_menu_links\SmartMenuLinkInterface|null $entity
   *   Optional entity to return from getEntity().
   *
   * @return \Drupal\smart_menu_links\Plugin\Menu\SmartMenuLink
   *   The plugin instance.
   */
  protected function createPlugin(array $plugin_definition = [], string $path = '/node/1', ?SmartMenuLinkInterface $entity = NULL): SmartMenuLink {
    $definition_defaults = [
      'metadata' => ['entity_id' => 'test_link'],
      'title' => 'Test link',
      'description' => '',
      'menu_name' => 'main',
      'parent' => '',
      'weight' => 0,
      'enabled' => 1,
      'expanded' => 0,
      'provider' => 'smart_menu_links',
      'id' => 'smart_menu_links:test_link',
      'class' => SmartMenuLink::class,
    ];

    $entity_type_manager = $this->createMock(EntityTypeManagerInterface::class);
    if ($entity !== NULL) {
      $storage = $this->createMock(EntityStorageInterface::class);
      $storage->method('loadMultiple')->willReturn(['test_link' => $entity]);
      $entity_type_manager->method('getStorage')->willReturn($storage);
    }

    $request = Request::create($path);
    $request_stack = new RequestStack();
    $request_stack->push($request);

    $language_manager = $this->createMock(LanguageManagerInterface::class);
    $language_manager->method('isMultilingual')->willReturn(FALSE);

    $entity_repository = $this->createMock(EntityRepositoryInterface::class);
    // Return the passed entity unchanged so getEntity() stores it correctly.
    $entity_repository->method('getTranslationFromContext')->willReturnArgument(0);

    return new SmartMenuLink(
      [],
      'smart_menu_links:test_link',
      $definition_defaults + $plugin_definition,
      $entity_type_manager,
      $request_stack,
      $language_manager,
      $entity_repository,
      NULL,
    );
  }

  /**
   * Creates a mock SmartMenuLinkInterface entity with field getters.
   *
   * @param array $fields
   *   Fields to return from ->get().
   * @param bool $enabled
   *   Whether the entity is enabled.
   *
   * @return \Drupal\smart_menu_links\SmartMenuLinkInterface
   *   The mock entity.
   */
  protected function createEntityMock(array $fields = [], bool $enabled = TRUE): SmartMenuLinkInterface {
    $entity = $this->createMock(SmartMenuLinkInterface::class);
    // Merge 'enabled' into fields so get('enabled') returns the right bool.
    $all_fields = array_merge(['enabled' => $enabled], $fields);
    $entity->method('get')->willReturnCallback(fn($key) => $all_fields[$key] ?? NULL);
    $entity->method('isEnabled')->willReturn($enabled);
    $entity->method('id')->willReturn('test_link');
    $entity->method('getTitle')->willReturn($fields['link_text'] ?? 'Test link');
    return $entity;
  }

  /**
   * Calls a protected method on the plugin via reflection.
   *
   * @param \Drupal\smart_menu_links\Plugin\Menu\SmartMenuLink $plugin
   *   The plugin instance.
   * @param string $method
   *   The method name.
   * @param mixed ...$args
   *   Method arguments.
   *
   * @return mixed
   *   The return value.
   */
  protected function callProtected(SmartMenuLink $plugin, string $method, mixed ...$args): mixed {
    $ref = new \ReflectionMethod($plugin, $method);
    return $ref->invoke($plugin, ...$args);
  }

  // -------------------------------------------------------------------------
  // validatePath() tests
  // -------------------------------------------------------------------------

  /**
   * No validation criteria set returns TRUE.
   */
  public function testValidatePathNoValidationCriteria(): void {
    $entity = $this->createEntityMock([
      'validate_segment_id' => NULL,
      'validate_segment_value' => '',
    ]);
    $plugin = $this->createPlugin();
    $result = $this->callProtected($plugin, 'validatePath', $entity, ['', 'node', '1']);
    $this->assertTrue($result);
  }

  /**
   * Validate_segment_id set but value empty returns TRUE.
   */
  public function testValidatePathNoValidationValue(): void {
    $entity = $this->createEntityMock([
      'validate_segment_id' => 2,
      'validate_segment_value' => '',
    ]);
    $plugin = $this->createPlugin();
    $result = $this->callProtected($plugin, 'validatePath', $entity, ['', 'node', '1', 'extra']);
    $this->assertTrue($result);
  }

  /**
   * Path segment matches expected value returns TRUE.
   */
  public function testValidatePathSegmentMatches(): void {
    $entity = $this->createEntityMock([
      'validate_segment_id' => 1,
      'validate_segment_value' => 'node',
    ]);
    $plugin = $this->createPlugin();
    $result = $this->callProtected($plugin, 'validatePath', $entity, ['', 'node', '42']);
    $this->assertTrue($result);
  }

  /**
   * Path segment does not match expected value returns FALSE.
   */
  public function testValidatePathSegmentMismatch(): void {
    $entity = $this->createEntityMock([
      'validate_segment_id' => 1,
      'validate_segment_value' => 'node',
    ]);
    $plugin = $this->createPlugin();
    $result = $this->callProtected($plugin, 'validatePath', $entity, ['', 'article', '42']);
    $this->assertFalse($result);
  }

  // -------------------------------------------------------------------------
  // cleanArray() tests
  // -------------------------------------------------------------------------

  /**
   * Empty string values are removed.
   */
  public function testCleanArrayRemovesEmpty(): void {
    $plugin = $this->createPlugin();
    $result = $this->callProtected($plugin, 'cleanArray', ['a' => '', 'b' => 'published']);
    $this->assertArrayNotHasKey('a', $result);
    $this->assertArrayHasKey('b', $result);
  }

  /**
   * The string '0' is removed.
   */
  public function testCleanArrayRemovesZeroString(): void {
    $plugin = $this->createPlugin();
    $result = $this->callProtected($plugin, 'cleanArray', ['a' => '0', 'b' => 'draft']);
    $this->assertArrayNotHasKey('a', $result);
    $this->assertArrayHasKey('b', $result);
  }

  /**
   * Valid non-empty values survive.
   */
  public function testCleanArrayKeepsValidValues(): void {
    $plugin = $this->createPlugin();
    $result = $this->callProtected($plugin, 'cleanArray', [
      'published' => 'published',
      'draft' => 'draft',
    ]);
    $this->assertCount(2, $result);
  }

  // -------------------------------------------------------------------------
  // getCacheContexts() tests
  // -------------------------------------------------------------------------

  /**
   * Always returns url.path context.
   */
  public function testGetCacheContexts(): void {
    $plugin = $this->createPlugin();
    $this->assertSame(['url.path'], $plugin->getCacheContexts());
  }

  // -------------------------------------------------------------------------
  // getCacheTags() tests
  // -------------------------------------------------------------------------

  /**
   * When getEntity() returns NULL only base config list tag is returned.
   */
  public function testGetCacheTagsNoEntity(): void {
    // Use plugin with no metadata entity_id so entity load returns NULL.
    $entity_type_manager = $this->createMock(EntityTypeManagerInterface::class);
    $storage = $this->createMock(EntityStorageInterface::class);
    $storage->method('loadMultiple')->willReturn([]);
    $storage->method('load')->willReturn(NULL);
    $entity_type_manager->method('getStorage')->willReturn($storage);

    $request_stack = new RequestStack();
    $request_stack->push(Request::create('/'));

    $plugin = new SmartMenuLink(
      [],
      'smart_menu_links:missing',
      [
        'metadata' => ['entity_id' => 'missing'],
        'title' => 'Missing',
        'menu_name' => 'main',
        'parent' => '',
        'weight' => 0,
        'enabled' => 1,
        'expanded' => 0,
        'provider' => 'smart_menu_links',
        'id' => 'smart_menu_links:missing',
        'class' => SmartMenuLink::class,
      ],
      $entity_type_manager,
      $request_stack,
      $this->createMock(LanguageManagerInterface::class),
      $this->createMock(EntityRepositoryInterface::class),
      NULL,
    );

    $tags = $plugin->getCacheTags();
    $this->assertSame(['config:smart_menu_link_list'], $tags);
  }

  /**
   * Entity with bundle includes bundle-specific entity list tag.
   */
  public function testGetCacheTagsWithBundle(): void {
    $entity = $this->createEntityMock([
      'target_entity_type' => 'node',
      'target_bundle' => 'article',
    ]);
    $plugin = $this->createPlugin([], '/node/1', $entity);
    $tags = $plugin->getCacheTags();

    $this->assertContains('config:smart_menu_link_list', $tags);
    $this->assertContains('config:smart_menu_links.smart_menu_link.test_link', $tags);
    $this->assertContains('node_list:article', $tags);
    $this->assertNotContains('node_list', $tags);
  }

  /**
   * Entity without bundle includes plain entity type list tag.
   */
  public function testGetCacheTagsWithoutBundle(): void {
    $entity = $this->createEntityMock([
      'target_entity_type' => 'node',
      'target_bundle' => '',
    ]);
    $plugin = $this->createPlugin([], '/node/1', $entity);
    $tags = $plugin->getCacheTags();

    $this->assertContains('node_list', $tags);
    foreach ($tags as $tag) {
      $this->assertStringNotContainsString('node_list:', $tag);
    }
  }

  // -------------------------------------------------------------------------
  // isEnabled() tests
  // -------------------------------------------------------------------------

  /**
   * Returns FALSE when entity cannot be loaded.
   */
  public function testIsEnabledEntityNotFound(): void {
    $entity_type_manager = $this->createMock(EntityTypeManagerInterface::class);
    $storage = $this->createMock(EntityStorageInterface::class);
    $storage->method('loadMultiple')->willReturn([]);
    $storage->method('load')->willReturn(NULL);
    $entity_type_manager->method('getStorage')->willReturn($storage);

    $request_stack = new RequestStack();
    $request_stack->push(Request::create('/node/1'));

    $plugin = new SmartMenuLink(
      [],
      'smart_menu_links:gone',
      [
        'metadata' => ['entity_id' => 'gone'],
        'title' => 'Gone',
        'menu_name' => 'main',
        'parent' => '',
        'weight' => 0,
        'enabled' => 1,
        'expanded' => 0,
        'provider' => 'smart_menu_links',
        'id' => 'smart_menu_links:gone',
        'class' => SmartMenuLink::class,
      ],
      $entity_type_manager,
      $request_stack,
      $this->createMock(LanguageManagerInterface::class),
      $this->createMock(EntityRepositoryInterface::class),
      NULL,
    );

    $this->assertFalse($plugin->isEnabled());
  }

  /**
   * Returns FALSE when entity is disabled and there is no relatedTo entity.
   */
  public function testIsEnabledEntityDisabled(): void {
    $entity = $this->createEntityMock([
      'moderation_states' => [],
    ], FALSE);
    $plugin = $this->createPlugin([], '/node/1', $entity);
    $this->assertFalse($plugin->isEnabled());
  }

  /**
   * Returns TRUE when entity is enabled and moderation_states is empty.
   */
  public function testIsEnabledNoModerationStates(): void {
    $entity = $this->createEntityMock([
      'moderation_states' => [],
    ], TRUE);
    $plugin = $this->createPlugin([], '/node/1', $entity);
    $this->assertTrue($plugin->isEnabled());
  }

  /**
   * Returns TRUE when relatedTo entity moderation state is in allowed states.
   */
  public function testIsEnabledModerationStateMatch(): void {
    $entity = $this->createEntityMock([
      'moderation_states' => ['published' => 'published'],
    ], TRUE);
    $plugin = $this->createPlugin([], '/node/1', $entity);

    // Build a minimal content entity stub with moderation_state field.
    $state_item = new \stdClass();
    $state_item->value = 'published';
    $related = $this->createMock(ContentEntityInterface::class);
    $related->method('get')->with('moderation_state')->willReturn($state_item);

    $prop = new \ReflectionProperty($plugin, 'relatedTo');
    $prop->setValue($plugin, $related);

    $this->assertTrue($plugin->isEnabled());
  }

  /**
   * Returns FALSE when relatedTo entity moderation state is not in allowed.
   */
  public function testIsEnabledModerationStateMismatch(): void {
    $entity = $this->createEntityMock([
      'moderation_states' => ['published' => 'published'],
    ], TRUE);
    $plugin = $this->createPlugin([], '/node/1', $entity);

    $state_item = new \stdClass();
    $state_item->value = 'draft';
    $related = $this->createMock(ContentEntityInterface::class);
    $related->method('get')->with('moderation_state')->willReturn($state_item);

    $prop = new \ReflectionProperty($plugin, 'relatedTo');
    $prop->setValue($plugin, $related);

    $this->assertFalse($plugin->isEnabled());
  }

  // -------------------------------------------------------------------------
  // getTitle() tests
  // -------------------------------------------------------------------------

  /**
   * On a monolingual site the title comes from the plugin definition.
   */
  public function testGetTitleMonolingual(): void {
    $language_manager = $this->createMock(LanguageManagerInterface::class);
    $language_manager->method('isMultilingual')->willReturn(FALSE);

    $request_stack = new RequestStack();
    $request_stack->push(Request::create('/'));

    $plugin = new SmartMenuLink(
      [],
      'smart_menu_links:test',
      [
        'metadata' => ['entity_id' => 'test'],
        'title' => 'Definition title',
        'menu_name' => 'main',
        'parent' => '',
        'weight' => 0,
        'enabled' => 1,
        'expanded' => 0,
        'provider' => 'smart_menu_links',
        'id' => 'smart_menu_links:test',
        'class' => SmartMenuLink::class,
      ],
      $this->createMock(EntityTypeManagerInterface::class),
      $request_stack,
      $language_manager,
      $this->createMock(EntityRepositoryInterface::class),
      NULL,
    );

    $this->assertSame('Definition title', $plugin->getTitle());
  }

  /**
   * On a multilingual site the title comes from the entity.
   */
  public function testGetTitleMultilingual(): void {
    $entity = $this->createEntityMock(['link_text' => 'Translated title'], TRUE);

    $entity_type_manager = $this->createMock(EntityTypeManagerInterface::class);
    $storage = $this->createMock(EntityStorageInterface::class);
    $storage->method('loadMultiple')->willReturn(['test_link' => $entity]);
    $entity_type_manager->method('getStorage')->willReturn($storage);

    $language_manager = $this->createMock(LanguageManagerInterface::class);
    $language_manager->method('isMultilingual')->willReturn(TRUE);

    $entity_repository = $this->createMock(EntityRepositoryInterface::class);
    $entity_repository->method('getTranslationFromContext')->willReturnArgument(0);

    $request_stack = new RequestStack();
    $request_stack->push(Request::create('/'));

    $plugin = new SmartMenuLink(
      [],
      'smart_menu_links:test_link',
      [
        'metadata' => ['entity_id' => 'test_link'],
        'title' => 'Definition title',
        'menu_name' => 'main',
        'parent' => '',
        'weight' => 0,
        'enabled' => 1,
        'expanded' => 0,
        'provider' => 'smart_menu_links',
        'id' => 'smart_menu_links:test_link',
        'class' => SmartMenuLink::class,
      ],
      $entity_type_manager,
      $request_stack,
      $language_manager,
      $entity_repository,
      NULL,
    );

    $this->assertSame('Translated title', $plugin->getTitle());
  }

  // -------------------------------------------------------------------------
  // updateLink() tests
  // -------------------------------------------------------------------------

  /**
   * Keys not in overrideAllowed are stripped from the update.
   */
  public function testUpdateLinkFiltersDisallowedKeys(): void {
    $entity = $this->createEntityMock([], TRUE);
    $plugin = $this->createPlugin([], '/node/1', $entity);

    $result = $plugin->updateLink([
      'weight' => 5,
      'title' => 'Should be ignored',
      'target_entity_type' => 'should_be_ignored',
    ], FALSE);

    $this->assertSame(5, $result['weight']);
    $this->assertSame('Test link', $result['title']);
    $this->assertArrayNotHasKey('target_entity_type', $result);
  }

  /**
   * When persist is FALSE, entity storage save() is never called.
   */
  public function testUpdateLinkNoPersist(): void {
    $entity = $this->createEntityMock([], TRUE);

    $storage = $this->createMock(EntityStorageInterface::class);
    $storage->expects($this->never())->method('save');
    $storage->method('loadMultiple')->willReturn(['test_link' => $entity]);

    $entity_type_manager = $this->createMock(EntityTypeManagerInterface::class);
    $entity_type_manager->method('getStorage')->willReturn($storage);

    $request_stack = new RequestStack();
    $request_stack->push(Request::create('/node/1'));

    $plugin = new SmartMenuLink(
      [],
      'smart_menu_links:test_link',
      [
        'metadata' => ['entity_id' => 'test_link'],
        'title' => 'Test link',
        'menu_name' => 'main',
        'parent' => '',
        'weight' => 0,
        'enabled' => 1,
        'expanded' => 0,
        'provider' => 'smart_menu_links',
        'id' => 'smart_menu_links:test_link',
        'class' => SmartMenuLink::class,
      ],
      $entity_type_manager,
      $request_stack,
      $this->createMock(LanguageManagerInterface::class),
      $this->createMock(EntityRepositoryInterface::class),
      NULL,
    );

    $plugin->updateLink(['weight' => 3], FALSE);
  }

}
