<?php

declare(strict_types=1);

namespace Drupal\views_bulk_operations\Action;

use Drupal\Component\Plugin\ConfigurableInterface;
use Drupal\Core\Action\ActionBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\views\ViewExecutable;
use Drupal\views_bulk_operations\Traits\ReturnTypeDeprecationTrait;
use Drupal\views_bulk_operations\Traits\ViewsBulkOperationsActionCompletedTrait;

/**
 * Views Bulk Operations action plugin base.
 *
 * Provides a base implementation for a configurable
 * and preconfigurable VBO Action plugin.
 */
abstract class ViewsBulkOperationsActionBase extends ActionBase implements ViewsBulkOperationsActionInterface, ConfigurableInterface {

  use ViewsBulkOperationsActionCompletedTrait;
  use ReturnTypeDeprecationTrait;

  /**
   * Action context.
   *
   * Contains view data and optionally batch operation context.
   */
  protected array $context;

  /**
   * The processed view.
   */
  protected ?ViewExecutable $view = NULL;

  /**
   * Configuration array.
   *
   * @var array
   *   NOTE: Don't add a type hint due to parent declaration unless changed.
   */
  protected $configuration;

  /**
   * {@inheritdoc}
   */
  public function setContext(array &$context): void {
    $this->context['sandbox'] = &$context['sandbox'];
    foreach ($context as $key => $item) {
      if ($key === 'sandbox') {
        continue;
      }
      $this->context[$key] = $item;
    }
  }

  /**
   * {@inheritdoc}
   */
  public function setView(ViewExecutable $view): void {
    $this->view = $view;
  }

  /**
   * {@inheritdoc}
   *
   * @return mixed[]
   *   An array of MarkupInterface objects or an empty array or an array
   *   of arrays with 'message' (MarkupInterface) and 'type' (string) keys.
   */
  public function executeMultiple(array $objects) {
    $this->deprecateMissingReturnType('executeMultiple', 'array', 'views_bulk_operations:4.4.8', 'views_bulk_operations:5.0.0');

    $results = [];
    foreach ($objects as $entity) {
      $results[] = $this->execute($entity);
    }

    return $results;
  }

  /**
   * {@inheritdoc}
   */
  public function defaultConfiguration(): array {
    return [];
  }

  /**
   * Default configuration form validator.
   *
   * This method will be needed if a child class will implement
   * \Drupal\Core\Plugin\PluginFormInterface. Code saver.
   *
   * @param array &$form
   *   Form array.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state object.
   */
  public function validateConfigurationForm(array &$form, FormStateInterface $form_state): void {

  }

  /**
   * Default configuration form submit handler.
   *
   * This method will be needed if a child class will implement
   * \Drupal\Core\Plugin\PluginFormInterface. Code saver.
   *
   * @param array &$form
   *   Form array.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state object.
   */
  public function submitConfigurationForm(array &$form, FormStateInterface $form_state): void {
    $form_state->cleanValues();
    foreach ($form_state->getValues() as $key => $value) {
      $this->configuration[$key] = $value;
    }
  }

  /**
   * {@inheritdoc}
   */
  public function getConfiguration(): array {
    return $this->configuration;
  }

  /**
   * {@inheritdoc}
   */
  public function setConfiguration(array $configuration): void {
    $this->configuration = $configuration;
  }

}
