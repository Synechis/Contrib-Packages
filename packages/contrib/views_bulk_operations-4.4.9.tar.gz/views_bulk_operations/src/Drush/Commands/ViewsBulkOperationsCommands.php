<?php

declare(strict_types=1);

namespace Drupal\views_bulk_operations\Drush\Commands;

use Consolidation\OutputFormatters\StructuredData\RowsOfFields;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Session\AccountProxyInterface;
use Drupal\views\Views;
use Drupal\views_bulk_operations\Traits\ViewsBulkOperationsActionCompletedTrait;
use Drupal\views_bulk_operations\Service\ViewsBulkOperationsActionManager;
use Drupal\views_bulk_operations\Service\ViewsBulkOperationsViewDataInterface;
use Drupal\views_bulk_operations\ViewsBulkOperationsBatch;
use Drush\Attributes as CLI;
use Drush\Commands\AutowireTrait;
use Drush\Commands\DrushCommands;
use Drush\Drush;
use Psr\Log\LogLevel;

/**
 * Defines Drush commands for the module.
 */
final class ViewsBulkOperationsCommands extends DrushCommands {

  use ViewsBulkOperationsActionCompletedTrait {
    message as traitMessage;
  }
  use AutowireTrait;

  /**
   * ViewsBulkOperationsCommands object constructor.
   *
   * @param \Drupal\Core\Session\AccountProxyInterface $currentUser
   *   The current user object.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   *   The entity type manager.
   * @param \Drupal\views_bulk_operations\Service\ViewsBulkOperationsViewDataInterface $viewData
   *   VBO View data service.
   * @param \Drupal\views_bulk_operations\Service\ViewsBulkOperationsActionManager $actionManager
   *   VBO Action manager service.
   */
  public function __construct(
    private readonly AccountProxyInterface $currentUser,
    private readonly EntityTypeManagerInterface $entityTypeManager,
    private readonly ViewsBulkOperationsViewDataInterface $viewData,
    private readonly ViewsBulkOperationsActionManager $actionManager,
  ) {
    parent::__construct();
  }

  /**
   * Execute an action on all results of the specified view.
   *
   * Use the --verbose option to see progress messages.
   */
  #[CLI\Command(name: 'views:bulk-operations:execute', aliases: [
    'vbo-execute',
    'vbo-exec',
    'views-bulk-operations:execute',
  ])]
  #[CLI\Argument(name: 'view_id', description: 'The ID of the view to use.')]
  #[CLI\Argument(name: 'action_id', description: 'The ID of the action to execute.')]
  #[CLI\Option(name: 'display-id', description: 'ID of the display to use.')]
  #[CLI\Option(name: 'args', description: 'View arguments (slash is a delimiter).')]
  #[CLI\Option(name: 'exposed', description: 'Exposed filters (query string format).')]
  #[CLI\Option(name: 'batch-size', description: 'Processing batch size.')]
  #[CLI\Option(name: 'configuration', description: 'Action configuration (query string format).')]
  #[CLI\Option(name: 'user-id', description: 'The ID of the user account used for performing the operation.')]
  #[CLI\Usage(name: 'drush views:bulk-operations:execute some_view some_action', description: 'Execute some action on some view.')]
  #[CLI\Usage(name: 'drush vbo-execute some_view some_action --args=arg1/arg2 --batch-size=50', description: 'Execute some action on some view with arg1 and arg2 as the view arguments and 50 entities processed per batch.')]
  #[CLI\Usage(name: 'drush vbo-exec some_view some_action --configuration=&quot;key1=value1&amp;key2=value2&quot;', description: 'Execute some action on some view with the specified action configuration.')]
  public function vboExecute(
    string $view_id,
    string $action_id,
    array $options = [
      'display-id' => 'default',
      'args' => self::REQ,
      'exposed' => self::REQ,
      'batch-size' => 10,
      'configuration' => self::REQ,
      'user-id' => 1,
    ],
  ): void {
    if ($view_id === '' || $action_id === '') {
      throw new \Exception('You must specify the view ID and the action ID parameters.');
    }

    $this->timer($options['verbose']);

    // Prepare options.
    if ($options['args'] !== NULL) {
      $options['args'] = \explode('/', $options['args']);
    }
    else {
      $options['args'] = [];
    }

    // Decode query string format options.
    foreach (['configuration', 'exposed'] as $name) {
      if ($options[$name] !== NULL && !\is_array($options[$name])) {
        \parse_str($options[$name], $options[$name]);
      }
      else {
        $options[$name] = [];
      }
    }

    $vbo_data = [
      'list' => [],
      'view_id' => $view_id,
      'display_id' => $options['display-id'],
      'action_id' => $action_id,
      'preconfiguration' => $options['configuration'],
      'batch' => TRUE,
      'arguments' => $options['args'],
      'exposed_input' => $options['exposed'],
      'batch_size' => $options['batch-size'],
      'relationship_id' => 'none',
      // We set the clear_on_exposed parameter to true, otherwise with empty
      // selection exposed filters are not taken into account.
      'clear_on_exposed' => TRUE,
      'exclude_mode' => FALSE,
    ];

    // Login as the provided user, as drush 9+ doesn't support the
    // --user parameter. Default: user 1.
    $account = $this->entityTypeManager->getStorage('user')->load($options['user-id']);
    $this->currentUser->setAccount($account);

    // Initialize the view to check if parameters are correct.
    $view = Views::getView($vbo_data['view_id']);
    if ($view === NULL) {
      throw new \Exception('Incorrect view ID provided.');
    }
    if (!$view->setDisplay($vbo_data['display_id'])) {
      throw new \Exception('Incorrect view display ID provided.');
    }
    if (\count($vbo_data['arguments']) !== 0) {
      $view->setArguments($vbo_data['arguments']);
    }
    if (\count($vbo_data['exposed_input']) !== 0) {
      $view->setExposedInput($vbo_data['exposed_input']);
    }

    // We need total rows count for proper progress message display.
    $view->get_total_rows = TRUE;
    $view->execute();

    // Get relationship ID if VBO field exists.
    $vbo_data['relationship_id'] = 'none';
    foreach ($view->field as $field) {
      if ($field->options['id'] === 'views_bulk_operations_bulk_form') {
        $vbo_data['relationship_id'] = $field->options['relationship'];
      }
    }

    // Get total rows count.
    $this->viewData->init($view, $view->getDisplay(), $vbo_data['relationship_id']);
    $vbo_data['total_results'] = $this->viewData->getTotalResults($vbo_data['clear_on_exposed']);

    // Get action definition and check if action ID is correct.
    $action_definition = $this->actionManager->getDefinition($action_id);
    $vbo_data['action_label'] = (string) $action_definition['label'];

    $this->timer($options['verbose'], 'init');

    // Populate entity list.
    $context = [];
    do {
      $context['finished'] = 1;
      $context['message'] = '';
      ViewsBulkOperationsBatch::getList($vbo_data, $context);
      if (\array_key_exists('message', $context)) {
        $this->logger->info($context['message']);
      }
    } while ($context['finished'] < 1);
    $vbo_data = $context['results'];

    $this->timer($options['verbose'], 'list');

    // Execute the selected action.
    $context = [];
    do {
      $context['finished'] = 1;
      $context['message'] = '';
      ViewsBulkOperationsBatch::operation($vbo_data, $context);
      if (\array_key_exists('message', $context) && $context['message'] !== '') {
        $this->logger->info($context['message']);
      }
    } while ($context['finished'] < 1);

    // Display debug information.
    if ($options['verbose']) {
      $this->timer($options['verbose'], 'execute');
      $this->logger->info($this->t('Initialization time: @time ms.', [
        '@time' => $this->timer($options['verbose'], 'init'),
      ]));
      $this->logger->info($this->t('Entity list generation time: @time ms.', [
        '@time' => $this->timer($options['verbose'], 'list'),
      ]));
      $this->logger->info($this->t('Execution time: @time ms.', [
        '@time' => $this->timer($options['verbose'], 'execute'),
      ]));
    }

    static::finished(TRUE, $context['results'], []);
  }

  /**
   * List available actions for a view.
   */
  #[CLI\Command(name: 'views:bulk-operations:list', aliases: ['vbo-list'])]
  #[CLI\DefaultTableFields(fields: ['id', 'label', 'entity_type_id'])]
  #[CLI\FieldLabels(labels: ['id' => 'ID', 'label' => 'Label', 'entity_type_id' => 'Entity type ID'])]
  #[CLI\Usage(name: 'drush views:bulk-operations:list some_view some_action', description: 'Execute some action on some view.')]
  #[CLI\Usage(name: ' drush vbo-list', description: 'List all available actions info.')]
  public function vboList(array $options = ['format' => 'table']): RowsOfFields {
    $rows = [];
    $actions = $this->actionManager->getDefinitions(['nocache' => TRUE]);
    foreach ($actions as $id => $definition) {
      $rows[] = [
        'id' => $id,
        'label' => $definition['label'],
        'entity_type_id' => $definition['type'] ?? \dt('(any)'),
      ];
    }

    return new RowsOfFields($rows);
  }

  /**
   * Helper function to set / get timer.
   *
   * @param bool $debug
   *   Should the function do anything at all?
   * @param string $id
   *   ID of a specific timer span.
   *
   * @return float|null
   *   NULL or value of a specific timer if set.
   */
  private function timer($debug = TRUE, $id = NULL): ?float {
    if (!$debug) {
      return NULL;
    }

    static $timers = [];

    if ($id === NULL) {
      $timers['start'] = \microtime(TRUE);
    }
    else {
      if (\array_key_exists($id, $timers)) {
        \end($timers);
        do {
          if (\key($timers) === $id) {
            return \round((\current($timers) - \prev($timers)) * 1000, 3);
          }
          else {
            $result = \prev($timers);
          }
        } while ($result);
      }
      else {
        $timers[$id] = \microtime(TRUE);
      }
    }

    return NULL;
  }

  /**
   * Translates a string using the dt function.
   *
   * @param string $message
   *   The message to translate.
   * @param array $arguments
   *   (optional) The translation arguments.
   *
   * @return string
   *   The translated message.
   */
  private function t($message, array $arguments = []): string {
    return \dt($message, $arguments);
  }

  /**
   * Message method.
   *
   * Overrides the one from the trait and uses Drush logger.
   */
  public static function message(string|\Stringable $message, string $type = 'status', bool $repeat = TRUE): void {
    // Status type no longer exists, mapping required.
    if ($type === 'status') {
      $type = LogLevel::INFO;
    }
    Drush::logger()->log($type, $message, []);
  }

}
