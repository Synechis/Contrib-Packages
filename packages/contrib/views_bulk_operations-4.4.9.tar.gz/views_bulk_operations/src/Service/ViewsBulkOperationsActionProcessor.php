<?php

declare(strict_types=1);

namespace Drupal\views_bulk_operations\Service;

use Drupal\Core\Access\AccessResultReasonInterface;
use Drupal\Core\Action\ActionInterface;
use Drupal\Core\Database\Query\SelectInterface;
use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Extension\ModuleHandlerInterface;
use Drupal\Core\Session\AccountProxyInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\views\Plugin\ViewsPluginManager;
use Drupal\views\ViewExecutable;
use Drupal\views\Views;
use Drupal\views_bulk_operations\Action\ViewsBulkOperationsActionInterface;
use Drupal\views_bulk_operations\ViewsBulkOperationsBatch;
use Symfony\Component\DependencyInjection\Attribute\Autowire;
use Symfony\Component\DependencyInjection\Attribute\AutowireCallable;
use Symfony\Component\HttpFoundation\RedirectResponse;

/**
 * Defines VBO action processor.
 */
class ViewsBulkOperationsActionProcessor implements ViewsBulkOperationsActionProcessorInterface {

  use StringTranslationTrait;

  /**
   * Maximum number of labels fetched for informational purposes.
   */
  public const MAX_LIST_COUNT = 50;

  /**
   * Is the object initialized?
   */
  protected bool $initialized = FALSE;

  /**
   * The processed action object.
   */
  protected ?ActionInterface $action = NULL;

  /**
   * The current view object.
   */
  protected ViewExecutable $view;

  /**
   * View data from the bulk form.
   */
  protected array $bulkFormData;

  /**
   * Array of entities that will be processed in the current batch.
   *
   * @var \Drupal\Core\Entity\EntityInterface[]
   */
  protected array $queue = [];

  /**
   * Constructor.
   */
  public function __construct(
    protected readonly ViewsBulkOperationsViewDataInterface $viewDataService,
    protected readonly ViewsBulkOperationsActionManager $actionManager,
    #[Autowire(service: AccountProxyInterface::class, lazy: true)]
    protected readonly AccountProxyInterface $currentUser,
    #[AutowireCallable(service: ModuleHandlerInterface::class, method: 'invokeAll')]
    private readonly \Closure $invokeAll,
    #[AutowireCallable(service: EntityTypeManagerInterface::class, method: 'getDefinition', lazy: TRUE)]
    private readonly \Closure $getEntityTypeDefinition,
    #[Autowire(service: 'plugin.manager.views.style')]
    protected readonly ViewsPluginManager $stylePluginManager,
  ) {}

  /**
   * {@inheritdoc}
   */
  public function initialize(array $view_data, $view = NULL): void {
    // It may happen that the service was already initialized
    // in this request (e.g. multiple Batch API operation calls).
    // Clear the processing queue in such a case.
    if ($this->initialized) {
      $this->queue = [];
    }

    if (
      !\array_key_exists('exclude_list', $view_data) ||
      \count($view_data['exclude_list']) === 0
    ) {
      // Nothing to exclude.
      $view_data['exclude_mode'] = FALSE;
    }

    if (\array_key_exists('action_id', $view_data)) {
      if (!\array_key_exists('configuration', $view_data)) {
        $view_data['configuration'] = [];
      }
      if (\array_key_exists('preconfiguration', $view_data)) {
        $view_data['configuration'] += $view_data['preconfiguration'];
      }

      // Initialize action object.
      $this->action = $this->actionManager->createInstance($view_data['action_id'], $view_data['configuration']);

      // Set action context.
      $this->setActionContext($view_data);
    }

    // Set entire view data as object parameter for future reference.
    $this->bulkFormData = $view_data;

    // Set the current view.
    $this->setView($view);

    $this->initialized = TRUE;
  }

  /**
   * Set the current view object.
   *
   * @param mixed $view
   *   The current view object or NULL.
   */
  private function setView($view = NULL): void {
    if (!\is_null($view)) {
      $this->view = $view;
    }
    else {
      $this->view = Views::getView($this->bulkFormData['view_id']);
      $this->view->setDisplay($this->bulkFormData['display_id']);
    }
    $this->view->get_total_rows = TRUE;
    // @phpstan-ignore property.notFound
    $this->view->views_bulk_operations_processor_built = TRUE;
    if (
      \array_key_exists('arguments', $this->bulkFormData) &&
      \count($this->bulkFormData['arguments']) !== 0
    ) {
      $this->view->setArguments($this->bulkFormData['arguments']);
    }
  }

  /**
   * {@inheritdoc}
   */
  public function getLabels(array $view_data): array {
    $this->initialize($view_data);

    // We don't want to load too many entities here due to performance reasons.
    if (\count($view_data['list']) > self::MAX_LIST_COUNT) {
      $view_data['list'] = \array_slice($view_data['list'], 0, self::MAX_LIST_COUNT);
    }

    $this->populateQueue($view_data);

    $labels = [];
    foreach ($this->queue as $entity) {
      $labels[] = $entity->label();
    }
    return $labels;
  }

  /**
   * {@inheritdoc}
   */
  public function getPageList($page): array {
    $list = [];

    $this->viewDataService->init($this->view, $this->view->getDisplay(), $this->bulkFormData['relationship_id']);

    // Set exposed filters and pager parameters.
    if (
      (\array_key_exists('clear_on_exposed', $this->bulkFormData) && $this->bulkFormData['clear_on_exposed'] !== FALSE) &&
      (\array_key_exists('exposed_input', $this->bulkFormData) && \count($this->bulkFormData['exposed_input']) !== 0)
    ) {
      $this->view->setExposedInput($this->bulkFormData['exposed_input']);
    }
    else {
      $this->view->setExposedInput(['_views_bulk_operations_override']);
    }

    $base_field = $this->view->storage->get('base_field');
    $base_table = $this->view->storage->get('base_table');

    // In some cases we may encounter nondeterministic behavior in
    // db queries with sorts allowing different order of results.
    // To fix this we're removing all sorts and setting one sorting
    // rule by the view base id field.
    $sort_base = [
      'table' => $base_table,
      'order' => 'ASC',
      'relationship' => 'none',
      'group_type' => 'group',
      'exposed' => FALSE,
      'plugin_id' => 'standard',
    ];
    foreach (\array_keys($this->view->getHandlers('sort')) as $id) {
      $this->view->setHandler($this->bulkFormData['display_id'], 'sort', $id, NULL);
    }
    $this->view->setHandler($this->bulkFormData['display_id'], 'sort', $base_field, [
      'id' => $base_field,
      'field' => $base_field,
    ] + $sort_base);

    // If the entity type supports translations, we need an additional sort
    // by langcode.
    $entity_type_ids = $this->viewDataService->getEntityTypeIds();
    $entity_type_id = \count($entity_type_ids) === 1 ? \reset($entity_type_ids) : NULL;
    if ($entity_type_id !== NULL) {
      $entity_type_definition = ($this->getEntityTypeDefinition)($entity_type_id);

      if ($entity_type_definition->isTranslatable() && $entity_type_definition->hasKey('langcode')) {
        $langcode_field = $entity_type_definition->getKey('langcode');

        // Add this as another sort handler. You can give it a unique ID.
        $this->view->setHandler($this->bulkFormData['display_id'], 'sort', $langcode_field, [
          'id' => $langcode_field,
          'field' => $langcode_field,
        ] + $sort_base);
      }
    }

    $this->view->setItemsPerPage($this->bulkFormData['batch_size']);
    $this->view->setCurrentPage($page);
    $this->view->style_plugin = $this->stylePluginManager->createInstance('default');
    $this->view->style_plugin->init($this->view, $this->view->getDisplay());
    $this->view->build();

    $offset = $this->bulkFormData['batch_size'] * $page;
    // If the view doesn't start from the first result,
    // move the offset.
    // @phpstan-ignore nullsafe.neverNull
    if ($pager_offset = $this->view->pager?->getOffset()) {
      $offset += $pager_offset;
    }
    $this->view->query->setLimit($this->bulkFormData['batch_size']);
    $this->view->query->setOffset($offset);
    ($this->invokeAll)('views_pre_execute', [$this->view]);
    $this->view->query->execute($this->view);

    foreach ($this->view->result as $row) {
      $entity = $this->viewDataService->getEntity($row);

      $exclude = FALSE;
      if ($this->bulkFormData['exclude_mode']) {
        // Filter out excluded results basing on base field ID and language.
        foreach ($this->bulkFormData['exclude_list'] as $item) {
          if ($row->{$base_field} === $item[0] && $entity->language()->getId() === $item[1]) {
            $exclude = TRUE;
            break;
          }
        }
      }

      if (!$exclude) {
        $list[] = [
          $row->{$base_field},
          $entity->language()->getId(),
          $entity->getEntityTypeId(),
          $entity->id(),
        ];
      }
    }

    return $list;
  }

  /**
   * {@inheritdoc}
   */
  public function populateQueue(array $data, array &$context = []): int {
    $list = $data['list'];
    $base_field = $this->view->storage->get('base_field');
    $this->queue = [];

    // Determine batch size and offset.
    if (\array_key_exists('sandbox', $context)) {
      $batch_size = $data['batch_size'];
      if (!\array_key_exists('current_batch', $context['sandbox'])) {
        $context['sandbox']['current_batch'] = 0;
      }
      $current_batch = &$context['sandbox']['current_batch'];
      $offset = $current_batch * $batch_size;
    }
    else {
      $batch_size = 0;
      $current_batch = 0;
      $offset = 0;
    }

    if ($batch_size) {
      $batch_list = \array_slice($list, $offset, $batch_size);
    }
    else {
      $batch_list = $list;
    }

    // Note: this needs to be set to 0 because otherwise we may lose
    // entity translations from the results.
    $this->view->setItemsPerPage(0);
    $this->view->setCurrentPage(0);
    $this->view->setOffset(0);
    $this->view->initHandlers();
    $this->view->setExposedInput(['_views_bulk_operations_override']);

    // Remove all exposed filters so we don't have any default filter
    // values that could make the actual selection out of range.
    if (\count($this->view->filter) !== 0) {
      foreach ($this->view->filter as $id => $filter) {
        if (
          \array_key_exists('exposed', $filter->options) &&
          $filter->options['exposed'] === TRUE
        ) {
          unset($this->view->filter[$id]);
        }
      }
    }

    // Build the view query.
    $this->view->build();

    // Modify the view query: determine and apply the base field condition.
    $base_field_values = [];
    foreach ($batch_list as $item) {
      $base_field_values[$item[0]] = $item[0];
    }
    if (\count($base_field_values) === 0) {
      return 0;
    }

    if (
      \property_exists($this->view->query, 'fields') &&
      \array_key_exists($base_field, $this->view->query->fields)
    ) {
      if (
        \array_key_exists('table', $this->view->query->fields[$base_field])
        && $this->view->query->fields[$base_field]['table'] !== ''
      ) {
        $base_field_alias = $this->view->query->fields[$base_field]['table'] . '.' . $this->view->query->fields[$base_field]['alias'];
      }
      else {
        $base_field_alias = $this->view->query->fields[$base_field]['alias'];
      }
    }
    else {
      $base_field_alias = $base_field;
    }

    // Narrow the query to the selected base field values: add directly to a
    // built SQL query (its root is always AND), otherwise via the query
    // plugin's addWhere() before the rebuild (e.g. for Search API).
    $built_query = $this->view->build_info['query'];
    if (!($built_query instanceof SelectInterface)) {
      if (!\method_exists($this->view->query, 'addWhere')) {
        throw new \Exception(\sprintf('Unsupported query type: %s', $this->view->query::class));
      }
      $this->view->query->addWhere('views_bulk_operations', $base_field_alias, $base_field_values, 'IN');
    }

    // Rebuild the view query.
    $this->view->query->build($this->view);

    // We just destroyed any metadata that other modules may have added to the
    // query. Give those modules the opportunity to alter the query again.
    $this->view->query->alter($this->view);

    $built_query = $this->view->build_info['query'];
    if ($built_query instanceof SelectInterface) {
      $built_query->condition($base_field_alias, $base_field_values, 'IN');
    }

    // The count query is built separately from the row query, so it needs
    // the same restriction, otherwise get_total_rows reflects the whole
    // (unfiltered) view instead of the current selection.
    $count_query = $this->view->build_info['count_query'] ?? NULL;
    if ($count_query instanceof SelectInterface) {
      $count_query->condition($base_field_alias, $base_field_values, 'IN');
    }

    // Use a different pager ID so we don't break the real pager.
    // @todo Check if we can use something else to set this value.
    $pager = $this->view->getPager();
    if (\array_key_exists('id', $pager->options)) {
      $pager->options['id'] += 1000 + $this->view->getItemsPerPage();
    }

    // Execute the view.
    ($this->invokeAll)('views_pre_execute', [$this->view]);
    $this->view->query->execute($this->view);

    // Get all the entities in the batch_list from the view.
    // Check language as well as the query will fetch results basing on
    // base ID field for all languages.
    $this->viewDataService->init($this->view, $this->view->getDisplay(), $this->bulkFormData['relationship_id']);
    $result_hits = [];
    foreach ($batch_list as $list_item) {
      foreach ($this->view->result as $row_index => $row) {
        if (\array_key_exists($row_index, $result_hits)) {
          continue;
        }
        $entity = $this->viewDataService->getEntity($row);
        if ($row->{$base_field} === $list_item[0] && $entity->language()->getId() === $list_item[1]) {
          $result_hits[$row_index] = TRUE;
          $this->queue[] = $entity;
          break;
        }
      }
    }

    // Extra processing when executed in a Batch API operation.
    if (\array_key_exists('sandbox', $context)) {
      if (!\array_key_exists('total', $context['sandbox'])) {
        if (\count($list) === 0) {
          $context['sandbox']['total'] = $this->viewDataService->getTotalResults($data['clear_on_exposed']);
        }
        else {
          $context['sandbox']['total'] = \count($list);
        }
      }
      // Add batch size to context array for potential use in actions.
      $context['sandbox']['batch_size'] = $batch_size;
      $this->setActionContext($context);
    }

    if ($batch_size) {
      $current_batch++;
    }

    $this->setActionView();

    return \count($this->queue);
  }

  /**
   * Set action context if action method exists.
   *
   * @param array $context
   *   The context to be set.
   */
  private function setActionContext(array &$context): void {
    if ($this->action !== NULL && \method_exists($this->action, 'setContext')) {
      $this->action->setContext($context);
    }
  }

  /**
   * Sets the current view object as the executed action parameter.
   */
  private function setActionView(): void {
    if ($this->action !== NULL && \method_exists($this->action, 'setView')) {
      $this->action->setView($this->view);
    }
  }

  /**
   * {@inheritdoc}
   */
  public function process(): array {
    $output = [];

    // Check if all queue items are actually Drupal entities.
    foreach ($this->queue as $delta => $entity) {
      if (!($entity instanceof EntityInterface)) {
        $output[] = $this->t('Skipped');
        unset($this->queue[$delta]);
      }
    }

    // Check entity type for multi-type views like search_api index.
    $action_definition = $this->actionManager->getDefinition($this->bulkFormData['action_id']);
    if (\array_key_exists('type', $action_definition) && $action_definition['type'] !== '') {
      foreach ($this->queue as $delta => $entity) {
        if ($entity->getEntityTypeId() !== $action_definition['type']) {
          $output[] = $this->t('Entity type not supported');
          unset($this->queue[$delta]);
        }
      }
    }

    // Check access.
    foreach ($this->queue as $delta => $entity) {
      $accessResult = $this->action->access($entity, $this->currentUser, TRUE);
      if ($accessResult->isAllowed() === FALSE) {
        $result = [
          'message' => (string) $this->t('Access denied'),
          'type' => 'warning',
        ];

        // If we're given a reason why access was denied, display it.
        if ($accessResult instanceof AccessResultReasonInterface) {
          $reason = $accessResult->getReason();
          if ($reason !== '') {
            $result = [
              'message' => (string) $this->t('Access denied: @reason', [
                '@reason' => $reason,
              ]),
              'type' => 'warning',
            ];
          }
        }

        $output[] = $result;
        unset($this->queue[$delta]);
      }
    }

    // Process queue.
    $results = $this->action->executeMultiple($this->queue) ?? [];

    // Set completion messages.
    $message_override = $this->bulkFormData['preconfiguration']['message_override'] ?? '';

    if ($this->action instanceof ViewsBulkOperationsActionInterface) {
      foreach ($results as &$result) {
        if ($message_override !== '') {
          $result = [
            'message' => $message_override,
          ];
          continue;
        }

        if (!\is_array($result)) {
          $result = [
            'message' => (string) $result,
          ];
        }
        if (!\array_key_exists('message', $result)) {
          throw new \Exception(\sprintf('Result message not provided by the %s action.', $this->action->getPluginId()));
        }
        $result['message'] = (string) $result['message'];
      }
    }

    // Populate output if empty (for core actions).
    if (\count($results) === 0) {
      $count = \count($this->queue);
      for ($i = 0; $i < $count; $i++) {
        $output[] = [
          'message' => $message_override === '' ? $this->bulkFormData['action_label'] : $message_override,
        ];
      }
      return $output;
    }
    return \array_merge($output, $results);
  }

  /**
   * {@inheritdoc}
   */
  public function processResults(array $results, array $previous = []): array {
    $output = $previous;
    if (!\array_key_exists('operations', $output)) {
      $output['operations'] = [];
    }

    foreach ($results as $result) {
      if (!\array_key_exists('type', $result)) {
        $result['type'] = 'status';
      }
      $found_delta = NULL;
      foreach ($output['operations'] as $delta => $item) {
        if ($item['message'] === $result['message'] && $item['type'] === $result['type']) {
          $found_delta = $delta;
          break;
        }
      }
      if ($found_delta !== NULL) {
        $output['operations'][$found_delta]['count']++;
      }
      else {
        $result['count'] = 1;
        $output['operations'][] = $result;
      }
    }

    return $output;
  }

  /**
   * {@inheritdoc}
   */
  public function executeProcessing(array &$data, $view = NULL): RedirectResponse {
    if (
      (!\array_key_exists('prepopulated', $data) || $data['prepopulated'] === FALSE) &&
      $data['exclude_mode'] &&
      !\array_key_exists('exclude_list', $data)
    ) {
      $data['exclude_list'] = $data['list'];
      $data['list'] = [];
    }

    // Get action finished callable.
    $definition = $this->actionManager->getDefinition($data['action_id']);
    if (\in_array(ViewsBulkOperationsActionInterface::class, \class_implements($definition['class']), TRUE)) {
      $data['finished_callback'] = [$definition['class']];
    }
    else {
      $data['finished_callback'] = [ViewsBulkOperationsBatch::class];
    }
    $data['finished_callback'][] = 'finished';

    if ($data['batch']) {
      $batch = ViewsBulkOperationsBatch::getBatch($data);
      \batch_set($batch);
      $redirect_response = \batch_process($data['redirect_url']);
    }
    else {
      $this->initialize($data, $view);

      // Ensure compatibility with a Batch API process.
      $context = [
        'sandbox' => [
          'processed' => 0,
          'total' => 0,
          'page' => 0,
          'current_batch' => 1,
        ],
        'results' => [
          'operations' => [],
        ],
      ];
      $this->setActionContext($context);

      // Populate and process queue.
      if (!\array_key_exists('list', $data) || \count($data['list']) === 0) {
        $data['list'] = $this->getPageList(0);
      }
      $batch_results = [];
      if ($this->populateQueue($data) !== 0) {
        $batch_results = $this->process();
      }

      $results = $this->processResults($batch_results, $context['results']);
      $redirect_response = $data['finished_callback'](TRUE, $results, []);
      if ($redirect_response === NULL) {
        $redirect_response = new RedirectResponse($data['redirect_url']->setAbsolute()->toString());
      }
    }

    return $redirect_response;
  }

}
