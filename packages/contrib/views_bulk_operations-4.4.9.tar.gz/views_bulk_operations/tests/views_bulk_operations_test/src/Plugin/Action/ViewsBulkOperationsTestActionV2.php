<?php

declare(strict_types=1);

namespace Drupal\views_bulk_operations_test\Plugin\Action;

use Drupal\Core\Action\Attribute\Action;
use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Messenger\MessengerTrait;
use Drupal\Core\Session\AccountInterface;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\views_bulk_operations\Action\ViewsBulkOperationsActionBase;
use Symfony\Component\HttpFoundation\RedirectResponse;

/**
 * Action for test purposes only.
 */
#[Action(
  id: 'views_bulk_operations_test_action_v2',
  label: new TranslatableMarkup('VBO V2 API test action'),
  type: ''
)]
final class ViewsBulkOperationsTestActionV2 extends ViewsBulkOperationsActionBase {
  use MessengerTrait;

  /**
   * {@inheritdoc}
   */
  public function execute(?EntityInterface $entity = NULL): mixed {
    if ($entity->label() === 'Title 1') {
      $output = [
        'message' => $this->t('A warning message.'),
        'type' => 'warning',
      ];
    }
    elseif ($entity->label() === 'Title 2') {
      $output = [
        'message' => $this->t('A warning message with a "quote", an & ampersand, and <tag>.'),
        'type' => 'warning',
      ];
    }
    else {
      $output = $this->t('Standard output.');
    }
    return $output;
  }

  /**
   * {@inheritdoc}
   */
  public function access($object, ?AccountInterface $account = NULL, $return_as_object = FALSE) {
    return $object->access('update', $account, $return_as_object);
  }

  /**
   * {@inheritdoc}
   */
  public static function finished($success, array $results, array $operations): ?RedirectResponse {
    // Let's return a bit different message. We don't except failures
    // in tests as well so no need to check for a success.
    $details = [];
    foreach ($results['operations'] as $operation) {
      $details[] = $operation['message'] . ' (' . $operation['count'] . ')';
    }
    $message = static::translate('Custom processing message: @operations.', [
      '@operations' => \implode(', ', $details),
    ]);
    static::message($message);
    return NULL;
  }

}
