<?php

declare(strict_types=1);

namespace Drupal\Tests\views_bulk_operations\Functional;

use Drupal\Tests\BrowserTestBase;
use Drupal\Tests\views_bulk_operations\WatchdogTestTrait;
use Drupal\views_bulk_operations\Drush\Commands\ViewsBulkOperationsCommands;
use Drush\TestTraits\DrushTestTrait;
use PHPUnit\Framework\Attributes\CoversClass;
use PHPUnit\Framework\Attributes\Group;

/**
 * Test Drush commands.
 */
#[CoversClass(ViewsBulkOperationsCommands::class)]
#[Group('views_bulk_operations')]
final class DrushCommandsTest extends BrowserTestBase {
  use DrushTestTrait;
  use WatchdogTestTrait;

  private const TEST_NODE_COUNT = 15;

  /**
   * {@inheritdoc}
   */
  protected $defaultTheme = 'stable9';

  /**
   * Array of node objects used for testing.
   *
   * @var \Drupal\node\NodeInterface[]
   */
  protected array $testNodes = [];

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'dblog',
    'node',
    'views',
    'views_bulk_operations',
    'views_bulk_operations_test',
  ];

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    // Create some nodes for testing.
    $this->drupalCreateContentType(['type' => 'page']);

    $this->testNodes = [];
    $time = $this->container->get('datetime.time')->getRequestTime();
    for ($i = 0; $i < self::TEST_NODE_COUNT; $i++) {
      // Ensure nodes are sorted in the same order they are inserted in the
      // array.
      $time -= $i;
      $this->testNodes[] = $this->drupalCreateNode([
        'type' => 'page',
        'title' => 'Title ' . $i,
        'sticky' => $i % 2,
        'created' => $time,
        'changed' => $time,
      ]);
    }

  }

  /**
   * Tests the VBO Drush command.
   */
  public function testDrushCommand(): void {
    $arguments = [
      'views_bulk_operations_test',
      'views_bulk_operations_simple_test_action',
    ];

    // Basic test.
    $this->drush('vbo-exec', $arguments);
    for ($i = 0; $i < self::TEST_NODE_COUNT; $i++) {
      self::assertStringContainsString("Test action (label: Title $i)", $this->getErrorOutput());
    }

    // Exposed filters test.
    $this->drush('vbo-exec', $arguments, ['exposed' => 'sticky=1']);
    for ($i = 0; $i < self::TEST_NODE_COUNT; $i++) {
      $test_string = "Test action (label: Title $i)";
      if ($i % 2 !== 0) {
        self::assertStringContainsString($test_string, $this->getErrorOutput());
      }
      else {
        self::assertStringNotContainsString($test_string, $this->getErrorOutput());
      }
    }
  }

}
